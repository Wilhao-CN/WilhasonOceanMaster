"""集中定义版本号与项目元信息。

原先版本号只硬编码在 `ui/main_window.py` 的窗口标题里，其它地方
（「关于系统」页、README、打包脚本）各写各的，容易不一致。
统一到这里，改一处即可。

用法：
    from _version import __version__, APP_NAME
"""
from __future__ import annotations

# 语义化版本：主版本.次版本.修订号
__version__ = "1.0.0"

# 面向用户的显示名（窗口标题、「关于」页、README 都用它）
APP_NAME = "LandStation-Lite"
APP_TITLE = f"{APP_NAME} v{__version__} · 双无人船协同控制上位机"

# 一句话简介
APP_DESCRIPTION = "USV 双船协同控制地面站（无人船 + 浮船坞）"

# 许可说明。
# ✅ 已定：GPL v3（方案 A）。本工程依赖 PyQt5 / PyQtWebEngine，二者采用
#    GPL v3 与商业双授权；选用 GPL 版 PyQt5 ⇒ 整个工程以 GPL v3 发布。
#    完整条款见工程根目录 LICENSE，第三方组件许可见 THIRD_PARTY_NOTICES.md。
#    「关于系统」页读取下面这一行。
LICENSE_NAME = "GPL v3"

# 第三方组件与致谢，见工程根目录 THIRD_PARTY_NOTICES.md
NOTICE_FILE = "THIRD_PARTY_NOTICES.md"
