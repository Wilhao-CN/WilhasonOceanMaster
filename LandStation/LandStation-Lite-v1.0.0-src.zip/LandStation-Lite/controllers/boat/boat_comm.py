# 文件路径: controllers/boat/boat_comm.py
from PyQt5.QtCore import QObject, pyqtSignal, QSize
from core.Thread.comm_thread import SerialThread
from core.Thread.network_thread import NetworkThread
from core.Thread.video_thread import VideoThread
from core.protocol import USVProtocol
from core.Thread.zmq_video_thread import ZmqVideoThread
class BoatCommUnit(QObject):
    """
    ====================================================================
    🚤 子船通信管理单元 (V9.0 仿真模式与逻辑对齐版)
    职责: 100% 还原双路回传监听、视频拉流，负责硬件级对话。
    特性: 逻辑与船坞完全对齐，支持指令在串口与仿真网络间动态重定向。
    ====================================================================
    """
    # --- 向上层(大脑和UI)汇报的原始信号 ---
    sig_frame_received = pyqtSignal(bytes)  # 收到完整传感器帧 (生肉字节流)
    sig_serial_status = pyqtSignal(bool)    # 串口连接状态
    sig_net_status = pyqtSignal(bool)       # 网络连接状态
    sig_log_triggered = pyqtSignal(str)     # 向上汇报日志（包含异常）
    sig_pwm_actual = pyqtSignal(int, int, int, int)  # 实际下发硬件的补偿后 PWM

    def __init__(self, parent=None):
        super().__init__(parent)
        
        # --- 1. 100% 还原三大底层物理线程 ---
        self.serial_thread = SerialThread(parent=self)
        self.network_thread = NetworkThread(parent=self, device_id=0x02)
        self.video_thread = VideoThread(parent=self)
        self.sim_video_thread = ZmqVideoThread(parent=self)
        
        # --- 2. 💡 [逻辑对齐] 硬件状态镜像与仿真标志 ---
        self.is_simulation = False # 默认为真实硬件模式 (走串口发送)
        self.hw_tx_link = "serial"  # 💡 [新增] 存储子船硬件模式下的指令链路状态
        
        self.relay_mirror = [0, 0, 0, 0, 0, 0]
        self.sensor_mirror = {
            "imu_en": 0x01, "imu_ms": 50,
            "gps_en": 0x01, "gps_ms": 100
        }

        self._bind_internal_signals()

    def _bind_internal_signals(self):
        """将底层物理线程的原始信号汇聚，实现双路并发监听回传"""
        # 💡 [核心对齐] 串口和网络线程同时向上汇报数据，谁先到用谁的
        for thread in (self.serial_thread, self.network_thread):
            thread.sig_frame_received.connect(self.sig_frame_received)
            thread.error_occurred.connect(lambda m: self.sig_log_triggered.emit(f"[底层错误] {m}"))
            thread.sig_debug_log.connect(self.sig_log_triggered)
            
        self.serial_thread.connection_status.connect(self.sig_serial_status)
        self.network_thread.connection_status.connect(self.sig_net_status)

        # 视频异常抛出
        self.video_thread.sig_error.connect(
            lambda m: self.sig_log_triggered.emit(f"[视频异常] {m}")
        )
        self.sim_video_thread.sig_error.connect(
            lambda m: self.sig_log_triggered.emit(f"[仿真视频异常] {m}")
        )

    # ==========================================
    # 🔀 核心路由逻辑 (支持仿真重定向)
    # ==========================================
    def set_mode(self, mode_str: str):
        """切换运行模式：serial (真实硬件) / network (仿真模拟)"""
        # 💡 注意：此处不再断开链路，仅修改指令下发的路由指向
        self.is_simulation = (mode_str == "network")
        status_text = "🧪 仿真模拟" if self.is_simulation else "🔌 真实硬件"
        self.sig_log_triggered.emit(f"🔄 [系统] 子船指令发送路径切换至: {status_text} 模式")

    @property
    def active_tx_thread(self):
        """
        核心路由：决定子船的【控制指令】从哪条物理链路出去
        """
        # 1. 仿真模式：锁定本地网络
        if self.is_simulation:
            return self.network_thread
        
        # 2. 真实硬件模式：根据 UI 切换结果路由
        if self.hw_tx_link == "network":
            # 💡 指令将通过 4G UDP 链路发送给子船 (端口 8882)
            return self.network_thread
        else:
            # 💡 默认走 LORA 串口链路
            return self.serial_thread

    # ==========================================
    # 🔗 链路生命周期管理 (与 Dock 保持 100% 对齐)
    # ==========================================
    def open_serial(self, port: str, baud: int):
        """打开串口监听"""
        return self.serial_thread.open_port(port, baud)

    def close_serial(self):
        """关闭串口监听"""
        self.serial_thread.close_port()

    def open_network_and_video(self, ip: str, tx_port: int, rx_port: int, v_port: int, target_video_size: QSize):
        if self.network_thread.connect_network(ip, tx_port, rx_port):
            self.sig_log_triggered.emit(f"🌐 [子船数据] UDP 监听开启: {ip}:{rx_port}")

            # 💡 视频路由判断
            if self.is_simulation:
                # 仿真模式：强制监听子船后视角的 5003 端口
                self.sim_video_thread.set_connection_params(ip, 5003)
                self.sim_video_thread.start_video()
                self.sig_log_triggered.emit(f"💻 [孪生视频] 子船 TCP 拉流已启动 (Port: 5003)")
            else:
                self.video_thread.set_listen_port(v_port)
                if target_video_size:
                    self.video_thread.set_target_size(target_video_size)
                self.video_thread.start_video()
                self.sig_log_triggered.emit(f"📹 [实体视频] 子船 UDP 监听已启动 (Port: {v_port})")
            return True
        return False

    def close_network_and_video(self):
        self.network_thread.close_port()
        self.video_thread.stop_video()
        self.sim_video_thread.stop_video()
        self.sig_log_triggered.emit("🔌 [网络] 子船实体与孪生视频链路已断开")

    @property
    def active_video_thread(self):
        """返回当前模式真正使用的视频线程。"""
        return self.sim_video_thread if self.is_simulation else self.video_thread

    def close_all_links(self):
        """一键切断所有物理链路 (供 MainWindow 退出时调用)"""
        self.close_serial()
        self.close_network_and_video()

    # ==========================================
    # 🚀 核心指令下发 (ID: 02, 动态路由至 active_tx_thread)
    # ==========================================
    def send_control_ratios(self, r1: float, r2: float, r3: float, r4: float,flush: bool = False):
        """子船 4通道比例下发 (根据模式自动选择串口或网络)"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running: return

        # 计算补偿后的实际 PWM (供 UI 显示)
        ap1 = USVProtocol._apply_compensation(0x02, 1, r1)
        ap2 = USVProtocol._apply_compensation(0x02, 2, r2)
        ap3 = USVProtocol._apply_compensation(0x02, 3, r3)
        ap4 = USVProtocol._apply_compensation(0x02, 4, r4)
        self.sig_pwm_actual.emit(ap1, ap2, ap3, ap4)

        cmd_bytes = USVProtocol.pack_control_cmd(
            target_id=0x02, mode=0x01,
            pwm1=r1, pwm2=r2, pwm3=r3, pwm4=r4,
            relays=self.relay_mirror, **self.sensor_mirror
        )
        target_thread.send_data(cmd_bytes,flush=flush)

    def send_stop_cmd(self):
        """💡 [核心防雷] 下发 1500 (中位) 强制停车"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running: return
        stop_cmd = USVProtocol.pack_control_cmd(
            target_id=0x02, mode=0x01, 
            pwm1=1500, pwm2=1500, pwm3=1500, pwm4=1500, 
            relays=self.relay_mirror, **self.sensor_mirror
        )
        target_thread.send_data(stop_cmd)

    def send_init(self):
        """系统初始化指令"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running: return
        self.relay_mirror = [1, 1, 1, 1, 1, 1]
        self.sensor_mirror = {"imu_en": 0x01, "imu_ms": 50, "gps_en": 0x01, "gps_ms": 100}
        cmd_bytes = USVProtocol.get_init_cmd(target_id=0x02)
        target_thread.send_data(cmd_bytes)
        # 触发 IMU 静态零偏校准
        calib_bytes = USVProtocol.pack_imu_calib_cmd(target_id=0x02)
        target_thread.send_data(calib_bytes)
        self.sig_log_triggered.emit("⚙️ [TX-初始化] 子船动力上锁 + IMU零偏校准 (ID:02)")

    def send_estop(self) -> bool:
        """急停指令：彻底锁死硬件，返回 True 表示已成功送入发送队列"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running:
            self.sig_log_triggered.emit("❌ [急停失败] 子船通信线程未启动，请先连接串口或网络！")
            return False
        # 🔒 [关键] 同步更新镜像状态，防止后续 send_control_ratios 用旧值覆盖急停
        self.relay_mirror = [0, 0, 0, 0, 1, 0]
        self.sensor_mirror = {"imu_en": 0x00, "imu_ms": 0, "gps_en": 0x00, "gps_ms": 0}
        stop_cmd = USVProtocol.get_estop_cmd(target_id=0x02)
        target_thread.send_data(stop_cmd)
        self.sig_log_triggered.emit(f"🛑 [TX-急停] 子船急停指令已下发 (ID:02) {USVProtocol.bytes_to_hex_str(stop_cmd)}")
        return True

    def send_return(self):
        """子船专用一键返航指令"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running: return
        cmd_bytes = USVProtocol.get_boat_return_cmd()
        target_thread.send_data(cmd_bytes)
        self.sig_log_triggered.emit(f"[TX-一键返航] {USVProtocol.bytes_to_hex_str(cmd_bytes)}")

    def send_gps_calib(self, target_id: int, lat_off: float, lon_off: float):
        """GPS校准偏移下发单片机"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running:
            return
        cmd_bytes = USVProtocol.pack_gps_calib_cmd(target_id, lat_off, lon_off)
        target_thread.send_data(cmd_bytes)
        self.sig_log_triggered.emit(
            f"📡 [GPS校准] 已下发至 ID:{target_id} ΔLat:{lat_off:.7f} ΔLon:{lon_off:.7f}"
        )

    def send_ekf_cmd(self, target_id: int, enable: bool):
        """EKF启停控制下发"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running:
            return
        cmd_bytes = USVProtocol.pack_ekf_cmd(target_id, enable)
        target_thread.send_data(cmd_bytes)
        tag = "启动" if enable else "关闭"
        self.sig_log_triggered.emit(f"🧠 [EKF控制] ID:{target_id} EKF已{tag}")

    def send_imu_deadband(self, target_id: int, deadband: float):
        """IMU角速度积分死区配置下发"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running:
            return
        cmd_bytes = USVProtocol.pack_imu_deadband_cmd(target_id, deadband)
        target_thread.send_data(cmd_bytes)
        hex_str = USVProtocol.bytes_to_hex_str(cmd_bytes)
        self.sig_log_triggered.emit(
            f"📐 [IMU死区] ID:{target_id} 死区={deadband:.2f}°/s | "
            f"下发 {len(cmd_bytes)} 字节: {hex_str}"
        )

    def send_raw_hex(self, hex_text: str):
        """处理手动 HEX 指令输入"""
        try:
            target_thread = self.active_tx_thread
            data = bytes.fromhex(hex_text.replace(' ', ''))
            target_thread.send_data(data)
            mode_tag = "仿真" if self.is_simulation else "串口"
            self.sig_log_triggered.emit(f"[TX-{mode_tag}HEX] {hex_text.upper()}")
            return True
        except ValueError:
            self.sig_log_triggered.emit("[警告] HEX 格式无效")
            return False

    def update_sensor_config(self, imu_en=None, imu_ms=None, gps_en=None, gps_ms=None):
        """传感器配置管理 (与 Dock 保持对称)"""
        if imu_en is not None: self.sensor_mirror["imu_en"] = imu_en
        if imu_ms is not None: self.sensor_mirror["imu_ms"] = imu_ms
        if gps_en is not None: self.sensor_mirror["gps_en"] = gps_en
        if gps_ms is not None: self.sensor_mirror["gps_ms"] = gps_ms
        self.sig_log_triggered.emit(f"📝 [同步] 子船传感器配置已暂存")
    def set_hw_tx_link(self, mode_str: str):
        """
        💡 [新增] 接收来自 UI 的切换信号
        mode_str: 'serial' (LORA) 或 'network' (4G)
        """
        self.hw_tx_link = mode_str
        tag = "🌐 4G网络" if mode_str == "network" else "📡 LORA串口"
        self.sig_log_triggered.emit(f"🔄 [链路切换] 子船指令下发路径已切换至: {tag}")
