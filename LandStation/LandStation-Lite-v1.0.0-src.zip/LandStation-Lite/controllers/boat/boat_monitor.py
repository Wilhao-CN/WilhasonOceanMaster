# 文件路径: controllers/boat/boat_monitor.py
from PyQt5.QtCore import QObject, Qt
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QPushButton, QLabel, QScrollArea, QWidget

# ==========================================
# 🧬 [独立外壳] 算法调参弹窗类 (通用)
# ==========================================
class TuningShellWindow(QDialog):
    """
    职责：作为一个独立的“容器”，承载并显示算法类吐出的 QWidget 调参界面。
    """
    def __init__(self, title="算法调参", parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(380, 450)
        # 💡 设置置顶属性，方便调参时观察地图或视频
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        
        self.main_layout = QVBoxLayout(self)
        
        # 增加滚动支持
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.NoFrame)
        self.container = QWidget()
        self.content_layout = QVBoxLayout(self.container)
        self.scroll.setWidget(self.container)
        
        self.main_layout.addWidget(self.scroll)
        
        self.btn_close = QPushButton("确 定")
        self.btn_close.setFixedHeight(40)
        self.btn_close.clicked.connect(self.accept)
        self.main_layout.addWidget(self.btn_close)

    def set_content(self, h_ui, s_ui):
        """
        🚀 [稳健修复] 注入算法 UI 组件并清理旧组件
        """
        # 💡 关键修复：先获取引用，防止清除父对象后引用变 None
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
            
        has_any = False
        if h_ui:
            self.content_layout.addWidget(QLabel("<b>艏向控制参数 (Heading):</b>"))
            self.content_layout.addWidget(h_ui)
            has_any = True
            
        if s_ui:
            self.content_layout.addWidget(QLabel("<b>速度控制参数 (Speed):</b>"))
            self.content_layout.addWidget(s_ui)
            has_any = True
            
        if not has_any:
            self.content_layout.addWidget(QLabel("该算法当前未提供可调节的参数。"))
            
        self.content_layout.addStretch()

# ==========================================
# 🖥️ [业务监视器] 子船状态监控与弹窗管理
# ==========================================
class BoatMonitor(QObject):
    def __init__(self, boat_panel, parent=None):
        super().__init__(parent)
        self.panel = boat_panel # 引用自 side_panels.py
        self.tuning_window = None
        self.curr_heading_algo = None
        self.curr_speed_algo = None

    # 1. 基础数据与 UI 同步 (与 BoatController 信号兼容)
    def refresh_ui_and_map(self, data: dict):
        """刷新侧边栏仪表盘"""
        self.panel.update_sensor_data(data)
        
    def sync_widget_states(self, status: dict):
        """同步 UI 按钮勾选状态"""
        if "auto_heading" in status:
            button = self.panel.btn_auto_heading
            previous = button.blockSignals(True)
            button.setChecked(status["auto_heading"])
            button.blockSignals(previous)
        if "auto_speed" in status:
            button = self.panel.btn_auto_speed
            previous = button.blockSignals(True)
            button.setChecked(status["auto_speed"])
            button.blockSignals(previous)

    # 2. 核心弹窗逻辑 (安全第一：切换即关闭)
    def setup_algo_tuning_ui(self, heading_algo, speed_algo):
        """
        🚀 [安全机制] 当大脑切换算法时由信号触发
        落实方案 2：如果调参窗口开着，强制关闭。
        """
        self.curr_heading_algo = heading_algo
        self.curr_speed_algo = speed_algo
        
        if self.tuning_window and self.tuning_window.isVisible():
            self.tuning_window.close()
            self.tuning_window = None
            self.append_log("⚠️ [安全] 监测到子船算法变更，调参窗口已强制关闭。")

    def open_tuning_window(self):
        """响应 UI 上的 🛠️ 按钮点击请求"""
        if not self.curr_heading_algo and not self.curr_speed_algo:
            self.append_log("❌ [提示] 子船当前未加载有效算法。")
            return

        if not self.tuning_window:
            self.tuning_window = TuningShellWindow(title="2号子船 - 算法实时微调", parent=self.panel)
        
        # 索要算法类自带的 UI
        h_ui = self.curr_heading_algo.get_tuning_widget(self.tuning_window) if self.curr_heading_algo else None
        s_ui = self.curr_speed_algo.get_tuning_widget(self.tuning_window) if self.curr_speed_algo else None
        
        self.tuning_window.set_content(h_ui, s_ui)
        self.tuning_window.show()
        self.tuning_window.raise_()

    # 3. 辅助分发方法 (兼容性维护)
    def distribute_video_frame(self, qimg):
        """分发视频帧给侧边栏 Label"""
        self.panel.update_video_frame(qimg)

    def append_log(self, text: str):
        """输出日志到子船通信面板"""
        self.panel.comm_panel.append_log(text)

    def clear_hex_input(self):
        """清理指令输入框"""
        if hasattr(self.panel.comm_panel, 'txt_hex_input'):
            self.panel.comm_panel.txt_hex_input.clear()

    def update_serial_light(self, connected: bool):
        """串口连接状态指示灯"""
        self.panel.comm_panel.set_serial_light(connected)

    def update_net_light(self, connected: bool):
        """网络连接状态指示灯"""
        self.panel.comm_panel.set_net_light(connected)

    def update_latency(self, metrics: dict):
        self.panel.comm_panel.set_latency_metrics(metrics)

    def update_fault_status(self, status: dict):
        """显示 MCU、树莓派和 4G 的综合状态。"""
        self.panel.update_fault_status(status)
