# 文件路径: controllers/boat/boat_brain.py
import time
from PyQt5.QtCore import QObject, pyqtSignal
from core.PID_controller.pid_controller import HeadingPIDController, StandardPIDController
from core.Managers.navigator_manager import MissionNavigator
from core.heading_source import (
    HEADING_SOURCE_DUAL_GPS,
    HEADING_SOURCE_EKF,
    select_control_heading,
)
from core.utils import CoordUtils
from core.pose_return import PoseReturnGuidance
from core.vision.visual_pid_setpoint import VisualPIDSetpointGenerator
from core.protocol import USVProtocol  # 💡 [关键引入] 用于解析生肉数据
from PyQt5.QtCore import QTimer
import math

class BoatBrain(QObject):
    """
    ====================================================================
    🧠 子船逻辑决策大脑 (V8.0 纯净解耦版)
    职责: 100% 还原状态机、自动任务领航、PID 闭环与手柄抢占逻辑。
    特性: 4 通道解耦动力学混控器 (与船坞同构)，输出 4 路比例。
    ====================================================================
    """
    # --- 核心输出信号 ---
    # 1. 动力输出：算好的 4 路比例，交给通信层去打包 (子船主要用前两路)
    sig_control_ratios_ready = pyqtSignal(float, float, float, float, bool)

    # 2. 💡 [数据输出] 将解析好的“熟肉”抛出，供 Monitor 和地图刷新
    sig_data_parsed = pyqtSignal(dict) 
    
    # 3. 状态与日志输出
    sig_status_changed = pyqtSignal(dict)  # 通知 UI 同步按钮状态 
    sig_mission_log = pyqtSignal(str)      # 纯日志输出
    sig_manual_override = pyqtSignal()     # 物理手柄抢占警报，一路传到 MainWindow
    sig_algo_tuning_ui_ready = pyqtSignal(object, object)
    
    # 💡 [新增] 目标值反向同步信号 (速度, 航向)，用于通知 UI 界面更新
    sig_target_sync = pyqtSignal(float, float)
    sig_return_home = pyqtSignal(float, float)  # 🏠 一键返航：通知地图打标记

    def __init__(self, mission_manager, parent=None):
        """
        💡 修改：注入 mission_manager 引用
        """
        super().__init__(parent)
        self.mission_manager = mission_manager # 存储任务管理器引用
        self.visual_setpoint_generator = VisualPIDSetpointGenerator(
            # 🚀 前进速度带：下限仅在最外层限幅逻辑判定"可推进"时生效
            min_speed_m_s=0.15,
            max_speed_m_s=0.25,
            speed_floor_angle_deg=2.5,
            speed_floor_release_cm=45.0,
        )
        self.vision_docking_active = False
        self._vision_control_state = "LOST"
        self._vision_phase = "SEARCH_GATE"
        self._last_visual_setpoint = None
        self._vision_smoothed_surge = 0.0
        self._vision_smoothed_yaw = 0.0
        self.current_heading = 0.0
        self.heading_source = HEADING_SOURCE_EKF
        
        self.auto_heading_active = False
        self.target_heading = 0.0
        self.auto_speed_active = False
        self.target_speed = 0.0
        
        self.last_pid_time = 0.0
        self.is_mission_active = False
        self.current_wp_index = -1     
        
        self.last_gps_pos = None
        self.last_gps_time = None
        self.smooth_speed = 0.0

        # --- 一键返航常量 ---
        self.HOME_LAT = 23.013944  # 23°00'50.2"N 子船返航点
        self.HOME_LON = 113.397861 # 113°23'52.3"E

        # --- 到点稳停 (Steady Hold) 状态变量 ---
        self.steady_hold_active = False
        self.steady_hold_target = (0.0, 0.0)
        self.pose_return = PoseReturnGuidance()

        self.navigator = MissionNavigator(arrival_threshold=2.0, default_speed=0.3)

        # 🛡️ 速度指令保护参数
        self.max_physical_speed = 2.0     # 船体物理极速 (m/s)
        self.speed_rate_limit = 0.5       # 最大加速度 (m/s²)
        self._smooth_target_speed = 0.0   # 变化率限幅后的平滑速度
        self._last_speed_update_time = time.time()

        self.heading_algos = {
            "PID 经典控制": HeadingPIDController(kp=3.0, ki=0.1, kd=1.5, deadband=5.0),
        }
        self.speed_algos = {
            "PID 经典控制": StandardPIDController(kp=150.0, ki=10.0, kd=0.0),
        }
        self.active_heading_algo = self.heading_algos["PID 经典控制"]
        self.active_speed_algo = self.speed_algos["PID 经典控制"]

        QTimer.singleShot(500, lambda: self.sig_algo_tuning_ui_ready.emit(self.active_heading_algo, self.active_speed_algo))
        self.cached_auto_ratios = [0.0, 0.0, 0.0, 0.0, False]

    def set_nav_cruise_speed(self, speed: float):
        """运行时更新 P2P/LOS 领航器的默认巡航速度（下一帧立即生效）。"""
        self.navigator.default_speed = max(0.0, float(speed))
        self.sig_mission_log.emit(
            f"🧭 [领航巡航] 子船巡航速度已设为 {self.navigator.default_speed:.2f} m/s"
        )

    def set_heading_source(self, source: str):
        """切换子船闭环控制使用的当前艏向（与船坞一致）。"""
        if source not in (HEADING_SOURCE_EKF, HEADING_SOURCE_DUAL_GPS):
            return
        self.heading_source = source
        source_name = "双GPS艏向" if source == HEADING_SOURCE_DUAL_GPS else "EKF融合艏向"
        self.sig_mission_log.emit(f"🎛 [艏向源] 子船控制已切换为{source_name}")

    def _get_control_heading(self, imu_data: dict) -> float:
        return select_control_heading(imu_data, self.heading_source)

    def _get_thruster_ratio_limits(self, thruster_indices: list):
        """
        从 USVProtocol.USV_CONFIGS 反算推进器比例的有效限幅范围
        与 UI 推进器配置弹窗联动，动态钳位 PID 输出
        返回: (min_ratio, max_ratio) — 多通道综合最保守限幅
        """
        target_id = 0x02
        default_cfg = {"min": 1300, "max": 1800, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400}
        ship_configs = USVProtocol.USV_CONFIGS.get(target_id, {})
        min_ratios, max_ratios = [], []
        for idx in thruster_indices:
            cfg = ship_configs.get(idx, default_cfg)
            max_r = (cfg["max"] - 1500 - cfg["pos"]) / cfg["slope_pos"] if cfg["slope_pos"] > 0 else 1.0
            min_r = (cfg["min"] - 1500 + cfg["neg"]) / cfg["slope_neg"] if cfg["slope_neg"] > 0 else -1.0
            min_ratios.append(min_r)
            max_ratios.append(max_r)
        return (max(min_ratios), min(max_ratios))

    def _clamp_with_limits(self, ratio: float, thruster_indices: list) -> float:
        """使用推进器限幅对单路比例进行钳位"""
        lo, hi = self._get_thruster_ratio_limits(thruster_indices)
        return max(lo, min(hi, ratio))

    # ==========================================
    # 🎛️ 统一动力学分配器 (Mixer)
    # ==========================================
    def _allocate_thrust(self, surge_ratio: float, yaw_ratio: float, flush: bool = False):
        """
        统一的底层推力混控器 — 4 通道解耦 (与船坞同构)。
        所有上层控制算法(手动、PID、视觉)都必须调用此接口输出动力。

        :param surge_ratio: 期望的纵向推力比例 [-1.0 到 1.0] → 1/4 号主推
        :param yaw_ratio:   期望的偏航旋转力矩 [-1.0 到 1.0] → 2/3 号转向 (正为右转)
        """
        # 1. 🔗 推进器限幅联动：主推/转向分别按各自配置动态钳位
        r_main   = self._clamp_with_limits(surge_ratio, [1, 4])
        r_steer  = self._clamp_with_limits(yaw_ratio,   [2, 3])

        # 2. 缓存记录并向底层通讯线程发射: 主推L, 转向A, 转向B, 主推R
        self.cached_auto_ratios = [r_main, r_steer, -r_steer, r_main, False]
        self.sig_control_ratios_ready.emit(r_main, r_steer, -r_steer, r_main, flush)

    @staticmethod
    def _slew_value(current, target, dt, rise_rate, fall_rate):
        reducing = abs(target) < abs(current) or current * target < 0.0
        rate = fall_rate if reducing else rise_rate
        max_delta = max(0.0, dt) * rate
        return current + max(-max_delta, min(max_delta, target - current))

    def _shape_visual_pid_output(self, surge_ratio, yaw_ratio, dt):
        """最后一道PID输出变化率保护，人工急停不经过这里。"""
        self._vision_smoothed_surge = self._slew_value(
            self._vision_smoothed_surge,
            surge_ratio,
            dt,
            rise_rate=0.25,
            fall_rate=0.50,
        )
        self._vision_smoothed_yaw = self._slew_value(
            self._vision_smoothed_yaw,
            yaw_ratio,
            dt,
            rise_rate=0.60,
            fall_rate=0.80,
        )
        return self._vision_smoothed_surge, self._vision_smoothed_yaw

    def _apply_speed_limits(self, requested_speed: float) -> float:
        """
        🛡️ 速度指令保护：绝对物理上限 + 变化率限幅
        防止外环指令跳变导致内环 PID 积分饱和
        """
        now = time.time()
        dt = now - self._last_speed_update_time
        self._last_speed_update_time = now

        # 第一层：绝对物理上限
        clamped = max(0.0, min(self.max_physical_speed, requested_speed))

        # 第二层：变化率限幅 (防止指令跳变)
        if dt > 0 and dt < 1.0:
            max_delta = self.speed_rate_limit * dt
            delta = clamped - self._smooth_target_speed
            delta = max(-max_delta, min(max_delta, delta))
            self._smooth_target_speed += delta
        else:
            self._smooth_target_speed = clamped

        return self._smooth_target_speed


    def process_sensor_data(self, frame_bytes: bytes):
        """处理传感器回传数据，执行闭环控制"""
        parsed_data = USVProtocol.parse_sensor_data(frame_bytes)
        
        # 子船校验 ID 为 0x02
        if not parsed_data or parsed_data.get("id") != 0x02:
            return

        control_heading = self._get_control_heading(parsed_data["imu"])
        self.current_heading = CoordUtils.normalize_angle(control_heading)
        parsed_data["imu"]["control_heading"] = control_heading
        parsed_data["imu"]["control_heading_source"] = self.heading_source

        # --- MCU已自行校准，坐标直接使用 ---
        curr_lat = (parsed_data["gps"]["lat"] + parsed_data["gps_B"]["lat"]) / 2.0
        curr_lon = (parsed_data["gps"]["lon"] + parsed_data["gps_B"]["lon"]) / 2.0
        curr_time = time.perf_counter()

        if self.last_gps_pos is not None and self.last_gps_time is not None:
            dt = curr_time - self.last_gps_time
            if dt > 0.001:
                dist, _ = CoordUtils.calculate_distance_and_bearing(
                    self.last_gps_pos[0], self.last_gps_pos[1], curr_lat, curr_lon
                )
                instant_speed = dist / dt
                self.smooth_speed = (self.smooth_speed * 0.7) + (instant_speed * 0.3)
                parsed_data["calculated_speed"] = self.smooth_speed

        self.last_gps_pos = (curr_lat, curr_lon)
        self.last_gps_time = curr_time

        parsed_data["targets"] = {
            "heading": self.target_heading if (self.auto_heading_active or self.is_mission_active) else None,
            "speed": self.target_speed if (self.auto_speed_active or self.is_mission_active) else 0.0
        }

        # 发射信号给 UI 和地图 (已修正)
        self.sig_data_parsed.emit(parsed_data)

        # 循环试验专用位姿返航，不改变普通任务导航器的到点逻辑。
        if self.pose_return.active:
            curr_heading = control_heading
            command = self.pose_return.update(curr_lat, curr_lon, curr_heading)
            if command.get("phase_changed") and command.get("phase") == "align":
                self.active_speed_algo.reset()
            self.target_heading = command["target_heading"]
            self.target_speed = self._apply_speed_limits(command["target_speed"])
            self.sig_target_sync.emit(self.target_speed, self.target_heading)

        # 领航员逻辑 (基于修正后的坐标)
        elif self.is_mission_active:
            curr_heading = control_heading
            target_h, target_s, dist_wp, is_finished = self.navigator.update(
                curr_lat, curr_lon, curr_heading=curr_heading
            )
            
            if is_finished:
                if self.steady_hold_active:
                    tgt_lat, tgt_lon = self.steady_hold_target
                    self.navigator.set_path([[tgt_lat, tgt_lon]])
                    self.current_wp_index = -1
                    self.sig_mission_log.emit(
                        f"⚓ [到点稳停] 已到达，重新锁定目标保持位置"
                    )
                else:
                    self.sig_mission_log.emit(
                        f"✅ [任务] 已到达第 {len(self.navigator.mission_path)} 点 🏁 已到达最终航点。"
                    )
                    self.stop_mission()
            else:
                self.target_heading = target_h
                self.target_speed = self._apply_speed_limits(target_s)
                self.sig_target_sync.emit(self.target_speed, self.target_heading)

                if self.navigator.current_wp_index != self.current_wp_index:
                    if self.current_wp_index >= 0:
                        self.sig_mission_log.emit(
                            f"✅ [任务] 已到达第 {self.current_wp_index + 1} 点"
                        )
                    self.current_wp_index = self.navigator.current_wp_index
                    self.sig_mission_log.emit(
                        f"📍 [任务] 前往第 {self.current_wp_index + 1} 点，距离 {dist_wp:.1f}m"
                    )

        # PID 控制逻辑... (保持不变)
        current_time = time.time()
        dt = current_time - self.last_pid_time
        if dt <= 0 or dt > 1.0: dt = 0.05

        if self.auto_heading_active or self.auto_speed_active:
            # 1. 算定速 PID
            s_ratio = self.active_speed_algo.compute(
                parsed_data["gps"]["speed"], self.target_speed, dt
            ) if self.auto_speed_active else 0.0
            
            # 防 PID 积分爆炸：先粗略限幅，最终限幅由 Mixer 按推进器配置钳位
            s_ratio = max(-1.0, min(1.0, s_ratio)) 

            # 2. 算转向 PID
            h_ratio = self.active_heading_algo.compute(
                control_heading, self.target_heading, dt
            ) if self.auto_heading_active else 0.0

            # 保留原有的转向削弱系数（PID算法本身的特性）
            h_ratio = h_ratio * 0.75 

            if self.vision_docking_active:
                # 低速靠泊禁止速度PID主动反推，并限制两个PID的最大输出。
                s_ratio = max(0.0, min(0.35, s_ratio))
                h_ratio = max(-0.25, min(0.25, h_ratio))
                if self._vision_control_state in {
                    "LOST", "REACQUIRE", "DOCKED"
                }:
                    s_ratio = 0.0
                    h_ratio = 0.0
                elif self._vision_control_state == "DEGRADED":
                    s_ratio = 0.0
                    h_ratio = max(-0.20, min(0.20, h_ratio))
                s_ratio, h_ratio = self._shape_visual_pid_output(
                    s_ratio, h_ratio, dt
                )

            # 3. 直接喂给统一分配器
            self._allocate_thrust(s_ratio, h_ratio, flush=False)
            self.last_pid_time = current_time

    # ==========================================
    # 🕹️ 外部输入处理 (手柄 / 急停)
    # ==========================================
    def process_joystick(self, x: float, y: float, interval_sec: float, flush: bool = False):
        """
        处理子船摇杆物理输入。
        :param interval_sec: 预留的发送间隔变量
        :param flush: [新增] 是否要求底层立即清空旧指令并发送这一帧
        """
        # 1. 抢占逻辑 (保持不变)
        if abs(x) > 15 or abs(y) > 15:
            if self.auto_heading_active or self.auto_speed_active or self.is_mission_active or getattr(self, 'vision_docking_active', False):
                self.auto_heading_active = False
                self.auto_speed_active = False
                self.is_mission_active = False
                self.vision_docking_active = False
                self.pose_return.stop()
                # --- 新增：软件速度解算变量 ---
                self.last_gps_pos = None     # 存储上一帧 (lat, lon)
                self.last_gps_time = None    # 存储上一帧 perf_counter 时间戳
                self.smooth_speed = 0.0      # 平滑后的速度值 (m/s)
                self.sig_status_changed.emit({"auto_heading": False, "auto_speed": False})
                self.sig_mission_log.emit("⚠️ [安全] 物理手柄强行接管子船动力，自动模式已关闭！")
                self.sig_manual_override.emit() 

        # 2. 如果当前处于自动模式且手柄没动，直接返回
        if self.auto_heading_active or self.auto_speed_active or self.is_mission_active: 
            return 
        
        # 3. 4 通道解耦混控：纵轴→主推，横轴→转向
        surge_cmd = y / 100.0  # 纵向推力 (→ 1/4 号主推)
        yaw_cmd = x / 100.0    # 偏航力矩 (→ 2/3 号转向)
    
        # 调用统一分配器
        self._allocate_thrust(surge_cmd, yaw_cmd, flush=flush)
        
        

    def process_estop(self):
        """急停状态重置：复位一切状态（硬件指令已由 send_estop() 直接下发）"""
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.is_mission_active = False
        self.steady_hold_active = False
        self.vision_docking_active = False
        self.pose_return.stop()
        self.sig_status_changed.emit({"auto_heading": False, "auto_speed": False})
        self.sig_manual_override.emit()
        # 🔒 不再发射 sig_control_ratios_ready，避免 send_control_ratios 用 mode=0x01
        #    覆盖急停的 mode=0x00 锁定态，造成继电器断开后又重新吸合

    # ==========================================
    # 👁️ 视觉靠泊控制逻辑 (新增)
    # ==========================================
    def set_vision_dock_active(self, active: bool):
        """显式启停视觉目标值到现有速度/艏向PID的闭环链路。"""
        self.vision_docking_active = bool(active)
        if active:
            self.is_mission_active = False
            self.steady_hold_active = False
            self.pose_return.stop()
            self.navigator.stop()
            self.auto_heading_active = True
            self.auto_speed_active = True
            self.target_heading = self.current_heading
            self.target_speed = 0.0
            self._vision_control_state = "REACQUIRE"
            self._vision_phase = "SEARCH_GATE"
            self._vision_smoothed_surge = 0.0
            self._vision_smoothed_yaw = 0.0
            self.active_heading_algo.reset()
            self.active_speed_algo.reset()
            self.visual_setpoint_generator.reset(
                current_heading_deg=self.current_heading,
                current_speed_m_s=self.smooth_speed,
            )
            self.last_pid_time = time.time()
            self.sig_status_changed.emit({
                "auto_heading": True,
                "auto_speed": True,
            })
            self.sig_target_sync.emit(self.target_speed, self.target_heading)
            self.sig_mission_log.emit(
                "🎯 [视觉对接] 已接入现有速度PID与艏向PID；等待四码目标。"
            )
        else:
            self.auto_heading_active = False
            self.auto_speed_active = False
            self.target_speed = 0.0
            self._vision_control_state = "LOST"
            self._vision_smoothed_surge = 0.0
            self._vision_smoothed_yaw = 0.0
            self.active_heading_algo.reset()
            self.active_speed_algo.reset()
            self.sig_status_changed.emit({
                "auto_heading": False,
                "auto_speed": False,
            })
            self.sig_mission_log.emit(
                "🛑 [视觉对接] PID闭环已切断，视觉识别可继续运行。"
            )
            self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0, True)

    def process_vision_target(self, target_data: dict):
        """旧的单码直推接口已停用，防止绕过PID和四码安全状态机。"""
        return

    def process_vision_guidance(self, guidance: dict):
        """把四码视觉引导转换为平滑目标值，实际推力由现有PID计算。"""
        if not self.vision_docking_active:
            return
        if self.is_mission_active:
            return

        phase = str(guidance.get("phase", "SEARCH_GATE"))
        control_state = str(guidance.get("control_state", "LOST"))
        single_marker = bool(guidance.get("single_marker", False))
        try:
            pos_angle = guidance.get("pos_angle_deg")
            pos_angle = None if pos_angle is None else float(pos_angle)
            distance = guidance.get("distance_cm")
            distance = None if distance is None else float(distance)
        except (TypeError, ValueError):
            pos_angle = None
            distance = None

        previous_state = self._vision_control_state
        previous_phase = self._vision_phase
        output = self.visual_setpoint_generator.update(
            phase=phase,
            control_state=control_state,
            pos_angle_deg=pos_angle,
            distance_cm=distance,
            current_heading_deg=self.current_heading,
            single_marker=single_marker,
        )
        self._vision_control_state = control_state
        self._vision_phase = phase
        self._last_visual_setpoint = output
        self.target_speed = output.target_speed_m_s
        self.target_heading = output.target_heading_deg

        if control_state != previous_state and control_state in {
            "LOST", "REACQUIRE", "DOCKED"
        }:
            self.active_speed_algo.reset()
            self.active_heading_algo.reset()

        self.sig_target_sync.emit(self.target_speed, self.target_heading)
        if phase != previous_phase:
            self.sig_mission_log.emit(
                f"🧭 [视觉PID] {previous_phase} → {phase}，"
                f"目标速度 {self.target_speed:.3f}m/s，"
                f"目标艏向 {self.target_heading:.1f}°"
            )

    # ==========================================
    # ⚙️ 任务与模式管理接口 (由外观类调用)
    # ==========================================
    def start_pose_return(self, config: dict):
        """启动循环试验专用的两段式位姿返航。"""
        self.navigator.stop()
        self.is_mission_active = False
        self.steady_hold_active = False
        self.vision_docking_active = False
        self.active_heading_algo.reset()
        self.active_speed_algo.reset()
        self._smooth_target_speed = 0.0
        self.pose_return.start(
            config["lat"], config["lon"], config["heading"],
            config.get("position_tolerance", 1.0),
            config.get("approach_distance", 4.0),
            config.get("cruise_speed", 0.25),
            config.get("final_speed", 0.12),
        )
        self.auto_heading_active = True
        self.auto_speed_active = True
        self.sig_status_changed.emit({"auto_heading": True, "auto_speed": True})
        self.sig_mission_log.emit(
            f"🔁 [循环试验] 子船开始返回起始位姿，目标艏向 {config['heading']:.1f}°"
        )

    def stop_pose_return(self, send_zero: bool = True):
        was_active = self.pose_return.active
        self.pose_return.stop()
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.active_heading_algo.reset()
        self.active_speed_algo.reset()
        self._smooth_target_speed = 0.0
        if send_zero:
            self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0, True)
        if was_active:
            self.sig_mission_log.emit("✅ [循环试验] 子船位姿返航已停止")

    def start_mission(self, coords):
        """开始路径跟踪任务"""
        self.pose_return.stop()
        self.navigator.set_path(coords)
        self.is_mission_active = True
        
        self.auto_speed_active = True
        self.auto_heading_active = True
        
        # ✅ 新增：告诉 UI 界面，把“自动定速”和“自动定艏”的按钮点亮
        self.sig_status_changed.emit({"auto_heading": True, "auto_speed": True})
        
        # 同步初次目标值
        self.sig_target_sync.emit(self.target_speed, self.target_heading)
        self.sig_mission_log.emit(f"🚀 [任务启动] 已加载 {len(coords)} 个航点，自动闭环已同步开启。")

    def stop_mission(self):
        self.is_mission_active = False
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.navigator.stop()
        self.current_wp_index = -1
        self.sig_mission_log.emit("🛑 子船任务已停止，动力输出已复位")
        self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0,True)

    def start_steady_hold(self, lat, lon):
        """📌 到点稳停：单点 P2P 导航并在到达后自动保持位置"""
        self.steady_hold_active = True
        self.steady_hold_target = (lat, lon)
        coords = [[lat, lon]]
        self.navigator.set_path(coords)
        self.is_mission_active = True
        self.auto_heading_active = True
        self.auto_speed_active = True
        self.sig_status_changed.emit({"auto_heading": True, "auto_speed": True})
        self.sig_mission_log.emit(f"🧭 [到点稳停] 目标已锁定: Lat {lat:.6f}, Lon {lon:.6f}，P2P 导航中...")

    def stop_steady_hold(self):
        """🛑 停止到点稳停"""
        self.steady_hold_active = False
        self.is_mission_active = False
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.navigator.stop()
        self.sig_mission_log.emit("🛑 [到点稳停] 任务结束，船只可自由移动。")
        self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0, True)

    def start_return_home(self):
        """🎯 一键返航：P2P 导航返回子船停靠点 (23°00'50.2"N 113°23'52.3"E)"""
        self.start_steady_hold(self.HOME_LAT, self.HOME_LON)
        self.sig_return_home.emit(self.HOME_LAT, self.HOME_LON)
        self.sig_mission_log.emit(
            f"🏠 [一键返航] P2P返航中 → 停靠点: "
            f"Lat {self.HOME_LAT:.6f}, Lon {self.HOME_LON:.6f}"
        )

    def change_algorithm(self, name):
        """切换底层 PID 算法并同步 UI"""
        if self.active_heading_algo is not None:
            self.active_heading_algo.reset()
            
        if self.active_speed_algo is not None:
            self.active_speed_algo.reset()
        
        if name in self.heading_algos: 
            self.active_heading_algo = self.heading_algos[name]
        if name in self.speed_algos: 
            self.active_speed_algo = self.speed_algos[name]
            
        self.sig_mission_log.emit(f"🧠 [算法切换] 子船当前算法: {name}")
        
        # 💡 [核心新增] 发射信号，携带最新的算法实例，触发侧边栏 UI 刷新
        self.sig_algo_tuning_ui_ready.emit(self.active_heading_algo, self.active_speed_algo)

    # def set_auto_heading(self, active: bool, target_heading: float):
    #     self.auto_heading_active = active
    #     self.target_heading = target_heading
    #     if active:
    #         self.active_heading_algo.reset()
    #         self.last_pid_time = time.time()
    def set_auto_heading(self, active: bool, target_heading: float):
        self.auto_heading_active = active
        self.target_heading = target_heading
        if active:
            self.active_heading_algo.reset()
            self.last_pid_time = time.time()
        else:
            # 💡 [核心修复] 关闭定艏时，如果正在执行任务，必须彻底停止任务
            if self.is_mission_active:
                self.stop_mission()
                return
            if not self.auto_speed_active:
                self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0,True)

    def set_auto_speed(self, active: bool, target_speed: float):
        self.auto_speed_active = active
        self.target_speed = self._apply_speed_limits(target_speed)
        if active:
            self.active_speed_algo.reset()
            self.last_pid_time = time.time()
        else:
            # 💡 [核心修复] 关闭定速时，如果正在执行任务，必须彻底停止任务
            if self.is_mission_active:
                self.stop_mission()
                return
            if not self.auto_heading_active:
                self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0,True)
    def step_target(self, d_speed: float, d_heading: float):
        """
        💡 [新增] 动态微调目标值 (步长累加)
        绝对不调用 PID.reset()，保证过渡丝滑
        """
        updated = False
        
        # 1. 只有在定速模式下，才允许微调速度
        if self.auto_speed_active and d_speed != 0:
            new_speed = self.target_speed + d_speed
            self.target_speed = self._apply_speed_limits(new_speed)
            updated = True
            
        # 2. 只有在定艏模式下，才允许微调航向
        if self.auto_heading_active and d_heading != 0:
            self.target_heading = CoordUtils.normalize_angle(self.target_heading + d_heading)
            # self.target_heading += d_heading
            # # 处理 360 度环绕
            # while self.target_heading >= 360.0: self.target_heading -= 360.0
            # while self.target_heading < 0.0: self.target_heading += 360.0
            updated = True
            
        # 3. 如果有更新，发射信号通知 UI 界面同步变化
        if updated:
            self.sig_target_sync.emit(self.target_speed, self.target_heading)
            self.sig_mission_log.emit(f"🎛️ [微调] 子船目标已更新 -> 航向: {self.target_heading:.1f}°, 速度: {self.target_speed:.1f}m/s")
    def set_target_heading_absolute(self, heading: float):
        """💡 [新增] 接收来自 UI 输入框的绝对航向值"""
        if self.auto_heading_active and self.target_heading != heading:
            # ✅ 修改点：对外部输入的值进行强制归一化
            self.target_heading = CoordUtils.normalize_angle(heading)
            self.sig_mission_log.emit(f"🎛️ [面板微调] 目标航向无感更新为: {self.target_heading:.1f}°")

    def set_target_speed_absolute(self, speed: float):
        """💡 [新增] 接收来自 UI 输入框的绝对速度值"""
        if self.auto_speed_active and self.target_speed != speed:
            self.target_speed = self._apply_speed_limits(speed)
            self.sig_mission_log.emit(f"🎛️ [面板微调] 目标速度无感更新为: {self.target_speed:.1f}m/s")
