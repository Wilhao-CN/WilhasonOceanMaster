# 文件路径: controllers/boat/boat_worker.py
"""
====================================================================
🧵 BoatBrainWorker — 运行在专用 QThread 的 QObject 包装器 (V1.0)
职责: 将 BoatBrain 的所有数据处理移出主线程，仅在 Worker 线程中执行。
      UI 更新通过信号跨线程回到主线程 (Qt 自动 QueuedConnection)。
====================================================================
"""
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot
from controllers.boat.boat_brain import BoatBrain


class BoatBrainWorker(QObject):
    """
    ====================================================================
    子船大脑工作线程对象

    输入: 通过 input signals 接收主线程发来的指令
    处理: 在 Worker 线程中执行 Brain 的全部逻辑 (PID/导航/视觉对接/数据解析)
    输出: 转发 Brain 的输出信号到主线程 (Qt 自动 QueuedConnection)

    与 DockBrainWorker 的区别:
    - 子船信号 sig_algo_tuning_ui_ready 只有 2 个参数 (无 ESO)
    - 子船额外支持视觉对接: process_vision_target / set_vision_dock_active
    ====================================================================
    """

    # ==========================================
    # 🔽 输入信号 (主线程 → Worker 线程)
    # ==========================================
    sig_frame = pyqtSignal(bytes)
    sig_joystick = pyqtSignal(float, float, float, bool)
    sig_estop = pyqtSignal()
    sig_start_mission = pyqtSignal(list)
    sig_stop_mission = pyqtSignal()
    sig_auto_heading = pyqtSignal(bool, float)
    sig_auto_speed = pyqtSignal(bool, float)
    sig_step_target = pyqtSignal(float, float)
    sig_change_algo = pyqtSignal(str)
    sig_steady_hold_start = pyqtSignal(float, float)
    sig_steady_hold_stop = pyqtSignal()
    sig_return_home_start = pyqtSignal()
    sig_target_heading_abs = pyqtSignal(float)
    sig_target_speed_abs = pyqtSignal(float)
    sig_pose_return_start = pyqtSignal(dict)
    sig_pose_return_stop = pyqtSignal()
    sig_nav_cruise = pyqtSignal(float)                  # P2P/LOS 领航巡航速度
    sig_heading_source = pyqtSignal(str)                # 子船控制艏向源
    # 子船专属: 视觉对接
    sig_vision_dock_active = pyqtSignal(bool)
    sig_vision_target = pyqtSignal(dict)
    sig_vision_guidance = pyqtSignal(dict)

    # ==========================================
    # 🔼 输出信号 (Worker 线程 → 主线程)
    # ==========================================
    sig_data_parsed = pyqtSignal(dict)
    sig_control_ratios_ready = pyqtSignal(float, float, float, float, bool)
    sig_status_changed = pyqtSignal(dict)
    sig_mission_log = pyqtSignal(str)
    sig_manual_override = pyqtSignal()
    sig_algo_tuning_ui_ready = pyqtSignal(object, object)
    sig_target_sync = pyqtSignal(float, float)
    sig_return_home = pyqtSignal(float, float)

    def __init__(self, mission_manager, parent=None):
        super().__init__(parent)
        self.brain = BoatBrain(mission_manager)

        # ---- 桥接: 输入信号 → Brain 方法 ----
        self.sig_frame.connect(self._on_frame)
        self.sig_joystick.connect(self._on_joystick)
        self.sig_estop.connect(self._on_estop)
        self.sig_start_mission.connect(self._on_start_mission)
        self.sig_stop_mission.connect(self._on_stop_mission)
        self.sig_auto_heading.connect(self._on_auto_heading)
        self.sig_auto_speed.connect(self._on_auto_speed)
        self.sig_step_target.connect(self._on_step_target)
        self.sig_change_algo.connect(self._on_change_algo)
        self.sig_steady_hold_start.connect(self._on_steady_hold_start)
        self.sig_steady_hold_stop.connect(self._on_steady_hold_stop)
        self.sig_return_home_start.connect(self._on_return_home_start)
        self.sig_target_heading_abs.connect(self._on_target_heading_abs)
        self.sig_target_speed_abs.connect(self._on_target_speed_abs)
        self.sig_pose_return_start.connect(self._on_pose_return_start)
        self.sig_pose_return_stop.connect(self._on_pose_return_stop)
        self.sig_nav_cruise.connect(self._on_nav_cruise)
        self.sig_heading_source.connect(self._on_heading_source)
        self.sig_vision_dock_active.connect(self._on_vision_dock_active)
        self.sig_vision_target.connect(self._on_vision_target)
        self.sig_vision_guidance.connect(self._on_vision_guidance)

        # ---- 转发: Brain 输出信号 → Worker 输出信号 ----
        self.brain.sig_data_parsed.connect(self.sig_data_parsed)
        self.brain.sig_control_ratios_ready.connect(self.sig_control_ratios_ready)
        self.brain.sig_status_changed.connect(self.sig_status_changed)
        self.brain.sig_mission_log.connect(self.sig_mission_log)
        self.brain.sig_manual_override.connect(self.sig_manual_override)
        self.brain.sig_algo_tuning_ui_ready.connect(self.sig_algo_tuning_ui_ready)
        self.brain.sig_target_sync.connect(self.sig_target_sync)
        self.brain.sig_return_home.connect(self.sig_return_home)

    # ==========================================
    # 🔧 内部处理方法 (全部在 Worker 线程执行)
    # ==========================================

    @pyqtSlot(bytes)
    def _on_frame(self, frame_bytes: bytes):
        self.brain.process_sensor_data(frame_bytes)

    @pyqtSlot(float, float, float, bool)
    def _on_joystick(self, x, y, interval_sec, flush):
        self.brain.process_joystick(x, y, interval_sec, flush)

    @pyqtSlot()
    def _on_estop(self):
        self.brain.process_estop()

    @pyqtSlot(list)
    def _on_start_mission(self, coords):
        self.brain.start_mission(coords)

    @pyqtSlot()
    def _on_stop_mission(self):
        self.brain.stop_mission()

    @pyqtSlot(bool, float)
    def _on_auto_heading(self, active, target_heading):
        self.brain.set_auto_heading(active, target_heading)

    @pyqtSlot(bool, float)
    def _on_auto_speed(self, active, target_speed):
        self.brain.set_auto_speed(active, target_speed)

    @pyqtSlot(float, float)
    def _on_step_target(self, d_speed, d_heading):
        self.brain.step_target(d_speed, d_heading)

    @pyqtSlot(str)
    def _on_change_algo(self, name):
        self.brain.change_algorithm(name)

    @pyqtSlot(float, float)
    def _on_steady_hold_start(self, lat, lon):
        self.brain.start_steady_hold(lat, lon)

    @pyqtSlot()
    def _on_steady_hold_stop(self):
        self.brain.stop_steady_hold()

    @pyqtSlot()
    def _on_return_home_start(self):
        self.brain.start_return_home()

    @pyqtSlot(float)
    def _on_target_heading_abs(self, heading):
        self.brain.set_target_heading_absolute(heading)

    @pyqtSlot(float)
    def _on_target_speed_abs(self, speed):
        self.brain.set_target_speed_absolute(speed)

    @pyqtSlot(dict)
    def _on_pose_return_start(self, config):
        self.brain.start_pose_return(config)

    @pyqtSlot()
    def _on_pose_return_stop(self):
        self.brain.stop_pose_return()

    @pyqtSlot(float)
    def _on_nav_cruise(self, speed):
        self.brain.set_nav_cruise_speed(speed)

    @pyqtSlot(str)
    def _on_heading_source(self, source):
        self.brain.set_heading_source(source)

    @pyqtSlot(bool)
    def _on_vision_dock_active(self, active):
        self.brain.set_vision_dock_active(active)

    @pyqtSlot(dict)
    def _on_vision_target(self, target_data):
        self.brain.process_vision_target(target_data)

    @pyqtSlot(dict)
    def _on_vision_guidance(self, guidance):
        self.brain.process_vision_guidance(guidance)

