# 文件路径: controllers/dock_controller.py
import struct
import datetime
import os
import time
from PyQt5.QtCore import QObject, pyqtSignal, QThread, QTimer

# 导入解耦后的核心组件
from controllers.dock.dock_brain import DockBrain
from controllers.dock.dock_comm import DockCommUnit
from controllers.dock.dock_monitor import DockMonitor
from controllers.dock.dock_worker import DockBrainWorker  # 🧵 [方案三] Worker 线程包装器
from core.fault_history_client import FaultHistoryClient
from core.fault_status_manager import FaultStatusManager
from ui.dialogs.fault_history_dialog import FaultHistoryDialog

class DockController(QObject):
    """
    ====================================================================
    🎛️ 船坞总控制器 (V11.0 Worker线程隔离版)
    职责: 100% 兼容原版 API 接口，负责船坞端大脑、通信与 UI 的连线。
    特性:
    - 🧵 [方案三] Brain 运行在专用 QThread，数据处理不阻塞主线程 UI
    - 所有 Brain 方法调用通过信号 emit 跨线程安全调用
    - 输出信号自动 QueuedConnection 回主线程
    ====================================================================
    """
    # 物理手柄抢占信号
    sig_manual_override = pyqtSignal()
    sig_cooperative_hold_fault = pyqtSignal(str)

    def __init__(self, dock_panel, driving_console, config_dialog, mission_manager, parent=None):
        super().__init__(parent)

        # --- 1. 保存 UI 和参数引用 ---
        self.panel = dock_panel
        self.console = driving_console
        self.config_dialog = config_dialog

        # --- 2. 🧵 [方案三] 创建专用工作线程 + Worker ---
        self.brain_thread = QThread(self)
        self.brain_worker = DockBrainWorker(mission_manager)
        self.brain_worker.moveToThread(self.brain_thread)
        self.brain_thread.start()

        # 🛡️ 向后兼容: 保留 self.brain 引用 (main_window 大量使用 brain 的信号/属性)
        self.brain = self.brain_worker.brain

        # --- 3. 通信层与监视器 (保持在主线程) ---
        self.comm = DockCommUnit(parent=self)
        self.monitor = DockMonitor(self.panel, parent=self)
        self.fault_status = FaultStatusManager(parent=self)
        self.fault_history_client = FaultHistoryClient(
            device_id=0x01,
            device_name="船坞",
            parent=self,
        )
        self.fault_history_dialog = None

        # --- 4. 🛡️ 属性暴露 (兼容 MainWindow 逻辑) ---
        self.serial_thread = self.comm.serial_thread
        self.network_thread = self.comm.network_thread
        self.video_thread = self.comm.video_thread
        self.relay_mirror = self.comm.relay_mirror
        self.sensor_mirror = self.comm.sensor_mirror
        self._repeat_separation_ratios = None
        self.nof_centering_active = False  # 🎯 主线程镜像，供 main_window 查询

        self._cooperative_hold_requested = False
        self._cooperative_hold_request_time = 0.0
        self._cooperative_hold_watchdog = QTimer(self)
        self._cooperative_hold_watchdog.setInterval(200)
        self._cooperative_hold_watchdog.timeout.connect(
            self._check_cooperative_docking_hold
        )

        # --- 5. 内部信号绑定 ---
        self._bind_internal_signals()
        self._bind_ui_signals()
        self.panel.update_fault_status(self.fault_status.snapshot())
        self.panel.set_fault_history_count(
            self.fault_history_client.cache.fault_count(0x01)
        )
        self.fault_history_client.start()

    def _bind_internal_signals(self):
        """🧬 内部组件连线 (🧵 Worker线程版)"""
        # 🧵 数据链: Comm →(信号跨线程)→ Worker线程:Brain.process() → Worker输出信号 →(QueuedConnection)→ 主线程:Monitor
        # 关键改动: Comm 的 sig_frame_received 连接到 Worker 的 sig_frame 输入信号
        #   这样 Brain.process_sensor_data() 就在 Worker 线程执行，不阻塞主线程
        self.comm.sig_frame_received.connect(self.brain_worker.sig_frame)
        # Worker 输出信号 → 主线程消费者 (Qt 自动 QueuedConnection)
        self.brain_worker.sig_data_parsed.connect(self.monitor.refresh_ui_and_map)
        self.brain_worker.sig_data_parsed.connect(self._update_mcu_fault_status)
        self.brain_worker.sig_control_ratios_ready.connect(self.comm.send_control_ratios)

        # 视频与日志同步 (视频线程独立，不变)
        self.comm.video_thread.sig_frame_ready.connect(self.monitor.distribute_video_frame)
        # 仿真视频由侧边面板定时读取 latest_qimage，避免“信号推送 + 定时拉取”重复刷新。
        # 状态/算法/日志信号 (Worker → 主线程，Qt 自动 QueuedConnection)
        self.brain_worker.sig_status_changed.connect(self.monitor.sync_widget_states)
        self.brain_worker.sig_algo_tuning_ui_ready.connect(self.monitor.setup_algo_tuning_ui)
        self.brain_worker.sig_mission_log.connect(self.monitor.append_log)
        self.brain_worker.sig_manual_override.connect(self.sig_manual_override)
        self.brain_worker.sig_target_sync.connect(self._sync_ui_targets)

        # 硬件状态显示
        self.comm.sig_serial_status.connect(self.monitor.update_serial_light)
        self.comm.sig_net_status.connect(self.monitor.update_net_light)
        self.comm.sig_log_triggered.connect(self.monitor.append_log)
        self.network_thread.latency_updated.connect(self.monitor.update_latency)
        self.network_thread.remote_status_changed.connect(
            self._handle_remote_status_changed
        )

        # 故障健康状态、历史补拉与 UI
        self.fault_status.status_changed.connect(self.monitor.update_fault_status)
        self.fault_history_client.health_received.connect(
            self.fault_status.update_health
        )
        self.fault_history_client.health_unavailable.connect(
            self._handle_health_unavailable
        )
        self.fault_history_client.history_updated.connect(
            self._handle_history_updated
        )
        self.fault_history_client.sync_log.connect(
            lambda text: self.monitor.append_log(f"📋 [故障同步] {text}")
        )

        # 🧠 连接建立后自动开启 EKF
        self.comm.sig_serial_status.connect(self._auto_enable_ekf)
        self.comm.sig_net_status.connect(self._auto_enable_ekf)

    def _bind_ui_signals(self):
        """👆 连接 UI 面板信号 (🧵 通过 Worker input signals 跨线程调用 Brain)"""
        cp = self.panel.comm_panel
        cp.sig_tx_link_changed.connect(self.comm.set_hw_tx_link)
        self.config_dialog.sig_comm_mode_changed.connect(self._handle_mode_changed)

        cp.sig_connect_req.connect(self._handle_connect)
        cp.sig_connect_net_req.connect(self._handle_connect_network)

        if hasattr(cp, 'sig_disconnect_serial_req'): cp.sig_disconnect_serial_req.connect(self._handle_disconnect_serial)
        if hasattr(cp, 'sig_disconnect_net_req'): cp.sig_disconnect_net_req.connect(self._handle_disconnect_network)

        cp.sig_send_req.connect(self._handle_send_hex)
        self.panel.sig_init_clicked.connect(self._handle_init)
        self.panel.sig_return_clicked.connect(self._handle_return)
        self.panel.sig_estop_clicked.connect(self._handle_estop)
        self.panel.sig_custom_clicked.connect(self._handle_custom_feature)
        self.panel.sig_auto_heading_toggled.connect(self._handle_auto_heading_toggled)
        self.panel.sig_auto_speed_toggled.connect(self._handle_auto_speed_toggled)
        # 🧵 UI输入 → Worker 线程安全调用
        self.panel.sig_target_heading_changed.connect(self.brain_worker.sig_target_heading_abs)
        self.panel.sig_target_speed_changed.connect(self.brain_worker.sig_target_speed_abs)
        self.panel.sig_heading_source_changed.connect(self.brain_worker.sig_heading_source)
        self.panel.sig_open_tuning_req.connect(self.monitor.open_tuning_window)
        # 录像控制信号连线
        self.panel.sig_record_toggled.connect(self._handle_record_toggled)
        self.panel.sig_fault_history_requested.connect(self._show_fault_history)
        self.config_dialog.sig_dock_algo_changed.connect(self._handle_algo_changed)
        if hasattr(self.config_dialog, 'sig_dock_nav_algo_changed'):
            self.config_dialog.sig_dock_nav_algo_changed.connect(self._handle_nav_algo_changed)
        if hasattr(self.config_dialog, 'sig_dock_nav_cruise_req'):
            self.config_dialog.sig_dock_nav_cruise_req.connect(self._handle_nav_cruise)
        self.console.sig_dock_pwm_updated.connect(self._handle_manual_pwm)

    # ==========================================
    # 🔗 业务处理方法
    # ==========================================
    def _handle_mode_changed(self, mode_str):
        self.comm.set_mode(mode_str)
        self.panel.comm_panel.switch_mode(mode_str)

    def _handle_connect(self, p, b): self.comm.open_serial(p, b)

    def _handle_connect_network(self):
        ip = self.config_dialog.dock_ip_input.text().strip()
        try:
            tx, rx, v = int(self.config_dialog.dock_port_tx.text()), int(self.config_dialog.dock_port_rx.text()), int(self.config_dialog.dock_port_video.text())
            if self.comm.open_network_and_video(ip, tx, rx, v, self.panel.video_size):
                self.fault_status.set_network_enabled(True)
                if self.comm.is_simulation:
                    self.fault_history_client.clear_target()
                else:
                    self.fault_history_client.configure_target(ip, 8891)
                self.panel.start_video_display(self.comm.active_video_thread)
        except ValueError: self.monitor.append_log("[错误] 网络端口格式不正确！")

    def _handle_disconnect_network(self):
        self.comm.close_network_and_video()
        self.fault_history_client.clear_target()
        self.fault_status.set_network_enabled(False)
        self.panel.stop_video_display()
    def _handle_disconnect_serial(self): self.comm.close_serial()

    def _update_mcu_fault_status(self, data: dict):
        self.fault_status.update_mcu_fault(data.get("fault_code", 0))

    def _handle_remote_status_changed(self, online: bool):
        self.fault_status.update_remote_online(online)
        if online:
            self.monitor.append_log("✅ [远端状态] 船坞网络遥测已恢复")
            self.fault_history_client.request_refresh()

    def _handle_health_unavailable(self, reason: str):
        self.fault_status.health_unavailable(reason)
        self.monitor.append_log(f"⚠️ [故障同步] 船坞健康服务不可达: {reason}")
        if self.fault_history_dialog and self.fault_history_dialog.isVisible():
            self.fault_history_dialog.set_sync_error(reason)

    def _handle_history_updated(self, events: list, count: int):
        self.panel.set_fault_history_count(count)
        if self.fault_history_dialog:
            self.fault_history_dialog.set_events(events)

    def _show_fault_history(self):
        if self.fault_history_dialog is None:
            self.fault_history_dialog = FaultHistoryDialog(
                "1号端：船坞", parent=self.panel
            )
            self.fault_history_dialog.refresh_requested.connect(
                self.fault_history_client.request_refresh
            )
            self.fault_history_dialog.clear_requested.connect(
                self.fault_history_client.clear_history
            )
        self.fault_history_dialog.set_events(
            self.fault_history_client.local_events()
        )
        self.fault_history_dialog.show()
        self.fault_history_dialog.raise_()
        self.fault_history_dialog.activateWindow()
        self.fault_history_client.request_refresh()

    def _handle_init(self): self.comm.send_init()
    def _handle_return(self):
        """🎯 一键返航: 触发大脑 P2P 返航逻辑 (🧵 Worker线程)"""
        self.brain_worker.sig_return_home_start.emit()

    def _handle_estop(self):
        self._repeat_separation_ratios = None
        self.set_cooperative_docking_hold(False)
        self.brain_worker.sig_estop.emit()
        if self.comm.send_estop():
            self.monitor.append_log("🚨 [急停] 船坞动力已切断。")
        else:
            self.monitor.append_log("❌ [急停失败] 船坞急停指令未能发出，请检查通信连接！")

    def _handle_gps_calib(self, target_id: int, lat_off: float, lon_off: float):
        """GPS校准下发单片机 + 重置EKF使其立即对齐双GPS艏向"""
        from PyQt5.QtCore import QTimer
        self.comm.send_gps_calib(target_id, lat_off, lon_off)
        # 校准后双GPS艏向可能跳变，先关后开EKF强制重新初始化
        QTimer.singleShot(300, lambda: self.comm.send_ekf_cmd(target_id, False))
        QTimer.singleShot(400, lambda: self.comm.send_ekf_cmd(target_id, True))

    def _auto_enable_ekf(self, connected: bool):
        """连接建立后自动开启 EKF (延迟 500ms 等待 MCU 就绪)"""
        if connected:
            from PyQt5.QtCore import QTimer
            QTimer.singleShot(500, lambda: self.comm.send_ekf_cmd(0x01, True))

    def send_imu_deadband(self, deadband: float):
        """IMU角速度死区配置"""
        self.comm.send_imu_deadband(0x01, deadband)

    def handle_steady_hold_start(self, lat: float, lon: float):
        self.brain_worker.sig_steady_hold_start.emit(lat, lon)

    def handle_steady_hold_stop(self):
        self.brain_worker.sig_steady_hold_stop.emit()

    def _handle_send_hex(self, hex_text):
        if self.comm.send_raw_hex(hex_text): self.monitor.clear_hex_input()

    def get_auto_control_params(self):
        """🧵 线程安全读取 cached_auto_ratios (Python 引用赋值是原子的)"""
        if self._repeat_separation_ratios is not None:
            return self._repeat_separation_ratios
        if (self.brain.auto_heading_active or self.brain.auto_speed_active
                or self.brain.is_mission_active):
            return self.brain.cached_auto_ratios
        return None

    def _handle_joystick(self, x, y, flush=False):
        self.brain_worker.sig_joystick.emit(x, y, self.panel.comm_panel.get_interval_sec(), flush)

    def _handle_manual_pwm(self, p1, p2, p3, p4):
        """处理驾驶台直接下发的 PWM (🧵 抢占时通过信号通知 Worker)"""
        if self.brain.auto_heading_active or self.brain.auto_speed_active or self.brain.is_mission_active:
            # 通过 emit estop 信号让 Worker 线程重置状态
            self.brain_worker.sig_estop.emit()
            self.monitor.append_log("⚠️ [安全] 驾驶台抢占，自动模式关闭。")
        self.comm.send_control_ratios(p1, p2, p3, p4, flush=True)

    def _handle_algo_changed(self, name):
        self.comm.send_stop_cmd()
        self.brain_worker.sig_change_algo.emit(name)

    def _handle_nav_algo_changed(self, algo_name):
        # 🧵 navigator.switch_algorithm 是简单的属性赋值，跨线程安全
        self.brain.navigator.switch_algorithm(algo_name)

    def _handle_nav_cruise(self, speed: float):
        # 🧵 改 default_speed 是简单属性赋值，但经 Worker 信号串行化，确保线程安全
        self.brain_worker.sig_nav_cruise.emit(speed)

    def _handle_auto_heading_toggled(self, checked, angle):
        self.brain_worker.sig_auto_heading.emit(checked, angle)
        if not checked and not self.brain.auto_speed_active: self.comm.send_stop_cmd()

    def _handle_auto_speed_toggled(self, checked, speed):
        self.brain_worker.sig_auto_speed.emit(checked, speed)
        if not checked and not self.brain.auto_heading_active: self.comm.send_stop_cmd()

    def step_target(self, d_speed, d_heading):
        self.brain_worker.sig_step_target.emit(d_speed, d_heading)

    def _sync_ui_targets(self, speed, heading):
        """反向同步目标值至 UI (主线程直接操作 UI 安全)"""
        self.panel.spin_speed.blockSignals(True)
        self.panel.spin_speed.setValue(speed)
        self.panel.spin_speed.blockSignals(False)
        self.panel.spin_heading.blockSignals(True)
        self.panel.spin_heading.setValue(heading)
        self.panel.spin_heading.blockSignals(False)

    def can_start_cooperative_docking_hold(self):
        """Check whether the dock has a fresh heading and no conflicting task."""
        brain = self.brain
        if brain.is_mission_active or brain.pose_return.active:
            return False, "船坞正在执行自动任务，请先停止任务。"
        if brain.last_sensor_time is None:
            return False, "尚未收到船坞遥测，无法锁存艏向。"
        if time.perf_counter() - brain.last_sensor_time > 1.0:
            return False, "船坞遥测已超过1秒未更新，无法安全启动。"
        return True, ""

    def set_cooperative_docking_hold(self, active: bool):
        """Latch/release dock heading hold in the dock worker thread."""
        active = bool(active)
        self._cooperative_hold_requested = active
        if active:
            self._cooperative_hold_request_time = time.perf_counter()
            self._cooperative_hold_watchdog.start()
        else:
            self._cooperative_hold_watchdog.stop()
        self.brain_worker.sig_docking_hold.emit(active)

    def _check_cooperative_docking_hold(self):
        if not self._cooperative_hold_requested:
            self._cooperative_hold_watchdog.stop()
            return

        now = time.perf_counter()
        if self.brain.last_sensor_time is None or now - self.brain.last_sensor_time > 1.0:
            reason = "船坞遥测中断，协同定艏已自动解除。"
        elif (
            now - self._cooperative_hold_request_time > 0.5
            and not self.brain.docking_hold_active
        ):
            reason = "船坞定艏保持已被解除，小船视觉闭环已停止。"
        else:
            return

        self.set_cooperative_docking_hold(False)
        self.sig_cooperative_hold_fault.emit(reason)

    def set_vision_dock_active(self, active: bool):
        """给UI留一个空接口，防止报错，船坞尚未实现视觉自控靠泊"""
        self.monitor.append_log("⚠️ 船坞暂不支持视觉自控闭环动力")

    def set_nof_centering_active(self, active: bool):
        """🎯 启停船坞 NOF 视觉居中伺服 (🧵 Worker线程)"""
        active = bool(active)
        self.nof_centering_active = active
        self.brain_worker.sig_nof_centering_active.emit(active)

    def update_nof_offset(self, offset_x: float):
        """🎯 逐帧推送 NOF 框中心归一化水平偏移给船坞大脑"""
        self.brain_worker.sig_nof_offset.emit(float(offset_x))

    def set_boat_position(self, lat: float, lon: float):
        """🎯 把子船 GPS 中点桥接给船坞大脑，供视觉丢失时 GPS 相对方位角兜底。"""
        self.brain_worker.sig_boat_position.emit(float(lat), float(lon))

    # 船坞高清录像控制中心
    def _handle_record_toggled(self, checked: bool):
        active_video_thread = self.comm.active_video_thread
        if not active_video_thread.is_running:
            self.monitor.append_log("❌ [错误] 视频流未连接，无法录制！")
            self.panel.btn_record.setChecked(False)
            return

        if checked:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"records/dock_video_{timestamp}.mp4"
            active_video_thread.start_recording(filename, fps=20)
            self.monitor.append_log(f"🎬 [录像开始] 原画保存至 {filename}")
        else:
            active_video_thread.stop_recording()
            self.monitor.append_log("🛑 [录像结束] 视频文件已安全封口。")

    def start_mission(self, coords):
        self.brain_worker.sig_start_mission.emit(coords)

    def stop_mission(self):
        self.brain_worker.sig_stop_mission.emit()

    def start_pose_return(self, config: dict):
        self.brain_worker.sig_pose_return_start.emit(config)

    def stop_pose_return(self):
        self.brain_worker.sig_pose_return_stop.emit()

    def set_repeat_separation_ratios(self, ratios=None):
        """循环试验分离阶段的最高优先级推力覆盖。"""
        if ratios is None:
            self._repeat_separation_ratios = None
            self.comm.send_stop_cmd(flush=True)
            return
        values = [float(value) for value in ratios]
        if len(values) != 4:
            raise ValueError("分离推力必须包含4个通道")
        self._repeat_separation_ratios = values + [False]
        self.comm.send_control_ratios(*values, flush=True)

    def set_sensor_config(self, imu_en=None, imu_ms=None, gps_en=None, gps_ms=None):
        self.comm.update_sensor_config(imu_en, imu_ms, gps_en, gps_ms)

    def _handle_custom_feature(self):
        """🧪 测试数据注入 (直接emit到Worker线程处理)"""
        fmt = '> 5B 4H 2h 3H 2i B'
        payload = struct.pack(fmt, 0xBB, 0x01, 0x01, 99, 0x00, 1500, 1500, 1500, 1500, -100, 100, 9000, 9000, 0, 225431500, 1141235000, 10)
        mock_bytes = payload + struct.pack('>BB', sum(payload)&0xFF, 0xCC)
        self.brain_worker.sig_frame.emit(mock_bytes)

    # ==========================================
    # 🧹 线程清理
    # ==========================================
    def shutdown(self):
        """安全退出 Worker 线程"""
        self.fault_history_client.stop()
        self.fault_history_client.wait(3000)
        self.brain.shutdown()
        self.brain_thread.quit()
        self.brain_thread.wait(3000)  # 最多等 3 秒
