# 文件路径: controllers/boat_controller.py
import struct
import datetime
from PyQt5.QtCore import QObject, pyqtSignal, QThread

# 导入解耦后的三大核心组件
from controllers.boat.boat_brain import BoatBrain
from controllers.boat.boat_comm import BoatCommUnit
from controllers.boat.boat_monitor import BoatMonitor
from controllers.boat.boat_worker import BoatBrainWorker  # 🧵 [方案三] Worker 线程包装器
from core.fault_history_client import FaultHistoryClient
from core.fault_status_manager import FaultStatusManager
from ui.dialogs.fault_history_dialog import FaultHistoryDialog

class BoatController(QObject):
    """
    ====================================================================
    🎛️ 子船总控制器 (V11.0 Worker线程隔离版)
    职责: 100% 兼容原版 API 接口，负责三大组件(Brain/Comm/Monitor)的信号路由。
    特性:
    - 🧵 [方案三] Brain 运行在专用 QThread，数据处理不阻塞主线程 UI
    - 所有 Brain 方法调用通过信号 emit 跨线程安全调用
    - 输出信号自动 QueuedConnection 回主线程
    ====================================================================
    """
    # 保持原有的物理手柄抢占信号 (向主窗口发送)
    sig_manual_override = pyqtSignal()

    def __init__(self, boat_panel, driving_console, config_dialog, mission_manager, parent=None):
        super().__init__(parent)

        # --- 1. 保存 UI 与参数引用 ---
        self.panel = boat_panel
        self.console = driving_console
        self.config_dialog = config_dialog

        # --- 2. 🧵 [方案三] 创建专用工作线程 + Worker ---
        self.brain_thread = QThread(self)
        self.brain_worker = BoatBrainWorker(mission_manager)
        self.brain_worker.moveToThread(self.brain_thread)
        self.brain_thread.start()

        # 🛡️ 向后兼容: 保留 self.brain 引用 (main_window 大量使用)
        self.brain = self.brain_worker.brain

        # --- 3. 通信层与监视器 (保持在主线程) ---
        self.comm = BoatCommUnit(parent=self)
        self.monitor = BoatMonitor(self.panel, parent=self)
        self.fault_status = FaultStatusManager(parent=self)
        self.fault_history_client = FaultHistoryClient(
            device_id=0x02,
            device_name="子船",
            parent=self,
        )
        self.fault_history_dialog = None

        # --- 4. 🛡️ 属性暴露机制 (确保 MainWindow 现有逻辑不报错) ---
        self.serial_thread = self.comm.serial_thread
        self.network_thread = self.comm.network_thread
        self.video_thread = self.comm.video_thread
        self.relay_mirror = self.comm.relay_mirror
        self.sensor_mirror = self.comm.sensor_mirror
        self._repeat_separation_ratios = None

        # --- 5. 开始信号连线 ---
        self._bind_internal_signals()
        self._bind_ui_signals()
        self.panel.update_fault_status(self.fault_status.snapshot())
        self.panel.set_fault_history_count(
            self.fault_history_client.cache.fault_count(0x02)
        )
        self.fault_history_client.start()

    def _bind_internal_signals(self):
        """🧬 内部组件间的信号走线 (🧵 Worker线程版)"""
        # 🧵 数据流: Comm →(跨线程)→ Worker:Brain.process() → Worker输出 →(QueuedConnection)→ 主线程
        self.comm.sig_frame_received.connect(self.brain_worker.sig_frame)
        self.brain_worker.sig_data_parsed.connect(self.monitor.refresh_ui_and_map)
        self.brain_worker.sig_data_parsed.connect(self._update_mcu_fault_status)

        # 控制流: Worker输出 → 物理下发
        self.brain_worker.sig_control_ratios_ready.connect(self.comm.send_control_ratios)

        # 视频流: 双路画面分发 (视频线程独立，不变)
        self.comm.video_thread.sig_frame_ready.connect(self.monitor.distribute_video_frame)
        # 仿真视频由侧边面板定时读取 latest_qimage，避免“信号推送 + 定时拉取”重复刷新。

        # 状态同步、安全熔断与算法 UI 注入
        self.brain_worker.sig_status_changed.connect(self.monitor.sync_widget_states)
        self.brain_worker.sig_target_sync.connect(self._sync_ui_targets)
        self.brain_worker.sig_algo_tuning_ui_ready.connect(self.monitor.setup_algo_tuning_ui)
        self.brain_worker.sig_mission_log.connect(self.monitor.append_log)
        self.brain_worker.sig_manual_override.connect(self.sig_manual_override)

        # 硬件指示灯与通信日志
        self.comm.sig_serial_status.connect(self.monitor.update_serial_light)
        self.comm.sig_net_status.connect(self.monitor.update_net_light)
        self.comm.sig_log_triggered.connect(self.monitor.append_log)
        self.network_thread.latency_updated.connect(self.monitor.update_latency)
        self.network_thread.remote_status_changed.connect(
            self._handle_remote_status_changed
        )

        # 故障健康状态、历史补拉与 UI
        self.fault_status.status_changed.connect(self.monitor.update_fault_status)
        self.fault_history_client.health_received.connect(
            self.fault_status.update_health
        )
        self.fault_history_client.health_unavailable.connect(
            self._handle_health_unavailable
        )
        self.fault_history_client.history_updated.connect(
            self._handle_history_updated
        )
        self.fault_history_client.sync_log.connect(
            lambda text: self.monitor.append_log(f"📋 [故障同步] {text}")
        )

        # 🧠 连接建立后自动开启 EKF
        self.comm.sig_serial_status.connect(self._auto_enable_ekf)
        self.comm.sig_net_status.connect(self._auto_enable_ekf)

        # 实际 PWM 回传驾驶台显示
        self.comm.sig_pwm_actual.connect(self.console.update_actual_pwm_boat)

    def _bind_ui_signals(self):
        """👆 连接 UI 面板上的交互信号"""
        cp = self.panel.comm_panel
        # 通信链路控制
        cp.sig_tx_link_changed.connect(self.comm.set_hw_tx_link)
        self.config_dialog.sig_comm_mode_changed.connect(self._handle_mode_changed)
        cp.sig_connect_req.connect(self._handle_connect_serial)
        cp.sig_connect_net_req.connect(self._handle_connect_network)

        # 兼容不同版本的断开信号
        if hasattr(cp, 'sig_disconnect_req'):
            cp.sig_disconnect_req.connect(self._handle_disconnect)
        if hasattr(cp, 'sig_disconnect_serial_req'):
            cp.sig_disconnect_serial_req.connect(self._handle_disconnect)
        if hasattr(cp, 'sig_disconnect_net_req'):
            cp.sig_disconnect_net_req.connect(self._handle_disconnect)

        cp.sig_send_req.connect(self._handle_send_hex)

        # 业务功能按钮
        self.panel.sig_init_clicked.connect(self._handle_init)
        self.panel.sig_return_clicked.connect(self._handle_return)
        self.panel.sig_estop_clicked.connect(self._handle_estop)
        self.panel.sig_custom_clicked.connect(self._handle_custom_feature)
        self.panel.sig_auto_heading_toggled.connect(self._handle_auto_heading_toggled)
        self.panel.sig_auto_speed_toggled.connect(self._handle_auto_speed_toggled)

        # 🧵 目标值输入同步 → Worker 线程安全调用
        self.panel.sig_target_heading_changed.connect(self.brain_worker.sig_target_heading_abs)
        self.panel.sig_target_speed_changed.connect(self.brain_worker.sig_target_speed_abs)

        # 🎛 控制艏向源切换（与船坞一致）
        self.panel.sig_heading_source_changed.connect(self.brain_worker.sig_heading_source)

        # 录像控制信号连线
        self.panel.sig_record_toggled.connect(self._handle_record_toggled)
        self.panel.sig_fault_history_requested.connect(self._show_fault_history)

        # 算法调参面板控制
        self.panel.sig_open_tuning_req.connect(self.monitor.open_tuning_window)
        self.config_dialog.sig_boat_algo_changed.connect(self._handle_algo_changed)
        if hasattr(self.config_dialog, 'sig_boat_nav_algo_changed'):
            self.config_dialog.sig_boat_nav_algo_changed.connect(self._handle_nav_algo_changed)
        if hasattr(self.config_dialog, 'sig_boat_nav_cruise_req'):
            self.config_dialog.sig_boat_nav_cruise_req.connect(self._handle_nav_cruise)

    # ==========================================
    # 🔗 业务处理方法
    # ==========================================
    def _sync_ui_targets(self, speed: float, heading: float):
        """💡 大脑目标改变时，反向更新 UI 文本框 (主线程操作 UI 安全)"""
        self.panel.spin_speed.blockSignals(True)
        self.panel.spin_speed.setValue(speed)
        self.panel.spin_speed.blockSignals(False)

        self.panel.spin_heading.blockSignals(True)
        self.panel.spin_heading.setValue(heading)
        self.panel.spin_heading.blockSignals(False)

    def _handle_mode_changed(self, mode_str):
        self.comm.set_mode(mode_str)
        self.panel.comm_panel.switch_mode(mode_str)

    def _handle_connect_serial(self, p, b):
        self.comm.open_serial(p, b)

    def _handle_connect_network(self):
        ip = self.config_dialog.boat_ip_input.text().strip()
        try:
            tx = int(self.config_dialog.boat_port_tx.text().strip())
            rx = int(self.config_dialog.boat_port_rx.text().strip())
            v_port = int(self.config_dialog.boat_port_video.text().strip())
            if self.comm.open_network_and_video(ip, tx, rx, v_port, self.panel.video_size):
                self.fault_status.set_network_enabled(True)
                if self.comm.is_simulation:
                    self.fault_history_client.clear_target()
                else:
                    self.fault_history_client.configure_target(ip, 8891)
                self.panel.start_video_display(self.comm.active_video_thread)
        except ValueError:
            self.monitor.append_log("[错误] 网络端口格式不正确！")

    def _handle_disconnect(self):
        self.comm.close_all_links()
        self.fault_history_client.clear_target()
        self.fault_status.set_network_enabled(False)
        self.panel.stop_video_display()

    def _update_mcu_fault_status(self, data: dict):
        self.fault_status.update_mcu_fault(data.get("fault_code", 0))

    def _handle_remote_status_changed(self, online: bool):
        self.fault_status.update_remote_online(online)
        if online:
            self.monitor.append_log("✅ [远端状态] 子船网络遥测已恢复")
            self.fault_history_client.request_refresh()

    def _handle_health_unavailable(self, reason: str):
        self.fault_status.health_unavailable(reason)
        self.monitor.append_log(f"⚠️ [故障同步] 子船健康服务不可达: {reason}")
        if self.fault_history_dialog and self.fault_history_dialog.isVisible():
            self.fault_history_dialog.set_sync_error(reason)

    def _handle_history_updated(self, events: list, count: int):
        self.panel.set_fault_history_count(count)
        if self.fault_history_dialog:
            self.fault_history_dialog.set_events(events)

    def _show_fault_history(self):
        if self.fault_history_dialog is None:
            self.fault_history_dialog = FaultHistoryDialog(
                "2号端：子船", parent=self.panel
            )
            self.fault_history_dialog.refresh_requested.connect(
                self.fault_history_client.request_refresh
            )
            self.fault_history_dialog.clear_requested.connect(
                self.fault_history_client.clear_history
            )
        self.fault_history_dialog.set_events(
            self.fault_history_client.local_events()
        )
        self.fault_history_dialog.show()
        self.fault_history_dialog.raise_()
        self.fault_history_dialog.activateWindow()
        self.fault_history_client.request_refresh()

    def _handle_init(self): self.comm.send_init()
    def _handle_return(self):
        """🎯 一键返航: 触发大脑 P2P 返航逻辑 (🧵 Worker线程)"""
        self.brain_worker.sig_return_home_start.emit()

    def _handle_estop(self):
        self._repeat_separation_ratios = None
        self.brain_worker.sig_estop.emit()
        if self.comm.send_estop():
            self.monitor.append_log("🚨 [急停] 子船动力已强制切断。")
        else:
            self.monitor.append_log("❌ [急停失败] 子船急停指令未能发出，请检查通信连接！")

    def _handle_send_hex(self, hex_text):
        if self.comm.send_raw_hex(hex_text):
            self.monitor.clear_hex_input()

    def _handle_gps_calib(self, target_id: int, lat_off: float, lon_off: float):
        """GPS校准下发单片机 + 重置EKF使其立即对齐双GPS艏向"""
        from PyQt5.QtCore import QTimer
        self.comm.send_gps_calib(target_id, lat_off, lon_off)
        # 校准后双GPS艏向可能跳变，先关后开EKF强制重新初始化
        QTimer.singleShot(300, lambda: self.comm.send_ekf_cmd(target_id, False))
        QTimer.singleShot(400, lambda: self.comm.send_ekf_cmd(target_id, True))

    def _auto_enable_ekf(self, connected: bool):
        """连接建立后自动开启 EKF (延迟 500ms 等待 MCU 就绪)"""
        if connected:
            from PyQt5.QtCore import QTimer
            QTimer.singleShot(500, lambda: self.comm.send_ekf_cmd(0x02, True))

    def send_imu_deadband(self, deadband: float):
        """IMU角速度死区配置"""
        self.comm.send_imu_deadband(0x02, deadband)

    def get_auto_control_params(self):
        """🧵 线程安全读取 cached_auto_ratios"""
        if self._repeat_separation_ratios is not None:
            return self._repeat_separation_ratios
        if (self.brain.auto_heading_active or
            self.brain.auto_speed_active or self.brain.is_mission_active):
            return self.brain.cached_auto_ratios
        return None

    def _handle_joystick(self, x: float, y: float, flush: bool = False):
        self.brain_worker.sig_joystick.emit(x, y, self.panel.comm_panel.get_interval_sec(), flush)

    def _handle_algo_changed(self, name):
        self.comm.send_stop_cmd()
        self.brain_worker.sig_change_algo.emit(name)

    def _handle_nav_algo_changed(self, algo_name: str):
        self.brain.navigator.switch_algorithm(algo_name)
        self.monitor.append_log(f"🧭 [领航切换] 子船算法切换至: {algo_name}")

    def _handle_nav_cruise(self, speed: float):
        # 🧵 经 Worker 信号串行化，确保跨线程安全
        self.brain_worker.sig_nav_cruise.emit(speed)

    def _handle_auto_heading_toggled(self, checked, angle):
        self.brain_worker.sig_auto_heading.emit(checked, angle)
        if not checked and not self.brain.auto_speed_active:
            self.comm.send_stop_cmd()

    def _handle_auto_speed_toggled(self, checked, speed):
        self.brain_worker.sig_auto_speed.emit(checked, speed)
        if not checked and not self.brain.auto_heading_active:
            self.comm.send_stop_cmd()

    # ==========================================
    # 📢 供主窗口调用的公共 API
    # ==========================================
    def update_vision_target(self, target_data):
        """处理来自 ArUco 二维码的视觉数据，传给 Worker 线程中的 Brain"""
        self.brain_worker.sig_vision_target.emit(target_data)

    def update_vision_guidance(self, guidance):
        """将四码阶段引导送入 Worker，由现有速度/艏向PID执行。"""
        self.brain_worker.sig_vision_guidance.emit(guidance)

    def set_vision_dock_active(self, active: bool):
        """供UI调用: 开始或停止子船纯视觉运动对接控制 (🧵 Worker线程)"""
        self.brain_worker.sig_vision_dock_active.emit(active)

    # 子船高清录像控制中心
    def _handle_record_toggled(self, checked: bool):
        active_video_thread = self.comm.active_video_thread
        if not active_video_thread.is_running:
            self.monitor.append_log("❌ [错误] 视频流未连接，无法录制！")
            self.panel.btn_record.setChecked(False)
            return

        if checked:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"records/boat_video_{timestamp}.mp4"
            active_video_thread.start_recording(filename, fps=20)
            self.monitor.append_log(f"🎬 [录像开始] 原画保存至 {filename}")
        else:
            active_video_thread.stop_recording()
            self.monitor.append_log("🛑 [录像结束] 视频文件已安全封口。")

    def start_mission(self, coords):
        self.brain_worker.sig_start_mission.emit(coords)

    def stop_mission(self):
        self.brain_worker.sig_stop_mission.emit()

    def start_pose_return(self, config: dict):
        self.brain_worker.sig_pose_return_start.emit(config)

    def stop_pose_return(self):
        self.brain_worker.sig_pose_return_stop.emit()

    def set_repeat_separation_ratios(self, ratios=None):
        """循环试验分离阶段的最高优先级推力覆盖。"""
        if ratios is None:
            self._repeat_separation_ratios = None
            self.comm.send_stop_cmd()
            return
        values = [float(value) for value in ratios]
        if len(values) != 4:
            raise ValueError("分离推力必须包含4个通道")
        self._repeat_separation_ratios = values + [False]
        self.comm.send_control_ratios(*values, flush=True)

    def set_sensor_config(self, imu_en=None, imu_ms=None, gps_en=None, gps_ms=None):
        self.comm.update_sensor_config(imu_en, imu_ms, gps_en, gps_ms)

    def _handle_custom_feature(self):
        """🧪 测试数据注入 (直接emit到Worker线程处理)"""
        fmt = '> 5B 4H 2h 3H 2i B'
        payload = struct.pack(fmt, 0xBB, 0x02, 0x01, 99, 0x00, 1500, 1500, 1500, 1500, -100, 100, 9000, 9000, 0, 225431500, 1141235000, 10)
        mock_bytes = payload + struct.pack('>BB', sum(payload)&0xFF, 0xCC)
        self.brain_worker.sig_frame.emit(mock_bytes)

    # ==========================================
    # 🧹 线程清理
    # ==========================================
    def shutdown(self):
        """安全退出 Worker 线程"""
        self.fault_history_client.stop()
        self.fault_history_client.wait(3000)
        self.brain_thread.quit()
        self.brain_thread.wait(3000)
