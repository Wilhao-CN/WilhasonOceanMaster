# 文件路径: controllers/dock/dock_monitor.py
import numpy as np
from PyQt5.QtCore import QObject, Qt, pyqtSignal
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QLabel, QScrollArea, QWidget, QGroupBox, QDoubleSpinBox)

# ==========================================
# ==========================================
class TuningShellWindow(QDialog):
    def __init__(self, title="算法调参", parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(420, 550)
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        
        self.main_layout = QVBoxLayout(self)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.NoFrame)
        self.container = QWidget()
        self.content_layout = QVBoxLayout(self.container)
        self.scroll.setWidget(self.container)
        
        self.main_layout.addWidget(self.scroll)
        self.btn_close = QPushButton("确 定")
        self.btn_close.setFixedHeight(40)
        self.btn_close.clicked.connect(self.accept)
        self.main_layout.addWidget(self.btn_close)

    def set_content(self, h_ui, s_ui):
        """🚀 注入算法 UI 组件并安全清理"""
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

        has_any = False

        if h_ui:
            self.content_layout.addWidget(QLabel("<b>艏向控制参数 (Heading):</b>"))
            self.content_layout.addWidget(h_ui)
            has_any = True
            
        if s_ui:
            self.content_layout.addWidget(QLabel("<b>速度控制参数 (Speed):</b>"))
            self.content_layout.addWidget(s_ui)
            has_any = True
                        
        if not has_any:
            self.content_layout.addWidget(QLabel("该算法当前未提供可调节的参数。"))
            
        self.content_layout.addStretch()

# ==========================================
# 🖥️ [业务监视器] 船坞状态监控与弹窗管理
# ==========================================
class DockMonitor(QObject):
    def __init__(self, dock_panel, parent=None):
        super().__init__(parent)
        self.panel = dock_panel 
        self.tuning_window = None
        self.curr_heading_algo = None
        self.curr_speed_algo = None

    def refresh_ui_and_map(self, data: dict):
        self.panel.update_sensor_data(data)        
    def sync_widget_states(self, status: dict):
        if "auto_heading" in status:
            button = self.panel.btn_auto_heading
            previous = button.blockSignals(True)
            button.setChecked(status["auto_heading"])
            button.blockSignals(previous)
        if "auto_speed" in status:
            button = self.panel.btn_auto_speed
            previous = button.blockSignals(True)
            button.setChecked(status["auto_speed"])
            button.blockSignals(previous)

    def setup_algo_tuning_ui(self, heading_algo, speed_algo):
        self.curr_heading_algo = heading_algo
        self.curr_speed_algo = speed_algo

        if self.tuning_window and self.tuning_window.isVisible():
            self.tuning_window.close()
            self.tuning_window = None
            self.append_log("⚠️ [安全] 监测到船坞算法变更，调参窗口已强制销毁。")

    def open_tuning_window(self):
        if not self.curr_heading_algo and not self.curr_speed_algo:
            self.append_log("❌ [错误] 船坞当前未激活有效算法。")
            return

        if not self.tuning_window:
            self.tuning_window = TuningShellWindow(title="1号船坞 - 实时调参中心", parent=self.panel)
                    
        h_ui = self.curr_heading_algo.get_tuning_widget(self.tuning_window) if self.curr_heading_algo else None
        s_ui = self.curr_speed_algo.get_tuning_widget(self.tuning_window) if self.curr_speed_algo else None

        self.tuning_window.set_content(h_ui, s_ui)
        self.tuning_window.show()
        self.tuning_window.raise_()

    def distribute_video_frame(self, qimg):
        self.panel.update_video_frame(qimg)

    def append_log(self, text: str):
        self.panel.comm_panel.append_log(text)

    def clear_hex_input(self):
        if hasattr(self.panel.comm_panel, 'txt_hex_input'):
            self.panel.comm_panel.txt_hex_input.clear()

    def update_serial_light(self, connected: bool):
        self.panel.comm_panel.set_serial_light(connected)

    def update_net_light(self, connected: bool):
        self.panel.comm_panel.set_net_light(connected)

    def update_latency(self, metrics: dict):
        self.panel.comm_panel.set_latency_metrics(metrics)

    def update_fault_status(self, status: dict):
        """显示 MCU、树莓派和 4G 的综合状态。"""
        self.panel.update_fault_status(status)

