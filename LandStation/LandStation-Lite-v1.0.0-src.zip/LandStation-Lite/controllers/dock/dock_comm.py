# 文件路径: controllers/dock/dock_comm.py
from PyQt5.QtCore import QObject, pyqtSignal, QSize
from core.Thread.comm_thread import SerialThread
from core.Thread.network_thread import NetworkThread
from core.Thread.video_thread import VideoThread
from core.protocol import USVProtocol
from core.Thread.zmq_video_thread import ZmqVideoThread
class DockCommUnit(QObject):
    """
    ====================================================================
    🚢 船坞通信管理单元 (V9.0 仿真模式与逻辑对齐版)
    职责: 100% 还原双核通信链路与视频拉流链路，负责底层封包与硬件直接对话。
    特性: 保持强制串口控制传统，同时新增仿真模式下的指令网络重定向功能。
    ====================================================================
    """
    # --- 向上层(大脑和UI)汇报的原始信号 ---
    sig_frame_received = pyqtSignal(bytes)  # 收到完整传感器帧 (生肉字节流)
    sig_serial_status = pyqtSignal(bool)    # 串口连接状态
    sig_net_status = pyqtSignal(bool)       # 网络连接状态
    sig_log_triggered = pyqtSignal(str)     # 向上汇报日志
    sig_pwm_actual = pyqtSignal(int, int, int, int)  # 实际下发硬件的补偿后 PWM

    def __init__(self, parent=None):
        super().__init__(parent)
        
        # --- 1. 100% 还原三大底层物理线程 ---
        self.serial_thread = SerialThread(parent=self)
        self.network_thread = NetworkThread(parent=self, device_id=0x01)
        # 💡 [关键保留] 初始化参数 camera_source=0 保持不变
        self.video_thread = VideoThread(parent=self)
        self.sim_video_thread = ZmqVideoThread(parent=self)
        
        # --- 2. 💡 [逻辑对齐] 硬件状态镜像与仿真标志 ---
        self.is_simulation = False # 默认为真实硬件模式 (强制串口发送)
        self.hw_tx_link = "serial"  # 💡 [新增] 存储硬件模式下的指令链路状态 ('serial' 或 'network')
        
        self.relay_mirror = [0, 0, 0, 0, 0, 0]
        self.sensor_mirror = {
            "imu_en": 0x01, "imu_ms": 100,
            "gps_en": 0x01, "gps_ms": 100
        }

        self._bind_internal_signals()

    def _bind_internal_signals(self):
        """将底层三个物理线程的原始信号汇聚，统一向上层发射"""
        # 💡 [核心对齐] 串口和网络回传数据并行监听
        self.serial_thread.sig_frame_received.connect(self.sig_frame_received)
        self.serial_thread.connection_status.connect(self.sig_serial_status)
        self.serial_thread.sig_debug_log.connect(self.sig_log_triggered)
        
        self.network_thread.sig_frame_received.connect(self.sig_frame_received)
        self.network_thread.connection_status.connect(self.sig_net_status)
        self.network_thread.sig_debug_log.connect(self.sig_log_triggered)
        
        # 💡 [关键保留] 视频链路异常必须向上层抛出日志
        self.video_thread.sig_error.connect(
            lambda m: self.sig_log_triggered.emit(f"[视频异常] {m}")
        )
        self.sim_video_thread.sig_error.connect(
            lambda m: self.sig_log_triggered.emit(f"[仿真视频异常] {m}")
        )
    # ==========================================
    # 🔀 核心路由逻辑 (仿真重定向)
    # ==========================================
    def set_mode(self, mode_str: str):
        """切换运行模式：serial (真实硬件) / network (仿真模拟)"""
        self.is_simulation = (mode_str == "network")
        status_text = "🧪 仿真模拟" if self.is_simulation else "🔌 真实硬件"
        self.sig_log_triggered.emit(f"🔄 [系统] 船坞指令发送路径切换至: {status_text} 模式")

    @property
    def active_tx_thread(self):
        """
        核心路由：决定【控制指令】从哪条物理链路出去
        """
        # 1. 仿真模式：强制走本地网络
        if self.is_simulation:
            return self.network_thread
        
        # 2. 真实硬件模式：根据 UI 切换结果路由
        if self.hw_tx_link == "network":
            # 💡 指令将通过 4G UDP 链路发送 (端口 8881)
            return self.network_thread
        else:
            # 💡 默认走 LORA 串口链路
            return self.serial_thread

    # ==========================================
    # 🔗 链路生命周期管理 (100% 还原原版连接逻辑)
    # ==========================================
    def open_serial(self, port: str, baud: int):
        """打开串口监听"""
        return self.serial_thread.open_port(port, baud)

    def close_serial(self):
        """关闭串口监听"""
        self.serial_thread.close_port()

    def open_network_and_video(self, ip: str, tx_port: int, rx_port: int, v_port: int, target_video_size: QSize):
        """处理网络连接，并同步开启视频流"""
        if self.network_thread.connect_network(ip, tx_port, rx_port):
            self.sig_log_triggered.emit(f"🌐 [船坞数据] 已开启 UDP 监听: {ip}:{rx_port}")

            # 💡 [核心修改] 视频路由判断：开启哪个视频流？
            if self.is_simulation:
                # 仿真模式：启动 ZMQ 线程，强制监听 5001 端口
                self.sim_video_thread.set_connection_params(ip, 5001)
                self.sim_video_thread.start_video()
                self.sig_log_triggered.emit(f"💻 [孪生视频] 船坞 TCP 拉流已启动 (Port: 5001)")
            else:
                # 真实模式：启动 UDP 线程，监听 UI 传来的端口
                self.video_thread.set_listen_port(v_port)
                if target_video_size:
                    self.video_thread.set_target_size(target_video_size)
                self.video_thread.start_video()
                self.sig_log_triggered.emit(f"📹 [实体视频] 船坞 UDP 监听已启动 (Port: {v_port})")
            return True
        return False

    def close_network_and_video(self):
            """同时断开网络与所有视频"""
            self.network_thread.close_port()
            self.video_thread.stop_video()
            self.sim_video_thread.stop_video() # 💡 安全停掉仿真视频
            self.sig_log_triggered.emit("🔌 [网络] 船坞实体与孪生视频链路已断开")

    @property
    def active_video_thread(self):
        """返回当前模式真正使用的视频线程。"""
        return self.sim_video_thread if self.is_simulation else self.video_thread

    @property
    def is_serial_active(self):
        """暴露串口活跃状态供 Brain 判断"""
        return self.serial_thread.is_running

    # ==========================================
    # 🚀 核心指令下发 (ID: 01, 动态路由至 active_tx_thread)
    # ==========================================
    def send_control_ratios(self, r1: float, r2: float, r3: float, r4: float, flush: bool = False):
        """
        子船指令下发。
        💡 注意：子船物理上仅有 2 个推进器（r1:左, r2:右）。
        r3 和 r4 在大脑端已固定为 0.0，此处保留参数仅为兼容 33 字节统一协议包。
        """
        target_thread = self.active_tx_thread
        if not target_thread.is_running: return

        # 计算补偿后的实际 PWM (供 UI 显示)
        ap1 = USVProtocol._apply_compensation(0x01, 1, r1)
        ap2 = USVProtocol._apply_compensation(0x01, 2, r2)
        ap3 = USVProtocol._apply_compensation(0x01, 3, r3)
        ap4 = USVProtocol._apply_compensation(0x01, 4, r4)
        self.sig_pwm_actual.emit(ap1, ap2, ap3, ap4)

        # 打包 33 字节指令
        cmd_bytes = USVProtocol.pack_control_cmd(
            target_id=0x01, mode=0x01,
            pwm1=r1, pwm2=r2, pwm3=r3, pwm4=r4,
            relays=self.relay_mirror, **self.sensor_mirror
        )

        # 💡 [关键修改] 调用底层 send_data 时透传 flush 标志
        # 确保在手动推杆时，串口能清空旧数据，只发最热乎的这一帧
        target_thread.send_data(cmd_bytes, flush=flush)

    def send_stop_cmd(self, flush: bool = True):
        """
        💡 [瞬间刹车] 下发 1500 中位停止指令。
        默认开启 flush，确保清空缓冲区积压，实现“松手即停”。
        """
        target_thread = self.active_tx_thread
        if not target_thread.is_running: return
        
        stop_cmd = USVProtocol.pack_control_cmd(
            target_id=0x01, mode=0x01, 
            pwm1=1500, pwm2=1500, pwm3=1500, pwm4=1500, 
            relays=self.relay_mirror, **self.sensor_mirror
        )
        # 强制刷新缓冲区并发送停止指令
        target_thread.send_data(stop_cmd, flush=flush)

    def send_init(self):
        """系统初始化指令"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running: return
        self.relay_mirror = [1, 1, 1, 1, 1, 1]
        self.sensor_mirror = {"imu_en": 0x01, "imu_ms": 100, "gps_en": 0x01, "gps_ms": 100}
        cmd_bytes = USVProtocol.get_init_cmd(target_id=0x01)
        target_thread.send_data(cmd_bytes)
        # 触发 IMU 静态零偏校准
        calib_bytes = USVProtocol.pack_imu_calib_cmd(target_id=0x01)
        target_thread.send_data(calib_bytes)
        self.sig_log_triggered.emit(f"⚙️ [TX-初始化] 船坞动力上锁 + IMU零偏校准 (ID:01)")

    def send_estop(self) -> bool:
        """急停指令：彻底锁死硬件，返回 True 表示已成功送入发送队列"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running:
            self.sig_log_triggered.emit("❌ [急停失败] 船坞通信线程未启动，请先连接串口或网络！")
            return False
        # 🔒 [关键] 同步更新镜像状态，防止后续 send_control_ratios 用旧值覆盖急停
        self.relay_mirror = [0, 0, 0, 0, 1, 0]
        self.sensor_mirror = {"imu_en": 0x00, "imu_ms": 0, "gps_en": 0x00, "gps_ms": 0}
        stop_cmd = USVProtocol.get_estop_cmd(target_id=0x01)
        target_thread.send_data(stop_cmd)
        self.sig_log_triggered.emit(f"🛑 [TX-急停] 船坞急停指令已下发 (ID:01) {USVProtocol.bytes_to_hex_str(stop_cmd)}")
        return True

    def send_gps_calib(self, target_id: int, lat_off: float, lon_off: float):
        """GPS校准偏移下发单片机"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running:
            return
        cmd_bytes = USVProtocol.pack_gps_calib_cmd(target_id, lat_off, lon_off)
        target_thread.send_data(cmd_bytes)
        self.sig_log_triggered.emit(
            f"📡 [GPS校准] 已下发至 ID:{target_id} ΔLat:{lat_off:.7f} ΔLon:{lon_off:.7f}"
        )

    def send_ekf_cmd(self, target_id: int, enable: bool):
        """EKF启停控制下发"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running:
            return
        cmd_bytes = USVProtocol.pack_ekf_cmd(target_id, enable)
        target_thread.send_data(cmd_bytes)
        tag = "启动" if enable else "关闭"
        self.sig_log_triggered.emit(f"🧠 [EKF控制] ID:{target_id} EKF已{tag}")

    def send_imu_deadband(self, target_id: int, deadband: float):
        """IMU角速度积分死区配置下发"""
        target_thread = self.active_tx_thread
        if not target_thread.is_running:
            return
        cmd_bytes = USVProtocol.pack_imu_deadband_cmd(target_id, deadband)
        target_thread.send_data(cmd_bytes)
        hex_str = USVProtocol.bytes_to_hex_str(cmd_bytes)
        self.sig_log_triggered.emit(
            f"📐 [IMU死区] ID:{target_id} 死区={deadband:.2f}°/s | "
            f"下发 {len(cmd_bytes)} 字节: {hex_str}"
        )

    def send_raw_hex(self, hex_text: str):
        """处理手动 HEX 指令输入"""
        try:
            target_thread = self.active_tx_thread
            data = bytes.fromhex(hex_text.replace(' ', ''))
            target_thread.send_data(data)
            mode_tag = "仿真" if self.is_simulation else "串口"
            self.sig_log_triggered.emit(f"[TX-{mode_tag}HEX] {hex_text.upper()}")
            return True
        except ValueError:
            self.sig_log_triggered.emit("[警告] HEX 格式无效")
            return False
    def set_hw_tx_link(self, mode_str: str):
        """
        💡 [新增] 接收来自 UI 的切换信号
        mode_str: 'serial' (LORA) 或 'network' (4G)
        """
        self.hw_tx_link = mode_str
        tag = "🌐 4G网络" if mode_str == "network" else "📡 LORA串口"
        self.sig_log_triggered.emit(f"🔄 [链路切换] 指令下发路径已切换至: {tag}")
    def update_sensor_config(self, imu_en=None, imu_ms=None, gps_en=None, gps_ms=None):
        """传感器配置暂存镜像"""
        if imu_en is not None: self.sensor_mirror["imu_en"] = imu_en
        if imu_ms is not None: self.sensor_mirror["imu_ms"] = imu_ms
        if gps_en is not None: self.sensor_mirror["gps_en"] = gps_en
        if gps_ms is not None: self.sensor_mirror["gps_ms"] = gps_ms
        self.sig_log_triggered.emit(f"📝 [同步] 船坞传感器配置已暂存")
