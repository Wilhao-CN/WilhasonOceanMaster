# 文件路径: controllers/dock/dock_worker.py
"""
====================================================================
🧵 DockBrainWorker — 运行在专用 QThread 的 QObject 包装器 (V1.0)
职责: 将 DockBrain 的所有数据处理移出主线程，仅在 Worker 线程中执行。
      UI 更新通过信号跨线程回到主线程 (Qt 自动 QueuedConnection)。
====================================================================
"""
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot
from controllers.dock.dock_brain import DockBrain


class DockBrainWorker(QObject):
    """
    ====================================================================
    船坞大脑工作线程对象

    输入: 通过 input signals 接收主线程发来的指令
    处理: 在 Worker 线程中执行 Brain 的全部逻辑 (PID/导航/数据解析)
    输出: 转发 Brain 的输出信号到主线程 (Qt 自动 QueuedConnection)

    关键设计:
    - Worker 拥有 Brain 实例，Brain 的所有发射信号在 Worker 线程中执行
    - 主线程通过 emit input signals 来触发 Worker 中的方法
    - 主线程连接 Worker 的 output signals 来接收处理结果
    ====================================================================
    """

    # ==========================================
    # 🔽 输入信号 (主线程 → Worker 线程)
    # 外部通过 emit 这些信号来触发 Worker 线程中的处理
    # ==========================================
    sig_frame = pyqtSignal(bytes)                        # 原始 59 字节传感器帧
    sig_joystick = pyqtSignal(float, float, float, bool)  # x, y, interval_sec, flush
    sig_estop = pyqtSignal()                             # 急停
    sig_start_mission = pyqtSignal(list)                  # 坐标列表启动任务
    sig_stop_mission = pyqtSignal()                       # 停止任务
    sig_auto_heading = pyqtSignal(bool, float)            # 定艏 开关 + 目标角度
    sig_auto_speed = pyqtSignal(bool, float)              # 定速 开关 + 目标速度
    sig_step_target = pyqtSignal(float, float)            # 步进微调 d_speed, d_heading
    sig_change_algo = pyqtSignal(str)                     # 切换 PID 算法
    sig_steady_hold_start = pyqtSignal(float, float)      # 到点稳停 lat, lon
    sig_steady_hold_stop = pyqtSignal()                   # 停止稳停
    sig_return_home_start = pyqtSignal()                  # 一键返航
    sig_target_heading_abs = pyqtSignal(float)            # 绝对航向设置
    sig_target_speed_abs = pyqtSignal(float)              # 绝对速度设置
    sig_pose_return_start = pyqtSignal(dict)              # 循环试验位姿返航
    sig_pose_return_stop = pyqtSignal()
    sig_docking_hold = pyqtSignal(bool)                  # boat docking -> dock heading hold
    sig_nof_centering_active = pyqtSignal(bool)          # NOF 视觉居中伺服 启停
    sig_nof_offset = pyqtSignal(float)                    # NOF 框中心归一化水平偏移
    sig_boat_position = pyqtSignal(float, float)          # 子船 GPS 中点 → 船坞（方位角兜底）
    sig_heading_source = pyqtSignal(str)                 # 船坞控制艏向源
    sig_nav_cruise = pyqtSignal(float)                   # P2P/LOS 领航巡航速度

    # ==========================================
    # 🔼 输出信号 (Worker 线程 → 主线程)
    # 直接转发 Brain 的信号，Qt 会自动使用 QueuedConnection
    # ==========================================
    sig_data_parsed = pyqtSignal(dict)
    sig_control_ratios_ready = pyqtSignal(float, float, float, float, bool)
    sig_status_changed = pyqtSignal(dict)
    sig_mission_log = pyqtSignal(str)
    sig_manual_override = pyqtSignal()
    sig_algo_tuning_ui_ready = pyqtSignal(object, object, object)
    sig_target_sync = pyqtSignal(float, float)
    sig_return_home = pyqtSignal(float, float)

    def __init__(self, mission_manager, parent=None):
        super().__init__(parent)
        # 创建 Brain — 在 __init__ 时所属线程尚未确定，
        # moveToThread 后 Brain 会跟随 Worker 一起迁移
        self.brain = DockBrain(mission_manager)

        # ---- 桥接: 输入信号 → Brain 方法 (同一线程内 DirectConnection) ----
        self.sig_frame.connect(self._on_frame)
        self.sig_joystick.connect(self._on_joystick)
        self.sig_estop.connect(self._on_estop)
        self.sig_start_mission.connect(self._on_start_mission)
        self.sig_stop_mission.connect(self._on_stop_mission)
        self.sig_auto_heading.connect(self._on_auto_heading)
        self.sig_auto_speed.connect(self._on_auto_speed)
        self.sig_step_target.connect(self._on_step_target)
        self.sig_change_algo.connect(self._on_change_algo)
        self.sig_steady_hold_start.connect(self._on_steady_hold_start)
        self.sig_steady_hold_stop.connect(self._on_steady_hold_stop)
        self.sig_return_home_start.connect(self._on_return_home_start)
        self.sig_target_heading_abs.connect(self._on_target_heading_abs)
        self.sig_target_speed_abs.connect(self._on_target_speed_abs)
        self.sig_pose_return_start.connect(self._on_pose_return_start)
        self.sig_pose_return_stop.connect(self._on_pose_return_stop)
        self.sig_docking_hold.connect(self._on_docking_hold)
        self.sig_nof_centering_active.connect(self._on_nof_centering_active)
        self.sig_nof_offset.connect(self._on_nof_offset)
        self.sig_boat_position.connect(self._on_boat_position)
        self.sig_heading_source.connect(self._on_heading_source)
        self.sig_nav_cruise.connect(self._on_nav_cruise)

        # ---- 转发: Brain 输出信号 → Worker 输出信号 ----
        self.brain.sig_data_parsed.connect(self.sig_data_parsed)
        self.brain.sig_control_ratios_ready.connect(self.sig_control_ratios_ready)
        self.brain.sig_status_changed.connect(self.sig_status_changed)
        self.brain.sig_mission_log.connect(self.sig_mission_log)
        self.brain.sig_manual_override.connect(self.sig_manual_override)
        self.brain.sig_algo_tuning_ui_ready.connect(self.sig_algo_tuning_ui_ready)
        self.brain.sig_target_sync.connect(self.sig_target_sync)
        self.brain.sig_return_home.connect(self.sig_return_home)

    # ==========================================
    # 🔧 内部处理方法 (全部在 Worker 线程执行)
    # ==========================================
    @pyqtSlot(bytes)
    def _on_frame(self, frame_bytes: bytes):
        self.brain.process_sensor_data(frame_bytes)

    @pyqtSlot(float, float, float, bool)
    def _on_joystick(self, x, y, interval_sec, flush):
        self.brain.process_joystick(x, y, interval_sec, flush)

    @pyqtSlot()
    def _on_estop(self):
        self.brain.process_estop()

    @pyqtSlot(list)
    def _on_start_mission(self, coords):
        self.brain.start_mission(coords)

    @pyqtSlot()
    def _on_stop_mission(self):
        self.brain.stop_mission()

    @pyqtSlot(bool, float)
    def _on_auto_heading(self, active, target_heading):
        self.brain.set_auto_heading(active, target_heading)

    @pyqtSlot(bool, float)
    def _on_auto_speed(self, active, target_speed):
        self.brain.set_auto_speed(active, target_speed)

    @pyqtSlot(float, float)
    def _on_step_target(self, d_speed, d_heading):
        self.brain.step_target(d_speed, d_heading)

    @pyqtSlot(str)
    def _on_change_algo(self, name):
        self.brain.change_algorithm(name)

    @pyqtSlot(float, float)
    def _on_steady_hold_start(self, lat, lon):
        self.brain.start_steady_hold(lat, lon)

    @pyqtSlot()
    def _on_steady_hold_stop(self):
        self.brain.stop_steady_hold()

    @pyqtSlot()
    def _on_return_home_start(self):
        self.brain.start_return_home()

    @pyqtSlot(float)
    def _on_target_heading_abs(self, heading):
        self.brain.set_target_heading_absolute(heading)

    @pyqtSlot(float)
    def _on_target_speed_abs(self, speed):
        self.brain.set_target_speed_absolute(speed)

    @pyqtSlot(dict)
    def _on_pose_return_start(self, config):
        self.brain.start_pose_return(config)

    @pyqtSlot()
    def _on_pose_return_stop(self):
        self.brain.stop_pose_return()

    @pyqtSlot(bool)
    def _on_docking_hold(self, active):
        self.brain.set_docking_hold_active(active)

    @pyqtSlot(bool)
    def _on_nof_centering_active(self, active):
        self.brain.set_nof_centering_active(active)

    @pyqtSlot(float)
    def _on_nof_offset(self, offset_x):
        self.brain.update_nof_offset(offset_x)

    @pyqtSlot(float, float)
    def _on_boat_position(self, lat, lon):
        self.brain.set_boat_position(lat, lon)

    @pyqtSlot(str)
    def _on_heading_source(self, source):
        self.brain.set_heading_source(source)

    @pyqtSlot(float)
    def _on_nav_cruise(self, speed):
        self.brain.set_nav_cruise_speed(speed)

