# 文件路径: controllers/dock/dock_brain.py
import time
from pathlib import Path
from PyQt5.QtCore import QObject, pyqtSignal
from core.PID_controller.pid_controller import HeadingPIDController, StandardPIDController 
from core.Managers.navigator_manager import MissionNavigator
from core.heading_source import (
    HEADING_SOURCE_DUAL_GPS,
    HEADING_SOURCE_EKF,
    select_control_heading,
)
from core.utils import CoordUtils
from core.pose_return import PoseReturnGuidance
from core.protocol import USVProtocol  # 💡 [关键补充] 必须引入协议栈进行数据解析
from PyQt5.QtCore import QTimer
import math
class DockBrain(QObject):
    """
    ====================================================================
    🧠 船坞逻辑决策大脑 (V8.1 GPS校准集成版)
    职责: 100% 还原状态机、自动任务领航、PID 闭环与手柄抢占逻辑。
    ====================================================================
    """
    # --- 核心输出信号 ---
    sig_control_ratios_ready = pyqtSignal(float, float, float, float, bool)
    sig_data_parsed = pyqtSignal(dict)
    sig_status_changed = pyqtSignal(dict)
    sig_mission_log = pyqtSignal(str)
    sig_manual_override = pyqtSignal()
    sig_algo_tuning_ui_ready = pyqtSignal(object, object, object)
    sig_target_sync = pyqtSignal(float, float)
    sig_return_home = pyqtSignal(float, float)  # 🏠 一键返航：通知地图打标记

    def __init__(self, mission_manager, parent=None):
        """
        💡 修改：注入 mission_manager 引用
        """
        super().__init__(parent)
        self.mission_manager = mission_manager # 存储任务管理器引用
        # --- 1. 业务状态位 ---
        self.auto_heading_active = False
        self.target_heading = 0.0
        self.auto_speed_active = False
        self.target_speed = 0.0
        self.docking_hold_active = False
        self.current_heading = 0.0
        self.heading_source = HEADING_SOURCE_EKF
        self.last_sensor_time = None

        # 🎯 NOF 视觉居中伺服状态 (YOLO 检出 NOF 大框后接管船坞转向)
        self.nof_centering_active = False
        self.nof_offset_x = 0.0      # 归一化中心偏移 (-0.5 ~ +0.5, 正=目标偏右)
        self.nof_offset_time = 0.0   # 最近一次 NOF 偏移更新时间 (perf_counter)
        self.nof_yaw_kp = 0.6        # 视觉转向比例增益
        self.nof_yaw_deadband = 0.03 # 框中心偏移死区 (归一化)
        self.nof_stale_timeout = 0.5 # 目标丢失超过此时长则停止转向 (秒)

        # 🎯 NOF 视觉 ↔ GPS 相对方位角 兜底状态机
        self.nof_visual_state = "VISUAL"   # VISUAL(视觉居中) / BEARING(方位角PID)
        self.nof_lost_count = 0            # 连续丢失计数
        self.nof_seen_count = 0            # 连续可见计数
        self.nof_lose_frames = 3           # 连续丢 3 帧退到方位角 PID
        self.nof_reacquire_frames = 5      # 连续重连 5 帧回到视觉 (滞回防抖)
        self.boat_lat = None               # 子船 GPS 中点 (供方位角兜底)
        self.boat_lon = None
        self.boat_pos_time = 0.0
        self.current_lat = None            # 本船当前位置
        self.current_lon = None
        
        self.last_pid_time = 0.0
        self.last_joy_send_time = 1.0 
        
        self.current_wp_index = -1     
        self.is_mission_active = False
        self.control_algorithm_name = "PID 经典控制"
        
        # --- 核心初始化：软件速度解算变量 ---
        self.last_gps_pos = None     
        self.last_gps_time = None    
        self.smooth_speed = 0.0      
        # --- 一键返航常量 ---
        self.HOME_LAT = 23.014    # 23°00'50.4"N 船坞停靠点
        self.HOME_LON = 113.398   # 113°23'52.8"E

        # --- 到点稳停 (Steady Hold) 状态变量 ---
        self.steady_hold_active = False
        self.steady_hold_target = (0.0, 0.0)
        self.pose_return = PoseReturnGuidance()
        # --- 状态变量 ---
        self.last_commanded_pwms = [1500, 1500, 1500, 1500] # 🚀 新增：用来映射给 UI 的 PWM 缓存
        # --- 2. 算法池 ---
        self.navigator = MissionNavigator(arrival_threshold=2.0, default_speed=0.3)

        # 🛡️ 速度指令保护参数
        self.max_physical_speed = 2.0     # 船体物理极速 (m/s)
        self.speed_rate_limit = 0.5       # 最大加速度 (m/s²)
        self._smooth_target_speed = 0.0   # 变化率限幅后的平滑速度
        self._last_speed_update_time = time.time()

        self.heading_algos = {
            "PID 经典控制": HeadingPIDController(kp=3.0, ki=0.1, kd=1.5, deadband=5.0),
        }
        self.speed_algos = {
            "PID 经典控制": StandardPIDController(kp=150.0, ki=10.0, kd=0.0),
        }
        self.active_heading_algo = self.heading_algos["PID 经典控制"]
        self.active_speed_algo = self.speed_algos["PID 经典控制"]
        
        QTimer.singleShot(500, lambda: self.sig_algo_tuning_ui_ready.emit(self.active_heading_algo, self.active_speed_algo, None))
        self.cached_auto_ratios = [0.0, 0.0, 0.0, 0.0, False]
    def set_heading_source(self, source: str):
        """切换船坞闭环控制使用的当前艏向。"""
        if source not in (HEADING_SOURCE_EKF, HEADING_SOURCE_DUAL_GPS):
            return
        self.heading_source = source
        source_name = "双GPS艏向" if source == HEADING_SOURCE_DUAL_GPS else "EKF融合艏向"
        self.sig_mission_log.emit(f"🎛 [艏向源] 船坞控制已切换为{source_name}")

    def set_nav_cruise_speed(self, speed: float):
        """运行时更新 P2P/LOS 领航器的默认巡航速度（下一帧立即生效）。"""
        self.navigator.default_speed = max(0.0, float(speed))
        self.sig_mission_log.emit(
            f"🧭 [领航巡航] 船坞巡航速度已设为 {self.navigator.default_speed:.2f} m/s"
        )

    def _get_control_heading(self, imu_data: dict) -> float:
        return select_control_heading(imu_data, self.heading_source)

    def _get_thruster_ratio_limits(self, thruster_indices: list):
        """
        从 USVProtocol.USV_CONFIGS 反算推进器比例的有效限幅范围
        与 UI 推进器配置弹窗联动，动态钳位 PID 输出
        返回: (min_ratio, max_ratio) — 多通道综合最保守限幅
        ⚠ 不要加 @staticmethod：调用方是 `self._get_thruster_ratio_limits(idx)`，
          加了会把实参吃进 self，报 missing positional argument（实测踩过）。
        """
        target_id = 0x01
        default_cfg = {"min": 1300, "max": 1800, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400}
        ship_configs = USVProtocol.USV_CONFIGS.get(target_id, {})
        min_ratios, max_ratios = [], []
        for idx in thruster_indices:
            cfg = ship_configs.get(idx, default_cfg)
            max_r = (cfg["max"] - 1500 - cfg["pos"]) / cfg["slope_pos"] if cfg["slope_pos"] > 0 else 1.0
            min_r = (cfg["min"] - 1500 + cfg["neg"]) / cfg["slope_neg"] if cfg["slope_neg"] > 0 else -1.0
            min_ratios.append(min_r)
            max_ratios.append(max_r)
        return (max(min_ratios), min(max_ratios))

    def _clamp_with_limits(self, ratio: float, thruster_indices: list) -> float:
        """使用推进器限幅对单路比例进行钳位"""
        lo, hi = self._get_thruster_ratio_limits(thruster_indices)
        return max(lo, min(hi, ratio))

    def start_steady_hold(self, lat, lon):
        self.docking_hold_active = False
        self.steady_hold_active = True
        self.steady_hold_target = (lat, lon)
        coords = [[lat, lon]]
        self.navigator.set_path(coords)
        self.is_mission_active = True
        self.auto_heading_active = True
        self.auto_speed_active = True
        self.sig_status_changed.emit({"auto_heading": True, "auto_speed": True})
        self.sig_mission_log.emit(f"🧭 [到点稳停] 目标已锁定: Lat {lat:.6f}, Lon {lon:.6f}，P2P 导航中...")

    def stop_steady_hold(self):
        self.docking_hold_active = False
        self.steady_hold_active = False
        self.is_mission_active = False
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.navigator.stop()
        self.sig_mission_log.emit("🛑 [到点稳停] 任务结束，船只可自由移动。")
        self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0, True)

    def start_return_home(self):
        """🎯 一键返航：P2P 导航返回船坞停靠点 (23°00'50.4"N 113°23'52.8"E)"""
        self.start_steady_hold(self.HOME_LAT, self.HOME_LON)
        self.sig_return_home.emit(self.HOME_LAT, self.HOME_LON)
        self.sig_mission_log.emit(
            f"🏠 [一键返航] P2P返航中 → 停靠点: "
            f"Lat {self.HOME_LAT:.6f}, Lon {self.HOME_LON:.6f}"
        )

    def _apply_speed_limits(self, requested_speed: float) -> float:
        """
        🛡️ 速度指令保护：绝对物理上限 + 变化率限幅
        防止外环指令跳变导致内环 PID 积分饱和
        """
        now = time.time()
        dt = now - self._last_speed_update_time
        self._last_speed_update_time = now

        # 第一层：绝对物理上限
        clamped = max(0.0, min(self.max_physical_speed, requested_speed))

        # 第二层：变化率限幅 (防止指令跳变)
        if dt > 0 and dt < 1.0:
            max_delta = self.speed_rate_limit * dt
            delta = clamped - self._smooth_target_speed
            delta = max(-max_delta, min(max_delta, delta))
            self._smooth_target_speed += delta
        else:
            self._smooth_target_speed = clamped

        return self._smooth_target_speed

    def process_sensor_data(self, frame_bytes: bytes):
        """处理传感器回传数据，执行闭环控制"""
        parsed_data = USVProtocol.parse_sensor_data(frame_bytes)
        
        # 放宽条件：允许船坞(0x01)和子船(0x02)的数据通过
        if not parsed_data or parsed_data.get("id") != 0x01:
            return

        # --- MCU已自行校准，坐标直接使用 ---
        curr_lat = (parsed_data["gps"]["lat"] + parsed_data["gps_B"]["lat"]) / 2.0
        curr_lon = (parsed_data["gps"]["lon"] + parsed_data["gps_B"]["lon"]) / 2.0
        curr_time = time.perf_counter()
        self.current_lat = curr_lat
        self.current_lon = curr_lon

        gps_speed = parsed_data["gps"]["speed"]
        control_heading = self._get_control_heading(parsed_data["imu"])
        self.current_heading = CoordUtils.normalize_angle(control_heading)
        parsed_data["imu"]["control_heading"] = control_heading
        parsed_data["imu"]["control_heading_source"] = self.heading_source
        self.last_sensor_time = curr_time

        # 原有：用于简单 UI 显示的标量速度
        self.smooth_speed = (self.smooth_speed * 0.7) + (gps_speed * 0.3)
        parsed_data["calculated_speed"] = self.smooth_speed


        if self.last_gps_pos is not None and self.last_gps_time is not None:
            dt = curr_time - self.last_gps_time
            if dt > 0.001:
                dist, _ = CoordUtils.calculate_distance_and_bearing(
                    self.last_gps_pos[0], self.last_gps_pos[1], curr_lat, curr_lon
                )
                instant_speed = dist / dt
                self.smooth_speed = (self.smooth_speed * 0.7) + (instant_speed * 0.3)
                parsed_data["calculated_speed"] = self.smooth_speed

        self.last_gps_pos = (curr_lat, curr_lon)
        self.last_gps_time = curr_time

        parsed_data["targets"] = {
            "heading": self.target_heading if (self.auto_heading_active or self.is_mission_active) else None,
            "speed": self.target_speed if (self.auto_speed_active or self.is_mission_active) else 0.0
        }

        # 发射信号 (UI 和地图接收到的已是修正坐标)
        self.sig_data_parsed.emit(parsed_data)

        # 循环试验专用位姿返航，不改变普通任务导航器的到点逻辑。
        if self.pose_return.active:
            command = self.pose_return.update(curr_lat, curr_lon, control_heading)
            if command.get("phase_changed") and command.get("phase") == "align":
                self.active_speed_algo.reset()
            self.target_heading = command["target_heading"]
            self.target_speed = self._apply_speed_limits(command["target_speed"])
            self.sig_target_sync.emit(self.target_speed, self.target_heading)

        # 领航员逻辑 (基于修正后的真值)
        elif self.is_mission_active:
            target_h, target_s, dist_wp, is_finished = self.navigator.update(
                curr_lat, curr_lon, curr_heading=control_heading
            )
            
            if is_finished:
                self.sig_mission_log.emit(
                    f"✅ [任务] 已到达第 {len(self.navigator.mission_path)} 个航点"
                )
                if self.steady_hold_active:
                    tgt_lat, tgt_lon = self.steady_hold_target
                    self.navigator.set_path([[tgt_lat, tgt_lon]])
                    self.current_wp_index = -1
                else:
                    self.sig_mission_log.emit("🏁 [任务] 船坞任务圆满完成！")
                    self.stop_mission()
                    self.current_wp_index = -1
            else:
                self.target_heading = target_h
                self.target_speed = self._apply_speed_limits(target_s)
                self.sig_target_sync.emit(self.target_speed, self.target_heading)
                
                if self.navigator.current_wp_index != self.current_wp_index:
                    if self.current_wp_index >= 0:
                        self.sig_mission_log.emit(
                            f"✅ [任务] 已到达第 {self.current_wp_index + 1} 个航点"
                        )
                    self.current_wp_index = self.navigator.current_wp_index
                    self.sig_mission_log.emit(
                        f"📍 [任务] 切换目标：前往第 {self.current_wp_index + 1} 个航点，距离目标 {dist_wp:.1f}m"
                    )

        # 控制指令生成。普通自动控制由 PID 闭环唯一接管。
        current_time = time.time()
        dt = current_time - self.last_pid_time
        if dt <= 0 or dt > 1.0: dt = 0.05

        if self.nof_centering_active:
            # 🎯 NOF 视觉对接控制：视觉居中优先，失锁时退到 GPS 相对方位角 PID。
            # 优先级高于 PID 策略，确保视觉接管时不会被其它控制覆盖。
            visible = (time.perf_counter() - self.nof_offset_time) <= self.nof_stale_timeout

            # 滞回状态机：丢 N 帧退到方位角，重连 M 帧回到视觉 (M > N 防抖)
            if visible:
                self.nof_seen_count += 1
                self.nof_lost_count = 0
            else:
                self.nof_lost_count += 1
                self.nof_seen_count = 0

            if self.nof_visual_state == "VISUAL" and self.nof_lost_count >= self.nof_lose_frames:
                self.nof_visual_state = "BEARING"
                self.active_heading_algo.reset()
                self.sig_mission_log.emit(
                    "⚠️ [NOF对接] 视觉目标连续丢失，已退到 GPS 相对方位角 PID。"
                )
            elif self.nof_visual_state == "BEARING" and self.nof_seen_count >= self.nof_reacquire_frames:
                self.nof_visual_state = "VISUAL"
                self.sig_mission_log.emit(
                    "✅ [NOF对接] 视觉目标重连，已恢复视觉居中伺服。"
                )

            s_ratio = 0.0
            if self.nof_visual_state == "VISUAL":
                h_ratio = self._compute_nof_yaw_ratio()
            else:
                h_ratio = self._compute_bearing_yaw_ratio(dt)

            self.cached_auto_ratios = [s_ratio, h_ratio, -h_ratio, s_ratio, False]
            self.last_pid_time = current_time
            self.last_commanded_pwms = [
                int(1500 + s_ratio * 500),
                int(1500 + h_ratio * 500),
                int(1500 + (-h_ratio) * 500),
                int(1500 + s_ratio * 500)
            ]
        elif (
            self.control_algorithm_name == "PID 经典控制"
            and (self.auto_heading_active or self.auto_speed_active)
        ):
            s_ratio = self.active_speed_algo.compute(
                parsed_data["gps"]["speed"], self.target_speed, dt
            ) if self.auto_speed_active else 0.0
            h_ratio = self.active_heading_algo.compute(
                control_heading, self.target_heading, dt
            ) if self.auto_heading_active else 0.0

            # 🔗 推进器限幅联动：根据 UI 配置动态钳位 PID 输出
            s_ratio = self._clamp_with_limits(s_ratio, [1, 4])
            h_ratio = self._clamp_with_limits(h_ratio, [2, 3])

            if self.docking_hold_active:
                # Cooperative docking only needs gentle yaw correction.  The
                # main-thruster surge channels remain neutral.
                s_ratio = 0.0
                h_ratio = max(-0.20, min(0.20, h_ratio))

            self.cached_auto_ratios = [s_ratio, h_ratio, -h_ratio, s_ratio, False]
            self.last_pid_time = current_time
            # 基于当前 PID 输出同步更新 PWM 缓存，确保日志落盘正确
            self.last_commanded_pwms = [
                int(1500 + s_ratio * 500),
                int(1500 + h_ratio * 500),
                int(1500 + (-h_ratio) * 500),
                int(1500 + s_ratio * 500)
            ]


    def process_joystick(self, x: float, y: float, interval_sec: float, flush: bool = False):
        """
        处理船坞摇杆物理输入。
        :param flush: [新增] 是否要求底层立即清空旧指令并发送这一帧
        """
        
        # 1. 核心抢占逻辑 (保持不变)
        if abs(x) > 15 or abs(y) > 15:
            if self.auto_heading_active or self.auto_speed_active or self.is_mission_active:
                self.docking_hold_active = False
                self.nof_centering_active = False
                self.auto_heading_active = False
                self.auto_speed_active = False
                self.is_mission_active = False
                self.pose_return.stop()
                # --- 新增：软件速度解算变量 ---
                self.last_gps_pos = None     # 存储上一帧 (lat, lon)
                self.last_gps_time = None    # 存储上一帧 perf_counter 时间戳
                self.smooth_speed = 0.0      # 平滑后的速度值 (m/s)
                self.sig_status_changed.emit({"auto_heading": False, "auto_speed": False})
                self.sig_mission_log.emit("⚠️ [安全] 物理手柄强行接管船坞动力，自动模式已关闭！")
                self.sig_manual_override.emit() 

        # 2. 如果当前处于自动模式且手柄没动，直接返回
        if self.auto_heading_active or self.auto_speed_active or self.is_mission_active: 
            return 
        
        # 3. 船坞专用的 4 通道解耦混控公式
        r_y = y / 100.0  # 纵向推力 (对应 1/4号主推)
        r_x = x / 100.0  # 转向力矩 (对应 2/3号转向)
        # 抛出顺序：主推L, 转向A, 转向B, 主推R, 是否刷新
        self.last_commanded_pwms = [
            int(1500 + r_y * 500),
            int(1500 + r_x * 500),
            int(1500 + (-r_x) * 500),
            int(1500 + r_y * 500)
        ]
        self.sig_control_ratios_ready.emit(r_y, r_x, -r_x, r_y, flush)

    def process_estop(self):
        """急停状态重置：复位一切状态（硬件指令已由 send_estop() 直接下发）"""
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.is_mission_active = False
        self.steady_hold_active = False
        self.docking_hold_active = False
        self.nof_centering_active = False
        self.pose_return.stop()
        self.sig_status_changed.emit({"auto_heading": False, "auto_speed": False})
        self.sig_manual_override.emit()
        # 🔒 不再发射 sig_control_ratios_ready，避免 send_control_ratios 用 mode=0x01
        #    覆盖急停的 mode=0x00 锁定态，造成继电器断开后又重新吸合

    # ==========================================
    # ⚙️ 任务与模式管理接口 (由外观类调用)
    # ==========================================
    def start_pose_return(self, config: dict):
        """启动循环试验专用的两段式位姿返航。"""
        self.docking_hold_active = False
        self.nof_centering_active = False
        self.navigator.stop()
        self.is_mission_active = False
        self.steady_hold_active = False
        self.active_heading_algo.reset()
        self.active_speed_algo.reset()
        self._smooth_target_speed = 0.0
        self.pose_return.start(
            config["lat"], config["lon"], config["heading"],
            config.get("position_tolerance", 1.0),
            config.get("approach_distance", 4.0),
            config.get("cruise_speed", 0.25),
            config.get("final_speed", 0.12),
        )
        self.auto_heading_active = True
        self.auto_speed_active = True
        self.sig_status_changed.emit({"auto_heading": True, "auto_speed": True})
        self.sig_mission_log.emit(
            f"🔁 [循环试验] 船坞开始返回起始位姿，目标艏向 {config['heading']:.1f}°"
        )

    def stop_pose_return(self, send_zero: bool = True):
        was_active = self.pose_return.active
        self.pose_return.stop()
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.active_heading_algo.reset()
        self.active_speed_algo.reset()
        self._smooth_target_speed = 0.0
        if send_zero:
            self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0, True)
        if was_active:
            self.sig_mission_log.emit("✅ [循环试验] 船坞位姿返航已停止")

    def start_mission(self, coords):
        self.docking_hold_active = False
        self.nof_centering_active = False
        self.pose_return.stop()
        if not coords: return
        self.navigator.set_path(coords)
        self.is_mission_active = True

        self.auto_heading_active = True
        self.auto_speed_active = True
        
        # ✅ 新增：点亮船坞 UI 界面上的两个自动控制按钮
        self.sig_status_changed.emit({"auto_heading": True, "auto_speed": True})
        
        self.sig_target_sync.emit(self.target_speed, self.target_heading)
        self.sig_mission_log.emit(f"🚀 船坞任务启动：已装载 {len(coords)} 个航点，模式=现有P2P/LOS领航")
        

    def stop_mission(self):
        self.docking_hold_active = False
        self.is_mission_active = False
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.navigator.stop()
        self.current_wp_index = -1
        self.sig_mission_log.emit("🛑 [任务] 船坞自动任务已取消，动力已切断")
        self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0,True)

    def change_algorithm(self, name):
        """Switch the complete dock closed-loop strategy."""
        # Strategy selection is never an arming action. Cancel every ordinary
        # automatic mode so the operator must explicitly re-arm afterwards.
        self.docking_hold_active = False
        self.nof_centering_active = False
        self.steady_hold_active = False
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.is_mission_active = False
        self.pose_return.stop()
        self.navigator.stop()
        self.sig_status_changed.emit({"auto_heading": False, "auto_speed": False})
        if self.active_heading_algo is not None:
            self.active_heading_algo.reset()
            
        if self.active_speed_algo is not None:
            self.active_speed_algo.reset()
        
        self.control_algorithm_name = name
        self.cached_auto_ratios = [0.0, 0.0, 0.0, 0.0, True]

        if name in self.heading_algos: 
            self.active_heading_algo = self.heading_algos[name]
        if name in self.speed_algos: 
            self.active_speed_algo = self.speed_algos[name]
            
        self.sig_mission_log.emit(f"🧠 [算法切换] 船坞当前算法: {name}")
        
        # 💡 [核心新增] 切换算法后，立即通知 UI 更新调参面板
        # 我们把两个算法实例都发出去，由 UI 决定显示哪个或全部显示
        self.sig_algo_tuning_ui_ready.emit(self.active_heading_algo, self.active_speed_algo, None)


    def shutdown(self):
        """释放船坞侧后台资源。"""

    def set_docking_hold_active(self, active: bool):
        """Hold the dock's current heading while the boat performs visual docking."""
        active = bool(active)
        if active:
            if self.is_mission_active or self.pose_return.active:
                self.sig_mission_log.emit(
                    "[协同靠泊] 船坞正在执行其他自动任务，无法启动定艏保持。"
                )
                return
            if self.last_sensor_time is None or time.perf_counter() - self.last_sensor_time > 1.0:
                self.sig_mission_log.emit(
                    "[协同靠泊] 船坞遥测已超时，无法锁存当前艏向。"
                )
                return

            self.docking_hold_active = True
            self.steady_hold_active = False
            self.auto_heading_active = True
            self.auto_speed_active = False
            self.target_heading = CoordUtils.normalize_angle(self.current_heading)
            self.target_speed = 0.0
            self._smooth_target_speed = 0.0
            self.active_heading_algo.reset()
            self.active_speed_algo.reset()
            self.last_pid_time = time.time()
            self.sig_status_changed.emit({
                "auto_heading": True,
                "auto_speed": False,
            })
            self.sig_target_sync.emit(self.target_speed, self.target_heading)
            self.sig_mission_log.emit(
                f"[协同靠泊] 船坞已锁存艏向 {self.target_heading:.1f}°，"
                "纵向推力保持为零。"
            )
            return

        was_active = self.docking_hold_active
        self.docking_hold_active = False
        if not was_active:
            return
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.target_speed = 0.0
        self._smooth_target_speed = 0.0
        self.active_heading_algo.reset()
        self.active_speed_algo.reset()
        self.cached_auto_ratios = [0.0, 0.0, 0.0, 0.0, False]
        self.sig_status_changed.emit({
            "auto_heading": False,
            "auto_speed": False,
        })
        self.sig_target_sync.emit(self.target_speed, self.target_heading)
        self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0, True)
        self.sig_mission_log.emit("[协同靠泊] 船坞定艏保持已解除。")

    def set_nof_centering_active(self, active: bool):
        """🎯 启停船坞 NOF 视觉居中伺服（仅转向，纵向推力为零）。"""
        active = bool(active)
        if active:
            if self.is_mission_active or self.pose_return.active:
                self.sig_mission_log.emit(
                    "[NOF对准] 船坞正在执行其他自动任务，无法开启视觉居中伺服。"
                )
                return
            if self.last_sensor_time is None or time.perf_counter() - self.last_sensor_time > 1.0:
                self.sig_mission_log.emit(
                    "[NOF对准] 船坞遥测已超时，无法开启视觉居中伺服。"
                )
                return

            self.nof_centering_active = True
            self.docking_hold_active = False
            self.steady_hold_active = False
            self.auto_heading_active = True
            self.auto_speed_active = False
            self.target_speed = 0.0
            self.target_heading = CoordUtils.normalize_angle(self.current_heading)
            self.nof_offset_x = 0.0
            self.nof_offset_time = 0.0
            self.nof_visual_state = "VISUAL"
            self.nof_lost_count = 0
            self.nof_seen_count = 0
            self.active_heading_algo.reset()
            self.active_speed_algo.reset()
            self.last_pid_time = time.time()
            self.sig_status_changed.emit({
                "auto_heading": True,
                "auto_speed": False,
            })
            self.sig_target_sync.emit(self.target_speed, self.target_heading)
            self.sig_mission_log.emit(
                "🎯 [NOF对准] 船坞已切换到视觉居中伺服，等待 NOF 目标。"
            )
            return

        was_active = self.nof_centering_active
        self.nof_centering_active = False
        self.nof_offset_x = 0.0
        self.nof_offset_time = 0.0
        self.nof_visual_state = "VISUAL"
        self.nof_lost_count = 0
        self.nof_seen_count = 0
        if not was_active:
            return
        self.auto_heading_active = False
        self.auto_speed_active = False
        self.target_speed = 0.0
        self._smooth_target_speed = 0.0
        self.active_heading_algo.reset()
        self.active_speed_algo.reset()
        self.cached_auto_ratios = [0.0, 0.0, 0.0, 0.0, False]
        self.sig_status_changed.emit({
            "auto_heading": False,
            "auto_speed": False,
        })
        self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0, True)
        self.sig_mission_log.emit("🛑 [NOF对准] 船坞视觉居中伺服已关闭。")

    def update_nof_offset(self, offset_x: float):
        """🎯 由主进程逐帧推送 NOF 框中心的归一化水平偏移。"""
        self.nof_offset_x = float(offset_x)
        self.nof_offset_time = time.perf_counter()

    def _compute_nof_yaw_ratio(self) -> float:
        """🎯 由 NOF 框中心偏移计算船坞转向比例（带死区 + 目标丢失保护）。"""
        if time.perf_counter() - self.nof_offset_time > self.nof_stale_timeout:
            return 0.0
        offset = float(self.nof_offset_x)
        if abs(offset) < self.nof_yaw_deadband:
            return 0.0
        ratio = self.nof_yaw_kp * offset
        return max(-0.25, min(0.25, ratio))

    def set_boat_position(self, lat: float, lon: float):
        """🎯 接收子船 GPS 中点，供视觉丢失时 GPS 相对方位角兜底。"""
        self.boat_lat = float(lat)
        self.boat_lon = float(lon)
        self.boat_pos_time = time.time()

    def _compute_bearing_yaw_ratio(self, dt: float) -> float:
        """🎯 GPS 相对方位角 PID：转向子船所在方位（视觉丢失时的兜底）。"""
        if self.boat_lat is None or time.time() - self.boat_pos_time > 2.0:
            return 0.0  # 子船位置缺失/过期，停止转向
        if self.current_lat is None or self.current_lon is None:
            return 0.0
        try:
            _, bearing = CoordUtils.calculate_distance_and_bearing(
                self.current_lat, self.current_lon, self.boat_lat, self.boat_lon
            )
        except Exception:
            return 0.0
        h_ratio = self.active_heading_algo.compute(
            self.current_heading, bearing, dt
        )
        return max(-0.25, min(0.25, h_ratio))

    def set_auto_heading(self, active: bool, target_heading: float):
        was_active = self.auto_heading_active
        if not active:
            self.docking_hold_active = False
        self.auto_heading_active = active
        self.target_heading = target_heading
        self.sig_status_changed.emit({"auto_heading": active})
        if active:
            self.active_heading_algo.reset()
            self.last_pid_time = time.time()
            # 💡 [关键同步] 无论是开启还是关闭，都同步一次当前目标给 UI
            self.sig_target_sync.emit(self.target_speed, self.target_heading)
        else:
            # 💡 [核心修复] 关闭定艏时，如果正在执行任务，必须彻底停止任务
            if self.is_mission_active:
                self.stop_mission()
                return
            if not self.auto_speed_active:
                self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0,True)

    def set_auto_speed(self, active: bool, target_speed: float):
        was_active = self.auto_speed_active
        if active:
            self.docking_hold_active = False
        self.auto_speed_active = active
        self.target_speed = self._apply_speed_limits(target_speed)
        if active:
            self.active_speed_algo.reset()
            self.last_pid_time = time.time()
            # 💡 [关键同步] 确保 UI 文本框数值与大脑内部目标一致
            self.sig_target_sync.emit(self.target_speed, self.target_heading)
        else:
            # 💡 [核心修复] 关闭定速时，如果正在执行任务，必须彻底停止任务
            if self.is_mission_active:
                self.stop_mission()
                return
            if not self.auto_heading_active:
                self.sig_control_ratios_ready.emit(0.0, 0.0, 0.0, 0.0,True)

    def step_target(self, d_speed: float, d_heading: float):
        """
        💡 [新增] 动态微调目标值 (步长累加)
        绝对不调用 PID.reset()，保证过渡丝滑
        """
        updated = False
        
        # 1. 只有在定速模式下，才允许微调速度
        if self.auto_speed_active and d_speed != 0:
            new_speed = self.target_speed + d_speed
            self.target_speed = self._apply_speed_limits(new_speed)
            updated = True
            
        # 2. 只有在定艏模式下，才允许微调航向
        # 2. 只有在定艏模式下，才允许微调航向
        if self.auto_heading_active and d_heading != 0:
            # ✅ 修改点：累加后立即调用归一化函数
            self.target_heading = CoordUtils.normalize_angle(self.target_heading + d_heading)
            updated = True
            
        # 3. 如果有更新，发射信号通知 UI 界面同步变化
        if updated:
            self.sig_target_sync.emit(self.target_speed, self.target_heading)
            self.sig_mission_log.emit(f"🎛️ [微调] 船坞目标已更新 -> 航向: {self.target_heading:.1f}°, 速度: {self.target_speed:.1f}m/s")
    def set_target_heading_absolute(self, heading: float):
        """💡 [新增] 接收来自 UI 输入框的绝对航向值"""
        if self.auto_heading_active and self.target_heading != heading:
            self.target_heading = CoordUtils.normalize_angle(heading)
            # 这里原本漏了信号发射
            self.sig_target_sync.emit(self.target_speed, self.target_heading) # 💡 [补发]

    def set_target_speed_absolute(self, speed: float):
        """💡 [新增] 接收来自 UI 输入框的绝对速度值"""
        if self.auto_speed_active and self.target_speed != speed:
            self.target_speed = self._apply_speed_limits(speed)
            self.sig_target_sync.emit(self.target_speed, self.target_heading)
