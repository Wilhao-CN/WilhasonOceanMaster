# 文件路径: vision/vision_process.py
import time
import multiprocessing as mp
import queue
import numpy as np
import cv2
from typing import Dict, List
# 导入我们上一步定义的基类
from vision.base_algo import BaseVisionAlgo, DetectionResult


def _safe_plugin_import(module_name: str, attr_name: str, label: str, hint: str):
    """容错导入视觉插件。

    某些插件依赖重量级/可选第三方库（YOLOv8 需要 ultralytics，WaSR-T 需要 torch）。
    以前这里是裸 import，只要有一个不满足，主进程 import ui.main_window 就会失败，
    整个地面站根本打不开——用户只是没装视觉依赖，却连界面都进不去。
    改成按插件降级：缺依赖就跳过该算法，界面上对应的算法选项不可用，其余功能照常。
    """
    try:
        module = __import__(module_name, fromlist=[attr_name])
        return getattr(module, attr_name)
    except Exception as exc:  # noqa: BLE001 - 缺依赖/加载失败都要降级而不是崩
        print(f"⚠️ [视觉插件] {label} 不可用（{type(exc).__name__}: {exc}）")
        print(f"           如需启用：{hint}")
        return None


YOLOv8Algo = _safe_plugin_import(
    "vision.algorithms.yolo_v8.yolo_impl", "YOLOv8Algo", "YOLOv8 目标检测",
    "pip install ultralytics",
)  # 🚀 YOLO v8 目标检测（精简版保留）
ArucoDockAlgo = _safe_plugin_import(
    "vision.algorithms.OpenCv.aruco_dock_algo", "ArucoDockAlgo", "ArUco 靠泊测距",
    "opencv-python 已随 requirements.txt 安装",
)  # 🎯 ArUco 靠泊测距：闭环视觉对接的观测源（保留）

class VisionProcess(mp.Process):
    """
    视觉算力进程：独立于主 UI 运行，保护主程序不卡死。
    """
    def __init__(self, cmd_queue: mp.Queue, result_queue: mp.Queue, shared_mem_dict: Dict):
        """
        :param cmd_queue: 接收主进程指令 (如: "开启YOLO", "切换算法")
        :param result_queue: 向主进程回传识别结果
        :param shared_mem_dict: 包含两船图像共享内存信息的字典
        """
        super().__init__()
        self.cmd_queue = cmd_queue
        self.result_queue = result_queue
        self.shared_mem_dict = shared_mem_dict
        
        self.is_running = mp.Value('b', True)
        
        # 💡 核心管理结构：为两艘船分别维护一个“激活的算法列表”
        # 格式: {"dock": {"yolo": <instance>}, "boat": {}}
        self.active_plugins = {"dock": {}, "boat": {}}

        # 📏 原始协议 IMU 字典缓存：回传给 UI 用于保艏/遥测显示
        #    保留原始字典（不要转成对象，否则会丢 ekf_heading）。
        self._imu_raw_cache = {"dock": None, "boat": None}
        self._last_frame_sequence = {"dock": None, "boat": None}
        
        # 💡 算法仓库：存放已加载的所有可用算法类
        # 缺依赖的插件在上面已降级为 None，这里过滤掉，界面下拉框就不会出现
        # 一个点了必然报错的选项。
        _candidates = {
            "yolo_v8": YOLOv8Algo,          # 🚀 YOLO v8 目标检测
            "aruco_dock": ArucoDockAlgo,    # 🎯 ArUco 靠泊测距（闭环对接观测源）
        }
        self.algo_repo = {k: v for k, v in _candidates.items() if v is not None}
        _missing = [k for k, v in _candidates.items() if v is None]
        if _missing:
            print(f"ℹ️ [视觉进程] 以下算法因缺少依赖未注册: {', '.join(_missing)}")

    def run(self):
        """
        进程主循环
        """
        print("🚀 [视觉进程] 算力引擎已启动，等待指令...")
        
        while self.is_running.value:
            # 1. 处理控制指令 (非阻塞查看)
            self._handle_commands()
            
            # 2. 核心流水线处理
            results_to_send = []
            
            for stream_id in ["dock", "boat"]:
                # 如果这艘船当前没有任何激活的算法，发送一个空结果以确保UI清空残留框，然后跳过
                if not self.active_plugins[stream_id]:
                    # 放一个空的大包进去刷新UI
                    if not getattr(self, f"_cleared_{stream_id}", False):
                        results_to_send.append({
                            "id": stream_id,
                            "timestamp": time.time(),
                            "data": []
                        })
                        setattr(self, f"_cleared_{stream_id}", True)
                    continue
                else:
                    setattr(self, f"_cleared_{stream_id}", False)
                
                # 💡 从共享内存读取最新帧 (下一步我们会完善 shared_mem)
                snapshot = self._get_frame_from_shm(stream_id)
                if snapshot is None:
                    continue
                frame, frame_meta = snapshot
                
                # 💡 执行该船下所有已开启的算法
                stream_results = []
                for algo_id, algo_instance in self.active_plugins[stream_id].items():
                    try:
                        # 执行推理
                        detection_list = algo_instance.process(frame)
                        stream_results.extend(detection_list)
                    except Exception as e:
                        import traceback
                        print(f"❌ [视觉进程] 算法 {algo_id} 推理异常: {e}\n{traceback.format_exc()}")

                # 无论是否有结果，都必须存入大包列表，以确保前端能收到空列表来清空残留的画框
                results_to_send.append({
                    "id": stream_id,
                    "timestamp": frame_meta["timestamp"],
                    "frame_sequence": frame_meta["sequence"],
                    "frame_width": frame_meta["width"],
                    "frame_height": frame_meta["height"],
                    "imu": self._imu_raw_cache.get(stream_id),
                    "data": stream_results
                })

            # 3. 统一回传识别数据
            if results_to_send:
                try:
                    # 采用 nowait 保证不会因为队列满而阻塞算力
                    self.result_queue.put_nowait(results_to_send)
                except queue.Full:
                    # 丢弃最旧批次后再尝试发布当前批次。感知显示宁可跳帧，
                    # 也不能积压成高延迟的“历史画面”。
                    try:
                        self.result_queue.get_nowait()
                        self.result_queue.put_nowait(results_to_send)
                    except (queue.Empty, queue.Full):
                        pass
            
            # 4. 适当休眠，避免在没有算法激活时空转 CPU
            if not any(self.active_plugins.values()):
                time.sleep(0.1)
            else:
                # 没有新帧时不会重复推理同一幅图；短暂停顿避免忙等。
                time.sleep(0.002)

    def _handle_commands(self):
        """
        解析来自主程序的指令
        指令格式示例: {"target": "boat", "cmd": "enable", "algo_id": "yolo_v8", "params": {}}
        """
        try:
            while not self.cmd_queue.empty():
                msg = self.cmd_queue.get_nowait()
                target = msg.get("target") # "dock" or "boat"
                cmd = msg.get("cmd")
                algo_id = msg.get("algo_id")
                
                if cmd == "enable":
                    self._enable_algorithm(target, algo_id, msg.get("params", {}))
                elif cmd == "disable":
                    if algo_id in self.active_plugins[target]:
                        # 🌊 先给插件收尾机会（WaSR-T 等重模型靠 shutdown() 停线程、放显存；
                        # 直接 del 会让后台线程继续持有实例，反复开关必然泄漏）
                        instance = self.active_plugins[target][algo_id]
                        shutdown = getattr(instance, "shutdown", None)
                        if callable(shutdown):
                            try:
                                shutdown()
                            except Exception as exc:
                                print(f"⚠️ [视觉进程] {algo_id} shutdown 异常: {exc}")
                        del self.active_plugins[target][algo_id]
                        print(f"🛑 [视觉进程] 已为 {target} 关闭算法: {algo_id}")
                elif cmd == "update_params":
                    # 🔥 [新增] 将新的参数推入正在运行的算法实例
                    if algo_id in self.active_plugins[target]:
                        self.active_plugins[target][algo_id].update_params(msg.get("params", {}))
                elif cmd == "set_imu":
                    # 📏 接收主进程推送的 IMU 数据，缓存原始字典供回传给 UI
                    imu_dict = dict(msg.get("imu", {}) or {})
                    if target in self._imu_raw_cache:
                        self._imu_raw_cache[target] = imu_dict
                elif cmd == "stop_all":
                    self.is_running.value = False
        except Exception:
            pass

    def _enable_algorithm(self, target: str, algo_id: str, params: dict):
        """
        动态激活插件逻辑
        """
        # 如果算法实例还不在 active 列表里，则从 repo 实例化或动态加载
        if algo_id not in self.active_plugins[target]:
            # 这里预留一个动态加载逻辑，以后我们可以根据 algorithms/ 文件夹动态 import
            # 目前假设我们已经手动注册了某些算法
            if algo_id in self.algo_repo:
                algo_class = self.algo_repo[algo_id]
                self.active_plugins[target][algo_id] = algo_class(params)
                print(f"✅ [视觉进程] 已为 {target} 开启算法: {algo_id}")

    def _get_frame_from_shm(self, stream_id: str):
        """从共享内存读取图像数据"""
        try:
            # 名字匹配 manager 里的定义
            name = self.shared_mem_dict.get(stream_id)
            if not name: return None
            
            if not hasattr(self, "_shm_buffers"):
                self._shm_buffers = {}
                from vision.shared_mem import SharedImageBuffer
                for st in ["dock", "boat"]:
                    shm_name = self.shared_mem_dict.get(st)
                    if shm_name:
                        self._shm_buffers[st] = SharedImageBuffer(
                            shm_name, create=False
                        )

            snapshot = self._shm_buffers[stream_id].read_latest(
                after_sequence=self._last_frame_sequence[stream_id]
            )
            if snapshot is None:
                return None
            frame, metadata = snapshot
            self._last_frame_sequence[stream_id] = metadata["sequence"]
            return frame, metadata
            
        except Exception as e:
            return None
