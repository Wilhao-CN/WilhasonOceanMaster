"""Process-safe latest-frame transport for the vision worker.

The old buffer forced every source into 640x480 and exposed the image while it
was being overwritten. This implementation keeps the source aspect ratio,
adds a frame sequence/timestamp, and uses a small seqlock header so the reader
can reject torn frames without blocking the video receiver.
"""

from __future__ import annotations

import os
import struct
import threading
import time
from multiprocessing import shared_memory

import numpy as np


class SharedImageBuffer:
    """Single-producer/latest-consumer image buffer backed by shared memory."""

    HEADER_SIZE = 64
    HEADER = struct.Struct("<QdIIII")

    def __init__(
        self,
        name: str,
        width: int = 1920,
        height: int = 1080,
        channels: int = 3,
        create: bool = False,
    ):
        self.name = name
        self.max_width = int(width)
        self.max_height = int(height)
        self.max_channels = int(channels)
        self.payload_capacity = self.max_width * self.max_height * self.max_channels
        self.size = self.HEADER_SIZE + self.payload_capacity
        self._write_lock = threading.Lock()

        if create:
            try:
                stale = shared_memory.SharedMemory(name=self.name)
                stale.close()
                stale.unlink()
            except FileNotFoundError:
                pass
            self.shm = shared_memory.SharedMemory(
                name=self.name, create=True, size=self.size
            )
            self.shm.buf[: self.HEADER_SIZE] = b"\0" * self.HEADER_SIZE
        else:
            self.shm = shared_memory.SharedMemory(name=self.name)
            if self.shm.size < self.size:
                actual_size = self.shm.size
                self.shm.close()
                raise ValueError(
                    f"共享内存 {self.name} 容量不足: {actual_size} < {self.size}"
                )

    def _header(self):
        return self.HEADER.unpack_from(self.shm.buf, 0)

    def write(self, frame_np: np.ndarray, timestamp: float | None = None) -> int:
        """Publish one complete BGR/RGB frame and return its stable sequence."""
        if frame_np is None or frame_np.ndim != 3:
            raise ValueError("视觉共享内存只接受 HxWxC 图像")

        frame = np.asarray(frame_np, dtype=np.uint8)
        height, width, channels = frame.shape
        if channels > self.max_channels:
            raise ValueError(
                f"图像通道数 {channels} 超过共享内存上限 {self.max_channels}"
            )

        if width > self.max_width or height > self.max_height:
            import cv2

            scale = min(self.max_width / width, self.max_height / height)
            width = max(1, int(round(width * scale)))
            height = max(1, int(round(height * scale)))
            frame = cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)

        frame = np.ascontiguousarray(frame)
        payload_size = int(frame.nbytes)
        if payload_size > self.payload_capacity:
            raise ValueError("图像数据超过视觉共享内存容量")

        published_at = time.time() if timestamp is None else float(timestamp)
        with self._write_lock:
            current_sequence = int(self._header()[0])
            writing_sequence = current_sequence + 1
            if writing_sequence % 2 == 0:
                writing_sequence += 1

            self.HEADER.pack_into(
                self.shm.buf,
                0,
                writing_sequence,
                published_at,
                width,
                height,
                channels,
                payload_size,
            )
            payload = np.ndarray(
                (payload_size,),
                dtype=np.uint8,
                buffer=self.shm.buf,
                offset=self.HEADER_SIZE,
            )
            payload[:] = frame.reshape(-1)

            stable_sequence = writing_sequence + 1
            self.HEADER.pack_into(
                self.shm.buf,
                0,
                stable_sequence,
                published_at,
                width,
                height,
                channels,
                payload_size,
            )
            return stable_sequence

    def read_latest(self, after_sequence: int | None = None, retries: int = 5):
        """Return ``(frame_copy, metadata)`` for a new consistent frame."""
        for _ in range(max(1, int(retries))):
            header_before = bytes(self.shm.buf[: self.HEADER_SIZE])
            sequence, timestamp, width, height, channels, payload_size = (
                self.HEADER.unpack_from(header_before, 0)
            )
            if sequence == 0 or sequence % 2 == 1:
                continue
            if after_sequence is not None and sequence == after_sequence:
                return None
            if (
                width <= 0
                or height <= 0
                or channels <= 0
                or width > self.max_width
                or height > self.max_height
                or channels > self.max_channels
                or payload_size != width * height * channels
                or payload_size > self.payload_capacity
            ):
                continue

            flat = np.ndarray(
                (payload_size,),
                dtype=np.uint8,
                buffer=self.shm.buf,
                offset=self.HEADER_SIZE,
            ).copy()
            header_after = bytes(self.shm.buf[: self.HEADER_SIZE])
            sequence_after = self.HEADER.unpack_from(header_after, 0)[0]
            if sequence != sequence_after or sequence_after % 2 == 1:
                continue

            frame = flat.reshape((height, width, channels))
            return frame, {
                "sequence": int(sequence),
                "timestamp": float(timestamp),
                "width": int(width),
                "height": int(height),
                "channels": int(channels),
            }
        return None

    def read(self) -> np.ndarray:
        """Compatibility helper returning the newest stable frame copy."""
        snapshot = self.read_latest()
        if snapshot is None:
            return np.empty((0, 0, self.max_channels), dtype=np.uint8)
        return snapshot[0]

    def close(self):
        try:
            self.shm.close()
        except (BufferError, FileNotFoundError) as exc:
            print(f"⚠️ [SHM] 关闭共享内存 {self.name} 失败: {exc}")

    def unlink(self):
        try:
            self.shm.unlink()
        except FileNotFoundError:
            pass


class VisionSyncManager:
    """Own the independent dock and boat latest-frame buffers."""

    MAX_WIDTH = 1920
    MAX_HEIGHT = 1080
    CHANNELS = 3

    def __init__(self, create: bool = False, names=None):
        if names is None:
            suffix = str(os.getpid()) if create else ""
            names = {
                "dock": f"shm_usv_dock_{suffix}" if suffix else "shm_usv_dock",
                "boat": f"shm_usv_boat_{suffix}" if suffix else "shm_usv_boat",
            }
        self.names = dict(names)
        self.buffers = {
            stream_id: SharedImageBuffer(
                shm_name,
                self.MAX_WIDTH,
                self.MAX_HEIGHT,
                self.CHANNELS,
                create=create,
            )
            for stream_id, shm_name in self.names.items()
        }

    def get_buffer(self, stream_id: str) -> SharedImageBuffer | None:
        return self.buffers.get(stream_id)

    def cleanup(self):
        for buffer in self.buffers.values():
            buffer.close()
            buffer.unlink()
