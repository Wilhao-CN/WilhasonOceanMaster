# 文件路径: vision/algorithms/yolo_v8/yolo_impl.py
import os
import cv2
import numpy as np
from typing import List, Dict, Any

# 💡 默认权重：与脚本同目录下的自定义训练模型 (best.pt)
# 使用相对 __file__ 路径，换机器/换工作目录也不会找不到。
_DEFAULT_MODEL_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "best.pt"
)

# 🎯 默认跟踪器配置：针对低置信度单类检测调优过的 BoT-SORT
_DEFAULT_TRACKER = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "botsort_nof.yaml"
)

# 💡 假设你已经安装了 ultralytics (pip install ultralytics)
# 注意：这里必须把异常重新抛出，不能让 YOLO 变成未定义名字——
# 否则用户开了 YOLO 算法时只会看到一句 NameError，很难定位真实原因。
try:
    from ultralytics import YOLO
except ImportError as exc:
    raise ImportError(
        "[YOLO插件] 未发现 ultralytics 库，请先执行: "
        "venv_usv\\Scripts\\python.exe -m pip install ultralytics"
    ) from exc

from vision.base_algo import BaseVisionAlgo, DetectionResult

class YOLOv8Algo(BaseVisionAlgo):
    """
    YOLO v8 目标检测算法实现
    """
    def __init__(self, params: Dict[str, Any] = None):
        super().__init__(params)
        # 💡 从参数中获取模型路径，默认为自定义训练的 best.pt
        model_path = self.config.get("model_path", _DEFAULT_MODEL_PATH)
        self.conf_threshold = self.config.get("conf_threshold", 0.25)
        # 🎯 跟踪器配置：persist 保持跨帧 track_id；默认用调优过的 BoT-SORT
        self.tracker = self.config.get("tracker", _DEFAULT_TRACKER)
        self.persist = self.config.get("persist", True)
        
        # 加载模型 (如果是第一次运行，它会自动下载模型权重)
        try:
            self.model = YOLO(model_path)
        except Exception as e:
            print(f"❌ [YOLO插件] 模型加载失败: {e}")
            self.model = None

    def get_plugin_info(self) -> Dict[str, Any]:
        return {
            "name": "YOLO v8 目标检测",
            "id": "yolo_v8",
            "params": {
                "conf_threshold": self.conf_threshold,
                "tracker": self.tracker,
                "model_path": _DEFAULT_MODEL_PATH
            }
        }

    def process(self, frame: np.ndarray) -> List[DetectionResult]:
        """
        核心推理逻辑
        """
        if self.model is None:
            return []

        results = []
        # 🎯 使用 track() 而非 predict()：检测命中帧校准，漏帧时由跟踪器
        # (Kalman 预测 + 帧间关联) 续上同一个 track_id，视觉输出保持连续。
        predict_results = self.model.track(
            source=frame, 
            conf=self.conf_threshold,
            persist=self.persist,      # 跨帧保持目标 ID
            tracker=self.tracker,      # "botsort.yaml" / "bytetrack.yaml"
            verbose=False,
            device='cpu' # 💡 如果你有 NVIDIA 显卡，可以改为 '0'
        )

        img_h, img_w = frame.shape[:2]

        for r in predict_results:
            boxes = r.boxes
            for box in boxes:
                # 1. 获取坐标 (xyxy 格式)
                coords = box.xyxy[0].tolist()
                
                # 💡 [关键步]：转换为归一化坐标 (0.0 - 1.0)
                # 这样我们的 HUD 窗口无论怎么拉伸都能准确画框
                norm_bbox = [
                    coords[0] / img_w, # x_min
                    coords[1] / img_h, # y_min
                    coords[2] / img_w, # x_max
                    coords[3] / img_h  # y_max
                ]

                # 2. 获取类别和置信度
                cls_id = int(box.cls[0])
                label = self.model.names[cls_id]
                conf = float(box.conf[0])

                # 3. 🎯 提取跟踪 ID（track 模式才存在；漏帧时同一目标 ID 不变）
                track_id = None
                try:
                    box_id = getattr(box, "id", None)
                    if box_id is not None and len(box_id) > 0:
                        track_id = int(box_id[0])
                except (TypeError, ValueError):
                    track_id = None

                # 4. 封装为统一的结果格式
                results.append(DetectionResult(
                    algo_id="yolo_v8",
                    label=label,
                    confidence=conf,
                    bbox=norm_bbox,
                    extra={"track_id": track_id},
                ))

        return results