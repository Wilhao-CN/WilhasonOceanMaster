# stabilizer.py
import math
import time

class OneEuroFilter:
    def __init__(self, min_cutoff=1.0, beta=0.05, d_cutoff=1.0):
        self.min_cutoff = float(min_cutoff)
        self.beta = float(beta)
        self.d_cutoff = float(d_cutoff)
        
        self.x_prev = None
        self.dx_prev = 0.0
        self.t_prev = None

    def update_params(self, min_cutoff, beta, d_cutoff):
        self.min_cutoff = float(min_cutoff)
        self.beta = float(beta)
        self.d_cutoff = float(d_cutoff)

    def smoothing_factor(self, t_e, cutoff):
        r = 2 * math.pi * cutoff * t_e
        return r / (r + 1.0) if (r + 1.0) != 0 else 0.5

    def __call__(self, x, t):
        if self.x_prev is None:
            self.x_prev = x
            self.t_prev = t
            return x

        t_e = t - self.t_prev
        if t_e <= 0: return x

        # 1. 计算变化率并平滑 (导数项)
        dx = (x - self.x_prev) / t_e
        alpha_d = self.smoothing_factor(t_e, self.d_cutoff)
        dx_hat = alpha_d * dx + (1.0 - alpha_d) * self.dx_prev

        # 2. 动态截止频率：min_cutoff 负责滤除静止抖动，beta 负责响应快速移动
        cutoff = self.min_cutoff + self.beta * abs(dx_hat)

        # 3. 计算最终平滑值
        alpha = self.smoothing_factor(t_e, cutoff)
        x_hat = alpha * x + (1.0 - alpha) * self.x_prev

        self.x_prev = x_hat
        self.dx_prev = dx_hat
        self.t_prev = t
        return x_hat

    def reset(self):
        self.x_prev = None
        self.dx_prev = 0.0
        self.t_prev = None


class PoseStabilizer:
    def __init__(self):
        # 针对船用低频运动的推荐初始参数
        self.min_cutoff = 0.1  # 极低频率过滤引擎振动
        self.beta = 0.01       # 降低响应敏感度，防止海浪造成的微小跳变被放大
        self.d_cutoff = 0.5
        self.timeout = 0.5     # 0.5秒无更新则强制重置滤波器状态
        
        self.filters = {
            'tx': OneEuroFilter(self.min_cutoff, self.beta, self.d_cutoff),
            'ty': OneEuroFilter(self.min_cutoff, self.beta, self.d_cutoff),
            'tz': OneEuroFilter(self.min_cutoff, self.beta, self.d_cutoff),
            'pitch': OneEuroFilter(self.min_cutoff, self.beta, self.d_cutoff),
            'yaw': OneEuroFilter(self.min_cutoff, self.beta, self.d_cutoff),
            'roll': OneEuroFilter(self.min_cutoff, self.beta, self.d_cutoff)
        }
        self.last_update_time = 0

    def update_params(self, params_dict):
        try:
            self.min_cutoff = float(params_dict.get('1e_min_cutoff', self.min_cutoff))
            self.beta = float(params_dict.get('1e_beta', self.beta))
            self.d_cutoff = float(params_dict.get('1e_d_cutoff', self.d_cutoff))
            
            for f in self.filters.values():
                f.update_params(self.min_cutoff, self.beta, self.d_cutoff)
        except: pass

    def update(self, pose_dict):
        current_time = time.time()
        
        # 自动重置逻辑：如果目标丢失时间过长，清空滤波器内存
        if current_time - self.last_update_time > self.timeout:
            self.reset_all()
                
        self.last_update_time = current_time
        smoothed_pose = {}
        
        try:
            for key in pose_dict:
                smoothed_pose[key] = self.filters[key](pose_dict[key], current_time)
            return smoothed_pose, ""
        except Exception as e:
            return pose_dict, str(e)

    def reset_all(self):
        for f in self.filters.values():
            f.reset()