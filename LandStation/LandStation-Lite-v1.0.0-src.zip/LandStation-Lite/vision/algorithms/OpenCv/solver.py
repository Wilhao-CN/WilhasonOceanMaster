# solver.py
import cv2
import cv2.aruco as aruco
import numpy as np
import time

class MarkerCAKalman:
    """
    自适应恒定加速度 (ACA) 卡尔曼滤波器
    状态向量 X = [x, y, vx, vy, ax, ay]^T
    """
    def __init__(self, x, y, dt=1/60):
        # 6个状态 (位置, 速度, 加速度), 2个测量 (位置)
        self.kf = cv2.KalmanFilter(6, 2)
        
        # 测量矩阵: 只测量 x, y
        self.kf.measurementMatrix = np.array([
            [1, 0, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0]
        ], np.float32)

        # 状态转移矩阵 (CA 模型)
        # x_new = x + vx*dt + 0.5*ax*dt^2
        # vx_new = vx + ax*dt
        dt2 = 0.5 * (dt**2)
        self.kf.transitionMatrix = np.array([
            [1, 0, dt,  0, dt2,   0],
            [0, 1,  0, dt,   0, dt2],
            [0, 0,  1,  0,  dt,   0],
            [0, 0,  0,  1,   0,  dt],
            [0, 0,  0,  0,   1,   0],
            [0, 0,  0,  0,   0,   1]
        ], np.float32)

        # 过程噪声 Q: 针对船上低频晃动，调大加速度项的噪声以保持灵敏度
        self.kf.processNoiseCov = np.eye(6, dtype=np.float32) * 1e-2
        
        # 初始化状态
        self.kf.statePre = np.array([[x], [y], [0], [0], [0], [0]], np.float32)
        self.kf.statePost = np.array([[x], [y], [0], [0], [0], [0]], np.float32)

    def predict(self):
        pred = self.kf.predict()
        # 返回预测的 x, y, vx, vy, ax, ay
        return pred.flatten()

    def correct(self, x, y):
        self.kf.correct(np.array([[np.float32(x)], [np.float32(y)]]))

class ArucoSolver:
    def __init__(self):
        # 基础参数
        self.marker_size = 0.05
        self.poly_approx = 0.04
        self.small_marker_scale = 1.5
        
        # --- 增强型参数 ---
        self.max_fallback = 30       # 船用环境增加容错时长
        self.conf_decay = 0.05       # 每帧置信度衰减率 (1/0.05=20帧)
        self.soft_landing_alpha = 0.2 # 软着陆系数，越小越平滑
        
        self.lk_params = dict(
            winSize=(21, 21),        # 增大窗口以应对晃动
            maxLevel=3,
            criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 20, 0.01)
        )
        
        # --- 记忆与融合中心 ---
        self.last_gray = None
        self.last_corners = {}       # 记录每个 ID 最后的四角位置
        self.kalmans = {}            # {id: MarkerCAKalman}
        self.confidence = {}         # {id: 0.0~1.0}
        self.offsets = {}            # {id: np.array([4,2])} 软着陆偏移量缓存

        # 实体相机 640x480 标定内参。实际输入若仍是 4:3，会按分辨率
        # 等比例缩放；Unity 16:9 则按 60 度垂直 FOV 动态计算。
        self.physical_reference_size = (640, 480)
        self.physical_camera_matrix = np.array([
            [591.622, 0,       333.374],
            [0,       591.427, 232.99],
            [0,       0,       1]
        ], dtype=np.float32)
        self.camera_matrix = self.physical_camera_matrix.copy()
        self.dist_coeffs = np.zeros((5, 1), dtype=np.float32)
        self.camera_profile = "auto"
        self.unity_vertical_fov_deg = 60.0
        self._camera_frame_size = self.physical_reference_size

        self.aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
        self._rebuild_obj_points()
        self._rebuild_detector()

    def _rebuild_obj_points(self):
        s = self.marker_size / 2.0
        self.obj_points = np.array([
            [-s,  s, 0], [ s,  s, 0], [ s, -s, 0], [-s, -s, 0]
        ], dtype=np.float32)

    def _rebuild_detector(self):
        self.parameters = aruco.DetectorParameters()
        self.parameters.polygonalApproxAccuracyRate = self.poly_approx
        self.parameters.cornerRefinementMethod = aruco.CORNER_REFINE_SUBPIX
        self.parameters.adaptiveThreshWinSizeMax = 53
        self.parameters.adaptiveThreshWinSizeStep = 4
        self.detector = aruco.ArucoDetector(self.aruco_dict, self.parameters)

    def _detect_markers(self, gray_frame):
        """Native detection plus one bounded small-marker retry."""
        corners, ids, rejected = self.detector.detectMarkers(gray_frame)
        merged = {}
        if ids is not None:
            for index, marker_id in enumerate(ids.flatten()):
                merged[int(marker_id)] = corners[index]

        scale = float(self.small_marker_scale)
        if scale > 1.0:
            enlarged = cv2.resize(
                gray_frame, None, fx=scale, fy=scale,
                interpolation=cv2.INTER_LINEAR
            )
            scaled_corners, scaled_ids, _ = self.detector.detectMarkers(enlarged)
            if scaled_ids is not None:
                for index, marker_id in enumerate(scaled_ids.flatten()):
                    marker_id = int(marker_id)
                    if marker_id not in merged:
                        merged[marker_id] = scaled_corners[index] / scale

        if not merged:
            return [], None, rejected
        merged_ids = np.array([[marker_id] for marker_id in merged], dtype=np.int32)
        return list(merged.values()), merged_ids, rejected

    def update_params(self, params_dict):
        try:
            if 'marker_size' in params_dict:
                self.marker_size = float(params_dict['marker_size'])
                self._rebuild_obj_points()
            if 'poly_approx' in params_dict:
                self.poly_approx = float(params_dict['poly_approx'])
                self._rebuild_detector()
            if 'small_marker_scale' in params_dict:
                self.small_marker_scale = float(params_dict['small_marker_scale'])
            if 'camera_profile' in params_dict:
                self.camera_profile = str(params_dict['camera_profile']).lower()
                self._camera_frame_size = None
            if 'unity_vertical_fov_deg' in params_dict:
                self.unity_vertical_fov_deg = float(params_dict['unity_vertical_fov_deg'])
                self._camera_frame_size = None
            self.max_fallback = int(params_dict.get('max_fallback', self.max_fallback))
            self.soft_landing_alpha = float(params_dict.get('soft_alpha', self.soft_landing_alpha))
        except: pass

    def _update_camera_for_frame(self, width, height):
        frame_size = (int(width), int(height))
        if frame_size == self._camera_frame_size:
            return

        profile = self.camera_profile
        if profile == "auto":
            aspect = width / max(float(height), 1.0)
            profile = "unity" if aspect >= 1.5 else "physical"

        if profile == "unity":
            fov_rad = np.deg2rad(self.unity_vertical_fov_deg)
            focal = height / (2.0 * np.tan(fov_rad / 2.0))
            self.camera_matrix = np.array([
                [focal, 0.0, width / 2.0],
                [0.0, focal, height / 2.0],
                [0.0, 0.0, 1.0],
            ], dtype=np.float32)
            self.dist_coeffs = np.zeros((5, 1), dtype=np.float32)
        else:
            ref_w, ref_h = self.physical_reference_size
            scale_x = width / float(ref_w)
            scale_y = height / float(ref_h)
            self.camera_matrix = self.physical_camera_matrix.copy()
            self.camera_matrix[0, 0] *= scale_x
            self.camera_matrix[0, 2] *= scale_x
            self.camera_matrix[1, 1] *= scale_y
            self.camera_matrix[1, 2] *= scale_y

        self._camera_frame_size = frame_size

    def _do_pnp_math(self, marker_id, marker_corner, method_name, conf=1.0):
        """执行 PnP 解算并包装结果"""
        success, rvec, tvec = cv2.solvePnP(
            self.obj_points, marker_corner, self.camera_matrix, self.dist_coeffs
        )
        if not success: return None

        rmat, _ = cv2.Rodrigues(rvec)
        euler = cv2.RQDecomp3x3(rmat)[0]
        
        return {
            "id": marker_id, "corners": marker_corner,
            "rvec_raw": rvec, "tvec_raw": tvec,
            "method": method_name, "confidence": conf,
            "pose": {
                "tx": tvec[0][0]*100, "ty": tvec[1][0]*100, "tz": tvec[2][0]*100,
                "pitch": euler[0], "yaw": euler[1], "roll": euler[2]
            }
        }

    def solve(self, gray_frame):
        if gray_frame is None: return [], "Empty frame"
        height, width = gray_frame.shape[:2]
        self._update_camera_for_frame(width, height)
        results = []
        
        # 1. 尝试 ArUco 原生探测
        corners, ids, _ = self._detect_markers(gray_frame)
        active_ids = []
        if ids is not None:
            active_ids = [int(i[0]) for i in ids]
            id_to_corners = {int(ids[i][0]): corners[i] for i in range(len(ids))}
        else:
            id_to_corners = {}

        # 2. 处理所有已知的追踪 ID (融合逻辑)
        # 获取所有待更新的 ID（包括刚看到的和之前留下的）
        all_tracked_ids = set(self.last_corners.keys()) | set(id_to_corners.keys())
        
        for m_id in list(all_tracked_ids):
            # --- A. 状态初始化与预测 ---
            if m_id not in self.kalmans:
                if m_id in id_to_corners:
                    cx, cy = np.mean(id_to_corners[m_id][0], axis=0)
                    self.kalmans[m_id] = MarkerCAKalman(cx, cy)
                    self.confidence[m_id] = 1.0
                    self.offsets[m_id] = np.zeros((1, 4, 2), dtype=np.float32)
                else: continue # 没见过且现在也没看到，跳过

            # 提前执行物理预测
            pred_state = self.kalmans[m_id].predict()
            pred_xy = pred_state[0:2]
            pred_v = pred_state[2:4]

            # --- B. 核心融合逻辑 ---
            current_output_corners = None
            method = ""

            if m_id in id_to_corners:
                # 轨道 1: ArUco 强锁定
                observed = id_to_corners[m_id]
                self.kalmans[m_id].correct(np.mean(observed[0], axis=0)[0], np.mean(observed[0], axis=0)[1])
                
                # 【软着陆】检查：如果之前有偏移，逐渐消除它
                if m_id in self.last_corners:
                    raw_diff = observed - self.last_corners[m_id] # 实际跳变
                    # 如果跳变过大，说明刚找回来，计算偏移量补偿
                    # 此处逻辑简化：直接利用插值逐渐收敛
                    pass 
                
                current_output_corners = observed
                self.confidence[m_id] = 1.0
                method = "aruco_locked"
            
            elif m_id in self.last_corners and self.last_gray is not None:
                # 轨道 2/3: 视觉丢失，惯性+光流导航
                if self.confidence[m_id] > 0:
                    # 使用 Kalman 预测的速度作为光流初值
                    p0 = self.last_corners[m_id].reshape(-1, 1, 2)
                    p1_guess = p0 + np.array([[[pred_v[0], pred_v[1]]]], dtype=np.float32)
                    
                    p1, st, _ = cv2.calcOpticalFlowPyrLK(
                        self.last_gray, gray_frame, p0, p1_guess, 
                        flags=cv2.OPTFLOW_USE_INITIAL_FLOW, **self.lk_params
                    )
                    
                    if st is not None and all(st == 1):
                        # 光流成功：结合 Kalman 更新状态
                        current_output_corners = p1.reshape(1, 4, 2)
                        cx, cy = np.mean(current_output_corners[0], axis=0)
                        self.kalmans[m_id].correct(cx, cy)
                        method = "flow_track"
                    else:
                        # 仅剩物理模拟 (Ghost Tracking)
                        # 将上一帧角点整体按照预测速度平移
                        current_output_corners = self.last_corners[m_id] + np.array([[[pred_v[0], pred_v[1]]]], dtype=np.float32)
                        method = "inertial_guess"
                    
                    # 降低置信度
                    self.confidence[m_id] -= self.conf_decay
                else:
                    # 彻底消失
                    del self.kalmans[m_id]
                    del self.last_corners[m_id]
                    del self.confidence[m_id]
                    continue

            # --- C. 输出与记忆 ---
            if current_output_corners is not None:
                res = self._do_pnp_math(m_id, current_output_corners, method, self.confidence[m_id])
                if res:
                    results.append(res)
                    self.last_corners[m_id] = current_output_corners

        self.last_gray = gray_frame.copy()
        return results, ""
