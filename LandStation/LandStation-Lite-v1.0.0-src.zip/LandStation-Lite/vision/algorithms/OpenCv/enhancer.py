# enhancer.py
import cv2
import numpy as np

class ImageEnhancer:
    def __init__(self):
        """初始化图像增强器，引入注意力机制"""
        # --- 基础增强参数 ---
        self.clip_limit = 3.0
        self.grid_x = 8
        self.grid_y = 8
        self.sharpen_weight = 5.0
        
        # --- 注意力机制参数 ---
        self.attention_enabled = True
        self.attention_box = None  # [x, y, w, h] 记录上一次码的位置
        self.roi_padding = 60      # 注意力区域的外扩范围（像素）
        self.focus_strength = 1.0  # 注意力区域的增强强度
        
        self._rebuild_tools()

    def _rebuild_tools(self):
        """重建底层 OpenCV 算子"""
        self.clahe = cv2.createCLAHE(
            clipLimit=float(self.clip_limit), 
            tileGridSize=(int(self.grid_x), int(self.grid_y))
        )
        
        w = float(self.sharpen_weight)
        self.sharpen_kernel = np.array([
            [ 0, -1,  0],
            [-1,  w, -1],
            [ 0, -1,  0]
        ], dtype=np.float32)

    def set_attention_from_corners(self, corners):
        """
        从 Solver 传回的角点更新注意力区域
        :param corners: numpy array (1, 4, 2) or list of arrays
        """
        if corners is not None and len(corners) > 0:
            import numpy as np
            # 兼容单码 array 和多码 list，直接展平为 Nx2 数组提取 min/max
            pts = np.array(corners).reshape(-1, 2)
            x_min, y_min = np.min(pts, axis=0)
            x_max, y_max = np.max(pts, axis=0)
            
            # 计算带 Padding 的矩形
            self.attention_box = [
                int(x_min - self.roi_padding),
                int(y_min - self.roi_padding),
                int(x_max + self.roi_padding),
                int(y_max + self.roi_padding)
            ]
        else:
            self.attention_box = None

    def update_params(self, params_dict):
        """热更新接口，增加注意力相关开关"""
        try:
            self.clip_limit = params_dict.get('clip_limit', self.clip_limit)
            self.grid_x = params_dict.get('grid_x', self.grid_x)
            self.grid_y = params_dict.get('grid_y', self.grid_y)
            self.sharpen_weight = params_dict.get('sharpen_weight', self.sharpen_weight)
            self.attention_enabled = params_dict.get('use_attention', self.attention_enabled)
            self.roi_padding = int(params_dict.get('roi_padding', self.roi_padding))
            
            self._rebuild_tools()
        except Exception as e:
            print(f"[Enhancer] 参数更新异常: {e}")

    def process(self, frame):
        """
        执行【空间注意力】增强流水线
        """
        if frame is None:
            return None, "Empty frame"

        # 1. 基础灰度转换
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # 如果未开启注意力或找不到目标，则退化为全屏增强（原有逻辑）
        if not self.attention_enabled or self.attention_box is None:
            try:
                enhanced = self.clahe.apply(gray)
                sharpened = cv2.filter2D(enhanced, -1, self.sharpen_kernel)
                # 全屏黑白增强
                return cv2.cvtColor(sharpened, cv2.COLOR_GRAY2BGR), ""
            except Exception as e:
                return frame, str(e)

        # 2. 空间注意力逻辑
        try:
            h, w = gray.shape
            x1, y1, x2, y2 = self.attention_box
            
            # 越界修正
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(w, x2), min(h, y2)

            # 提取 ROI 区域进行局部增强
            roi = gray[y1:y2, x1:x2]
            if roi.size == 0:
                return frame, "ROI size 0"

            # 仅对 ROI 应用 CLAHE 和锐化
            enhanced_roi = self.clahe.apply(roi)
            sharpened_roi = cv2.filter2D(enhanced_roi, -1, self.sharpen_kernel)

            # 🚀 [核心修复]：背景保留彩色，仅让目标区域（ROI）变成增强后的状态
            result_color = frame.copy()
            # 将单通道的黑白锐化图转为三通道，以便能贴回彩图中
            sharpened_bgr = cv2.cvtColor(sharpened_roi, cv2.COLOR_GRAY2BGR)
            result_color[y1:y2, x1:x2] = sharpened_bgr

            return result_color, ""

        except Exception as e:
            print(f"[Enhancer Guard] 注意力增强失败: {e}")
            return self.clahe.apply(gray), str(e)