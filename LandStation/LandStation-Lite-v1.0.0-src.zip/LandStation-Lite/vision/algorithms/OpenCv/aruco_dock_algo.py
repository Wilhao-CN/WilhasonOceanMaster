# 文件路径: vision/algorithms/OpenCv/aruco_dock_algo.py
import cv2
import cv2.aruco as aruco
import numpy as np

try:
    from vision.base_algo import BaseVisionAlgo, DetectionResult
except ImportError:
    # 兼容直接运行测试
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from base_algo import BaseVisionAlgo, DetectionResult

# 引入图像增强算子
try:
    from vision.algorithms.OpenCv.enhancer import ImageEnhancer
except ImportError:
    from enhancer import ImageEnhancer

class ArucoDockAlgo(BaseVisionAlgo):
    """
    ArUco 二维码对接算法
    专门用于近距离停靠，计算相机到二维码的相对位姿 (距离 + 角度)
    """
    def get_plugin_info(self):
        return {
            "name": "ArUco 靠泊测距",
            "id": "aruco_dock",
            "params": {"marker_size": self.params.get("marker_size", 0.14) if hasattr(self, 'params') else 0.14}
        }

    def __init__(self, params=None):
        super().__init__(params)
        
        # --- 0. 初始化图像增强与注意力机制 ---
        self.enhancer = ImageEnhancer()
        self.debug_view = False # UI 决定是否返回 X光 图像
        self.params = params or {}
        
        # --- 1. 挂载强化求解器与滤波器 ---
        try:
            from vision.algorithms.OpenCv.solver import ArucoSolver
            from vision.algorithms.OpenCv.stabilizer import PoseStabilizer
        except ImportError:
            from solver import ArucoSolver
            from stabilizer import PoseStabilizer

        self.solver = ArucoSolver()
        self._stabilizer_class = PoseStabilizer
        # 每个ID必须拥有独立滤波历史，否则多码同帧会互相污染位姿。
        self.stabilizers = {}
        self._stabilizer_params = {}
        
        # 四码感知约定：ID0/ID1 为入口，ID2/ID3 为终点。
        self.marker_size = self.params.get("marker_size", 0.14)
        self.valid_ids = list(self.params.get("valid_ids", [0, 1, 2, 3]))
        self.health_frame_count = 0
        self.health_by_id = {
            marker_id: self._new_health_state() for marker_id in self.valid_ids
        }
        
        self.solver.update_params({
            'marker_size': self.marker_size,
            'camera_profile': self.params.get('camera_profile', 'auto'),
            'unity_vertical_fov_deg': self.params.get('unity_vertical_fov_deg', 60.0),
        })

    @staticmethod
    def _new_health_state():
        return {
            "frames": 0,
            "direct_hits": 0,
            "current_miss_streak": 0,
            "max_miss_streak": 0,
            "dropout_events": 0,
            "ever_seen": False,
            "reacquire_frames": [],
        }

    def update_params(self, params: dict):
        """接收 UI 发来的实时图像增强配置"""
        super().update_params(params)
        if hasattr(self, 'enhancer'):
            self.enhancer.update_params(params)
        if hasattr(self, 'solver'):
            self.solver.update_params(params)
        if 'marker_size' in params:
            self.marker_size = float(params['marker_size'])
        if 'valid_ids' in params:
            self.valid_ids = [int(value) for value in params['valid_ids']]
            for marker_id in self.valid_ids:
                self.health_by_id.setdefault(marker_id, self._new_health_state())
        self._stabilizer_params.update(params)
        for stabilizer in self.stabilizers.values():
            stabilizer.update_params(params)
        self.debug_view = params.get('debug_view', False)

    def _get_stabilizer(self, marker_id):
        stabilizer = self.stabilizers.get(marker_id)
        if stabilizer is None:
            stabilizer = self._stabilizer_class()
            stabilizer.update_params(self._stabilizer_params)
            self.stabilizers[marker_id] = stabilizer
        return stabilizer

    def process(self, frame: np.ndarray) -> list:
        """
        核心处理函数：
        输入保持视频源原始宽高比的 BGR 图像数组
        输出标准的 DetectionResult 列表
        """
        results = []
        
        h, w = frame.shape[:2]

        # --- A. 反馈环路：告知眼睛（Enhancer）该看哪 ---
        if self.solver.last_corners:
            # 四码模式必须覆盖所有已知标记，不能只围绕字典中的第一个 ID
            # 建 ROI，否则远离该 ID 的另外三个码会失去增强和重捕获机会。
            self.enhancer.set_attention_from_corners(
                list(self.solver.last_corners.values())
            )
        else:
            self.enhancer.set_attention_from_corners(None)

        # --- B. 图像增强 ---
        enhanced_img, err_msg = self.enhancer.process(frame)
        if enhanced_img is None:
            enhanced_img = frame # 兜底逻辑

        # 直接检测和光流必须使用原始灰度。全屏 CLAHE + 强锐化会破坏仅十余像素
        # 的 4x4 小码单元边界；增强图只保留给调试视图观察。
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # --- C. 核心计算 (检测+光流+卡尔曼) ---
        solver_results, _ = self.solver.solve(gray_frame)

        direct_ids = set()
        tracked_ids = set()
        if solver_results:
            for res in solver_results:
                marker_id = res["id"]
                
                # 🚫 [拦截假阳性] 忽略非法 ID 的误识别！
                if marker_id not in self.valid_ids:
                    continue
                
                corners = res["corners"]
                method = res["method"] # 例如: aruco_locked, flow_track 等
                conf = res["confidence"]
                tracked_ids.add(marker_id)
                if method == "aruco_locked":
                    direct_ids.add(marker_id)

                # 1. 1-Euro 数据平滑
                smooth_pose, _ = self._get_stabilizer(marker_id).update(res["pose"])

                # 2. 获取 2D bbox 
                pts = corners[0]
                x1 = float(np.min(pts[:, 0]))
                y1 = float(np.min(pts[:, 1]))
                x2 = float(np.max(pts[:, 0]))
                y2 = float(np.max(pts[:, 1]))

                norm_bbox = (x1/w, y1/h, x2/w, y2/h)
                
                import math
                
                # 读取解算好的最终防抖数据
                tx = smooth_pose["tx"]
                ty = smooth_pose["ty"]
                tz = smooth_pose["tz"]
                pitch = smooth_pose["pitch"]
                yaw = smooth_pose["yaw"]
                roll = smooth_pose["roll"]
                
                straight_dist = math.sqrt(tx**2 + ty**2 + tz**2)
                pos_angle = math.degrees(math.atan2(tx, tz))
                
                # 依然维持你刚才要的角度
                rvec_raw = res["rvec_raw"]
                rot_angle = math.degrees(np.linalg.norm(rvec_raw))
                
                # 拼接显示内容：HUD 只放短标签，完整数据由 extra 字段与「四码距离清单」面板提供
                label_text = f"ID{marker_id}·{straight_dist:.0f}cm·{pos_angle:.1f}°"

                res_obj = DetectionResult(
                    algo_id="aruco_dock",
                    label=label_text,
                    confidence=conf,
                    bbox=norm_bbox,
                    extra={
                        "marker_id": marker_id,
                        "pos_angle_deg": pos_angle,
                        "straight_dist_cm": straight_dist,
                        "tracking_method": method,
                        "translation_cm": {"x": tx, "y": ty, "z": tz},
                        "euler_deg": {"pitch": pitch, "yaw": yaw, "roll": roll}
                    }
                )
                results.append(res_obj)
        results.append(self._build_health_result(direct_ids, tracked_ids))
        # solver彻底遗忘的ID同时释放其独立滤波器；短时光流期间仍保留。
        tracked_ids = set(self.solver.last_corners)
        for marker_id in list(self.stabilizers):
            if marker_id not in tracked_ids:
                self.stabilizers.pop(marker_id, None)
             
        # 💡 [X光图像回显] 假如UI开启了Show Enhanced 'X-Ray' View，我们需要通知视窗
        if getattr(self, 'debug_view', False):
            # 将混合图(全屏彩色+ROI局部黑白增强) 缩小并压缩，塞进通信队列传给前端！
            small_img = cv2.resize(enhanced_img, (320, 240))
            _, buffer = cv2.imencode('.jpg', small_img, [cv2.IMWRITE_JPEG_QUALITY, 60])
            import base64
            b64_str = base64.b64encode(buffer).decode('utf-8')
            
            res_xray = DetectionResult(
                algo_id="xray_frame",
                label="X-Ray",
                confidence=1.0,
                bbox=[0,0,0,0],
                extra={"image_b64": b64_str}
            )
            results.append(res_xray)

        return results

    def _build_health_result(self, direct_ids, tracked_ids):
        """Update direct-detection dropout counters for one real source frame."""
        self.health_frame_count += 1
        per_id = {}
        for marker_id in self.valid_ids:
            state = self.health_by_id.setdefault(marker_id, self._new_health_state())
            state["frames"] += 1
            if marker_id in direct_ids:
                state["direct_hits"] += 1
                missed = state["current_miss_streak"]
                if state["ever_seen"] and missed > 0:
                    state["reacquire_frames"].append(missed)
                state["current_miss_streak"] = 0
                state["ever_seen"] = True
            else:
                state["current_miss_streak"] += 1
                if state["ever_seen"] and state["current_miss_streak"] == 1:
                    state["dropout_events"] += 1
                state["max_miss_streak"] = max(
                    state["max_miss_streak"], state["current_miss_streak"]
                )

            reacquire = state["reacquire_frames"]
            per_id[str(marker_id)] = {
                "frames": state["frames"],
                "direct_hits": state["direct_hits"],
                "direct_rate": state["direct_hits"] / max(1, state["frames"]),
                "current_miss_streak": state["current_miss_streak"],
                "max_miss_streak": state["max_miss_streak"],
                "dropout_events": state["dropout_events"],
                "ever_seen": state["ever_seen"],
                "mean_reacquire_frames": (
                    float(np.mean(reacquire)) if reacquire else 0.0
                ),
                "max_reacquire_frames": max(reacquire) if reacquire else 0,
            }

        direct_text = ",".join(str(value) for value in sorted(direct_ids)) or "--"
        return DetectionResult(
            algo_id="aruco_health",
            label=f"Direct IDs: {direct_text}",
            confidence=1.0,
            bbox=[0.0, 0.0, 0.0, 0.0],
            extra={
                "frame_count": self.health_frame_count,
                "expected_ids": list(self.valid_ids),
                "direct_ids": sorted(direct_ids),
                "tracked_ids": sorted(tracked_ids),
                "missing_ids": sorted(set(self.valid_ids) - set(direct_ids)),
                "per_id": per_id,
            },
        )

    def reset(self):
        self.enhancer.set_attention_from_corners(None)
        self.stabilizers.clear()
        if hasattr(self, 'solver'):
            self.solver.last_corners.clear()
            self.solver.kalmans.clear()
        self.health_frame_count = 0
        self.health_by_id = {
            marker_id: self._new_health_state() for marker_id in self.valid_ids
        }
