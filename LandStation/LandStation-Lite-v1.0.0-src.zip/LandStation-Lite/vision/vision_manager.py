# 文件路径: vision/vision_manager.py
from PyQt5.QtCore import QObject, pyqtSignal, QTimer
import multiprocessing as mp
from typing import Dict

# 导入之前的组件
from vision.shared_mem import VisionSyncManager
from vision.vision_process import VisionProcess

class VisionManager(QObject):
    """
    主进程视觉管理中心：负责维护进程生命周期与数据分发
    """
    # 💡 信号：当 AI 结果返回时，通知 UI 画框
    # 格式: {"id": "dock", "data": [DetectionResult, ...]}
    sig_vision_results = pyqtSignal(dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # 1. 初始化通信管道
        self.cmd_queue = mp.Queue()
        # 视觉结果只需要“最新状态”。限制队列深度，避免算法短时突发时
        # 前端显示数秒前的旧框和旧丢码状态。
        self.result_queue = mp.Queue(maxsize=4)
        
        # 2. 申请共享内存空间 (create=True 表示主进程创建)
        self.shm_sync = VisionSyncManager(create=True)
        
        # 3. 实例化并启动后台进程
        self.process = VisionProcess(
            cmd_queue=self.cmd_queue,
            result_queue=self.result_queue,
            shared_mem_dict=self.shm_sync.names,
        )
        # 💡 [第一重防线]：设置为守护进程！主窗口一关，它必死无疑！
        self.process.daemon = True  
        self.process.start()

        
        # 4. 定时器：轮询 AI 结果队列并转发为信号
        self.result_timer = QTimer(self)
        self.result_timer.timeout.connect(self._poll_results)
        self.result_timer.start(20) # 50Hz 轮询，足以覆盖 30FPS 的视觉回传

    def link_video_threads(self, dock_thread, boat_thread):
        """
        核心连接：将视频线程与对应的共享内存挂接
        """
        if dock_thread:
            dock_thread.set_shm_buffer(self.shm_sync.get_buffer("dock"))
        if boat_thread:
            boat_thread.set_shm_buffer(self.shm_sync.get_buffer("boat"))

    def toggle_algorithm(self, target: str, algo_id: str, enabled: bool, params: dict = None):
        """
        对外接口：UI 通过此方法开启/关闭某个算法
        :param target: "dock" 或 "boat"
        :param algo_id: 算法插件 ID (如 "yolo_v8")
        """
        cmd = "enable" if enabled else "disable"
        msg = {
            "target": target,
            "cmd": cmd,
            "algo_id": algo_id,
            "params": params
        }
        self.cmd_queue.put(msg)

    def update_algo_params(self, target: str, algo_id: str, params: dict):
        """
        对外接口：UI 通过此方法实时动态更新算法运行参数(如图像增强系数)
        """
        msg = {
            "target": target,
            "cmd": "update_params",
            "algo_id": algo_id,
            "params": params
        }
        self.cmd_queue.put(msg)

    def send_imu(self, target: str, imu_dict: dict):
        """
        📏 将 IMU 数据推送到视觉进程，用于障碍物距离估计的光流旋转补偿
        :param target: "dock" 或 "boat"
        :param imu_dict: 协议解析的 IMU 字典，包含 yaw_rate, imu_vel_x 等字段
        """
        msg = {
            "target": target,
            "cmd": "set_imu",
            "imu": imu_dict
        }
        self.cmd_queue.put(msg)

    def _poll_results(self):
        """
        检查结果队列，将其转化为 PyQt 信号发射出去
        🚀 [优化] 每次最多处理 3 批，防止队列积压导致主线程连续同步阻塞
        """
        try:
            count = 0
            while not self.result_queue.empty() and count < 3:
                # 拿到算力进程打包好的结果列表
                results_batch = self.result_queue.get_nowait()
                for item in results_batch:
                    # item 格式: {"id": "dock", "data": [...]}
                    self.sig_vision_results.emit(item)
                count += 1
        except Exception:
            pass

    # def cleanup(self):
    #     """
    #     安全退出：销毁进程与内存
    #     """
    #     self.result_timer.stop()
    #     self.cmd_queue.put({"cmd": "stop_all"})
    #     self.process.join(timeout=1.0)
    #     self.shm_sync.cleanup()
    #     print("✅ [VisionManager] 视觉系统已安全关闭并释放资源")
    def cleanup(self):
        """
        安全退出：销毁进程与内存 (带强制斩杀机制)
        """
        self.result_timer.stop()
        self.cmd_queue.put({"cmd": "stop_all"})
        
        # 等待 1 秒看它能不能体面地自己死掉
        self.process.join(timeout=1.0)
        
        # 💡 [第二重防线]：如果 1 秒后它还活着（不体面），我们就帮它体面（强杀）
        if self.process.is_alive():
            print("⚠️ [VisionManager] 视觉进程未正常响应停止指令，执行强制斩杀！")
            self.process.terminate()
            self.process.join() # 确保强杀完毕
            
        self.shm_sync.cleanup()
        print("✅ [VisionManager] 视觉系统已安全关闭并释放资源")
