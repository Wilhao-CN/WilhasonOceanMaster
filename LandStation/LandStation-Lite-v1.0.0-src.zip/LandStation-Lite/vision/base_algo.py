# 文件路径: vision/base_algo.py
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Dict, Any
import numpy as np

@dataclass
class DetectionResult:
    """
    统一的视觉识别结果结构
    """
    algo_id: str               # 算法标识 (如 "yolo_v8")
    label: str                 # 目标类别 (如 "boat", "dock")
    confidence: float          # 置信度 (0.0 - 1.0)
    # 💡 核心：归一化坐标 [x_min, y_min, x_max, y_max] 范围 0.0-1.0
    # 使用归一化坐标是为了在不同大小的弹窗、缩略图中画框时，不需要重复计算。
    bbox: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0, 0.0])
    
    # 预留扩展字段 (如：跟踪 ID、中心点偏差等)
    extra: Dict[str, Any] = field(default_factory=dict)

class BaseVisionAlgo(ABC):
    """
    视觉算法插件基类
    """
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.is_enabled = False # 该插件是否被 UI 勾选开启

    def update_params(self, params: Dict[str, Any]):
        """
        接收来自UI界面的参数更新（例如图像增强系数）并合并到内部配置中
        具体算法如果需要在参数变更时重新初始化某些对象，可重写此方法
        """
        self.config.update(params)

    @abstractmethod
    def get_plugin_info(self) -> Dict[str, Any]:
        """
        💡 插件自述信息
        返回格式: {
            "name": "YOLO 目标检测",
            "id": "yolo_v8",
            "params": {"conf_threshold": 0.5} # 供 UI 自动生成调节滑块
        }
        """
        pass

    @abstractmethod
    def process(self, frame: np.ndarray) -> List[DetectionResult]:
        """
        💡 核心推理接口
        输入: 原始 BGR/RGB 图像 (NumPy 数组)
        输出: 检测结果列表
        """
        pass

    def update_config(self, new_config: Dict[str, Any]):
        """
        由 UI 实时调整算法参数 (如阈值)
        """
        self.config.update(new_config)
        