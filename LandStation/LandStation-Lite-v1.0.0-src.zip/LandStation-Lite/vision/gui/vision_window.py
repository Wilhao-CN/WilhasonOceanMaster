# 文件路径: vision/gui/vision_window.py
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                             QGroupBox, QCheckBox, QScrollArea, QFrame, QSplitter,
                             QSizePolicy)
from PyQt5.QtCore import QObject, Qt, pyqtSignal, pyqtSlot, QRectF, QTimer, QSize, QThread
from PyQt5.QtGui import QPainter, QColor, QPen, QFont, QPixmap, QImage
from core.vision.shadow_controller import ShadowDockingSupervisor
from core.vision.three_marker_docking import (
    DockMarkerObservation,
    ThreeMarkerDockingPlanner,
)
from core.vision.control_source import describe_boat_control, describe_dock_control


class HUDVideoLabel(QLabel):
    """
    HUD 视频图层：负责渲染视频，并在其上绘制 AI 识别结果
    优化：仅负责显示与 HUD 绘制，不负责任何图像缩放计算。
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("background-color: black;")
        self.results = []
        self.current_fps = 0.0            # 📊 实时帧率
        self.nof_consecutive = 0          # 🎯 连续识别到 NOF 的帧数（HUD 显示）

    def set_nof_consecutive(self, count: int):
        """🎯 更新 HUD 上显示的「NOF 连续识别帧数」。"""
        self.nof_consecutive = int(count)
        self.update()

    def update_vision_data(self, results):
        """接收归一化坐标并刷新图层"""
        self.results = results

        # 🚀 [性能优化] 预先在数据到达时解码一次图像，避免在高频 paintEvent 中解码！
        self.cached_xray_qimg = None

        for res in self.results:
            algo = getattr(res, "algo_id", None)

            if algo == "xray_frame":
                b64_str = getattr(res, "extra", {}).get("image_b64")
                if b64_str:
                    import base64
                    img_data = base64.b64decode(b64_str)
                    ximg = QImage()
                    ximg.loadFromData(img_data)
                    self.cached_xray_qimg = ximg

        self.update()

    def paintEvent(self, event):
        # 1. 拦截神秘的 X-Ray 回传图像并覆盖原画面
        xray_qimg = getattr(self, "cached_xray_qimg", None)

        if xray_qimg and not xray_qimg.isNull():
            # 自己画 X-Ray 底图
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)
            # 扩展到当前标签大小
            scaled_xray = xray_qimg.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            # 为了居中
            ox = (self.width() - scaled_xray.width()) // 2
            oy = (self.height() - scaled_xray.height()) // 2
            painter.drawImage(ox, oy, scaled_xray)
            
            # 使用 X-Ray 图片尺寸作为后续画框基准
            pix_w, pix_h = scaled_xray.width(), scaled_xray.height()
            offset_x, offset_y = ox, oy
        else:
            # 没有开启 X-Ray 时，执行原有的基类视频显示
            super().paintEvent(event)
            pix = self.pixmap()
            if not pix: return
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)
            pix_w, pix_h = pix.width(), pix.height()
            offset_x = (self.width() - pix_w) // 2
            offset_y = (self.height() - pix_h) // 2

        # 📊 实时帧率显示 (画面右上角)
        if self.current_fps > 0:
            fps_text = f"FPS: {self.current_fps:.1f}"
            fps_font = QFont("Consolas", 11, QFont.Bold)
            painter.setFont(fps_font)
            fps_fm = painter.fontMetrics()
            fps_text_width = fps_fm.boundingRect(fps_text).width() + 12
            fps_x = offset_x + pix_w - fps_text_width - 4
            fps_y = offset_y + 4
            painter.setBrush(QColor(0, 0, 0, 140))
            painter.setPen(Qt.NoPen)
            painter.drawRect(fps_x, fps_y, fps_text_width, 22)
            if self.current_fps >= 25:
                fps_color = QColor(0, 255, 0)
            elif self.current_fps >= 15:
                fps_color = QColor(255, 255, 0)
            else:
                fps_color = QColor(255, 80, 80)
            painter.setPen(fps_color)
            painter.drawText(fps_x + 6, fps_y + 16, fps_text)

        # 🎯 NOF 连续识别帧数显示 (FPS 下方)
        if self.nof_consecutive > 0:
            nof_text = f"NOF连续: {self.nof_consecutive}帧"
            nof_font = QFont("Consolas", 11, QFont.Bold)
            painter.setFont(nof_font)
            nof_fm = painter.fontMetrics()
            nof_text_width = nof_fm.boundingRect(nof_text).width() + 12
            nof_x = offset_x + pix_w - nof_text_width - 4
            nof_y = offset_y + 28
            painter.setBrush(QColor(0, 0, 0, 140))
            painter.setPen(Qt.NoPen)
            painter.drawRect(nof_x, nof_y, nof_text_width, 22)
            painter.setPen(QColor(0, 255, 128))
            painter.drawText(nof_x + 6, nof_y + 16, nof_text)

        # ── 🎯 四码距离清单 (左上角固定面板，不遮挡中间画面) ──
        if any(getattr(res, "algo_id", None) in {"aruco_dock", "aruco_health"}
               for res in self.results):
            aruco_by_id = {}
            for res in self.results:
                if getattr(res, "algo_id", None) == "aruco_dock":
                    extra = getattr(res, "extra", {}) or {}
                    mid = extra.get("marker_id")
                    if mid is not None:
                        aruco_by_id[int(mid)] = extra

            method_tag = {"aruco_locked": "锁", "flow_track": "流", "inertial_guess": "惯"}
            panel_lines = ["四码距离清单"]
            for mid in (0, 1, 2, 3):
                info = aruco_by_id.get(mid)
                if info is None:
                    panel_lines.append(f"ID{mid}  --")
                    continue
                d = info.get("straight_dist_cm")
                a = info.get("pos_angle_deg")
                m = method_tag.get(str(info.get("tracking_method", "")), "?")
                d_text = "--" if d is None else f"{d:.0f}cm"
                a_text = "--" if a is None else f"{a:.1f}°"
                panel_lines.append(f"ID{mid}  {d_text}  {a_text}  {m}")

            panel_font = QFont("Consolas", 10, QFont.Bold)
            painter.setFont(panel_font)
            pfm = painter.fontMetrics()
            line_h = pfm.height() + 4
            pad = 6
            max_w = max(pfm.boundingRect(line).width() for line in panel_lines)
            panel_w = max_w + pad * 2
            panel_h = line_h * len(panel_lines) + pad * 2
            panel_x = int(offset_x) + 4
            panel_y = int(offset_y) + 4

            painter.setBrush(QColor(0, 0, 0, 150))
            painter.setPen(Qt.NoPen)
            painter.drawRect(panel_x, panel_y, panel_w, panel_h)

            for i, line in enumerate(panel_lines):
                yy = panel_y + pad + i * line_h + pfm.ascent()
                if i == 0:
                    painter.setPen(QColor(0, 255, 255))
                else:
                    painter.setPen(QColor(255, 255, 255))
                painter.drawText(panel_x + pad, yy, line)

        if not self.results:
            painter.end()
            return

        # ── 第一步：先画所有检测框，同时收集文字信息 ──
        draw_items = []
        for res in self.results:
            if getattr(res, "algo_id", None) in {"xray_frame", "aruco_health"}:
                continue # 跳过专门传图的框

            x1, y1, x2, y2 = res.bbox
            rx1 = offset_x + (x1 * pix_w)
            ry1 = offset_y + (y1 * pix_h)
            rx2 = offset_x + (x2 * pix_w)
            ry2 = offset_y + (y2 * pix_h)

            # 为不同算法分配专属颜色
            if res.algo_id == "yolo_v8":
                color = QColor(0, 255, 0)      # 绿色
                display_text = f"{res.label} {res.confidence:.2f}"
            elif res.algo_id == "aruco_dock":
                color = QColor(0, 255, 255)    # 青色 (专门用于高精度定位)
                display_text = res.label       # ArUco 不显示置信度，只显示数据
            else:
                color = QColor(255, 255, 0)    # 黄色 (默认兜底)
                display_text = f"{res.label} {res.confidence:.2f}"

            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(color, 2))
            painter.drawRect(QRectF(rx1, ry1, rx2 - rx1, ry2 - ry1))

            draw_items.append({
                "rx1": rx1, "ry1": ry1, "ry2": ry2,
                "text": display_text, "color": color,
            })

        # ── 第二步：统一绘制文字标签，带防重叠布局 ──
        font = QFont("Consolas", 10, QFont.Bold)
        painter.setFont(font)
        fm = painter.fontMetrics()
        label_h = 20
        gap = 2
        right_edge = offset_x + pix_w
        left_edge = int(offset_x)

        def _base_y(item):
            # 纵向自适应：上方空间不够时，标签移到框下方
            y = int(item["ry1"] - label_h)
            if y < offset_y:
                y = int(item["ry2"] + 2)
            return y

        # 按基准 y 排序，重叠时自上而下顺序展开，避免四码距离文字叠成一团
        draw_items.sort(key=_base_y)

        placed = []
        for item in draw_items:
            text_width = fm.boundingRect(item["text"]).width() + 10

            # 横向防溢出：标签超出右侧时自动左移
            x = int(item["rx1"])
            if x + text_width > right_edge:
                x = int(right_edge - text_width - 2)
            if x < left_edge:
                x = left_edge

            y = _base_y(item)

            # 防重叠：与已放置标签逐一比对，相交则向下推
            while True:
                hit = False
                for (px, py, pw, ph) in placed:
                    if (x < px + pw and px < x + text_width
                            and y < py + ph and py < y + label_h):
                        y = py + ph + gap
                        hit = True
                        break
                if not hit:
                    break

            placed.append((x, y, text_width, label_h))

            painter.setBrush(item["color"])
            painter.setPen(Qt.NoPen)
            painter.drawRect(x, y, text_width, label_h)
            painter.setPen(item.get("text_color", QColor(0, 0, 0)))
            painter.drawText(x + 5, y + 15, item["text"])

        painter.end()


class VideoSurface(QWidget):
    """左侧视频画布：把 HUD 视频标签锁死在“源画面的原生宽高比”上。

    地面站两条链路都是按“控件尺寸”出图的：
      * 实机 UDP 链路在 core/Thread/video_thread.py 里按 target_size 做 cv2.resize；
      * 孪生 ZMQ 链路保留原帧，由 VisionWindow.update_frame 等比缩放进控件。
    所以只要视频标签自身的比例 = 源画面比例，窗口怎么拉、右侧分割条怎么拖，画面都不会变形：
      * 实机 640×480 (4:3) → 视频区 4:3，等比放大后正好铺满；
      * 数字孪生 Unity (16:9) → 视频区 16:9，保持原生比例，不压扁也不留黑边。
    初始比例由链路决定（VisionWindow 构造参数），之后由 follow_source() 按真实帧自动校正。
    """

    # 视频标签的实际尺寸变化（恒为当前源比例），转发给 VisionWindow.sig_resized
    sig_video_size_changed = pyqtSignal(QSize)

    # 允许的比例范围，防止异常帧把视频区拉成细条
    MIN_ASPECT = 0.5
    MAX_ASPECT = 2.6

    def __init__(self, aspect_w: int = 4, aspect_h: int = 3, parent=None):
        super().__init__(parent)
        self._aspect = float(aspect_w) / float(aspect_h)
        self.setStyleSheet("background-color: black;")  # 画面外的留边
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(160, 120)
        self.video_label = HUDVideoLabel(self)
        # 窗口还没走过 resizeEvent 之前（start_video_display 就在这个阶段取尺寸），
        # 也要保证标签已是目标比例，否则会把 QLabel 默认的 100×30 当成目标尺寸发给后台。
        hint = self.sizeHint()
        self.video_label.setGeometry(0, 0, hint.width(), hint.height())

    def sizeHint(self):
        """给分割条一个建议尺寸（按当前比例），保证首次显示时左区不会被压成畸形。"""
        height = 660
        width = int(round(height * self._aspect))
        return QSize(width, height)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.apply_aspect_ratio()
        self._emit_video_size()

    def apply_aspect_ratio(self):
        """在画布内居中放置一个当前比例的视频标签，多余空间留黑边。"""
        w, h = self.width(), self.height()
        if w <= 0 or h <= 0:
            return
        label_w = min(w, int(round(h * self._aspect)))
        label_h = int(round(label_w / self._aspect))
        if label_h > h:  # 极端窄高时的兜底
            label_h = h
            label_w = int(round(label_h * self._aspect))
        self.video_label.setGeometry(
            (w - label_w) // 2, (h - label_h) // 2, label_w, label_h
        )

    def set_aspect_ratio(self, aspect_w, aspect_h=None):
        """切换视频区比例（可传 (16, 9) 或直接传 16/9 的比值）。返回是否发生变化。"""
        if aspect_h is None:
            aspect = float(aspect_w)
        else:
            aspect = float(aspect_w) / float(aspect_h)
        aspect = min(max(aspect, self.MIN_ASPECT), self.MAX_ASPECT)
        if abs(aspect - self._aspect) < 1e-4:
            return False
        self._aspect = aspect
        self.apply_aspect_ratio()
        self._emit_video_size()
        return True

    def follow_source(self, frame_width: int, frame_height: int):
        """按真实收到的帧把视频区调成源比例（实机 4:3 / 孪生 16:9 都是原生显示）。"""
        if frame_width < 32 or frame_height < 32:
            return False
        ratio = float(frame_width) / float(frame_height)
        if abs(ratio - self._aspect) <= self._aspect * 0.01:  # 1% 容差，避免抖动
            return False
        return self.set_aspect_ratio(ratio)

    def _emit_video_size(self):
        size = self.video_label.size()
        if size.width() > 0 and size.height() > 0:
            self.sig_video_size_changed.emit(size)


class VisionWindow(QWidget):
    """
    视觉任务中心窗口：具备视频 HUD 与算法插件面板
    """
    sig_closed = pyqtSignal()
    sig_toggle_algo = pyqtSignal(str, str, bool) 
    sig_update_algo_params = pyqtSignal(str, str, dict) 
    # 🚀 [新增] 尺寸变更信号：用于实时通知后台线程调整缩放比例
    sig_resized = pyqtSignal(QSize)
    
    # 🚀 [新增] 请求开始纯视觉闭环对接的信号 (目标ID, 开/关)
    sig_start_docking = pyqtSignal(str, bool)
    # 四码规划结果，仅在用户显式开启闭环按钮后发送给子船PID。
    sig_docking_guidance = pyqtSignal(str, dict)

    def __init__(self, target_id: str, title: str, parent=None, video_aspect=(4, 3)):
        """video_aspect: 视频区初始比例。实机 UDP 链路 (640×480) 传 (4, 3)；
        数字孪生 Unity 链路传 (16, 9)，保持孪生画面原生比例不变。"""
        super().__init__(parent)
        self.target_id = target_id 
        self.setWindowTitle(title)
        self.resize(1280, 780)
        self.setMinimumSize(960, 620)
        
        self.display_timer = QTimer(self)
        self.display_timer.timeout.connect(self._pull_latest_frame)
        self.video_thread_ref = None 
        self.shadow_supervisor = ShadowDockingSupervisor()
        self.three_marker_planner = ThreeMarkerDockingPlanner()
        self._shadow_guidance = None
        self._shadow_imu = {}
        self._shadow_marker_id = "--"
        self._shadow_confidence = 0.0
        self.shadow_watchdog = QTimer(self)
        self.shadow_watchdog.setInterval(50)
        self.shadow_watchdog.timeout.connect(self._refresh_shadow_watchdog)

        self.main_layout = QHBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        # 🔧 [QSplitter] 拖拽分割条即可自由缩放视频 / 面板比例
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setHandleWidth(4)
        self.splitter.setStyleSheet("QSplitter::handle { background-color: #ccc; }")

        # --- 1. 左侧：HUD 视频区 (按链路保持原生比例：实机 4:3 / 孪生 16:9) ---
        self.video_surface = VideoSurface(*video_aspect)
        self.hud_label = self.video_surface.video_label
        # 画布尺寸一变就把“视频标签尺寸”回传给后台线程；实机链路按此尺寸等比
        # 缩放 640×480 原始帧，于是画面不再随窗口被拉扁/拉长。
        self.video_surface.sig_video_size_changed.connect(self.sig_resized)
        self.splitter.addWidget(self.video_surface)

        # --- 2. 右侧：算法控制面板 ---
        self.side_panel = QFrame()
        self.side_panel.setMinimumWidth(300)
        self.side_panel.setMaximumWidth(400)
        self.side_panel.setStyleSheet("background-color: #f0f0f0; border-left: 1px solid #ccc;")
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.addWidget(QLabel("🧠 视觉算法插件"))

        # =============== 🎮 控制源指示器（实时显示谁在控制船坞/小船） ===============
        self.group_control_source = QGroupBox("🎮 控制源")
        control_layout = QVBoxLayout(self.group_control_source)
        self.lbl_control_source = QLabel(
            "<span style='color:#888'>控制源未连接</span>"
        )
        self.lbl_control_source.setWordWrap(True)
        self.lbl_control_source.setTextFormat(Qt.RichText)
        self.lbl_control_source.setStyleSheet(
            "font-family: Consolas; background-color: white; "
            "border: 1px solid #ccc; padding: 6px;"
        )
        control_layout.addWidget(self.lbl_control_source)
        self.side_layout.addWidget(self.group_control_source)

        self._dock_brain = None
        self._boat_brain = None
        self.control_source_timer = QTimer(self)
        self.control_source_timer.setInterval(300)
        self.control_source_timer.timeout.connect(self._refresh_control_source)
        self.control_source_timer.start()

        self._algo_checkboxes = {}  # algo_id -> QCheckBox，供程序化启停算法
        
        # [控制对接开关] 专门给 ArUco 添加的运动控制许可
        from PyQt5.QtWidgets import QPushButton
        self._dock_action_unlocked = False
        self.btn_dock_action = QPushButton("🚢 开始闭环对接")
        self.btn_dock_action.setStyleSheet("background-color: #d1e7dd; font-size: 14px; font-weight: bold; padding: 8px;")
        self.btn_dock_action.setCheckable(True)
        self.btn_dock_action.setEnabled(False)
        self.btn_dock_action.setText("🔒 闭环已锁定（勾选 ArUco 后解锁）")
        self.side_layout.addWidget(self.btn_dock_action)
        # 说明：_dock_action_unlocked 在上方初始化，早于 add_algo_toggle 的回调，
        # 因此初始化阶段即使算法勾选框触发也不会引用到未创建的属性。

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.group_perception_health = QGroupBox("📊 四码感知健康度")
        health_layout = QVBoxLayout(self.group_perception_health)
        self.lbl_perception_health = QLabel(
            "等待 ArUco 感知数据…\n"
            "本阶段仅统计直接检出和丢码，不允许动力闭环。"
        )
        self.lbl_perception_health.setWordWrap(True)
        self.lbl_perception_health.setStyleSheet(
            "font-family: Consolas; background-color: white; "
            "border: 1px solid #ccc; padding: 6px;"
        )
        health_layout.addWidget(self.lbl_perception_health)
        self.scroll_layout.addWidget(self.group_perception_health)
        self.scroll.setWidget(self.scroll_content)
        self.side_layout.addWidget(self.scroll)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setCollapsible(0, False)
        self.splitter.setCollapsible(1, False)
        self.splitter.setStretchFactor(0, 3)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([900, 360])
        self.main_layout.addWidget(self.splitter)

        # 绑定按钮信号去发送靠泊对接命令
        def on_dock_clicked(checked):
            if checked:
                if not self._dock_action_unlocked:
                    # 🛡️ 双保险：未解锁时勾选被拒绝，直接弹回并保持零动力
                    #    （弹回触发的 on_dock_clicked(False) 只会补发一次"取消"，
                    #      永远不会发出 True，因此不可能给动力许可）
                    self.lbl_shadow_safety.setText("🔒 动力下发：禁止（请先勾选 ArUco 靠泊测距）")
                    QTimer.singleShot(0, lambda: self.btn_dock_action.setChecked(False))
                    return
                self.shadow_supervisor.reset()
                self.three_marker_planner.reset()
                self._shadow_guidance = None
                self.shadow_watchdog.start()
                self.btn_dock_action.setText("🛑 取消对接控制")
                self.btn_dock_action.setStyleSheet("background-color: #f8d7da; font-size: 14px; font-weight: bold; padding: 8px;")
                self.lbl_shadow_safety.setText("⚠️ 动力下发：速度/艏向PID已允许")
                self.sig_start_docking.emit(self.target_id, True)
            else:
                self.btn_dock_action.setText("🚢 开始闭环对接") 
                self.btn_dock_action.setStyleSheet("background-color: #d1e7dd; font-size: 14px; font-weight: bold; padding: 8px;")
                self.lbl_shadow_safety.setText("🔒 动力下发：禁止")
                self.sig_start_docking.emit(self.target_id, False)
                if not self.btn_shadow_control.isChecked():
                    self.shadow_watchdog.stop()

        self.btn_dock_action.toggled.connect(on_dock_clicked)

        # =============== ArUco 影子控制（只计算，绝不下发动力） ===============
        self.group_shadow = QGroupBox("🧭 靠泊测距 · 影子控制")
        shadow_layout = QVBoxLayout(self.group_shadow)

        self.btn_shadow_control = QPushButton("启用影子控制（仅计算）")
        self.btn_shadow_control.setCheckable(True)
        self.btn_shadow_control.setStyleSheet(
            "background-color: #fff3cd; font-weight: bold; padding: 7px;"
        )
        self.btn_shadow_control.setEnabled(False)
        shadow_layout.addWidget(self.btn_shadow_control)

        self.lbl_shadow_safety = QLabel("🔒 动力下发：禁止")
        self.lbl_shadow_safety.setStyleSheet(
            "color: #842029; background-color: #f8d7da; "
            "font-weight: bold; padding: 5px;"
        )
        shadow_layout.addWidget(self.lbl_shadow_safety)

        self.lbl_shadow_status = QLabel("请先开启 ArUco 靠泊测距")
        self.lbl_shadow_status.setWordWrap(True)
        shadow_layout.addWidget(self.lbl_shadow_status)

        self.lbl_shadow_values = QLabel(
            "状态: LOST\n"
            "阶段: SEARCH_GATE\n"
            "目标/距离: -- / --\n"
            "视觉年龄: --\n"
            "PosAngle: --\n"
            "滤波角度: --\n"
            "目标/平滑转向: -- / --\n"
            "左/右建议: -- / --\n"
            "目标/平滑前进: -- / --\n"
            "IMU保艏: --"
        )
        self.lbl_shadow_values.setStyleSheet(
            "font-family: Consolas; background-color: white; "
            "border: 1px solid #ccc; padding: 6px;"
        )
        shadow_layout.addWidget(self.lbl_shadow_values)
        # 船坞和子船摄像头都可用于台架测试；影子模式始终只做计算。
        self.group_shadow.setVisible(True)

        self.btn_shadow_control.toggled.connect(self._on_shadow_toggled)

        # =============== 图像增强参数 (Enhancer) ===============
        from PyQt5.QtWidgets import QFormLayout, QLineEdit
        self.group_enh = QGroupBox("📸 图像增强 (X-Ray)")
        lay_enh = QFormLayout()
        
        self.cb_debug_view = QCheckBox("👁️ 显示 X-Ray 视图")
        self.cb_use_attention = QCheckBox("🎯 开启空间注意力")
        self.cb_use_attention.setChecked(True)
        
        self.in_clip = QLineEdit("3.0")
        self.in_grid = QLineEdit("8")
        self.in_sharp = QLineEdit("5.0")
        self.in_padding = QLineEdit("60")
        
        lay_enh.addRow(self.cb_debug_view)
        lay_enh.addRow(self.cb_use_attention)
        lay_enh.addRow("对比限制:", self.in_clip)
        lay_enh.addRow("网格大小:", self.in_grid)
        lay_enh.addRow("锐化权重:", self.in_sharp)
        lay_enh.addRow("搜索扩边:", self.in_padding)
        self.group_enh.setLayout(lay_enh)
        self.group_enh.hide() # 默认隐藏
        
        # 绑定参数变更信号
        self.cb_use_attention.stateChanged.connect(self.sync_enhancer_params)
        self.cb_debug_view.stateChanged.connect(self.sync_enhancer_params)
        self.in_clip.editingFinished.connect(self.sync_enhancer_params)
        self.in_grid.editingFinished.connect(self.sync_enhancer_params)
        self.in_sharp.editingFinished.connect(self.sync_enhancer_params)
        self.in_padding.editingFinished.connect(self.sync_enhancer_params)

    def _set_dock_action_unlocked(self, unlocked: bool):
        """🔓 手动解锁/锁定闭环对接按钮（勾选 ArUco 算法即可手动开启）。

        解锁只放开 UI 许可，后端安全链路完全不绕过：
        main_window._handle_docking_req 仍会校验船坞定艏保持、MPPI/任务状态与遥测新鲜度，
        校验不通过会弹框并把按钮弹回未选中。
        """
        unlocked = bool(unlocked)
        self._dock_action_unlocked = unlocked
        if unlocked:
            self.btn_dock_action.setEnabled(True)
            if not self.btn_dock_action.isChecked():
                self.btn_dock_action.setText("🚢 开始闭环对接")
        else:
            self.btn_dock_action.setEnabled(False)
            if self.btn_dock_action.isChecked():
                self.btn_dock_action.setChecked(False)   # 走 on_dock_clicked 的收尾分支
            self.btn_dock_action.setText("🔒 闭环已锁定（勾选 ArUco 后解锁）")

    def set_control_source_providers(self, dock_brain, boat_brain):
        """绑定船坞/子船控制大脑，供控制源指示器定时刷新。"""
        self._dock_brain = dock_brain
        self._boat_brain = boat_brain
        self._refresh_control_source()

    def _refresh_control_source(self):
        """轮询两个大脑的控制标志，刷新控制源指示器文案。"""
        dock_mode, dock_detail = describe_dock_control(self._dock_brain)
        boat_mode, boat_detail = describe_boat_control(self._boat_brain)

        def color(mode: str) -> str:
            if mode in ("--", "手动"):
                return "#6c757d"  # 灰
            if "视觉" in mode or "NOF" in mode or "ArUco" in mode:
                return "#0d6efd"  # 蓝
            if "任务" in mode or "返航" in mode or "稳停" in mode:
                return "#198754"  # 绿
            if "协同" in mode:
                return "#0dcaf0"  # 青
            return "#0d6efd"      # 自动 PID → 蓝

        text = (
            f"<b>🚢 船坞</b>&nbsp;&nbsp;"
            f"<span style='color:{color(dock_mode)}'><b>{dock_mode}</b></span><br>"
            f"<span style='font-size:11px;color:#777'>&nbsp;&nbsp;&nbsp;&nbsp;{dock_detail}</span><br><br>"
            f"<b>🚤 小船</b>&nbsp;&nbsp;"
            f"<span style='color:{color(boat_mode)}'><b>{boat_mode}</b></span><br>"
            f"<span style='font-size:11px;color:#777'>&nbsp;&nbsp;&nbsp;&nbsp;{boat_detail}</span>"
        )
        self.lbl_control_source.setText(text)

    # ========================================================
    def resizeEvent(self, event):
        """
        🚀 [核心接口] 窗口尺寸变化时，发射信号告知 Controller
        """
        super().resizeEvent(event)
        # 发射当前视频标签的实际尺寸
        self.sig_resized.emit(self.hud_label.size())

    def start_video_display(self, video_thread):
        self.video_thread_ref = video_thread
        # 🔒 先把视频区几何按当前链路比例落位，再把尺寸同步给后台
        # （首次显示前也能拿到正确尺寸：实机 4:3 / 孪生 16:9）
        self.video_surface.apply_aspect_ratio()
        self.video_thread_ref.set_target_size(self.hud_label.size())
        self.display_timer.start(33)

    def stop_video_display(self):
        self.display_timer.stop()
        self.video_thread_ref = None

    def _pull_latest_frame(self):
        if self.video_thread_ref:
            latest_image = self.video_thread_ref.get_latest_frame()
            if latest_image:
                self.update_frame(latest_image)
            # 📊 同步实时帧率到 HUD 显示
            self.hud_label.current_fps = getattr(self.video_thread_ref, 'current_fps', 0.0)

    def update_frame(self, qimg):
        """
        接收 VideoThread 保留的完整分辨率 QImage，并仅按本窗口尺寸显示。
        主界面小预览不会再改变这里拿到的原始画面尺寸。
        """
        # 🖼 画面比例跟随真实帧：实机 640×480 → 4:3，数字孪生 Unity → 16:9。
        # 两条链路各按原生比例铺满显示区，既不变形也不浪费黑边。
        self.video_surface.follow_source(qimg.width(), qimg.height())

        pixmap = QPixmap.fromImage(qimg)
        target_size = self.hud_label.size()
        if target_size.width() > 0 and target_size.height() > 0:
            pixmap = pixmap.scaled(
                target_size,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation,
            )
        self.hud_label.setPixmap(pixmap)
        
        # 💡 [抗闪烁补丁]：如果开启了 X-Ray 并在画背景，由于摄像头线程帧率(30fps)
        # 大于 AI 结果帧率的覆盖，避免原图(Pixmap)在一瞬间覆盖掉画好的 XRay 结果，
        # 在收到摄像头新图时，我们主动触发重绘，让 paintEvent 执行阻断。
        if getattr(self.hud_label, "cached_xray_qimg", None) is not None:
            self.hud_label.update()

    def add_algo_toggle(self, algo_id: str, name: str):
        cb = QCheckBox(name)
        cb.setStyleSheet("font-size: 14px; padding: 5px;")
        
        def on_algo_toggled(state):
            is_checked = (state == Qt.Checked)
            self.sig_toggle_algo.emit(self.target_id, algo_id, is_checked)
            if algo_id == "aruco_dock":
                self.group_enh.setVisible(is_checked)
                self.btn_shadow_control.setEnabled(is_checked)
                # 🔓 手动入口：勾选 ArUco 靠泊算法即解锁闭环对接按钮（取消勾选则重新锁死）。
                # 后端安全校验不变，测试时可单独开启四码闭环而无需走 MPPI→NOF 自动交接。
                self._set_dock_action_unlocked(is_checked)
                if not is_checked:
                    self.btn_shadow_control.setChecked(False)
        
        cb.stateChanged.connect(on_algo_toggled)
        self.scroll_layout.addWidget(cb)
        self._algo_checkboxes[algo_id] = cb
        if algo_id == "aruco_dock":
            self.scroll_layout.addWidget(self.group_shadow)
            self.scroll_layout.addWidget(self.group_enh)

    def set_algo_enabled(self, algo_id: str, enabled: bool):
        """程序化启停算法勾选框（自动联动 sig_toggle_algo → vision_manager）。"""
        cb = self._algo_checkboxes.get(algo_id)
        if cb is not None and cb.isChecked() != bool(enabled):
            cb.setChecked(bool(enabled))

    def _on_shadow_toggled(self, checked):
        """Enable advisory calculations without emitting any control signal."""
        if checked:
            if not self.btn_dock_action.isChecked():
                self.shadow_supervisor.reset()
                self.three_marker_planner.reset()
                self._shadow_guidance = None
            self.shadow_watchdog.start()
            self.btn_shadow_control.setText("停止影子控制")
            self.btn_shadow_control.setStyleSheet(
                "background-color: #cff4fc; font-weight: bold; padding: 7px;"
            )
            self.lbl_shadow_status.setText("等待有效二维码目标…")
        else:
            if not self.btn_dock_action.isChecked():
                self.shadow_watchdog.stop()
            self.btn_shadow_control.setText("启用影子控制（仅计算）")
            self.btn_shadow_control.setStyleSheet(
                "background-color: #fff3cd; font-weight: bold; padding: 7px;"
            )
            if not self.btn_dock_action.isChecked():
                self.lbl_shadow_status.setText(
                    "影子控制已关闭" if self.btn_shadow_control.isEnabled()
                    else "请先开启 ArUco 靠泊测距"
                )
                self._clear_shadow_values()

    def _clear_shadow_values(self):
        self.lbl_shadow_values.setText(
            "状态: LOST\n"
            "阶段: SEARCH_GATE\n"
            "目标/距离: -- / --\n"
            "视觉年龄: --\n"
            "PosAngle: --\n"
            "滤波角度: --\n"
            "目标/平滑转向: -- / --\n"
            "左/右建议: -- / --\n"
            "目标/平滑前进: -- / --\n"
            "IMU保艏: --"
        )

    def _shadow_imu_values(self):
        imu = self._shadow_imu or {}
        try:
            heading = float(imu["ekf_heading"])
        except (KeyError, TypeError, ValueError):
            heading = None
        try:
            yaw_rate = float(imu.get("yaw_rate", 0.0))
        except (TypeError, ValueError):
            yaw_rate = 0.0
        return heading, yaw_rate

    def _render_shadow_output(self, output, guidance=None):
        state_styles = {
            "TRACKING": "color: #0f5132; background-color: #d1e7dd;",
            "DEGRADED": "color: #664d03; background-color: #fff3cd;",
            "LOST": "color: #842029; background-color: #f8d7da;",
            "REACQUIRE": "color: #055160; background-color: #cff4fc;",
            "DOCKED": "color: #0c5460; background-color: #bee5eb;",
        }
        self.lbl_shadow_status.setStyleSheet(
            state_styles.get(output.state, "")
            + "font-weight: bold; padding: 5px;"
        )
        phase = "--" if guidance is None else guidance.phase
        phase_action = "等待四码规划" if guidance is None else guidance.action
        observed = "--" if guidance is None or not guidance.observed_ids else "+".join(
            f"ID{marker_id}" for marker_id in guidance.observed_ids
        )
        self.lbl_shadow_status.setText(
            f"{output.state} · {phase}\n"
            f"{phase_action} · {output.action}\n"
            f"目标 {self._shadow_marker_id} · 看到 {observed} · "
            f"{output.tracking_method} · 置信度 {self._shadow_confidence:.2f}"
        )

        age_text = (
            "--" if output.vision_age_ms is None
            else f"{output.vision_age_ms:.0f} ms"
        )
        pos_text = (
            "--" if output.pos_angle_deg is None
            else f"{output.pos_angle_deg:+.2f}°"
        )
        filtered_text = (
            "--" if output.filtered_angle_deg is None
            else f"{output.filtered_angle_deg:+.2f}°"
        )
        distance_text = (
            "--" if guidance is None or guidance.distance_cm is None
            else f"{guidance.distance_cm:.1f} cm"
        )
        surge_cap_text = (
            "--" if guidance is None
            else f"{guidance.surge_limit * 100:.0f}%"
        )
        if output.imu_heading_deg is None:
            imu_text = "无IMU数据"
        elif output.imu_target_heading_deg is None:
            imu_text = f"当前 {output.imu_heading_deg:.1f}° / 等待目标"
        else:
            active_text = "接管中" if output.imu_hold_active else "待命"
            imu_text = (
                f"{active_text} · 当前 {output.imu_heading_deg:.1f}° / "
                f"目标 {output.imu_target_heading_deg:.1f}°"
            )

        self.lbl_shadow_values.setText(
            f"状态: {output.state}\n"
            f"阶段: {phase}\n"
            f"目标/距离: {self._shadow_marker_id} / {distance_text}\n"
            f"视觉年龄: {age_text}\n"
            f"PosAngle: {pos_text}\n"
            f"滤波角度: {filtered_text}\n"
            f"目标/平滑转向: {output.target_yaw_command:+.3f} / "
            f"{output.smoothed_yaw_command:+.3f}\n"
            f"左/右建议: {output.left_command:+.3f} / "
            f"{output.right_command:+.3f}\n"
            f"目标/平滑前进: {output.target_surge_permission * 100:.0f}% / "
            f"{output.smoothed_surge_permission * 100:.0f}%\n"
            f"阶段前进上限: {surge_cap_text}\n"
            f"IMU保艏: {imu_text}"
        )

    def _refresh_shadow_watchdog(self):
        """Advance loss timers even if the visual process stops returning frames."""
        if not (
            self.btn_shadow_control.isChecked()
            or self.btn_dock_action.isChecked()
        ):
            return
        heading, yaw_rate = self._shadow_imu_values()
        guidance = self._shadow_guidance
        output = self.shadow_supervisor.update(
            imu_heading_deg=heading,
            yaw_rate_deg_s=yaw_rate,
            surge_limit=(None if guidance is None else guidance.surge_limit),
            force_stop=bool(guidance is not None and guidance.docked),
        )
        self._render_shadow_output(output, guidance)
        self._emit_docking_guidance(output, guidance)

    def _update_shadow_control(self, results, imu=None):
        """Fuse ID0/ID1/ID2/ID3 and update advisory guidance for this frame."""
        if not (
            self.btn_shadow_control.isChecked()
            or self.btn_dock_action.isChecked()
        ):
            return
        if imu:
            if isinstance(imu, dict):
                self._shadow_imu = dict(imu)
            else:
                # Compatibility for older result packets that returned IMUData.
                import math
                angular_velocity = getattr(imu, "angular_velocity", (0.0, 0.0, 0.0))
                orientation = getattr(imu, "orientation", (0.0, 0.0, 0.0))
                self._shadow_imu = {
                    "yaw_rate": math.degrees(float(angular_velocity[2])),
                    "ekf_heading": math.degrees(float(orientation[2])) % 360.0,
                }

        observations = []
        for result in results:
            if getattr(result, "algo_id", None) != "aruco_dock":
                continue
            extra = getattr(result, "extra", {}) or {}
            translation = extra.get("translation_cm", {}) or {}
            try:
                tx = float(translation["x"])
                tz = float(translation["z"])
            except (KeyError, TypeError, ValueError):
                continue
            if tz <= 0.0:
                continue
            try:
                marker_id = int(extra["marker_id"])
                confidence = float(getattr(result, "confidence", 0.0))
            except (KeyError, TypeError, ValueError):
                continue
            observations.append(DockMarkerObservation(
                marker_id=marker_id,
                tx_cm=tx,
                tz_cm=tz,
                tracking_method=extra.get("tracking_method", "unknown"),
                confidence=confidence,
            ))

        guidance = self.three_marker_planner.update(observations)
        self._shadow_guidance = guidance
        self._shadow_marker_id = guidance.target_label
        self._shadow_confidence = guidance.confidence
        heading, yaw_rate = self._shadow_imu_values()
        output = self.shadow_supervisor.update(
            guidance.pos_angle_deg,
            tracking_method=(
                guidance.tracking_method
                if guidance.pos_angle_deg is not None
                else "missing"
            ),
            imu_heading_deg=heading,
            yaw_rate_deg_s=yaw_rate,
            surge_limit=guidance.surge_limit,
            force_stop=guidance.docked,
        )
        self._render_shadow_output(output, guidance)
        self._emit_docking_guidance(output, guidance)

    def _emit_docking_guidance(self, output, guidance):
        """Only the explicit closed-loop button may forward guidance to PID."""
        if not self._dock_action_unlocked or not self.btn_dock_action.isChecked():
            return
        self.sig_docking_guidance.emit(self.target_id, {
            "phase": "SEARCH_GATE" if guidance is None else guidance.phase,
            "control_state": output.state,
            "pos_angle_deg": None if guidance is None else guidance.pos_angle_deg,
            "distance_cm": None if guidance is None else guidance.distance_cm,
            "tracking_method": output.tracking_method,
            "docked": bool(guidance is not None and guidance.docked),
            "single_marker": bool(guidance is not None and guidance.single_marker),
        })

    # ── 图像增强参数同步 ────────────────────────────────────
    def sync_enhancer_params(self):
        try:
            params = {
                'clip_limit': float(self.in_clip.text()),
                'grid_x': int(self.in_grid.text()),
                'grid_y': int(self.in_grid.text()),
                'sharpen_weight': float(self.in_sharp.text()),
                'use_attention': self.cb_use_attention.isChecked(),
                'roi_padding': int(self.in_padding.text()),
                'debug_view': self.cb_debug_view.isChecked() 
            }
            if hasattr(self, 'sig_update_algo_params'):
                self.sig_update_algo_params.emit(self.target_id, "aruco_dock", params)
        except ValueError:
            pass 

    def on_vision_data_arrived(self, results, imu=None):
        """将 AI 生成的数据送入 HUD 涂层进行标注"""
        self.hud_label.update_vision_data(results)
        self._update_perception_health(results)
        self._update_shadow_control(results, imu=imu)

    def _update_perception_health(self, results):
        health = next(
            (
                result
                for result in results
                if getattr(result, "algo_id", None) == "aruco_health"
            ),
            None,
        )
        if health is None:
            return

        extra = getattr(health, "extra", {}) or {}
        direct_ids = extra.get("direct_ids", [])
        missing_ids = extra.get("missing_ids", [])
        lines = [
            f"直接检出: {direct_ids if direct_ids else '--'}",
            f"当前未检出: {missing_ids if missing_ids else '--'}",
            f"已处理新帧: {extra.get('frame_count', 0)}",
        ]
        per_id = extra.get("per_id", {}) or {}
        for marker_id in extra.get("expected_ids", [0, 1, 2, 3]):
            stats = per_id.get(str(marker_id), {})
            rate = 100.0 * float(stats.get("direct_rate", 0.0))
            lines.append(
                f"ID{marker_id}: {rate:5.1f}% | "
                f"连丢 {stats.get('current_miss_streak', 0)} | "
                f"最大 {stats.get('max_miss_streak', 0)}"
            )
        lines.append("🔒 动力闭环：禁止")
        self.lbl_perception_health.setText("\n".join(lines))

    def closeEvent(self, event):
        if self.btn_dock_action.isChecked():
            self.btn_dock_action.setChecked(False)
        self.stop_video_display()
        self.sig_closed.emit()
        event.accept()
