# 文件路径: ui/widgets/radar_view.py

import math
from PyQt5.QtWidgets import QWidget
from PyQt5.QtCore import Qt, QPointF
from PyQt5.QtGui import QPainter, QColor, QPen, QBrush, QFont

class RadarViewWidget(QWidget):
    """
    近场雷达视图组件 (微观相对坐标系)
    中心始终为船坞 (0,0)，周围显示子船的相对位置。
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(400, 400) # 保证雷达图有足够的显示空间
        
        # 雷达的最大量程 (米)，决定了最外圈代表多远
        self.max_range = 20.0 
        
        # 子船的数据状态 (初始为空)
        self.boat_dist = None     # 距离 (米)
        self.boat_angle = None    # 相对船坞的方位角 (度，北为0，顺时针)
        self.boat_heading = None  # 子船自身的艏向角 (度)

    def update_targets(self, dist: float, angle: float, heading: float):
        """
        [对外接口] 供外部传入最新的相对位置数据，并刷新雷达图
        """
        self.boat_dist = dist
        self.boat_angle = angle
        self.boat_heading = heading
        self.update() # 触发 paintEvent 重新绘制界面的核心机制

    def paintEvent(self, event):
        """
        [核心绘图] 每次窗口刷新、遮挡恢复、或者调用 self.update() 时自动执行
        """
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing) # 开启抗锯齿，让圆形和斜线更平滑

        width = self.width()
        height = self.height()
        cx = width / 2.0
        cy = height / 2.0
        
        # 计算比例尺：雷达半径占据画布较短边的一半 (留 10px 边距)
        radar_radius = min(width, height) / 2.0 - 10
        # 像素/米 比例
        pixels_per_meter = radar_radius / self.max_range

        # --- 1. 画雷达底盘 (黑色背景) ---
        painter.setBrush(QBrush(QColor(10, 20, 10))) # 深墨绿色/黑色背景
        painter.setPen(QPen(QColor(0, 255, 0), 2))   # 亮绿色外圈
        painter.drawEllipse(QPointF(cx, cy), radar_radius, radar_radius)

        # --- 2. 画同心圆刻度和十字准星 ---
        painter.setPen(QPen(QColor(0, 150, 0, 100), 1, Qt.DashLine)) # 半透明绿色虚线
        
        # 画 5m, 10m, 15m 的圈
        for r_meter in [5, 10, 15]:
            r_pixel = r_meter * pixels_per_meter
            painter.drawEllipse(QPointF(cx, cy), r_pixel, r_pixel)
            # 标上距离文字
            painter.drawText(int(cx + 5), int(cy - r_pixel - 5), f"{r_meter}m")

        # 画十字准星
        painter.drawLine(int(cx), int(cy - radar_radius), int(cx), int(cy + radar_radius))
        painter.drawLine(int(cx - radar_radius), int(cy), int(cx + radar_radius), int(cy))

        # --- 3. 画中心点：船坞 (Dock) ---
        painter.setBrush(QBrush(QColor(0, 150, 255))) # 蓝色
        painter.setPen(QPen(QColor(255, 255, 255), 1))
        painter.drawRect(int(cx - 8), int(cy - 8), 16, 16) # 画个正方形代表船坞
        painter.drawText(int(cx + 10), int(cy + 15), "Dock (0,0)")

        # --- 4. 画动点：子船 (Boat) ---
        if self.boat_dist is not None and self.boat_angle is not None:
            # 如果子船超出了雷达量程，就把它限制在边缘，防止画出界
            display_dist = min(self.boat_dist, self.max_range)
            
            # 【核心数学转换】：极坐标 (距离, 角度) 转 笛卡尔坐标 (X, Y)
            # 注意：屏幕的 Y 轴是向下的，而正北是向上的。
            # 0度(正北) -> Y减小；90度(正东) -> X增加。
            rad_angle = math.radians(self.boat_angle)
            bx = cx + (display_dist * pixels_per_meter) * math.sin(rad_angle)
            by = cy - (display_dist * pixels_per_meter) * math.cos(rad_angle)

            # 画子船的圆点 (红色)
            painter.setBrush(QBrush(QColor(255, 50, 50)))
            painter.drawEllipse(QPointF(bx, by), 6, 6)

            # 如果有航向角，画一条短线指示船头方向
            if self.boat_heading is not None:
                rad_heading = math.radians(self.boat_heading)
                head_x = bx + 15 * math.sin(rad_heading)
                head_y = by - 15 * math.cos(rad_heading)
                painter.setPen(QPen(QColor(255, 255, 0), 2)) # 黄色指针
                painter.drawLine(QPointF(bx, by), QPointF(head_x, head_y))

            # 标上文字和具体距离
            painter.setPen(QPen(QColor(255, 200, 200), 1))
            painter.drawText(int(bx + 10), int(by), f"USV ({self.boat_dist:.1f}m)")