# 文件路径: ui/widgets/driving_console.py

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
                             QLabel, QGroupBox, QCheckBox, QMessageBox, QSpinBox)
from PyQt5.QtCore import Qt, pyqtSignal

# 导入自定义摇杆组件
from ui.widgets.joystick import VirtualJoystick

class DrivingConsoleWidget(QWidget):
    """
    三摇杆协同驾驶台 (V4.0 指数曲线映射版)
    布局：[船坞-动力 A] + [船坞-转向 B] | [安全锁] | [子船-综合 C]
    """
    # 信号定义：用于通知 Controller 发送指令
    sig_dock_joy_moved = pyqtSignal(float, float) 
    sig_dock_pwm_updated = pyqtSignal(int, int, int, int)
    sig_boat_joy_moved = pyqtSignal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        self.group_box = QGroupBox("🕹️ 三杆协同驾驶台 (高精度指数映射)")
        h_layout = QHBoxLayout(self.group_box)

        # ==========================================
        # 1. 船坞控制区 (Dock: A杆 + B杆)
        # ==========================================
        dock_area_layout = QHBoxLayout()
        
        # --- A 杆：纵向动力 (Joystick A) ---
        dock_cruise_layout = QVBoxLayout()
        self.dock_joy_cruise = VirtualJoystick()
        self.dock_joy_cruise.setToolTip("船坞 A 杆：控制 1/4 号推进器 (纵向油门)")
        self.lbl_dock_a = QLabel("船坞-动力(A)\n[Y轴响应]")
        self.lbl_dock_a.setAlignment(Qt.AlignCenter)
        dock_cruise_layout.addWidget(self.dock_joy_cruise, alignment=Qt.AlignCenter)
        dock_cruise_layout.addWidget(self.lbl_dock_a)
        
        # --- B 杆：姿态转向 (Joystick B) ---
        dock_yaw_layout = QVBoxLayout()
        self.dock_joy_yaw = VirtualJoystick()
        self.dock_joy_yaw.setToolTip("船坞 B 杆：控制 2/3 号推进器 (旋转力矩)")
        self.lbl_dock_b = QLabel("船坞-转向(B)\n[X轴响应]")
        self.lbl_dock_b.setAlignment(Qt.AlignCenter)
        dock_yaw_layout.addWidget(self.dock_joy_yaw, alignment=Qt.AlignCenter)
        dock_yaw_layout.addWidget(self.lbl_dock_b)

        # --- 船坞 PWM 精确输入 ---
        dock_pwm_group = QGroupBox("船坞推力微调")
        dock_pwm_grid = QGridLayout(dock_pwm_group)
        
        self.dock_spin_1 = QSpinBox(); self._init_spinbox(self.dock_spin_1, "1号(主推L)")
        self.dock_spin_4 = QSpinBox(); self._init_spinbox(self.dock_spin_4, "4号(主推R)")
        self.dock_spin_2 = QSpinBox(); self._init_spinbox(self.dock_spin_2, "2号(转向A)")
        self.dock_spin_3 = QSpinBox(); self._init_spinbox(self.dock_spin_3, "3号(转向B)")

        dock_pwm_grid.addWidget(QLabel("1:"), 0, 0); dock_pwm_grid.addWidget(self.dock_spin_1, 0, 1)
        dock_pwm_grid.addWidget(QLabel("4:"), 1, 0); dock_pwm_grid.addWidget(self.dock_spin_4, 1, 1)
        dock_pwm_grid.addWidget(QLabel("2:"), 0, 2); dock_pwm_grid.addWidget(self.dock_spin_2, 0, 3)
        dock_pwm_grid.addWidget(QLabel("3:"), 1, 2); dock_pwm_grid.addWidget(self.dock_spin_3, 1, 3)

        dock_area_layout.addLayout(dock_cruise_layout)
        dock_area_layout.addLayout(dock_yaw_layout)
        dock_area_layout.addWidget(dock_pwm_group)

        # ==========================================
        # 2. 中间：全局安全锁
        # ==========================================
        self.lock_checkbox = QCheckBox("🔒 解锁手动控制")
        self.lock_checkbox.setStyleSheet("color: red; font-weight: bold; font-size: 14px;")
        self.lock_checkbox.toggled.connect(self._on_lock_toggled)

        # ==========================================
        # 3. 子船控制区 (Boat: C杆)
        # ==========================================
        boat_area_layout = QHBoxLayout()
        
        boat_joy_layout = QVBoxLayout()
        self.boat_joy = VirtualJoystick()
        self.boat_joy.setToolTip("子船 C 杆：标准差速控制 (X/Y 混合)")
        self.lbl_boat = QLabel("子船控制(C)\n[标准全向]")
        self.lbl_boat.setAlignment(Qt.AlignCenter)
        boat_joy_layout.addWidget(self.boat_joy, alignment=Qt.AlignCenter)
        boat_joy_layout.addWidget(self.lbl_boat)

        boat_pwm_group = QGroupBox("子船推力微调")
        boat_pwm_grid = QGridLayout(boat_pwm_group)
        self.boat_spin_l = QSpinBox(); self._init_spinbox(self.boat_spin_l, "左推")
        self.boat_spin_r = QSpinBox(); self._init_spinbox(self.boat_spin_r, "右推")
        boat_pwm_grid.addWidget(QLabel("L:"), 0, 0); boat_pwm_grid.addWidget(self.boat_spin_l, 0, 1)
        boat_pwm_grid.addWidget(QLabel("R:"), 1, 0); boat_pwm_grid.addWidget(self.boat_spin_r, 1, 1)

        boat_area_layout.addWidget(boat_pwm_group)
        boat_area_layout.addLayout(boat_joy_layout)

        # 组装主布局
        h_layout.addLayout(dock_area_layout, stretch=2)
        h_layout.addWidget(self.lock_checkbox, alignment=Qt.AlignCenter)
        h_layout.addLayout(boat_area_layout, stretch=1)
        main_layout.addWidget(self.group_box)

        # 绑定信号
        self._bind_logic_signals()
        self._set_controls_enabled(False)

    def _init_spinbox(self, sb, tip):
        sb.setRange(1000, 2000); sb.setValue(1500); sb.setSingleStep(10); sb.setToolTip(tip)
        sb.setKeyboardTracking(False)

    def _bind_logic_signals(self):
        # 摇杆正向映射
        self.dock_joy_cruise.joystickMoved.connect(self._on_dock_cruise_moved)
        self.dock_joy_yaw.joystickMoved.connect(self._on_dock_yaw_moved)
        self.boat_joy.joystickMoved.connect(self._on_boat_joy_moved)
        
        # 数字反向映射 (船坞)
        self.dock_spin_1.valueChanged.connect(self._on_dock_pwm_changed)
        self.dock_spin_4.valueChanged.connect(self._on_dock_pwm_changed)
        self.dock_spin_2.valueChanged.connect(self._on_dock_pwm_changed)
        self.dock_spin_3.valueChanged.connect(self._on_dock_pwm_changed)
        
        # 数字反向映射 (子船)
        self.boat_spin_l.valueChanged.connect(self._on_boat_pwm_changed)
        self.boat_spin_r.valueChanged.connect(self._on_boat_pwm_changed)

    # ==========================================
    # 💡 核心算法：指数映射 (提升中心区微操手感)
    # ==========================================
    def _apply_curve(self, val: float, exp: float = 1.5) -> float:
        """y = sign(x) * |x|^exp"""
        sign = 1 if val >= 0 else -1
        normalized = abs(val) / 100.0
        curved = pow(normalized, exp) * 100.0
        return sign * curved

    # ==========================================
    # 核心映射逻辑
    # ==========================================
    def _on_dock_cruise_moved(self, x, y):
        """A 杆移动：处理纵向动力，通过指数曲线平滑"""
        cy = self._apply_curve(y, 1.5)
        pwm = int(1500 + cy * 5)
        
        self.dock_spin_1.blockSignals(True); self.dock_spin_4.blockSignals(True)
        self.dock_spin_1.setValue(pwm); self.dock_spin_4.setValue(pwm)
        self.dock_spin_1.blockSignals(False); self.dock_spin_4.blockSignals(False)
        self._emit_dock_combined_signal()

    def _on_dock_yaw_moved(self, x, y):
        """B 杆移动：处理转向力矩，通过指数曲线平滑"""
        cx = self._apply_curve(x, 1.5)
        pwm_2 = int(1500 + cx * 5)
        pwm_3 = int(1500 - cx * 5)
        
        self.dock_spin_2.blockSignals(True); self.dock_spin_3.blockSignals(True)
        self.dock_spin_2.setValue(pwm_2); self.dock_spin_3.setValue(pwm_3)
        self.dock_spin_2.blockSignals(False); self.dock_spin_3.blockSignals(False)
        self._emit_dock_combined_signal()

    def _on_dock_pwm_changed(self):
        """数字框手动修改：同步 UI 摇杆，并直接下发手动 PWM 指令"""
        # 1) 同步左/右纵向摇杆位置
        y_val = (self.dock_spin_1.value() + self.dock_spin_4.value() - 3000) / 10.0
        self.dock_joy_cruise.set_position_from_values(0, y_val)

        # 2) 同步转向摇杆位置（差值控制）
        x_val = (self.dock_spin_2.value() - self.dock_spin_3.value()) / 10.0
        self.dock_joy_yaw.set_position_from_values(x_val, 0)

        # 3) 直接下发当前 4 通道 PWM（手动微调模式）
        self.sig_dock_pwm_updated.emit(
            self.dock_spin_1.value(), self.dock_spin_2.value(),
            self.dock_spin_3.value(), self.dock_spin_4.value()
        )

    # --- 1. 修改反算逻辑函数 ---
    def _emit_dock_combined_signal(self):
        """
        根据当前 PWM 状态，计算逻辑百分比并通知 Controller。
        💡 [修复] 转向值 x 不再只依赖 2 号，而是通过 2、3 号的差值计算。
        """
        # 修正公式：(2号PWM - 3号PWM) / 10.0 得到 -100 到 100 的逻辑比例
        # 这样无论是手动改 2 还是改 3，x 都会发生变化。
        x = (self.dock_spin_2.value() - self.dock_spin_3.value()) / 10.0 
        
        # 纵向油门 y 依然通过 1 号（主推）计算
        y = (self.dock_spin_1.value() - 1500) / 5.0
        
        self.sig_dock_joy_moved.emit(x, y)

    def _on_boat_joy_moved(self, x, y):
        """C 杆移动：子船差速混合映射，应用指数曲线"""
        cx, cy = self._apply_curve(x, 1.5), self._apply_curve(y, 1.5)
        
        pwm_l = int(max(1000, min(2000, 1500 + cy*5 + cx*5)))
        pwm_r = int(max(1000, min(2000, 1500 + cy*5 - cx*5)))
        
        self.boat_spin_l.blockSignals(True); self.boat_spin_r.blockSignals(True)
        self.boat_spin_l.setValue(pwm_l); self.boat_spin_r.setValue(pwm_r)
        self.boat_spin_l.blockSignals(False); self.boat_spin_r.blockSignals(False)
        
        self.sig_boat_joy_moved.emit(cx, cy)

    def _on_boat_pwm_changed(self):
        """子船数字反算摇杆位置"""
        x = (self.boat_spin_l.value() - self.boat_spin_r.value()) / 10.0
        y = (self.boat_spin_l.value() + self.boat_spin_r.value() - 3000) / 10.0
        self.boat_joy.set_position_from_values(x, y)
        self.sig_boat_joy_moved.emit(x, y)

    # ==========================================
    # 安全锁与使能控制
    # ==========================================
    def _on_lock_toggled(self, checked):
        if checked:
            if QMessageBox.warning(self, "确认解锁", "⚠️ 警告：即将接管 3 杆联动控制系统！", 
                                   QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
                self._set_controls_enabled(True)
                self.lock_checkbox.setText("🔓 动力已接管")
            else:
                self.lock_checkbox.setChecked(False)
        else:
            self._set_controls_enabled(False)
            self.lock_checkbox.setText("🔒 解锁手动控制")
            self._reset_all_to_neutral()

    def _set_controls_enabled(self, e):
        for w in [self.dock_joy_cruise, self.dock_joy_yaw, self.boat_joy,
                  self.dock_spin_1, self.dock_spin_2, self.dock_spin_3, self.dock_spin_4,
                  self.boat_spin_l, self.boat_spin_r]:
            w.setEnabled(e)

    def _reset_all_to_neutral(self):
        for sb in [self.dock_spin_1, self.dock_spin_2, self.dock_spin_3, self.dock_spin_4,
                   self.boat_spin_l, self.boat_spin_r]:
            sb.blockSignals(True); sb.setValue(1500); sb.blockSignals(False)
        self.dock_joy_cruise.set_position_from_values(0, 0)
        self.dock_joy_yaw.set_position_from_values(0, 0)
        self.boat_joy.set_position_from_values(0, 0)
        self.sig_dock_joy_moved.emit(0, 0)
        self.sig_boat_joy_moved.emit(0, 0)
        # --- 在 driving_console.py 类末尾新增 ---

    def update_actual_pwm_boat(self, p1: int, p2: int, p3: int, p4: int):
        """硬件回传子船实际 PWM，静默刷新数字框"""
        self.boat_spin_l.blockSignals(True)
        self.boat_spin_r.blockSignals(True)
        self.boat_spin_l.setValue(p1)
        self.boat_spin_r.setValue(p2)
        self.boat_spin_l.blockSignals(False)
        self.boat_spin_r.blockSignals(False)

    def update_actual_pwm_dock(self, p1: int, p2: int, p3: int, p4: int):
        """硬件回传船坞实际 PWM，静默刷新数字框"""
        for sb, val in [(self.dock_spin_1, p1), (self.dock_spin_2, p2),
                        (self.dock_spin_3, p3), (self.dock_spin_4, p4)]:
            sb.blockSignals(True)
            sb.setValue(val)
            sb.blockSignals(False)

    def sync_dock_ui(self, x: float, y: float):
        """
        💡 [硬件专用] 同步船坞 UI 状态，不触发信号。
        """
        # 🛑 删除或注释掉摇杆位置更新，避免双重刷新和鼠标抢占
        # self.dock_joy_cruise.set_position_from_values(0, y)
        # self.dock_joy_yaw.set_position_from_values(x, 0)

        # 计算映射后的 PWM
        cy = self._apply_curve(y, 1.5)

        # 计算映射后的 PWM
        cy = self._apply_curve(y, 1.5)
        cx = self._apply_curve(x, 1.5)
        pwm_main = int(1500 + cy * 5)
        pwm_steer_a = int(1500 + cx * 5)
        pwm_steer_b = int(1500 - cx * 5)

        # 🛡️ 使用 blockSignals(True) 静默刷新所有数字框
        # 这样 MainWindow 调用同步时，不会触发 _emit_dock_combined_signal 导致指令重发
        spins = [
            (self.dock_spin_1, pwm_main), (self.dock_spin_4, pwm_main),
            (self.dock_spin_2, pwm_steer_a), (self.dock_spin_3, pwm_steer_b)
        ]
        for sb, val in spins:
            sb.blockSignals(True)
            sb.setValue(val)
            sb.blockSignals(False)

    def sync_boat_ui(self, x: float, y: float):
        """
        💡 [硬件专用] 同步子船 UI 状态，不触发指令下发。
        """
        # 🛑 删除或注释掉摇杆位置更新
        # self.boat_joy.set_position_from_values(x, y)

        # 2. 计算差速 PWM
        cx, cy = self._apply_curve(x, 1.5), self._apply_curve(y, 1.5)

        # 2. 计算差速 PWM
        cx, cy = self._apply_curve(x, 1.5), self._apply_curve(y, 1.5)
        pwm_l = int(max(1000, min(2000, 1500 + cy*5 + cx*5)))
        pwm_r = int(max(1000, min(2000, 1500 + cy*5 - cx*5)))

        # 3. 静默更新数字框
        for sb, val in [(self.boat_spin_l, pwm_l), (self.boat_spin_r, pwm_r)]:
            sb.blockSignals(True)
            sb.setValue(val)
            sb.blockSignals(False)