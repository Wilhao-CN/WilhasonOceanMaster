# 文件路径: ui/widgets/oscilloscope/basic_data_oscilloscope.py
import pyqtgraph as pg
import time
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QScrollArea
from PyQt5.QtCore import Qt, QTimer
from ui.widgets.oscilloscope.base_plot_widget import BasePlotWidget

class BasicDataOscilloscope(QWidget):
    """
    ====================================================================
    📈 专业级多轴遥测示波器 (V4.0 节拍驱动版)
    优化点：
    1. 【路径预编译】：消除高频 split('/') 操作。
    2. 【渲染解耦】：引入 20Hz 刷新心跳，防止 UI 线程过载。
    ====================================================================
    """
    UNIT_GROUPS = {
        "heading": "角度组 (°)",
        "cog": "角度组 (°)",
        "speed": "速度组 (m/s)",
        "battery": "状态组 (%)",
        "dist": "距离组 (m)",
        "pwm": "动力组 (PWM)"
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("📉 多轴动态遥测中心")
        self.resize(1000, 800)

        self.main_layout = QVBoxLayout(self)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.container = QWidget()
        self.plot_layout = QVBoxLayout(self.container)
        self.scroll.setWidget(self.container)
        self.main_layout.addWidget(self.scroll)

        self.plot_widgets = {}  
        self.active_config = {} 
        self.start_time = time.perf_counter()
        self.color_pool = ['#00FF00', '#FFFF00', '#FF0000', '#00FFFF', '#FF00FF', '#FFFFFF']

        # 💡 [新增] 渲染心跳：每 50ms (20Hz) 刷新一次界面，确保不卡顿
        self.render_timer = QTimer(self)
        self.render_timer.timeout.connect(self._update_all_plots)
        self.render_timer.start(200)

    def update_config(self, config_dict: dict):
        """核心逻辑：根据勾选结果，动态重建子图布局并预解析路径"""
        for pw in self.plot_widgets.values():
            pw.setParent(None)
        self.plot_widgets.clear()
        self.active_config.clear()

        needed_units = set()
        for dev_id, items in config_dict.items():
            for name, path in items:
                unit = self._detect_unit(path)
                needed_units.add(unit)

        first_plot = None
        for unit in sorted(list(needed_units)):
            pw = BasePlotWidget(title=f"监控数据 - {unit}", max_points=600)
            self.plot_layout.addWidget(pw)
            self.plot_widgets[unit] = pw
            
            if first_plot is None:
                first_plot = pw.plot_widget
            else:
                pw.plot_widget.setXLink(first_plot)

        color_idx = 0
        for dev_id, items in config_dict.items():
            self.active_config[dev_id] = {}
            prefix = "1号船坞" if dev_id == 0x01 else "2号子船"
            
            for name, path in items:
                unit = self._detect_unit(path)
                unique_name = f"{prefix}: {name}"
                color = self.color_pool[color_idx % len(self.color_pool)]
                
                self.plot_widgets[unit].add_curve(unique_name, color=color)
                
                # 💡 [关键优化]：预先 split 路径，存为 list 供后续快速取值
                preparsed_path = path.split('/') 
                self.active_config[dev_id][unique_name] = (preparsed_path, unit)
                color_idx += 1

    def on_data_arrived(self, data: dict):
        """[高速回调]：仅负责压入数据，不触发重绘"""
        if not data or not self.isVisible(): return
        
        dev_id = data.get("id")
        if dev_id not in self.active_config: return

        current_x = time.perf_counter() - self.start_time

        for curve_name, (path_list, unit) in self.active_config[dev_id].items():
            # 💡 [关键优化]：使用 list 化的路径进行极速取值
            val = self._get_value_by_path_list(data, path_list)
            if val is not None:
                # 调用 BasePlotWidget 的 update_curve (此时它仅 push 数据)
                self.plot_widgets[unit].update_curve(curve_name, current_x, float(val))

    def _update_all_plots(self):
        """[定时触发]：统一重绘所有子图，控制渲染频率"""
        if not self.isVisible(): return
        for pw in self.plot_widgets.values():
            pw.update_display()

    def _detect_unit(self, path: str) -> str:
        for key, unit in self.UNIT_GROUPS.items():
            if key in path.lower(): return unit
        return "通用数据"

    def _get_value_by_path_list(self, data: dict, path_list: list):
        """[优化版] 使用预解析的列表快速取值，避开字符串操作"""
        try:
            temp = data
            for part in path_list:
                if part.isdigit(): temp = temp[int(part)]
                else: temp = temp[part]
            return temp
        except: return None