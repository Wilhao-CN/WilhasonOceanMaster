# 文件路径: ui/widgets/oscilloscope/data_manager_panel.py
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QTreeWidget, QTreeWidgetItem, 
                             QPushButton, QHBoxLayout, QLabel, QGroupBox)
from PyQt5.QtCore import pyqtSignal, Qt

class DataManagerPanel(QWidget):
    """
    ====================================================================
    🌲 数据资产管理面板 (V1.0)
    职责：提供树状勾选菜单，决定“看什么”和“存什么”。
    信号：
        - sig_apply_clicked(dict): 发射当前【已勾选】的配置映射
        - sig_save_toggled(bool): 切换【保存数据】的开启与关闭
    ====================================================================
    """
    sig_apply_clicked = pyqtSignal(dict)
    sig_save_toggled = pyqtSignal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.is_saving = False
        
        # --- 1. 核心映射表：定义 UI 显示与数据路径的对应关系 ---
        # 格式：{ "显示名称": "数据字典里的Key路径" }
        self.data_map = {
            "核心状态": {
                "Battery (%)": "battery",
                "Mode": "mode",
                "Fault Code": "fault_code",
                "Distance (m)": "dist", # 特殊字段，通常由 MainWindow 计算后注入
                "MCU Time (ms)": "timestamp" # 👈 新增加的单片机心跳时间戳
            },
            "姿态与导航": {
                "Heading (°)": "imu/dual_heading",  # 双GPS几何艏向角
                "RealTime Heading (°)": "imu/heading",   # IMU积分艏向角
                "Speed (m/s)": "gps/speed",
                "Longitude": "gps/lon",
                "Latitude": "gps/lat",
                "Longitude B": "gps_B/lon",
                "Latitude B": "gps_B/lat",
                "EKF Heading (°)": "imu/ekf_heading",
                "UTC Time A (ms)": "utc_time_A",
                "UTC Time B (ms)": "utc_time_B",
                "COG (°)": "gps/cog",
                "IMU Vx (m/s)": "imu/imu_vel_x",
                "Dual Heading (°)": "imu/dual_heading",
                "Yaw Rate (°/s)": "imu/yaw_rate",
                "Sway (m/s)": "imu/sway_speed",
            },
            "动力系统": {
                "PWM 1": "pwm/0",
                "PWM 2": "pwm/1",
                "PWM 3": "pwm/2",
                "PWM 4": "pwm/3"
            }
        }

        # 船坞和子船共用的双温度遥测字段。
        self.temperature_data_map = {
            "环境传感器": {
                "Water Temperature 01 (°C)": "temperatures/sensor_01/water_c",
                "Temperature 01 Valid": "temperatures/sensor_01/valid",
                "Temperature 01 Error Code": "temperatures/sensor_01/error_code",
                "Water Temperature 02 (°C)": "temperatures/sensor_02/water_c",
                "Temperature 02 Valid": "temperatures/sensor_02/valid",
                "Temperature 02 Error Code": "temperatures/sensor_02/error_code",
            }
        }
        # 兼容可能仍引用旧属性名的外围代码。
        self.boat_extra_data_map = self.temperature_data_map

        # 🔧 [默认勾选] 打开面板时自动选中的摇杆/导航关键数据路径
        self.DEFAULT_CHECKED_PATHS = {
            "gps/lat",          # GPS 纬度
            "gps/lon",          # GPS 经度
            "imu/ekf_heading",  # EKF 艏向角
            "imu/dual_heading", # 双GPS 艏向角
            "gps/cog",          # 对地航向 (COG)
            "timestamp",        # MCU 心跳时间戳
            "temperatures/sensor_01/water_c",  # 地址01水温
            "temperatures/sensor_02/water_c",  # 地址02水温
        }

        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)

        # --- A. 树状勾选区 ---
        self.tree = QTreeWidget()
        self.tree.setHeaderLabel("📡 设备与传感器选择")
        self.tree.setColumnCount(1)

        # 创建两个根节点：船坞 和 子船
        self.dock_root = self._create_device_node("🚢 1号端：船坞 (Dock)", 0x01)
        self.boat_root = self._create_device_node("🚤 2号端：子船 (Boat)", 0x02)

        # 🔧 自动应用默认勾选
        self._apply_default_checks()

        layout.addWidget(self.tree)

        # --- B. 控制按钮区 ---
        btn_layout = QHBoxLayout()
        self.btn_apply = QPushButton("✅ 确定显示")
        self.btn_apply.setStyleSheet("background-color: #2E7D32; color: white; font-weight: bold; height: 30px;")
        self.btn_apply.clicked.connect(self._emit_config)
        
        self.btn_save = QPushButton("💾 开始保存数据")
        self.btn_save.setCheckable(True)
        self.btn_save.setStyleSheet("height: 30px;")
        self.btn_save.clicked.connect(self._on_save_clicked)
        
        btn_layout.addWidget(self.btn_apply)
        btn_layout.addWidget(self.btn_save)
        layout.addLayout(btn_layout)

    def _create_device_node(self, text, device_id):
        """为每台设备创建子菜单"""
        root = QTreeWidgetItem(self.tree)
        root.setText(0, text)
        root.setData(0, Qt.UserRole, device_id) # 隐藏存储 ID
        root.setFlags(root.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsTristate)
        root.setCheckState(0, Qt.Unchecked)

        device_maps = [self.data_map, self.temperature_data_map]

        for data_map in device_maps:
            for group_name, items in data_map.items():
                group_node = QTreeWidgetItem(root)
                group_node.setText(0, group_name)
                group_node.setFlags(group_node.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsTristate)
                group_node.setCheckState(0, Qt.Unchecked)

                for display_name, data_path in items.items():
                    child = QTreeWidgetItem(group_node)
                    child.setText(0, display_name)
                    child.setData(0, Qt.UserRole, data_path) # 隐藏存储数据路径
                    child.setCheckState(0, Qt.Unchecked)

        root.setExpanded(True) # 默认展开
        return root

    def _apply_default_checks(self):
        """
        🔧 自动勾选预设的关键数据字段（GPS 经纬度、EKF 艏向角、双GPS 艏向角、COG、MCU 时间）。
        遍历船坞和子船两个根节点，将数据路径匹配的叶子节点默认打勾。
        """
        for root in [self.dock_root, self.boat_root]:
            for i in range(root.childCount()):
                group = root.child(i)
                for j in range(group.childCount()):
                    item = group.child(j)
                    path = item.data(0, Qt.UserRole)
                    if path in self.DEFAULT_CHECKED_PATHS:
                        item.setCheckState(0, Qt.Checked)

    def _emit_config(self):
        """遍历树，收集所有被勾选的项目"""
        config = { 0x01: [], 0x02: [] } # 存储格式：{ 0x01: [("显示名", "路径"), ...], 0x02: [...] }

        roots = [self.dock_root, self.boat_root]
        for root in roots:
            dev_id = root.data(0, Qt.UserRole)
            # 递归遍历子节点
            for i in range(root.childCount()):
                group = root.child(i)
                for j in range(group.childCount()):
                    item = group.child(j)
                    if item.checkState(0) == Qt.Checked:
                        config[dev_id].append((item.text(0), item.data(0, Qt.UserRole)))
        
        self.sig_apply_clicked.emit(config)

    def get_full_field_config(self) -> dict:
        """
        🔧 [V4.1 保存/显示分离] 生成全字段配置，用于存盘。
        遍历 data_map (船坞/子船) 的所有字段，
        不依赖 UI 勾选状态，确保存盘数据完整。
        返回格式: { 0x01: [(name, path), ...], 0x02: [...] }
        """
        config = {0x01: [], 0x02: []}

        # 船坞和子船共享基础字段及双温度遥测字段。
        for dev_id in [0x01, 0x02]:
            device_maps = [self.data_map, self.temperature_data_map]
            for data_map in device_maps:
                for group_name, items in data_map.items():
                    for display_name, data_path in items.items():
                        config[dev_id].append((display_name, data_path))

        return config

    def _on_save_clicked(self, checked):
        if checked:
            self.btn_save.setText("🛑 停止并导出 CSV")
            self.btn_save.setStyleSheet("background-color: #C62828; color: white; font-weight: bold; height: 30px;")
        else:
            self.btn_save.setText("💾 开始保存数据")
            self.btn_save.setStyleSheet("height: 30px;")
        
        self.sig_save_toggled.emit(checked)
