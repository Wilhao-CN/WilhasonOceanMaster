# 文件路径: ui/widgets/oscilloscope/telemetry_center.py
from PyQt5.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QSplitter, QVBoxLayout, QFrame
from PyQt5.QtCore import Qt, pyqtSignal

# 导入之前的两个核心积木
from ui.widgets.oscilloscope.data_manager_panel import DataManagerPanel
from ui.widgets.oscilloscope.basic_data_oscilloscope import BasicDataOscilloscope

class TelemetryCenterWindow(QMainWindow):
    """
    ====================================================================
    🏟️ 遥测分析中心独立窗口 (V3.0 集成版)
    职责：
    1. 【容器化】：整合配置面板与多轴绘图引擎，实现“即选即看”。
    2. 【内部闭环】：管理勾选逻辑与曲线重建的信号链路。
    3. 【性能守卫】：通过窗口可见性控制绘图逻辑的开启与关闭。
    ====================================================================
    """
    # 💡 信号转发：将保存数据的请求转发给主窗口的 DataLogger
    sig_save_req = pyqtSignal(bool)
    sig_whitelist_update = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🚀 无人船多轴数据遥测与分析中心")
        self.resize(1300, 850)
        
        # 主布局
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        self.main_layout = QHBoxLayout(central_widget)
        self.main_layout.setContentsMargins(5, 5, 5, 5)

        # 💡 [关键设计]：使用分割器，允许用户手动调整“配置区”和“绘图区”的比例
        self.splitter = QSplitter(Qt.Horizontal)

        # 1. 左侧：配置面板 (DataManagerPanel)
        self.config_panel = DataManagerPanel()
        self.config_panel.setMinimumWidth(300)
        self.splitter.addWidget(self.config_panel)

        # 2. 右侧：多轴示波器 (BasicDataOscilloscope)
        self.plot_engine = BasicDataOscilloscope()
        self.splitter.addWidget(self.plot_engine)

        # 设置初始伸缩比例：左侧 20%，右侧 80%
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 4)
        
        self.main_layout.addWidget(self.splitter)

        # --- 建立内部信号闭环 ---
        self._bind_internal_signals()

    def get_full_field_config(self) -> dict:
        """
        [V4.1 保存/显示分离] 供 MainWindow 在存盘前获取全字段配置。
        不依赖 UI 勾选，直接返回 data_map 的全部字段。
        """
        return self.config_panel.get_full_field_config()

    def _bind_internal_signals(self):
        """🧬 窗口内部积木间的连线"""
        # A. 当点击左侧“确定显示”时，直接驱动右侧示波器重建子图
        self.config_panel.sig_apply_clicked.connect(self.plot_engine.update_config)
        
        # B. 信号转发：存盘状态
        # [V4.1 保存/显示分离] 不再将 sig_apply_clicked 同步到白名单，
        # 显示勾选只管示波器曲线，存盘走独立的"全字段"策略。
        self.config_panel.sig_save_toggled.connect(self.sig_save_req.emit)

    def feed_data(self, data: dict):
        """
        数据注入入口：由主窗口调用
        💡 只有当本窗口处于打开状态时，才把数据喂给示波器渲染
        """
        if self.isVisible():
            self.plot_engine.on_data_arrived(data)

    def closeEvent(self, event):
        """关闭窗口时，默认只是隐藏，保留配置状态"""
        self.hide()
        event.ignore()