# 文件路径: ui/widgets/oscilloscope/base_plot_widget.py
import pyqtgraph as pg
from PyQt5.QtWidgets import QWidget, QVBoxLayout
from collections import deque

class BasePlotWidget(QWidget):
    """
    ====================================================================
    📈 高频实时示波器基类 (V4.1 兼容增强版)
    职责：提供统一的绘图画布，内部使用 deque 实现 $O(1)$ 级数据存取。
    优化：保留 update_curve 接口以防崩溃，但通过解耦重绘逻辑消除卡顿。
    ====================================================================
    """
    def __init__(self, title="实时监控示波器", max_points=600, parent=None):
        super().__init__(parent)
        self.max_points = max_points 
        
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(2, 2, 2, 2)
        
        pg.setConfigOptions(antialias=True) 
        self.plot_widget = pg.PlotWidget(title=title)
        self.plot_widget.setBackground('#121212') 
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        self.plot_widget.addLegend(offset=(10, 10)) 
        self.layout.addWidget(self.plot_widget)
        
        self.curves = {} 
        # 💡 [兼容性保留]：维持 self.data 命名，但内部改为存储 deque
        self.data = {}   

    def add_curve(self, name: str, color: str, width: int = 2):
        """注册曲线，初始化双端队列"""
        pen = pg.mkPen(color=color, width=width)
        self.curves[name] = self.plot_widget.plot(pen=pen, name=name)
        # 💡 [关键点]：使用 deque(maxlen=...) 替代 list
        self.data[name] = {
            'x': deque(maxlen=self.max_points),
            'y': deque(maxlen=self.max_points)
        }

    def update_curve(self, name: str, x_val: float, y_val: float):
        """
        🚀 [兼容性接口]：名称与 BasicDataOscilloscope 保持一致，防止 crash。
        逻辑变更：现在只管往内存塞数据，【不再】直接调用 setData()。
        """
        if name in self.data:
            self.data[name]['x'].append(x_val)
            self.data[name]['y'].append(y_val)
            # 💡 [性能开关]：此处删除了 self.curves[name].setData(...)

    def update_display(self):
        """
        🎨 [新增触发接口]：由后续步骤中的 QTimer 统一调用。
        一次性将缓冲区数据推送到 GPU 渲染。
        """
        for name, curve in self.curves.items():
            # 检查是否有数据，避免空渲染
            if len(self.data[name]['x']) > 0:
                # pyqtgraph 对 list 转换有原生优化，此处开销极低
                curve.setData(list(self.data[name]['x']), list(self.data[name]['y']))

    def clear_data(self):
        """清空数据（逻辑保持与旧版 API 兼容）"""
        for name in self.data:
            self.data[name]['x'].clear()
            self.data[name]['y'].clear()
            self.curves[name].setData([], [])