# 文件路径: ui/widgets/comm_panel.py
from datetime import datetime 
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, 
                             QLabel, QPushButton, QLineEdit, 
                             QPlainTextEdit, QGroupBox, QSpinBox, QComboBox)
from PyQt5.QtCore import pyqtSignal, Qt

class CommPanel(QWidget):
    """
    通用并发双模通信日志面板 (V10.2.1 状态同步增强版)
    职责：
    1. 提供串口/网络连接控制。
    2. [原有功能] 自动切换按钮文字 (连接/断开) 与背景色。
    3. [原有功能] 指令下发路径切换 (LORA/4G)。
    4. [核心补全] 响应 Monitor 调用的状态指示灯反馈。
    """
    # --- 核心信号：严禁修改名称，确保 Controller 绑定不失效 ---
    sig_connect_req = pyqtSignal(str, int)       
    sig_connect_net_req = pyqtSignal()           
    sig_send_req = pyqtSignal(str)               
    sig_disconnect_serial_req = pyqtSignal()     
    sig_disconnect_net_req = pyqtSignal()
    sig_disconnect_req = pyqtSignal()
    sig_tx_link_changed = pyqtSignal(str) # 'serial' 或 'network'

    def __init__(self, title="通信日志助手", default_port="COM1", default_baud="115200", parent=None):
        super().__init__(parent)
        self.is_serial_connected = False 
        self.is_net_connected = False 

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0) 

        self.group_box = QGroupBox(title)
        group_layout = QVBoxLayout(self.group_box)

        # --- 1. 串口配置行 (含链路选择与指示灯) ---
        serial_layout = QHBoxLayout()
        
        # 💡 [物理灯组件]
        self.lbl_serial_light = QLabel()
        self.lbl_serial_light.setFixedSize(12, 12)
        
        self.combo_tx_link = QComboBox()
        self.combo_tx_link.addItems(["📡 LORA (串口)", "🌐 4G (网络)"])
        self.combo_tx_link.setFixedWidth(110)
        self.combo_tx_link.currentTextChanged.connect(self._on_tx_link_changed)

        self.port_input = QLineEdit(default_port)
        self.baud_input = QLineEdit(default_baud)
        self.baud_input.setFixedWidth(60)

        serial_layout.addWidget(self.lbl_serial_light)
        serial_layout.addWidget(QLabel("指令路径:"))
        serial_layout.addWidget(self.combo_tx_link)
        serial_layout.addSpacing(5)
        serial_layout.addWidget(self.port_input)
        serial_layout.addWidget(self.baud_input)
        group_layout.addLayout(serial_layout)

        # --- 2. 4G/网络回传行 (含网络指示灯) ---
        net_layout = QHBoxLayout()

        # 💡 [物理灯组件]
        self.lbl_net_light = QLabel()
        self.lbl_net_light.setFixedSize(12, 12)

        net_hint = QLabel("🛰️ 4G 强发回传 (IMU/视频):")
        net_hint.setStyleSheet("color: #0055ff; font-weight: bold;")

        net_layout.addWidget(self.lbl_net_light)
        net_layout.addWidget(net_hint)
        net_layout.addStretch(1)
        group_layout.addLayout(net_layout)

        latency_layout = QHBoxLayout()
        latency_title = QLabel("⏱️ 链路延迟:")
        latency_title.setStyleSheet("font-weight: bold;")
        self.lbl_latency = QLabel("↑ -- ms   ↓ -- ms   RTT -- ms\n抖动 -- ms   丢包 --")
        self.lbl_latency.setWordWrap(True)
        self.lbl_latency.setToolTip(
            "↑ 树莓派到上位机；↓ 上位机到树莓派。"
            "标有≈时为基于四时间戳时钟偏移估算值。"
        )
        latency_layout.addWidget(latency_title)
        latency_layout.addWidget(self.lbl_latency)
        latency_layout.addStretch(1)
        group_layout.addLayout(latency_layout)

        # --- 2.5 连接按钮行 ---
        btn_layout = QHBoxLayout()
        self.btn_serial = QPushButton("打开串口")
        self.btn_serial.setFixedWidth(80)
        self.btn_net = QPushButton("连接网络")
        self.btn_net.setFixedWidth(80)
        btn_layout.addWidget(self.btn_serial)
        btn_layout.addWidget(self.btn_net)
        btn_layout.addStretch(1)
        group_layout.addLayout(btn_layout)

        # 初始化灯光状态
        self.set_serial_light(False)
        self.set_net_light(False)

        # --- 3. 工具设置行 (采样间隔) ---
        tools_layout = QHBoxLayout()
        self.spin_interval = QSpinBox()
        self.spin_interval.setRange(20, 2000) 
        self.spin_interval.setValue(200)      
        self.spin_interval.setSuffix(" ms")   
        tools_layout.addWidget(QLabel("摇杆采样间隔:"))  
        tools_layout.addWidget(self.spin_interval)
        tools_layout.addStretch(1)
        group_layout.addLayout(tools_layout)

        # --- 4. 日志显示区 ---
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setStyleSheet("font-family: 'Consolas'; font-size: 10pt;")
        group_layout.addWidget(self.log_view)
        
        # --- 5. 指令发送区 ---
        send_layout = QHBoxLayout()
        self.cmd_input = QLineEdit()
        self.cmd_input.setPlaceholderText("手动 Hex 指令下发...")
        self.btn_send = QPushButton("发送数据")
        self.btn_clear = QPushButton("清空日志")
        self.btn_clear.setFixedWidth(80)

        send_layout.addWidget(self.cmd_input)
        send_layout.addWidget(self.btn_send)
        send_layout.addWidget(self.btn_clear) 
        group_layout.addLayout(send_layout)

        main_layout.addWidget(self.group_box)

        # --- 事件绑定 ---
        self.btn_serial.clicked.connect(self._on_serial_clicked)
        self.btn_net.clicked.connect(self._on_net_clicked)
        self.btn_send.clicked.connect(self._on_send_clicked)
        self.cmd_input.returnPressed.connect(self._on_send_clicked) 
        self.btn_clear.clicked.connect(self.log_view.clear)

    # ==========================================
    # 📢 [核心修复] 状态同步逻辑整合区
    # ==========================================
    def set_serial_light(self, connected: bool):
        """
        核心 UI 反馈：同时更新灯光颜色、按钮文字和样式。
        适配：DockMonitor.update_serial_light 调用
        """
        self.is_serial_connected = connected
        # 1. 更新灯光颜色
        color = "#00ff00" if connected else "#ff4444"
        self.lbl_serial_light.setStyleSheet(f"background-color: {color}; border-radius: 6px; border: 1px solid #555;")
        # 2. 更新按钮文字与背景 (恢复你原本的功能)
        self.btn_serial.setText("关闭串口" if connected else "打开串口")
        self.btn_serial.setStyleSheet("background-color: #ffcccc;" if connected else "")
        # 3. 输入框锁定
        self.port_input.setEnabled(not connected)
        self.baud_input.setEnabled(not connected)

    def set_net_light(self, connected: bool):
        """
        核心 UI 反馈：同时更新网络灯光、按钮文字和样式。
        适配：DockMonitor.update_net_light 调用
        """
        self.is_net_connected = connected
        # 1. 更新灯光颜色
        color = "#00ff00" if connected else "#ff4444"
        self.lbl_net_light.setStyleSheet(f"background-color: {color}; border-radius: 6px; border: 1px solid #555;")
        # 2. 更新按钮文字与背景 (恢复你原本的功能)
        self.btn_net.setText("断开网络" if connected else "连接网络")
        self.btn_net.setStyleSheet("background-color: #cceeff;" if connected else "")
        if not connected:
            self.set_latency_metrics({"available": False})

    def set_latency_metrics(self, metrics: dict):
        """Update the compact per-device latency dashboard."""
        if not metrics.get("available"):
            self.lbl_latency.setText("↑ -- ms   ↓ -- ms   RTT -- ms\n抖动 -- ms   丢包 --")
            self.lbl_latency.setStyleSheet("color: #777777;")
            return

        upload = metrics.get("upload_ms")
        download = metrics.get("download_ms")
        rtt = metrics.get("rtt_ms")
        jitter = metrics.get("jitter_ms", 0.0)
        loss = metrics.get("loss_percent", 0.0)
        up_mark = "≈" if metrics.get("upload_estimated") else ""
        down_mark = "≈" if metrics.get("download_estimated") else ""

        def display(value):
            return "--" if value is None else f"{value:.0f}"

        self.lbl_latency.setText(
            f"↑ {up_mark}{display(upload)} ms   "
            f"↓ {down_mark}{display(download)} ms   "
            f"RTT {display(rtt)} ms\n抖动 {display(jitter)} ms   "
            f"丢包 {loss:.1f}%"
        )
        worst_delay = max(value for value in (upload, download, rtt) if value is not None)
        if loss >= 10.0 or worst_delay > 300.0:
            color = "#d32f2f"
        elif loss >= 3.0 or worst_delay > 100.0:
            color = "#e68a00"
        else:
            color = "#148a28"
        self.lbl_latency.setStyleSheet(f"color: {color}; font-weight: bold;")

    # ==========================================
    # 兼容性 API (转发给上述核心方法)
    # ==========================================
    def update_serial_state(self, is_connected: bool):
        self.set_serial_light(is_connected)

    def update_net_state(self, is_connected: bool):
        self.set_net_light(is_connected)

    # ==========================================
    # 业务处理 API (保持原逻辑不变)
    # ==========================================
    def _on_tx_link_changed(self, text):
        mode = "network" if "4G" in text else "serial"
        self.sig_tx_link_changed.emit(mode)
        self.append_log(f"🔄 指令下发路径切换至: {text}")

    def _on_serial_clicked(self):
        if not self.is_serial_connected:
            port = self.port_input.text().strip()
            try: baud = int(self.baud_input.text().strip())
            except: baud = 115200
            self.sig_connect_req.emit(port, baud)
        else:
            self.sig_disconnect_serial_req.emit()

    def _on_net_clicked(self):
        if not self.is_net_connected:
            self.sig_connect_net_req.emit()
        else:
            self.sig_disconnect_net_req.emit()

    def _on_send_clicked(self):
        text = self.cmd_input.text().strip()
        if text: self.sig_send_req.emit(text)

    def append_log(self, text: str):
        timestamp = datetime.now().strftime("[%H:%M:%S.%f]")[:-4] + "]"
        self.log_view.appendPlainText(f"{timestamp} {text}")
        self.log_view.ensureCursorVisible()

    def clear_input(self): self.cmd_input.clear()
    def get_interval_sec(self) -> float: return self.spin_interval.value() / 1000.0
    def switch_mode(self, mode): pass
