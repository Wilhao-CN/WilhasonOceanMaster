# 文件路径: ui/widgets/joystick.py

from PyQt5.QtWidgets import QWidget
from PyQt5.QtCore import Qt, QPoint, pyqtSignal
from PyQt5.QtGui import QPainter, QColor, QPen, QBrush

class VirtualJoystick(QWidget):
    # 定义一个信号，当摇杆移动时往外发送 X 和 Y 的值（范围设定为 -100 到 100）
    joystickMoved = pyqtSignal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(160, 160)
        self.setMaximumSize(160, 160)
        self.centerPoint = QPoint(80, 80)
        self.joystickPos = QPoint(80, 80)
        self.radius = 60 # 外圈活动半径
        self.stickRadius = 25 # 摇杆帽半径
        self.isDragging = False

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing) # 开启抗锯齿

        # 绘制背景底盘 (深灰色圈)
        painter.setPen(QPen(QColor(150, 150, 150), 2))
        painter.setBrush(QBrush(QColor(220, 220, 220, 100)))
        painter.drawEllipse(self.centerPoint, self.radius, self.radius)

        # 绘制十字刻度线
        painter.setPen(QPen(QColor(180, 180, 180), 1, Qt.DashLine))
        painter.drawLine(self.centerPoint.x() - self.radius, self.centerPoint.y(), 
                         self.centerPoint.x() + self.radius, self.centerPoint.y())
        painter.drawLine(self.centerPoint.x(), self.centerPoint.y() - self.radius, 
                         self.centerPoint.x(), self.centerPoint.y() + self.radius)

        # 绘制摇杆帽 (蓝色渐变或纯色)
        if self.isDragging:
            painter.setBrush(QBrush(QColor(50, 150, 255))) # 拖拽时高亮亮蓝色
        else:
            painter.setBrush(QBrush(QColor(100, 100, 100))) # 默认深灰色
            
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(self.joystickPos, self.stickRadius, self.stickRadius)

    def mousePressEvent(self, event):
        # 判断点击位置是否在摇杆范围内
        if (event.pos() - self.joystickPos).manhattanLength() < self.stickRadius * 2:
            self.isDragging = True
            self.updateJoystick(event.pos())

    def mouseMoveEvent(self, event):
        if self.isDragging:
            self.updateJoystick(event.pos())

    def mouseReleaseEvent(self, event):
        self.isDragging = False
        # 松开鼠标，摇杆自动回中
        self.joystickPos = self.centerPoint
        self.emitSignals()
        self.update()

    def updateJoystick(self, pos):
        # 限制摇杆不能拖出底盘外圈
        line = pos - self.centerPoint
        distance = (line.x()**2 + line.y()**2) ** 0.5
        if distance > self.radius:
            pos.setX(int(self.centerPoint.x() + line.x() * self.radius / distance))
            pos.setY(int(self.centerPoint.y() + line.y() * self.radius / distance))
        self.joystickPos = pos
        self.emitSignals()
        self.update()

    def emitSignals(self):
        # 将坐标映射到 -100 到 100 之间
        x_val = (self.joystickPos.x() - self.centerPoint.x()) / self.radius * 100
        y_val = -(self.joystickPos.y() - self.centerPoint.y()) / self.radius * 100 # Y轴翻转，向上为正
        self.joystickMoved.emit(x_val, y_val)

    # ==========================================
    # 💡 新增核心功能：反向坐标更新接口
    # ==========================================
    def set_position_from_values(self, x_val: float, y_val: float):
        """
        接收外部算好的 x, y (范围 -100 到 100)，自动重绘画布中的摇杆位置。
        不触发信号发射，专门用于输入框同步。
        """
        # 1. 限制输入范围在合法区间
        x_val = max(-100.0, min(100.0, float(x_val)))
        y_val = max(-100.0, min(100.0, float(y_val)))

        # 2. 将 x, y 数值转换回界面的像素坐标 (注意 UI 坐标系 Y 轴是向下的)
        px = self.centerPoint.x() + (x_val / 100.0) * self.radius
        py = self.centerPoint.y() - (y_val / 100.0) * self.radius
        new_pos = QPoint(int(px), int(py))

        # 3. 物理极坐标边界限制 (防止对角线溢出圆形底盘)
        line = new_pos - self.centerPoint
        distance = (line.x()**2 + line.y()**2) ** 0.5
        if distance > self.radius:
            new_pos.setX(int(self.centerPoint.x() + line.x() * self.radius / distance))
            new_pos.setY(int(self.centerPoint.y() + line.y() * self.radius / distance))

        # 4. 强制更新 UI 画布，不调用 emitSignals()
        self.joystickPos = new_pos
        self.update()