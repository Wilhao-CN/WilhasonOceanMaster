# 文件路径: ui/widgets/side_panels.py
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                             QGroupBox, QGridLayout, QPushButton, QDoubleSpinBox,
                             QComboBox)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPixmap # 💡 新增：用于将 OpenCV 图片显示在 Label 上
from ui.widgets.comm_panel import CommPanel
from PyQt5.QtCore import pyqtSignal, Qt, QSize, QTimer
from PyQt5.QtWidgets import QScrollArea # 💡 新增滚动区域组件


def _apply_fault_status(widget, status: dict):
    overall = status.get("overall", "unknown")
    overall_styles = {
        "normal": ("✅", "green"),
        "fault": ("❌", "#c62828"),
        "offline": ("⚠", "#ef6c00"),
        "unknown": ("❔", "#666666"),
    }
    icon, color = overall_styles.get(overall, ("❔", "#666666"))
    widget.lbl_status.setText(f"{icon} {status.get('overall_text', '状态未知')}")
    widget.lbl_status.setStyleSheet(f"color: {color}; font-weight: bold;")

    component_icons = {
        "normal": "✅",
        "fault": "❌",
        "unknown": "❔",
        "disabled": "⚪",
    }
    components = status.get("components", {})
    lines = []
    details = []
    for key, label in (("mcu", "MCU"), ("raspberry_pi", "树莓派"), ("4g", "4G")):
        item = components.get(key, {"state": "unknown", "text": "未知"})
        state = item.get("state", "unknown")
        text = str(item.get("text", "未知"))
        lines.append(f"{component_icons.get(state, '❔')} {label}: {text}")
        details.append(f"{label}: {text}")
    widget.lbl_fault_components.setText("\n".join(lines))
    widget.lbl_fault_components.setToolTip("\n".join(details))


def _set_fault_history_count(widget, count: int):
    count = max(0, int(count))
    suffix = f"（{count}）" if count else ""
    widget.btn_fault_history.setText(f"📋 查看故障历史{suffix}")
# ==========================================
# 1. 视频标签与弹窗组件 (功能增强)
# ==========================================
class ClickableVideoLabel(QLabel):
    sig_double_clicked = pyqtSignal()

    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        # 💡 新增：定义显示定时器
        # self.display_timer = QTimer(self)
        # self.display_timer.timeout.connect(self._pull_latest_frame)
        # self.video_thread_ref = None # 用于持有后台线程的引用
        self.setAlignment(Qt.AlignCenter)
        # 禁止 QLabel 把 16:9 视频强行拉伸到任意宽高比；由 set_image 使用
        # 高质量等比例缩放，避免侧边预览发糊和船体变形。
        self.setScaledContents(False)
        # 💡 新增：默认黑色背景
        self.setStyleSheet("background-color: black; color: white;")
    
    def mouseDoubleClickEvent(self, event):
        self.sig_double_clicked.emit()
        super().mouseDoubleClickEvent(event)

    # 💡 核心新增方法：让 Label 能够渲染图片
    def set_image(self, qimg):
        """
        🔒 [自适应缩放] 按 label 当前尺寸缩放后再贴图。
        VisionWindow 会改大共用 VideoThread 的 target_size，导致侧边栏收到超大帧，
        这里强制缩放到 label 实际尺寸，防止 sizeHint 撑出水平滚动条。
        """
        label_size = self.size()
        pixmap = QPixmap.fromImage(qimg)
        if label_size.width() > 0 and label_size.height() > 0:
            pixmap = pixmap.scaled(
                label_size,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation,
            )
        self.setPixmap(pixmap)

class VideoPopWindow(QWidget):
    sig_window_closed = pyqtSignal()

    def __init__(self, title="独立视频监控"):
        super().__init__()
        self.setWindowTitle(title)
        self.resize(800, 600)
        self.setWindowFlags(Qt.Window | Qt.WindowStaysOnTopHint)
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)

        # 🔒 弹窗自带独立视频标签，不搬动面板里的原标签
        self.video_label = ClickableVideoLabel("📹 独立视角\n(待接收画面)")
        self.layout.addWidget(self.video_label)

    def set_image(self, qimg):
        """接收视频帧并贴图"""
        self.video_label.set_image(qimg)

    def closeEvent(self, event):
        self.sig_window_closed.emit()
        event.ignore()
        self.hide()

# ==========================================
# 2. 船坞专用控制面板 (DockPanelWidget)
# ==========================================
class DockPanelWidget(QWidget):
    # 💡 信号定义完全保留，不作改动
    sig_return_clicked = pyqtSignal()
    sig_estop_clicked = pyqtSignal()
    sig_custom_clicked = pyqtSignal() 
    sig_init_clicked = pyqtSignal()                            
    sig_auto_heading_toggled = pyqtSignal(bool, float)         
    sig_auto_speed_toggled = pyqtSignal(bool, float)
    sig_open_tuning_req = pyqtSignal()  # 💡 [新增] 弹出调参窗信号
    
    # 💡 [新增] 录像功能信号
    sig_record_toggled = pyqtSignal(bool)

    # 💡 [新增] UI 输入框数值改变信号
    sig_target_heading_changed = pyqtSignal(float)
    sig_target_speed_changed = pyqtSignal(float)
    sig_heading_source_changed = pyqtSignal(str)
    sig_fault_history_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.is_auto_heading = False
        self.is_auto_speed = False

        # --- 🧩 第一步：构建”滚动外壳” ---
        # 1. 这是 Widget 真正的顶级布局
        self.main_v_layout = QVBoxLayout(self)
        self.main_v_layout.setContentsMargins(0, 0, 0, 0)

        # 2. 创建滚动区域
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)           # 关键：允许内容随窗口拉伸
        self.scroll.setFrameShape(QScrollArea.NoFrame) # 去掉边框

        # 3. 创建真正承载内容的内部小窗口
        self.content_widget = QWidget()
        self.layout = QVBoxLayout(self.content_widget) # 💡 关键：后续所有组件都装在这里
        self.layout.setContentsMargins(5, 5, 5, 5)

        # 4. 【核心连接】将内容装进滚动条，将滚动条装进主布局
        self.scroll.setWidget(self.content_widget)
        self.main_v_layout.addWidget(self.scroll)

        # --- 🧩 第二步：接下来的原有代码保持不变，它们会自动装入 self.layout ---
        # 💡 [关键：在这里初始化定时器]
        self.display_timer = QTimer(self)
        self.display_timer.timeout.connect(self._pull_latest_frame)
        self.video_thread_ref = None

        # 视频区域
        self.video_label = ClickableVideoLabel("📹 船坞视频监控流\n(待连接)")
        self.video_label.setStyleSheet("background-color: black; color: white; min-height: 230px; border-radius: 5px;")
        self.layout.addWidget(self.video_label)

        # 💡 [新增] 录制控制条
        record_layout = QHBoxLayout()
        self.btn_record = QPushButton("🔴 开始录制原画")
        self.btn_record.setCheckable(True)
        self.btn_record.setToolTip("录制未压缩、无 UI 遮挡的高清原始视频流")
        record_layout.addStretch()
        record_layout.addWidget(self.btn_record)
        self.layout.addLayout(record_layout)

        self.pop_window = VideoPopWindow("1号端：船坞监控独立视角")
        self.video_label.sig_double_clicked.connect(self._pop_out_video)
        self.pop_window.sig_window_closed.connect(self._pop_in_video)

        # 核心运行状态 (💡 所有的 lbl_... 命名严格遵循原版)
        core_group = QGroupBox("📊 核心运行状态")
        core_grid = QGridLayout(core_group)
        self.lbl_battery = QLabel("-- %")
        self.lbl_mode = QLabel("--")
        self.lbl_status = QLabel("--")
        self.lbl_fault_components = QLabel("❔ MCU: 未知\n❔ 树莓派: 未知\n❔ 4G: 未知")
        self.lbl_fault_components.setWordWrap(True)
        self.lbl_fault_components.setStyleSheet("color: #555555;")
        self.btn_fault_history = QPushButton("📋 查看故障历史")
        self.lbl_dist = QLabel("-- m")
        self.lbl_pwm_main = QLabel("L: --  R: --")
        self.lbl_pwm_aux = QLabel("3: --  4: --")
        self.lbl_temperature_01 = QLabel("-- ℃")
        self.lbl_temperature_status_01 = QLabel("等待双温度帧")
        self.lbl_temperature_02 = QLabel("-- ℃")
        self.lbl_temperature_status_02 = QLabel("等待双温度帧")

        core_grid.addWidget(QLabel("🔋 电量:"), 0, 0)
        core_grid.addWidget(self.lbl_battery, 0, 1)
        core_grid.addWidget(QLabel("⚙️ 模式:"), 0, 2)
        core_grid.addWidget(self.lbl_mode, 0, 3)
        core_grid.addWidget(QLabel("🚨 状态:"), 1, 0)
        core_grid.addWidget(self.lbl_status, 1, 1)
        core_grid.addWidget(QLabel("📏 距离:"), 1, 2)
        core_grid.addWidget(self.lbl_dist, 1, 3)
        # PWM 独占行，撑满宽度
        core_grid.addWidget(QLabel("⚡ 主动力:"), 2, 0)
        core_grid.addWidget(self.lbl_pwm_main, 2, 1, 1, 3)
        core_grid.addWidget(QLabel("🔌 副动力:"), 3, 0)
        core_grid.addWidget(self.lbl_pwm_aux, 3, 1, 1, 3)
        core_grid.addWidget(QLabel("🌡️ 水温01:"), 4, 0)
        core_grid.addWidget(self.lbl_temperature_01, 4, 1)
        core_grid.addWidget(QLabel("📗 状态1:"), 4, 2)
        core_grid.addWidget(self.lbl_temperature_status_01, 4, 3)
        core_grid.addWidget(QLabel("🌡️ 水温02:"), 5, 0)
        core_grid.addWidget(self.lbl_temperature_02, 5, 1)
        core_grid.addWidget(QLabel("📗 状态2:"), 5, 2)
        core_grid.addWidget(self.lbl_temperature_status_02, 5, 3)
        core_grid.addWidget(self.lbl_fault_components, 6, 0, 1, 4)
        core_grid.addWidget(self.btn_fault_history, 7, 0, 1, 4)
        self.layout.addWidget(core_group)

        # 导航与姿态数据
        nav_group = QGroupBox("🧭 导航与姿态数据")
        nav_grid = QGridLayout(nav_group)
        nav_grid.setHorizontalSpacing(6)
        nav_grid.setVerticalSpacing(3)
        self.lbl_sats = QLabel("-- °")
        self.lbl_speed = QLabel("-- m/s")
        self.lbl_calc_speed = QLabel("(GPS求解)")
        self.lbl_calc_speed.setStyleSheet("color: gray; font-size: 9pt;")
        self.lbl_heading = QLabel("-- °")
        self.lbl_cog = QLabel("-- °")
        self.lbl_dual_heading = QLabel("-- °")
        self.lbl_roll = QLabel("-- m/s")
        self.lbl_yaw_rate = QLabel("-- °/s")
        self.lbl_sway_speed = QLabel("-- m/s")
        self.lbl_gps = QLabel("N: -- / E: --")
        self.lbl_gps.setStyleSheet("color: #0055ff; font-family: 'Consolas'; font-weight: bold;")

        # Row 0: EKF艏向 + 速度
        nav_grid.addWidget(QLabel("🧭 EKF艏向:"), 0, 0)
        nav_grid.addWidget(self.lbl_sats, 0, 1)
        nav_grid.addWidget(QLabel("🚀 速度:"), 0, 2)
        nav_grid.addWidget(self.lbl_speed, 0, 3)

        # Row 1: 艏向 + 航向
        nav_grid.addWidget(QLabel("🧭 艏向:"), 1, 0)
        nav_grid.addWidget(self.lbl_heading, 1, 1)
        nav_grid.addWidget(QLabel("🌊 航向:"), 1, 2)
        nav_grid.addWidget(self.lbl_cog, 1, 3)

        # Row 2: 横速 + 角速
        nav_grid.addWidget(QLabel("🦀 横速:"), 2, 0)
        nav_grid.addWidget(self.lbl_sway_speed, 2, 1)
        nav_grid.addWidget(QLabel("🔄 角速:"), 2, 2)
        nav_grid.addWidget(self.lbl_yaw_rate, 2, 3)

        # Row 3: 辅速 + IMU速度
        nav_grid.addWidget(QLabel("🚀 辅速:"), 3, 0)
        nav_grid.addWidget(self.lbl_calc_speed, 3, 1)
        nav_grid.addWidget(QLabel("📐 IMU速度:"), 3, 2)
        nav_grid.addWidget(self.lbl_roll, 3, 3)

        # Row 4: 双GPS艏向 + 船坞控制艏向源
        nav_grid.addWidget(QLabel("📡 双GPS艏向:"), 4, 0)
        nav_grid.addWidget(self.lbl_dual_heading, 4, 1)
        nav_grid.addWidget(QLabel("🎛 控制源:"), 4, 2)
        self.combo_heading_source = QComboBox()
        self.combo_heading_source.addItem("EKF融合", "ekf")
        self.combo_heading_source.addItem("双GPS", "dual_gps")
        self.combo_heading_source.setToolTip("选择船坞路径跟踪和定艏控制使用的当前艏向")
        self.combo_heading_source.currentIndexChanged.connect(
            self._on_heading_source_changed
        )
        nav_grid.addWidget(self.combo_heading_source, 4, 3)

        # Row 5: GPS (独占一行)
        nav_grid.addWidget(QLabel("📍 GPS:"), 5, 0)
        nav_grid.addWidget(self.lbl_gps, 5, 1, 1, 3)

        # Row 6: 天线B GPS (独占一行)
        nav_grid.addWidget(QLabel("📡 天线B GPS:"), 6, 0)
        self.lbl_gps_b = QLabel("N: -- / E: --")
        self.lbl_gps_b.setStyleSheet("color: #cc6600; font-family: 'Consolas'; font-weight: bold;")
        nav_grid.addWidget(self.lbl_gps_b, 6, 1, 1, 3)

        self.layout.addWidget(nav_group)

        # 控制面板 (💡 按钮功能完全保留)
        control_group = QGroupBox("🎮 船坞控制面板")
        c_layout = QVBoxLayout(control_group)

        row1_layout = QHBoxLayout()
        self.btn_init = QPushButton("⚙️ 系统初始化")
        self.btn_return = QPushButton("🎯 一键返航")
        self.btn_return.setEnabled(True)  # ✅ 已启用 P2P 一键返航 (23°00'50.4"N 113°23'52.8"E)
        self.btn_return.setToolTip("点击后船坞自动 P2P 返航至停靠点")
        self.btn_estop = QPushButton("🛑 动力急停")
        self.btn_estop.setStyleSheet("color: red; font-weight: bold;")
        row1_layout.addWidget(self.btn_init)
        row1_layout.addWidget(self.btn_return)
        row1_layout.addWidget(self.btn_estop)
        c_layout.addLayout(row1_layout)

        # 自动定速/定艏输入
        row2_layout = QHBoxLayout()
        row2_layout.addWidget(QLabel("🚀 目标速度:"))
        self.spin_speed = QDoubleSpinBox()           
        self.spin_speed.setRange(-5.0, 5.0)
        self.spin_speed.setValue(1.0)                
        row2_layout.addWidget(self.spin_speed)
        self.btn_auto_speed = QPushButton("🚀 启动自动定速")  
        self.btn_auto_speed.setCheckable(True)       
        row2_layout.addWidget(self.btn_auto_speed)
        
        # 💡 [核心新增] 调参入口按钮
        self.btn_open_tuning = QPushButton("🛠️")
        self.btn_open_tuning.setFixedWidth(40) 
        self.btn_open_tuning.setToolTip("打开算法自带调参窗口")
        self.btn_open_tuning.clicked.connect(self.sig_open_tuning_req.emit) 
        row2_layout.addWidget(self.btn_open_tuning)
        
        c_layout.addLayout(row2_layout)

        row3_layout = QHBoxLayout()
        row3_layout.addWidget(QLabel("🎯 目标艏向角:"))
        self.spin_heading = QDoubleSpinBox()           
        self.spin_heading.setRange(-360.0, 360.0)         
        self.spin_heading.setValue(0.0)                
        row3_layout.addWidget(self.spin_heading)
        self.btn_auto_heading = QPushButton("🧭 启动自动定艏")  
        self.btn_auto_heading.setCheckable(True)       
        row3_layout.addWidget(self.btn_auto_heading)
        c_layout.addLayout(row3_layout)

        self.btn_custom = QPushButton("💡 预留功能 (注入测试数据)")
        c_layout.addWidget(self.btn_custom)
        
        # 信号绑定 (完全沿用原版)
        self.btn_return.clicked.connect(self.sig_return_clicked.emit)
        self.btn_estop.clicked.connect(self.sig_estop_clicked.emit)
        self.btn_custom.clicked.connect(self.sig_custom_clicked.emit)
        self.btn_init.clicked.connect(self.sig_init_clicked.emit)
        self.btn_auto_heading.toggled.connect(self._on_auto_heading_toggled)
        self.btn_auto_speed.toggled.connect(self._on_auto_speed_toggled)

        # 💡 [新增] 录像开关信号绑定
        self.btn_record.toggled.connect(self._on_record_toggled)
        self.btn_fault_history.clicked.connect(self.sig_fault_history_requested.emit)
        
        # 💡 [新增] 绑定输入框的数值变化信号，只要框里的数字一动，就发射信号
        self.spin_heading.valueChanged.connect(self.sig_target_heading_changed.emit)
        self.spin_speed.valueChanged.connect(self.sig_target_speed_changed.emit)

        self.layout.addWidget(control_group)
        # 💡 [核心新增] 算法实时调参插槽 (Slot)
        # self.algo_tuning_group = QGroupBox("🛠️ 算法实时调参")
        # self.algo_tuning_layout = QVBoxLayout(self.algo_tuning_group)
        # self.algo_tuning_group.hide() # 初始隐藏，有 UI 注入时再显示
        # self.layout.addWidget(self.algo_tuning_group)

        # 通信日志助手
        self.comm_panel = CommPanel(title="📟 船坞通信日志助手", default_port="COM1", default_baud="115200")
        self.layout.addWidget(self.comm_panel)
        # 💡 新增：记录视频标签的初始尺寸，后续会同步给后台线程
        self.video_size = self.video_label.size()
        self.layout.addStretch(1)

    # 💡 核心新增：视频更新接口
    def update_video_frame(self, image):
        self.video_label.set_image(image)
        # 🔒 弹窗独立标签同步刷新（不搬动原标签）
        if self.pop_window.isVisible():
            self.pop_window.set_image(image)

    # 💡 原有槽函数 100% 保留
    def _on_auto_heading_toggled(self, checked: bool):
        self.is_auto_heading = checked
        target_angle = self.spin_heading.value()
        if checked:
            self.btn_auto_heading.setText("🛑 停止自动定艏")
            self.btn_auto_heading.setStyleSheet("background-color: #ffcccc; color: red; font-weight: bold;")
        else:
            self.btn_auto_heading.setText("🧭 启动自动定艏")
            self.btn_auto_heading.setStyleSheet("")
        self.sig_auto_heading_toggled.emit(checked, target_angle)

    def _on_heading_source_changed(self, _index: int):
        self.sig_heading_source_changed.emit(
            str(self.combo_heading_source.currentData())
        )

    def _on_auto_speed_toggled(self, checked: bool):
        self.is_auto_speed = checked
        target_speed = self.spin_speed.value()
        if checked:
            self.btn_auto_speed.setText("🛑 停止自动定速")
            self.btn_auto_speed.setStyleSheet("background-color: #ffcccc; color: red; font-weight: bold;")
        else:
            self.btn_auto_speed.setText("🚀 启动自动定速")
            self.btn_auto_speed.setStyleSheet("")
        self.sig_auto_speed_toggled.emit(checked, target_speed)

    # 💡 [新增] 录像开关处理逻辑
    def _on_record_toggled(self, checked: bool):
        if checked:
            self.btn_record.setText("⏹️ 停止录像保存")
            self.btn_record.setStyleSheet("background-color: #ffcccc; color: red;")
        else:
            self.btn_record.setText("🔴 开始录制原画")
            self.btn_record.setStyleSheet("")
        self.sig_record_toggled.emit(checked)
        
    def _pull_latest_frame(self):
        """
        定时器触发：主动从后台仓库抓取最新一帧
        """
        if self.video_thread_ref:
            # 💡 核心：主动调用我们在第一步中写的 get_latest_frame 接口
            latest_image = self.video_thread_ref.get_latest_frame()
            if latest_image:
                # 已经是预缩放过的 QImage，直接显示
                self.video_label.set_image(latest_image)
                # 🔒 弹窗独立标签同步刷新（不搬动原标签）
                if self.pop_window.isVisible():
                    self.pop_window.set_image(latest_image)
    def _pop_out_video(self):
        # 🔒 不再搬动面板里的 video_label，弹窗自带独立标签
        self.pop_window.show()

    def _pop_in_video(self):
        # 🔒 只隐藏弹窗，面板里的原标签从未离开，无需插回
        self.pop_window.hide()
    def start_video_display(self, video_thread):
        """由 Controller 调用，建立引用并启动定时刷新"""
        self.video_thread_ref = video_thread
        # 💡 [关键：尺寸同步] 启动时立即告诉后台线程，侧边栏需要多大的图片
        if self.video_thread_ref:
            self.video_thread_ref.set_target_size(self.video_label.size())
        
        self.display_timer.start(getattr(video_thread, "display_interval_ms", 33))
    def stop_video_display(self):
        """停止刷新"""
        self.display_timer.stop()
        self.video_thread_ref = None
    def update_algo_tuning_ui(self, h_ui: QWidget, s_ui: QWidget):
        """
        🚀 [核心接口] 接收算法自带的 UI 并动态替换
        """
        # 1. 清空旧的 UI 插件
        while self.algo_tuning_layout.count():
            item = self.algo_tuning_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater() # 彻底销毁旧对象，防止内存泄漏

        # 2. 注入新的 UI 插件
        has_content = False
        if h_ui:
            self.algo_tuning_layout.addWidget(QLabel("<b>艏向控制参数:</b>"))
            self.algo_tuning_layout.addWidget(h_ui)
            has_content = True
        
        if s_ui:
            self.algo_tuning_layout.addWidget(QLabel("<b>速度控制参数:</b>"))
            self.algo_tuning_layout.addWidget(s_ui)
            has_content = True

        # 3. 根据内容自动显示/隐藏这个组
        self.algo_tuning_group.setVisible(has_content)

    @staticmethod
    def _update_temperature_display(sample, value_label, status_label):
        water_c = sample.get('water_c')
        if sample.get('valid') and water_c is not None:
            value_label.setText(f"{water_c:.1f} ℃")
            value_label.setStyleSheet("color: #0077aa; font-weight: bold;")
            status_label.setText("✅ 正常")
            status_label.setStyleSheet("color: green; font-weight: bold;")
            return

        value_label.setText("-- ℃")
        value_label.setStyleSheet("color: gray;")
        error_code = sample.get('error_code')
        if error_code is None:
            status_label.setText("等待双温度帧")
            status_label.setStyleSheet("color: gray;")
            return
        if error_code == 0:
            status_label.setText("等待首个温度")
            status_label.setStyleSheet("color: gray;")
            return

        error_map = {
            1: "HAL错误",
            2: "发送超时",
            3: "接收超时",
            4: "长度错误",
            5: "CRC错误",
            6: "响应错误",
            7: "Modbus异常",
            8: "温度越界",
        }
        error_text = error_map.get(error_code, f"错误{error_code}")
        status_label.setText(f"❌ {error_text}")
        status_label.setStyleSheet("color: red; font-weight: bold;")

    def update_fault_status(self, status: dict):
        _apply_fault_status(self, status)

    def set_fault_history_count(self, count: int):
        _set_fault_history_count(self, count)

    def update_sensor_data(self, data: dict):
        """💡 传感器显示更新：逻辑与命名与原版 100% 一致"""
        if 'battery' in data: self.lbl_battery.setText(f"{data['battery']} %")
        if 'mode' in data:
            mode_map = {0x00: "🔒 锁定", 0x01: "🕹️ 手动", 0x02: "🎯 返航"}
            self.lbl_mode.setText(mode_map.get(data['mode'], f"未知 ({data['mode']})"))
        if 'temperatures' in data:
            temperatures = data['temperatures']
            self._update_temperature_display(
                temperatures.get('sensor_01', {}),
                self.lbl_temperature_01,
                self.lbl_temperature_status_01,
            )
            self._update_temperature_display(
                temperatures.get('sensor_02', {}),
                self.lbl_temperature_02,
                self.lbl_temperature_status_02,
            )
        if 'pwm' in data and len(data['pwm']) >= 4:
            pwms = data['pwm']
            self.lbl_pwm_main.setText(f"L: {pwms[0]}  R: {pwms[1]}")
            self.lbl_pwm_aux.setText(f"3: {pwms[2]}  4: {pwms[3]}")
        if 'dist' in data: self.lbl_dist.setText(f"{data['dist']} m")
        if 'gps' in data:
            gps = data['gps']
            if 'speed' in gps: self.lbl_speed.setText(f"{gps['speed']:.2f} m/s")
            
            # 💡 [核心新增] 从 data 根目录提取 Brain 存入的解算速度
            if 'calculated_speed' in data:
                self.lbl_calc_speed.setText(f"({data['calculated_speed']:.2f})")
            if 'cog' in gps: self.lbl_cog.setText(f"{gps['cog']:.1f} °")
            if 'lat' in gps and 'lon' in gps: self.lbl_gps.setText(f"N: {gps['lat']:.6f} / E: {gps['lon']:.6f}")
        if 'gps_B' in data:
            gps_b = data['gps_B']
            if 'lat' in gps_b and 'lon' in gps_b and gps_b['lat'] != 0:
                self.lbl_gps_b.setText(f"N: {gps_b['lat']:.6f} / E: {gps_b['lon']:.6f}")
            else:
                self.lbl_gps_b.setText("N: -- / E: --")
        if 'imu' in data:
            imu = data['imu']
            if 'heading' in imu: self.lbl_heading.setText(f"{imu['heading']:.1f} °")
            if 'dual_heading' in imu: self.lbl_dual_heading.setText(f"{imu['dual_heading']:.1f} °")
            if 'imu_vel_x' in imu: self.lbl_roll.setText(f"{imu['imu_vel_x']:.2f} m/s")
            if 'yaw_rate' in imu: self.lbl_yaw_rate.setText(f"{imu['yaw_rate']:.1f} °/s")
            if 'sway_speed' in imu: self.lbl_sway_speed.setText(f"{imu['sway_speed']:.2f} m/s")
            if 'ekf_heading' in imu: self.lbl_sats.setText(f"{imu['ekf_heading']:.1f} °")

# ==========================================
# 3. 子船专用控制面板 (BoatPanelWidget)
# ==========================================
class BoatPanelWidget(QWidget):
    # 💡 信号定义：严格保留原版所有信号
    sig_return_clicked = pyqtSignal()
    sig_estop_clicked = pyqtSignal()
    sig_custom_clicked = pyqtSignal() 
    sig_init_clicked = pyqtSignal()                            
    sig_auto_heading_toggled = pyqtSignal(bool, float)         
    sig_auto_speed_toggled = pyqtSignal(bool, float)
    sig_open_tuning_req = pyqtSignal()  # 💡 [新增] 弹出调参窗信号
    
    # 💡 [新增] 录像功能信号
    sig_record_toggled = pyqtSignal(bool)

    # 💡 [新增] UI 输入框数值改变信号
    sig_target_heading_changed = pyqtSignal(float)
    sig_target_speed_changed = pyqtSignal(float)
    sig_heading_source_changed = pyqtSignal(str)
    sig_fault_history_requested = pyqtSignal()
    def __init__(self, parent=None):
        super().__init__(parent)
        self.is_auto_heading = False
        self.is_auto_speed = False

        # --- 🧩 子船同步开启滚动模式 ---
        self.main_v_layout = QVBoxLayout(self)
        self.main_v_layout.setContentsMargins(0, 0, 0, 0)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.NoFrame)

        self.content_widget = QWidget()
        self.layout = QVBoxLayout(self.content_widget)
        self.layout.setContentsMargins(5, 5, 5, 5)

        self.scroll.setWidget(self.content_widget)
        self.main_v_layout.addWidget(self.scroll)

        # 接下来原本的代码保持不变...
        self.display_timer = QTimer(self)
        self.display_timer.timeout.connect(self._pull_latest_frame)
        self.video_thread_ref = None

        # 1. 视频区域
        self.video_label = ClickableVideoLabel("📹 无人船主视角视频流\n(待连接)")
        self.video_label.setStyleSheet("background-color: black; color: white; min-height: 230px; border-radius: 5px;")
        self.layout.addWidget(self.video_label)

        # 💡 [新增] 录制控制条
        record_layout = QHBoxLayout()
        self.btn_record = QPushButton("🔴 开始录制原画")
        self.btn_record.setCheckable(True)
        self.btn_record.setToolTip("录制未压缩、无 UI 遮挡的高清原始视频流")
        record_layout.addStretch()
        record_layout.addWidget(self.btn_record)
        self.layout.addLayout(record_layout)

        self.pop_window = VideoPopWindow("2号端：无人船主视角独立窗口")
        self.video_label.sig_double_clicked.connect(self._pop_out_video)
        self.pop_window.sig_window_closed.connect(self._pop_in_video)

        # 2. 核心运行状态 (💡 变量名与原版一致，确保 update_sensor_data 不报错)
        core_group = QGroupBox("📊 核心运行状态")
        core_grid = QGridLayout(core_group)
        self.lbl_battery = QLabel("-- %")
        self.lbl_mode = QLabel("--")
        self.lbl_status = QLabel("--")
        self.lbl_fault_components = QLabel("❔ MCU: 未知\n❔ 树莓派: 未知\n❔ 4G: 未知")
        self.lbl_fault_components.setWordWrap(True)
        self.lbl_fault_components.setStyleSheet("color: #555555;")
        self.btn_fault_history = QPushButton("📋 查看故障历史")
        self.lbl_dist = QLabel("-- m")
        self.lbl_pwm_main = QLabel("L: --  R: --")
        self.lbl_pwm_aux = QLabel("3: --  4: --")
        self.lbl_temperature_01 = QLabel("-- ℃")
        self.lbl_temperature_status_01 = QLabel("等待双温度帧")
        self.lbl_temperature_02 = QLabel("-- ℃")
        self.lbl_temperature_status_02 = QLabel("等待双温度帧")

        core_grid.addWidget(QLabel("🔋 电量:"), 0, 0)
        core_grid.addWidget(self.lbl_battery, 0, 1)
        core_grid.addWidget(QLabel("⚙️ 模式:"), 0, 2)
        core_grid.addWidget(self.lbl_mode, 0, 3)
        core_grid.addWidget(QLabel("🚨 状态:"), 1, 0)
        core_grid.addWidget(self.lbl_status, 1, 1)
        core_grid.addWidget(QLabel("📏 距离:"), 1, 2)
        core_grid.addWidget(self.lbl_dist, 1, 3)
        # PWM 独占行，撑满宽度
        core_grid.addWidget(QLabel("⚡ 主动力:"), 2, 0)
        core_grid.addWidget(self.lbl_pwm_main, 2, 1, 1, 3)
        core_grid.addWidget(QLabel("🔌 副动力:"), 3, 0)
        core_grid.addWidget(self.lbl_pwm_aux, 3, 1, 1, 3)
        core_grid.addWidget(QLabel("🌡️ 水温01:"), 4, 0)
        core_grid.addWidget(self.lbl_temperature_01, 4, 1)
        core_grid.addWidget(QLabel("📡 状态01:"), 4, 2)
        core_grid.addWidget(self.lbl_temperature_status_01, 4, 3)
        core_grid.addWidget(QLabel("🌡️ 水温02:"), 5, 0)
        core_grid.addWidget(self.lbl_temperature_02, 5, 1)
        core_grid.addWidget(QLabel("📡 状态02:"), 5, 2)
        core_grid.addWidget(self.lbl_temperature_status_02, 5, 3)
        core_grid.addWidget(self.lbl_fault_components, 6, 0, 1, 4)
        core_grid.addWidget(self.btn_fault_history, 7, 0, 1, 4)
        self.layout.addWidget(core_group)

        # 3. 导航与姿态数据
        nav_group = QGroupBox("🧭 导航与姿态数据")
        nav_grid = QGridLayout(nav_group)
        nav_grid.setHorizontalSpacing(6)
        nav_grid.setVerticalSpacing(3)
        self.lbl_sats = QLabel("-- °")
        self.lbl_speed = QLabel("-- m/s")
        self.lbl_calc_speed = QLabel("(GPS求解)")
        self.lbl_calc_speed.setStyleSheet("color: gray; font-size: 9pt;")
        self.lbl_heading = QLabel("-- °")
        self.lbl_cog = QLabel("-- °")
        self.lbl_dual_heading = QLabel("-- °")
        self.lbl_roll = QLabel("-- m/s")
        self.lbl_yaw_rate = QLabel("-- °/s")
        self.lbl_sway_speed = QLabel("-- m/s")
        self.lbl_gps = QLabel("N: -- / E: --")
        self.lbl_gps.setStyleSheet("color: #0055ff; font-family: 'Consolas'; font-weight: bold;")

        # Row 0: EKF艏向 + 速度
        nav_grid.addWidget(QLabel("🧭 EKF艏向:"), 0, 0)
        nav_grid.addWidget(self.lbl_sats, 0, 1)
        nav_grid.addWidget(QLabel("🚀 速度:"), 0, 2)
        nav_grid.addWidget(self.lbl_speed, 0, 3)

        # Row 1: 艏向 + 航向
        nav_grid.addWidget(QLabel("🧭 艏向:"), 1, 0)
        nav_grid.addWidget(self.lbl_heading, 1, 1)
        nav_grid.addWidget(QLabel("🌊 航向:"), 1, 2)
        nav_grid.addWidget(self.lbl_cog, 1, 3)

        # Row 2: 横速 + 角速
        nav_grid.addWidget(QLabel("🦀 横速:"), 2, 0)
        nav_grid.addWidget(self.lbl_sway_speed, 2, 1)
        nav_grid.addWidget(QLabel("🔄 角速:"), 2, 2)
        nav_grid.addWidget(self.lbl_yaw_rate, 2, 3)

        # Row 3: 辅速 + IMU速度
        nav_grid.addWidget(QLabel("🚀 辅速:"), 3, 0)
        nav_grid.addWidget(self.lbl_calc_speed, 3, 1)
        nav_grid.addWidget(QLabel("📐 IMU速度:"), 3, 2)
        nav_grid.addWidget(self.lbl_roll, 3, 3)

        # Row 4: 双GPS艏向 + 子船控制艏向源
        nav_grid.addWidget(QLabel("📡 双GPS艏向:"), 4, 0)
        nav_grid.addWidget(self.lbl_dual_heading, 4, 1)
        nav_grid.addWidget(QLabel("🎛 控制源:"), 4, 2)
        self.combo_heading_source = QComboBox()
        self.combo_heading_source.addItem("EKF融合", "ekf")
        self.combo_heading_source.addItem("双GPS", "dual_gps")
        self.combo_heading_source.setToolTip("选择子船路径跟踪和定艏控制使用的当前艏向")
        self.combo_heading_source.currentIndexChanged.connect(
            self._on_heading_source_changed
        )
        nav_grid.addWidget(self.combo_heading_source, 4, 3)

        # Row 5: GPS (独占一行)
        nav_grid.addWidget(QLabel("📍 GPS:"), 5, 0)
        nav_grid.addWidget(self.lbl_gps, 5, 1, 1, 3)

        # Row 6: 天线B GPS (独占一行)
        nav_grid.addWidget(QLabel("📡 天线B GPS:"), 6, 0)
        self.lbl_gps_b = QLabel("N: -- / E: --")
        self.lbl_gps_b.setStyleSheet("color: #cc6600; font-family: 'Consolas'; font-weight: bold;")
        nav_grid.addWidget(self.lbl_gps_b, 6, 1, 1, 3)

        self.layout.addWidget(nav_group)

        # 4. 控制面板与通信面板
        control_group = QGroupBox("🎮 子船控制面板")
        c_layout = QVBoxLayout(control_group)

        row1_layout = QHBoxLayout()
        self.btn_init = QPushButton("⚙️ 系统初始化")
        self.btn_return = QPushButton("🎯 一键返航")
        self.btn_return.setEnabled(True)  # ✅ 已启用 P2P 一键返航 (23°00'50.2"N 113°23'52.3"E)
        self.btn_return.setToolTip("点击后子船自动 P2P 返航至停靠点")
        self.btn_estop = QPushButton("🛑 动力急停")
        self.btn_estop.setStyleSheet("color: red; font-weight: bold;")
        row1_layout.addWidget(self.btn_init)
        row1_layout.addWidget(self.btn_return)
        row1_layout.addWidget(self.btn_estop)
        c_layout.addLayout(row1_layout)

        # 自动定速/定艏输入 (已安装调参按钮)
        row2_layout = QHBoxLayout()
        row2_layout.addWidget(QLabel("🚀 目标速度:"))
        self.spin_speed = QDoubleSpinBox()
        self.spin_speed.setRange(-5.0, 5.0)
        self.spin_speed.setValue(1.0)
        row2_layout.addWidget(self.spin_speed)
        self.btn_auto_speed = QPushButton("🚀 启动自动定速")
        self.btn_auto_speed.setCheckable(True)
        row2_layout.addWidget(self.btn_auto_speed)

        # 💡 [核心新增] 调参入口按钮
        self.btn_open_tuning = QPushButton("🛠️")
        self.btn_open_tuning.setFixedWidth(40)
        self.btn_open_tuning.setToolTip("打开算法自带调参窗口")
        self.btn_open_tuning.clicked.connect(self.sig_open_tuning_req.emit)
        row2_layout.addWidget(self.btn_open_tuning)

        c_layout.addLayout(row2_layout)

        row3_layout = QHBoxLayout()
        row3_layout.addWidget(QLabel("🎯 目标艏向角:"))
        self.spin_heading = QDoubleSpinBox()
        self.spin_heading.setRange(-180.0, 180.0)
        self.spin_heading.setValue(0.0)
        row3_layout.addWidget(self.spin_heading)
        self.btn_auto_heading = QPushButton("🧭 启动自动定艏")
        self.btn_auto_heading.setCheckable(True)
        row3_layout.addWidget(self.btn_auto_heading)
        c_layout.addLayout(row3_layout)

        self.btn_custom = QPushButton("💡 预留功能 (注入测试数据)")
        c_layout.addWidget(self.btn_custom)

        # 信号绑定
        self.btn_return.clicked.connect(self.sig_return_clicked.emit)
        self.btn_estop.clicked.connect(self.sig_estop_clicked.emit)
        self.btn_custom.clicked.connect(self.sig_custom_clicked.emit)
        self.btn_init.clicked.connect(self.sig_init_clicked.emit)
        self.btn_auto_heading.toggled.connect(self._on_auto_heading_toggled)
        self.btn_auto_speed.toggled.connect(self._on_auto_speed_toggled) 
        
        # 💡 [新增] 录像开关信号绑定
        self.btn_record.toggled.connect(self._on_record_toggled)
        self.btn_fault_history.clicked.connect(self.sig_fault_history_requested.emit)
        
        # 💡 [新增] 绑定输入框的数值变化信号
        self.spin_heading.valueChanged.connect(self.sig_target_heading_changed.emit)
        self.spin_speed.valueChanged.connect(self.sig_target_speed_changed.emit)

        self.layout.addWidget(control_group)
# 💡 [核心新增] 子船算法调参插槽
        # self.algo_tuning_group = QGroupBox("🛠️ 算法实时调参")
        # self.algo_tuning_layout = QVBoxLayout(self.algo_tuning_group)
        # self.algo_tuning_group.hide()
        # self.layout.addWidget(self.algo_tuning_group)
        # 💡 使用自定义的 CommPanel
        self.comm_panel = CommPanel(title="📟 子船通信日志助手", default_port="COM2", default_baud="115200")
        self.layout.addWidget(self.comm_panel)
        # 💡 新增：记录视频标签的初始尺寸
        self.video_size = self.video_label.size()
        self.layout.addStretch(1)

    # 💡 核心新增：视频刷新接口 (Boat 专属)
    def update_video_frame(self, image):
        """接收来自 VideoThread 的 QImage 并贴图"""
        self.video_label.set_image(image)
        # 🔒 弹窗独立标签同步刷新（不搬动原标签）
        if self.pop_window.isVisible():
            self.pop_window.set_image(image)

    # ------------------------------------------
    # 原有逻辑处理函数 (100% 保留)
    # ------------------------------------------
    def _on_auto_heading_toggled(self, checked: bool):
        self.is_auto_heading = checked
        target_angle = self.spin_heading.value()
        if checked:
            self.btn_auto_heading.setText("🛑 停止自动定艏")
            self.btn_auto_heading.setStyleSheet("background-color: #ffcccc; color: red; font-weight: bold;")
        else:
            self.btn_auto_heading.setText("🧭 启动自动定艏")
            self.btn_auto_heading.setStyleSheet("")
        self.sig_auto_heading_toggled.emit(checked, target_angle)

    # 💡 [新增] 录像开关处理逻辑
    def _on_record_toggled(self, checked: bool):
        if checked:
            self.btn_record.setText("⏹️ 停止录像保存")
            self.btn_record.setStyleSheet("background-color: #ffcccc; color: red;")
        else:
            self.btn_record.setText("🔴 开始录制原画")
            self.btn_record.setStyleSheet("")
        self.sig_record_toggled.emit(checked)

    def _pull_latest_frame(self):
        if self.video_thread_ref:
            latest_image = self.video_thread_ref.get_latest_frame()
            if latest_image:
                self.video_label.set_image(latest_image)
                # 🔒 弹窗独立标签同步刷新（不搬动原标签）
                if self.pop_window.isVisible():
                    self.pop_window.set_image(latest_image)

    def start_video_display(self, video_thread):
        """启动视频显示并同步尺寸"""
        self.video_thread_ref = video_thread
        # 💡 [关键：尺寸同步] 确保子船后台生成的也是适合侧边栏的小图
        if self.video_thread_ref:
            self.video_thread_ref.set_target_size(self.video_label.size())
            
        self.display_timer.start(getattr(video_thread, "display_interval_ms", 33))

    def stop_video_display(self):
        self.display_timer.stop()
        self.video_thread_ref = None
    def _on_auto_speed_toggled(self, checked: bool):
        self.is_auto_speed = checked
        target_speed = self.spin_speed.value()
        if checked:
            self.btn_auto_speed.setText("🛑 停止自动定速")
            self.btn_auto_speed.setStyleSheet("background-color: #ffcccc; color: red; font-weight: bold;")
        else:
            self.btn_auto_speed.setText("🚀 启动自动定速")
            self.btn_auto_speed.setStyleSheet("")
        self.sig_auto_speed_toggled.emit(checked, target_speed)

    def _on_heading_source_changed(self, _index: int):
        self.sig_heading_source_changed.emit(
            str(self.combo_heading_source.currentData())
        )

    def _pop_out_video(self):
        # 🔒 不再搬动面板里的 video_label，弹窗自带独立标签
        self.pop_window.show()

    def _pop_in_video(self):
        # 🔒 只隐藏弹窗，面板里的原标签从未离开，无需插回
        self.pop_window.hide()
    def update_algo_tuning_ui(self, h_ui: QWidget, s_ui: QWidget):
        """🚀 [核心接口] 动态替换子船的算法调参界面"""
        while self.algo_tuning_layout.count():
            item = self.algo_tuning_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()

        has_content = False
        if h_ui:
            self.algo_tuning_layout.addWidget(QLabel("<b>艏向控制参数:</b>"))
            self.algo_tuning_layout.addWidget(h_ui)
            has_content = True
        if s_ui:
            self.algo_tuning_layout.addWidget(QLabel("<b>速度控制参数:</b>"))
            self.algo_tuning_layout.addWidget(s_ui)
            has_content = True
        self.algo_tuning_group.setVisible(has_content)
    @staticmethod
    def _update_temperature_display(sample, value_label, status_label):
        water_c = sample.get('water_c')
        if sample.get('valid') and water_c is not None:
            value_label.setText(f"{water_c:.1f} ℃")
            value_label.setStyleSheet("color: #0077aa; font-weight: bold;")
            status_label.setText("✅ 正常")
            status_label.setStyleSheet("color: green; font-weight: bold;")
            return

        value_label.setText("-- ℃")
        value_label.setStyleSheet("color: gray;")
        error_code = sample.get('error_code')
        if error_code is None:
            status_label.setText("等待双温度帧")
            status_label.setStyleSheet("color: gray;")
            return
        if error_code == 0:
            status_label.setText("等待首个温度")
            status_label.setStyleSheet("color: gray;")
            return

        error_map = {
            1: "HAL错误",
            2: "发送超时",
            3: "接收超时",
            4: "长度错误",
            5: "CRC错误",
            6: "响应错误",
            7: "Modbus异常",
            8: "温度越界",
        }
        error_text = error_map.get(error_code, f"错误{error_code}")
        status_label.setText(f"❌ {error_text}")
        status_label.setStyleSheet("color: red; font-weight: bold;")

    def update_fault_status(self, status: dict):
        _apply_fault_status(self, status)

    def set_fault_history_count(self, count: int):
        _set_fault_history_count(self, count)

    def update_sensor_data(self, data: dict):
        """💡 传感器显示更新：逻辑与命名与原版完全一致"""
        if 'battery' in data: self.lbl_battery.setText(f"{data['battery']} %")
        if 'mode' in data:
            mode_map = {0x00: "🔒 锁定", 0x01: "🕹️ 手动", 0x02: "🎯 返航"}
            self.lbl_mode.setText(mode_map.get(data['mode'], f"未知 ({data['mode']})"))
        if 'temperatures' in data:
            temperatures = data['temperatures']
            self._update_temperature_display(
                temperatures.get('sensor_01', {}),
                self.lbl_temperature_01,
                self.lbl_temperature_status_01,
            )
            self._update_temperature_display(
                temperatures.get('sensor_02', {}),
                self.lbl_temperature_02,
                self.lbl_temperature_status_02,
            )
        if 'pwm' in data and len(data['pwm']) >= 4:
            pwms = data['pwm']
            self.lbl_pwm_main.setText(f"L: {pwms[0]}  R: {pwms[1]}")
            self.lbl_pwm_aux.setText(f"3: {pwms[2]}  4: {pwms[3]}")
        if 'dist' in data: self.lbl_dist.setText(f"{data['dist']} m")
        if 'gps' in data:
            gps = data['gps']
            if 'speed' in gps: self.lbl_speed.setText(f"{gps['speed']:.2f} m/s")
            
            # 💡 [核心新增] 刷新子船解算速度
            if 'calculated_speed' in data:
                self.lbl_calc_speed.setText(f"({data['calculated_speed']:.2f})")
            if 'cog' in gps: self.lbl_cog.setText(f"{gps['cog']:.1f} °")
            if 'lat' in gps and 'lon' in gps: self.lbl_gps.setText(f"N: {gps['lat']:.6f} / E: {gps['lon']:.6f}")
        if 'gps_B' in data:
            gps_b = data['gps_B']
            if 'lat' in gps_b and 'lon' in gps_b and gps_b['lat'] != 0:
                self.lbl_gps_b.setText(f"N: {gps_b['lat']:.6f} / E: {gps_b['lon']:.6f}")
            else:
                self.lbl_gps_b.setText("N: -- / E: --")
        if 'imu' in data:
            imu = data['imu']
            if 'heading' in imu: self.lbl_heading.setText(f"{imu['heading']:.1f} °")
            if 'dual_heading' in imu: self.lbl_dual_heading.setText(f"{imu['dual_heading']:.1f} °")
            if 'imu_vel_x' in imu: self.lbl_roll.setText(f"{imu['imu_vel_x']:.2f} m/s")
            if 'yaw_rate' in imu: self.lbl_yaw_rate.setText(f"{imu['yaw_rate']:.1f} °/s")
            if 'sway_speed' in imu: self.lbl_sway_speed.setText(f"{imu['sway_speed']:.2f} m/s")
            if 'ekf_heading' in imu: self.lbl_sats.setText(f"{imu['ekf_heading']:.1f} °")
