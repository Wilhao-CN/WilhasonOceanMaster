# 文件路径: ui/widgets/mission_panel.py

import json
import math
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                             QListWidget, QLabel, QMessageBox, QListWidgetItem,
                             QInputDialog, QTabWidget, QProgressBar, QComboBox)
from PyQt5.QtCore import QObject, pyqtSlot, pyqtSignal, Qt

# ==========================================
# 💡 核心通信类：Python 端的接收天线
# ==========================================
class MapBridge(QObject):
    """
    Python 与 JS (地图) 之间的双向通信桥梁。
    """
    sig_path_received = pyqtSignal(list)
    sig_coord_identified = pyqtSignal(str)
    # 🚀 [新增] 专门用于校准的地图点击坐标信号
    sig_calib_point_clicked = pyqtSignal(float, float)
    # 🚀 新增：单点直达信号 (向外部发射)
    sig_point_go_requested = pyqtSignal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)

    @pyqtSlot(str)
    def receiveNewPath(self, path_json: str):
        try:
            coords = json.loads(path_json)
            self.sig_path_received.emit(coords)
        except Exception as e:
            print(f"❌ [地图桥梁] 解析路径数据失败: {e}")

    @pyqtSlot(float, float)
    def receiveClickCoord(self, lat, lon):
        # 💡 同时向两个方向分发：一个是原本的对数显示，一个是校准触发
        self.sig_calib_point_clicked.emit(lat, lon)
        log_msg = f"[地图识别] 纬度: {lat:.6f}, 经度: {lon:.6f}"
        self.sig_coord_identified.emit(log_msg)

    # 🚀 新增：接收 JS 调用并转发信号
    @pyqtSlot(float, float)
    def receivePointGoCoord(self, lat, lon):
        """接收地图传回的单点指令坐标"""
        self.sig_point_go_requested.emit(lat, lon)

    # 🔎 诊断用：把地图内部状态回传到 Python 终端。
    #    背景：孪生底图"一片空白"时，地图页里到底发生了什么从外面看不到
    #    （QtWebEngine 的 JS 报错不会自动出现在终端）。有了这条通路，
    #    启动时就能直接看到「Leaflet 有没有加载 / 容器多大 / 瓦片成没成」。
    @pyqtSlot(str)
    def reportMapState(self, payload_json: str):
        try:
            info = json.loads(payload_json)
        except Exception as e:                              # noqa: BLE001
            print(f"🔎 [地图诊断] 解析失败: {e}  原始: {payload_json[:200]}")
            return
        print("🔎 [地图诊断] " + json.dumps(info, ensure_ascii=False))


# ==========================================
# 任务规划面板 UI 组件 (V11.0 GPS校准集成版)
# ==========================================
class MissionPanelWidget(QWidget):
    """任务规划与 GPS 校准中心"""
    sig_start_edit = pyqtSignal()
    sig_clear_draft = pyqtSignal()
    sig_save_draft = pyqtSignal()
    sig_toggle_identify = pyqtSignal(bool)
    sig_preview_task = pyqtSignal(list)
    # 🚀 [新增] GPS校准完成，通知外部下发单片机
    sig_gps_calib_ready = pyqtSignal(int, float, float)

    def __init__(self, mission_manager, parent=None):
        super().__init__(parent)
        self.mission_manager = mission_manager  
        self.map_bridge = MapBridge() 
        
        # 🚀 [校准状态变量]
        self.last_display_coord = {"dock": None, "boat": None}  # 天线A显示坐标
        self.last_raw_B_coord = {"dock": None, "boat": None}    # 天线B原始传感器坐标
        self.waiting_for_calib_click = False
        
        self._init_ui()
        self._bind_logic()
        self.refresh_task_list()

    def _init_ui(self):
        self.main_layout = QVBoxLayout(self)
        
        # 💡 [核心重构] 使用 TabWidget 分割功能区
        self.tabs = QTabWidget()
        
        # --- 子页面 1: 📂 航线任务库 ---
        self.tab_mission = QWidget()
        self._setup_mission_tab()
        self.tabs.addTab(self.tab_mission, "📂 航线任务库")
        
        # --- 子页面 2: 🎯 GPS 全局校准 ---
        self.tab_calib = QWidget()
        self._setup_calib_tab()
        self.tabs.addTab(self.tab_calib, "🎯 GPS 静态校准")
        
        self.main_layout.addWidget(self.tabs)

    def _setup_mission_tab(self):
        """100% 还原原有的任务规划布局"""
        layout = QVBoxLayout(self.tab_mission)
        
        btn_layout = QHBoxLayout()
        self.btn_start = QPushButton("✏️ 开始画线")
        self.btn_identify = QPushButton("🔍 位置识别")
        self.btn_identify.setCheckable(True)

        # 🚀 新增：到点稳停按钮 (P2P 到达后自动定点保持)
        self.btn_steady_hold = QPushButton("📌 到点稳停")
        self.btn_steady_hold.setCheckable(True)
        self.btn_steady_hold.setToolTip("开启后在地图点一下，船坞 P2P 到达目标后自动定点保持，再次点击取消")

        # 🚀 新增：点选直达按钮
        self.btn_point_go = QPushButton("🎯 点选直达")
        self.btn_point_go.setToolTip("开启后，在地图点一下，船坞就直接走过去")

        self.btn_clear = QPushButton("🗑️ 清除草稿")
        self.btn_save = QPushButton("✅ 保存路径")
        
        btn_layout.addWidget(self.btn_start)
        btn_layout.addWidget(self.btn_identify)
        btn_layout.addWidget(self.btn_steady_hold) # 💡 到点稳停在位置识别右边
        btn_layout.addWidget(self.btn_point_go) # 💡 将按钮加入布局
        btn_layout.addWidget(self.btn_clear)
        btn_layout.addWidget(self.btn_save)
        layout.addLayout(btn_layout)

        layout.addWidget(QLabel("📂 已保存的任务路径库："))
        self.path_list = QListWidget()
        layout.addWidget(self.path_list)

        self.btn_delete_task = QPushButton("🗑️ 删除选中任务")
        self.btn_delete_task.setEnabled(False)
        self.btn_delete_task.setStyleSheet("color: #d32f2f;")
        layout.addWidget(self.btn_delete_task)

        assign_layout = QHBoxLayout()
        self.btn_assign_dock = QPushButton("🚀 指派给船坞")
        self.btn_assign_boat = QPushButton("🚀 指派给子船")
        self.btn_assign_dock.setEnabled(False) 
        self.btn_assign_boat.setEnabled(False)
        assign_layout.addWidget(self.btn_assign_dock)
        assign_layout.addWidget(self.btn_assign_boat)
        layout.addLayout(assign_layout)

    def _setup_calib_tab(self):
        """🚀 [快速校准界面] 采用一键对齐逻辑"""
        layout = QVBoxLayout(self.tab_calib)
        
        # 1. 目标选择
        layout.addWidget(QLabel("<b>1. 选择校准对象：</b>"))
        self.combo_target = QComboBox()
        self.combo_target.addItems(["1号端：船坞 (Dock)", "2号端：无人船 (Boat)", "🎯 同时校准两端 (船在坞内)"])
        layout.addWidget(self.combo_target)
        
        layout.addSpacing(15)
        
        # 2. 交互说明
        instruct = QLabel("<b>操作说明：</b>\n"
                          "1. 观察地图上船标位置。\n"
                          "2. 点击下方按钮进入校准模式。\n"
                          "3. 在地图上点击船只【实际所在】的位置。")
        instruct.setWordWrap(True)
        layout.addWidget(instruct)
        
        layout.addSpacing(20)
        
        # 3. 核心对齐按钮 (确保这个名字和下面 bind 里的对应)
        self.btn_quick_align = QPushButton("📍 此时在此打点校准")
        self.btn_quick_align.setFixedHeight(50)
        layout.addWidget(self.btn_quick_align)
        
        self.lbl_offset_status = QLabel("当前状态：等待校准")
        layout.addWidget(self.lbl_offset_status)
        
        layout.addStretch(1)
        
        # 4. 重置
        self.btn_reset_offset = QPushButton("♻️ 清除偏移量")
        layout.addWidget(self.btn_reset_offset)

    
    def _bind_logic(self):
        # --- 原有任务库绑定 (保持不变) ---
        self.btn_start.clicked.connect(self._on_start_edit_clicked)
        self.btn_identify.toggled.connect(self._on_identify_toggled)
        self.btn_steady_hold.toggled.connect(self._on_steady_hold_toggled)
        self.btn_clear.clicked.connect(self.sig_clear_draft.emit)
        self.btn_save.clicked.connect(self.sig_save_draft.emit)
        self.mission_manager.sig_missions_changed.connect(self.refresh_task_list)
        self.map_bridge.sig_path_received.connect(self.add_new_path)
        self.path_list.itemSelectionChanged.connect(self._on_item_selected)
        self.btn_delete_task.clicked.connect(self._on_delete_task_clicked)

        # --- 🚀 [修复点] 快速校准逻辑绑定 ---
        # 确保这里调用的是 btn_quick_align
        self.btn_quick_align.clicked.connect(self._prepare_quick_align) 
        self.map_bridge.sig_calib_point_clicked.connect(self._on_map_truth_received)
        self.btn_reset_offset.clicked.connect(self._reset_current_offset)

    # 🚀 新增：槽函数处理
    def _on_point_go_clicked(self):
        if self.btn_identify.isChecked(): 
            self.btn_identify.setChecked(False)
        # 触发该信号，通知 MainWindow 去调用 JS 的 enterPointGoMode()
        self.sig_start_edit.emit() # 复用这个信号来重置其它状态

   # ==========================================
    # 🛰️ GPS 快速对齐核心逻辑
    # ==========================================
    def feed_raw_gps(self, data: dict):
        """持续刷新缓存：记录天线A显示坐标 + 天线B原始坐标"""
        target_key = "dock" if data.get("id") == 0x01 else "boat"
        self.last_display_coord[target_key] = (data["gps"]["lat"], data["gps"]["lon"])
        # 天线B显示坐标 (已叠加旧偏移, 校准解算时会剥离还原)
        gps_b = data.get("gps_B", {})
        if gps_b.get("lat") and gps_b.get("lon"):
            self.last_raw_B_coord[target_key] = (gps_b["lat"], gps_b["lon"])

    def _start_sampling_process(self):
        """开启采样流程"""
        self.is_sampling = True
        self.sample_buffer = []
        self.progress_bar.setValue(0)
        self.btn_start_sample.setEnabled(False)
        self.btn_start_sample.setText("⏳ 正在采集样本...")
        self.btn_pick_map.setEnabled(False)

    def _prepare_for_map_click(self):
        """让地图进入识别模式，准备接收真值"""
        self.waiting_for_map_click = True
        # 借用原本的“位置识别”信号，让地图光标变样
        self.sig_toggle_identify.emit(True)
        QMessageBox.warning(self, "请点击地图", "现在请在地图上点击该船只目前的【真实准确位置】。")

    def _on_map_truth_received(self, lat, lon):
        """接收地图传回的“真值”，计算偏差并存入 Manager"""
        if not self.waiting_for_map_click or self.avg_raw_coord is None:
            return
            
        self.waiting_for_map_click = False
        self.sig_toggle_identify.emit(False) # 退出地图识别模式
        
        # 💡 核心算法：偏差 = 地图点(真) - 采样点(偏)
        lat_offset = lat - self.avg_raw_coord[0]
        lon_offset = lon - self.avg_raw_coord[1]
        
        # 存入持久化管理器
        selected_idx = self.combo_target.currentIndex()
        target_id = 0x01 if selected_idx == 0 else 0x02
        self.mission_manager.update_gps_offset(target_id, lat_offset, lon_offset)
        
        self.lbl_offset_info.setText(f"偏差已存: ΔLat:{lat_offset:.7f}, ΔLon:{lon_offset:.7f}")
        QMessageBox.information(self, "校准完成", f"校准偏置已应用并存入 missions.json！\n地图标点将立即自动修正。")

    def _reset_current_offset(self):
        """清空当前选择对象的A/B偏差量"""
        selected_idx = self.combo_target.currentIndex()

        if selected_idx == 2:
            targets = [(0x01, "dock"), (0x02, "boat")]
        elif selected_idx == 0:
            targets = [(0x01, "dock")]
        else:
            targets = [(0x02, "boat")]

        for target_id, name in targets:
            self.mission_manager.update_gps_offset(target_id, 0.0, 0.0, "A")
            self.mission_manager.update_gps_offset(target_id, 0.0, 0.0, "B")

        name_str = "两端" if len(targets) == 2 else targets[0][1]
        self.lbl_offset_info.setText(f"{name_str} 偏差已清零")
        self.btn_pick_map.setEnabled(False)
        self.progress_bar.setValue(0)
        QMessageBox.information(self, "重置成功", f"{name_str} A/B 天线偏差量均已恢复为 0。")

    # ==========================================
    # 📂 原有业务逻辑补充 (保持无损)
    # ==========================================
    def refresh_task_list(self):
        self.path_list.clear()
        missions = self.mission_manager.get_all_missions()
        for task_id, task in missions.items():
            display_text = f"{task.name} [{len(task.coords)} 个打点]"
            item = QListWidgetItem(display_text)
            item.setData(Qt.UserRole, task_id)
            self.path_list.addItem(item)

    def add_new_path(self, coords: list):
        if not coords: return
        default_name = f"新任务_{self.mission_manager._task_counter:02d}"
        name, ok = QInputDialog.getText(self, '保存路径', '请输入任务名称:', text=default_name)
        if ok and name.strip():
            task_name = name.strip()
            self.mission_manager.add_new_mission(coords, name=task_name)
            QMessageBox.information(self, "成功", f"任务 [{task_name}] 已存入库！")

    def get_selected_task_data(self):
        current_item = self.path_list.currentItem()
        if not current_item: return None
        task_id = current_item.data(Qt.UserRole)
        return self.mission_manager.get_mission_coords(task_id)

    def _on_identify_toggled(self, checked):
        if checked:
            self.btn_start.setEnabled(False)
            self.btn_identify.setText("🛑 停止识别")
        else:
            self.btn_start.setEnabled(True)
            self.btn_identify.setText("🔍 位置识别")
        self.sig_toggle_identify.emit(checked)

    def _on_steady_hold_toggled(self, checked: bool):
        if checked:
            self.btn_steady_hold.setText("📍 请点击地图...")
            self.btn_steady_hold.setStyleSheet("background-color: #ffcc80; font-weight: bold;")
            # 互斥：关闭位置识别
            if self.btn_identify.isChecked():
                self.btn_identify.setChecked(False)
        else:
            self.btn_steady_hold.setText("📌 到点稳停")
            self.btn_steady_hold.setStyleSheet("")

    def _on_start_edit_clicked(self):
        if self.btn_identify.isChecked(): self.btn_identify.setChecked(False)
        self.sig_start_edit.emit()

    def _on_item_selected(self):
        has_selection = self.path_list.currentItem() is not None
        self.btn_assign_dock.setEnabled(has_selection)
        self.btn_assign_boat.setEnabled(has_selection)
        self.btn_delete_task.setEnabled(has_selection)
        if has_selection:
            coords = self.get_selected_task_data()
            if coords: self.sig_preview_task.emit(coords)

    def _on_delete_task_clicked(self):
        current_item = self.path_list.currentItem()
        if not current_item: return
        task_id = current_item.data(Qt.UserRole)
        task_name = current_item.text()
        reply = QMessageBox.question(self, '确认删除', f"确定要永久删除 [{task_name}] 吗？",
                                   QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.mission_manager.delete_mission(task_id)
            self.sig_clear_draft.emit()

    def _prepare_quick_align(self):
        """进入地图点选模式"""
        # 1. 检查是否有数据进来
        selected_idx = self.combo_target.currentIndex()

        if selected_idx == 2:  # 🎯 同时校准两端
            missing = []
            if self.last_display_coord["dock"] is None:
                missing.append("船坞")
            if self.last_display_coord["boat"] is None:
                missing.append("无人船")
            if missing:
                QMessageBox.warning(self, "无效操作",
                    f"尚未收到{'、'.join(missing)}的GPS信号，无法同时校准！\n请确保两端均已上电并收到定位数据。")
                return
        else:
            target_key = "dock" if selected_idx == 0 else "boat"
            if self.last_display_coord[target_key] is None:
                QMessageBox.warning(self, "无效操作", f"尚未收到{target_key}的GPS信号，无法校准！")
                return

        # 2. 改变 UI 状态
        self.waiting_for_calib_click = True
        self.btn_quick_align.setText("⏳ 请在地图上点击真实位置...")
        self.btn_quick_align.setStyleSheet("background-color: #fff9c4; font-weight: bold;")
        
        # 3. 让地图鼠标变样 (进入识别模式)
        self.sig_toggle_identify.emit(True)

    def _on_map_truth_received(self, lat_truth, lon_truth):
        """核心解算：支持单端 / 双端同时校准（同一地图真值，各自独立解算）"""
        if not self.waiting_for_calib_click:
            return

        self.waiting_for_calib_click = False
        self.sig_toggle_identify.emit(False)
        self.btn_quick_align.setText("📍 此时在此打点校准")
        self.btn_quick_align.setStyleSheet("font-weight: bold; background-color: #e3f2fd;")

        selected_idx = self.combo_target.currentIndex()

        if selected_idx == 2:
            # --- 🎯 同时校准两端：同一个地图真值，独立解算 ---
            targets = [(0x01, "dock"), (0x02, "boat")]
        else:
            # --- 单端校准 ---
            target_id = 0x01 if selected_idx == 0 else 0x02
            target_key = "dock" if selected_idx == 0 else "boat"
            targets = [(target_id, target_key)]

        results_text = []
        for target_id, target_key in targets:
            # --- 天线A偏移（独立计算）---
            lat_display, lon_display = self.last_display_coord[target_key]
            old_off_a_lat, old_off_a_lon = self.mission_manager.get_gps_offset(target_id, "A")

            lat_raw_a = lat_display - old_off_a_lat
            lon_raw_a = lon_display - old_off_a_lon

            new_off_a_lat = lat_truth - lat_raw_a
            new_off_a_lon = lon_truth - lon_raw_a
            self.mission_manager.update_gps_offset(target_id, new_off_a_lat, new_off_a_lon, "A")

            # --- 天线B偏移（独立推算，船坞: 正西100cm / 无人船: 南83cm）---
            raw_b = self.last_raw_B_coord.get(target_key)
            b_msg = ""
            if raw_b is not None:
                old_off_b_lat, old_off_b_lon = self.mission_manager.get_gps_offset(target_id, "B")
                true_raw_b_lat = raw_b[0] - old_off_b_lat
                true_raw_b_lon = raw_b[1] - old_off_b_lon

                if target_key == "dock":
                    # 船坞天线B在A正西100cm
                    # 与固件保持一致: Dock_mcu/Src/cmd_process.c 与 Dock_mcu/MDK-ARM/gps_driver.c
                    cos_lat = math.cos(lat_truth * math.pi / 180.0)
                    b_truth_lat = lat_truth
                    b_truth_lon = lon_truth - 1.00 / (111319.5 * cos_lat)
                    b_dir_text = "正西100cm"
                else:
                    # 无人船天线B在A正南83cm
                    b_truth_lat = lat_truth - 0.83 / 111319.5
                    b_truth_lon = lon_truth
                    b_dir_text = "南83cm"

                new_off_b_lat = b_truth_lat - true_raw_b_lat
                new_off_b_lon = b_truth_lon - true_raw_b_lon
                self.mission_manager.update_gps_offset(target_id, new_off_b_lat, new_off_b_lon, "B")
                b_msg = (f"\n{target_key}天线B: ΔLat:{new_off_b_lat:.7f}, ΔLon:{new_off_b_lon:.7f}"
                         f" ({b_dir_text})")
            else:
                b_msg = f"\n{target_key}天线B: 无原始数据，未校准"

            label = "🛟 船坞" if target_key == "dock" else "🛥️ 无人船"
            results_text.append(
                f"{label}: 天线A ΔLat:{new_off_a_lat:.7f}, ΔLon:{new_off_a_lon:.7f}{b_msg}"
            )

            # 🚀 下发校准值到单片机，仅下发天线A的偏移
            self.sig_gps_calib_ready.emit(target_id, new_off_a_lat, new_off_a_lon)

        self.lbl_offset_status.setText(f"✅ 校准成功！\n" + "\n".join(results_text))
        QMessageBox.information(self, "校准完成",
            f"天线A/B 已完成对齐。\n地图上的图标将同时跳正。\n\n" + "\n".join(results_text))
