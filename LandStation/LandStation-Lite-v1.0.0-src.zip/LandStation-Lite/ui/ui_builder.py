# 文件路径: ui/ui_builder.py
import os
from PyQt5.QtCore import QUrl, Qt
from PyQt5.QtWebEngineWidgets import (QWebEngineView, QWebEngineSettings,
                                      QWebEnginePage)
from PyQt5.QtWebChannel import QWebChannel
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QLabel, QDockWidget, QSizePolicy,
                             QToolBar, QToolButton, QAction, QStatusBar, QStackedWidget, 
                             QComboBox, QMenu)

# ============================================================================
# 地图页控制台转发
# ============================================================================
# 🔎 为什么需要它：
#    地图是跑在 QtWebEngine 里的网页，它内部的 `console.log/error`
#    **默认不会出现在 Python 终端**。于是"地图一片空白"时，
#    从外面完全看不出发生了什么（Leaflet 没加载？瓦片全挂？容器尺寸为 0？）。
#    这里把网页控制台消息转发到终端，前缀 `🖥 [地图]`，一眼可辨。
#
#    ⚠️ 这是**只读诊断**，不改变任何地图/控制行为。
_MAP_CONSOLE_LEVELS = {0: "log", 1: "warn", 2: "error"}


class _MapConsolePage(QWebEnginePage):
    """把地图页的 JS 控制台消息打到 Python 终端。"""

    def javaScriptConsoleMessage(self, level, message, lineNumber, sourceID):
        lv = _MAP_CONSOLE_LEVELS.get(int(level), str(level))
        src = (str(sourceID) or "").rsplit("/", 1)[-1]
        print("🖥 [地图] %-5s %s:%s  %s" % (lv, src, lineNumber, message))


# 导入 UI 积木
from ui.widgets.side_panels import DockPanelWidget, BoatPanelWidget
from ui.widgets.driving_console import DrivingConsoleWidget
from ui.widgets.radar_view import RadarViewWidget 
from ui.widgets.mission_panel import MissionPanelWidget
from ui.dialogs.config_dialog import ConfigDialog
from ui.dialogs.thruster_limit_dialog import ThrusterLimitDialog 

class UIBuilder:
    """
    🎨 UI 组装工厂
    职责：只负责界面的实例化、排版和组装。不包含任何业务控制逻辑。
    """
    def __init__(self, main_window):
        self.mw = main_window  # 保存主窗口的引用

    def build_all(self):
        """一键组装所有界面"""
        self._init_dialogs()
        self._init_central_area()
        self._init_docks()
        self._init_menubar()
        self._init_toolbar()
        self._init_statusbar()

    def _init_dialogs(self):
        """实例化各类弹窗"""
        self.mw.config_dialog = ConfigDialog(self.mw)
        self.mw.dock_thruster_dialog = ThrusterLimitDialog(target_id=0x01, parent=self.mw)
        self.mw.boat_thruster_dialog = ThrusterLimitDialog(target_id=0x02, parent=self.mw)

    def _init_central_area(self):
        central_widget = QWidget()
        central_layout = QVBoxLayout(central_widget)
        central_layout.setContentsMargins(5, 5, 5, 5)

        self.mw.view_stack = QStackedWidget()
        self.mw.map_view = QWebEngineView()
        # 💡 核心：让地图成为“弹性填充物”
        self.mw.map_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # 🔴 [关键修复] 允许 file:// 页面读取**同目录下的本地资源**。
        #    地图页 map.html 是用 QUrl.fromLocalFile() 加载的（file:// 源），
        #    它需要用**相对路径**拉取同目录的：
        #        leaflet/leaflet.js   ← 没有 Leaflet，整张地图就是一片空白
        #        leaflet/leaflet.css
        #        twin_maps/*.png      ← 孪生底图图片
        #    QtWebEngine 默认**禁止** file:// 页面访问本地文件，于是：
        #        · Leaflet 加载失败 → 地图区域空白（本 bug 的表象）
        #        · 孪生底图 PNG 加载失败 → 即使 Leaflet 在，底图也出不来
        #    之前的代码从未设置过这个开关，所以一旦联网不畅（CDN 兜底失效）
        #    或 QtWebEngine 收紧策略，地图就会静默变成空白。
        #    注意：这不影响任何实船控制链路，只是让本地页面能读本地文件。
        _s = self.mw.map_view.settings()
        _s.setAttribute(QWebEngineSettings.LocalContentCanAccessFileUrls, True)
        _s.setAttribute(QWebEngineSettings.LocalContentCanAccessRemoteUrls, True)

        
        # 如果你希望地图启动时小一点，可以给它一个建议宽度
        self.mw.map_view.setBaseSize(600, 400)


        # WebView 通道与任务面板地图桥接 (需要 mw 提前实例化 mission_manager)
        self.mw.mission_panel = MissionPanelWidget(self.mw.mission_manager, self.mw)
        # 💡 核心：任务面板宽度锁死
        self.mw.mission_panel.setFixedWidth(450)
        self.mw.channel = QWebChannel()
        self.mw.channel.registerObject("pyBackend", self.mw.mission_panel.map_bridge)

        # 🔎 换成会转发控制台的地图页（必须在 setWebChannel 之前设置）。
        #    否则地图页里的报错在终端里完全看不见 —— 这正是"底图空白"
        #    这次排查困难的根本原因。
        #    用能力探测而不是直接调用：基线测试会把 QWebEngineView 换成桩，
        #    桩没有 setPage()；探测一下就不会把测试打崩。
        if hasattr(self.mw.map_view, "setPage"):
            self.mw.map_view.setPage(_MapConsolePage(self.mw.map_view))
        else:
            print("ℹ️ [地图] 当前 map_view 无 setPage()（测试桩），跳过控制台转发")
        self.mw.map_view.page().setWebChannel(self.mw.channel)

        # 加载本地 HTML
        current_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) # 注意层级
        html_path = os.path.join(current_dir, 'ui', 'map', 'map.html')

        # 🔎 [地图诊断] QtWebEngine 运行环境快照。
        #    这份输出用于区分"地图代码问题"与"Chromium 渲染进程起不来"。
        _webengine_proc = os.environ.get("QTWEBENGINEPROCESS_PATH", "")
        print("🗺 [地图] ---- 环境快照 ----")
        print("🗺 [地图] QTWEBENGINEPROCESS_PATH = %s" % (_webengine_proc or "(未设置)"))
        print("🗺 [地图]   该 exe 存在 = %s"
              % (os.path.isfile(_webengine_proc) if _webengine_proc else "(无路径)"))
        print("🗺 [地图] QTWEBENGINE_RESOURCES_PATH = %s"
              % os.environ.get("QTWEBENGINE_RESOURCES_PATH", "(未设置)"))
        print("🗺 [地图] QTWEBENGINE_CHROMIUM_FLAGS = %s"
              % os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "(未设置)"))
        print("🗺 [地图] QT_QPA_PLATFORM = %s"
              % os.environ.get("QT_QPA_PLATFORM", "(未设置)"))
        print("🗺 [地图] 准备加载: %s" % html_path)
        print("🗺 [地图] 文件存在: %s" % os.path.isfile(html_path))
        print("🗺 [地图] 页对象类型: %s" % type(self.mw.map_view.page()).__name__)

        # 🔎 先把回调接好，再 setUrl —— 避免任何竞态。
        #    loadFinished 是 Qt 信号，**只要页面被加载就一定触发**（成功或失败都会）。
        #    它若不出现，说明 QtWebEngine 的渲染进程根本没跑起来
        #    （页面从未被加载）——那是环境问题，不是地图代码问题。
        try:
            def _on_map_load_finished(ok):
                u = ""
                try:
                    u = self.mw.map_view.url().toString()
                except Exception:                            # noqa: BLE001
                    pass
                print("🗺 [地图] loadFinished(ok=%s)  url=%s" % (ok, u))
                if not ok:
                    print("🗺 [地图] ❌ 页面加载失败 —— 请检查 QtWebEngine 运行环境")
            self.mw.map_view.loadFinished.connect(_on_map_load_finished)

            # 🔎 渲染进程终止探针：这是"页面不加载"最直接的原因。
            try:
                def _on_render_terminated(status, code):
                    print("🗺 [地图] ❌❌ 渲染进程终止! status=%s exitCode=%s"
                          % (status, code))
                    print("🗺 [地图]     → 地图将保持空白。常见原因：")
                    print("🗺 [地图]       · GPU/沙箱冲突（可试 QTWEBENGINE_CHROMIUM_FLAGS="
                          "--disable-gpu --no-sandbox）")
                    print("🗺 [地图]       · QtWebEngineProcess.exe 无法启动/被杀软拦截")
                self.mw.map_view.page().renderProcessTerminated.connect(
                    _on_render_terminated)
                print("🗺 [地图] 已挂载渲染进程终止探针")
            except Exception as exc:                          # noqa: BLE001
                print("ℹ️ [地图] 无法挂 renderProcessTerminated: %s" % exc)
        except Exception as exc:                              # noqa: BLE001
            print("ℹ️ [地图] 无法连接 loadFinished（测试桩）: %s" % exc)

        self.mw.map_view.setUrl(QUrl.fromLocalFile(html_path))
        print("🗺 [地图] setUrl() 已调用")
        
        self.mw.view_stack.addWidget(self.mw.map_view) 

        self.mw.radar_view = RadarViewWidget()
        self.mw.view_stack.addWidget(self.mw.radar_view) 
        
        self.mw.sim_global_view = QLabel("等待 3D 数字孪生环境 (端口 5002) 画面接入...")
        self.mw.sim_global_view.setAlignment(Qt.AlignCenter)
        self.mw.sim_global_view.setStyleSheet("background-color: #1e1e1e; color: #00ff00; font-size: 20px; font-weight: bold;")
        self.mw.view_stack.addWidget(self.mw.sim_global_view) 

        self.mw.driving_console = DrivingConsoleWidget()

        central_layout.addWidget(self.mw.view_stack, stretch=1) 
        central_layout.addWidget(self.mw.driving_console, stretch=0) 
        self.mw.setCentralWidget(central_widget)

    def _init_docks(self):
        # 1. 船坞状态面板 (左侧)
        # self.mw.left_dock = QDockWidget("▼ 1号端：船坞 (可拖拽)", self.mw)
        # self.mw.left_dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        # self.mw.dock_panel = DockPanelWidget()

        # self.mw.dock_panel.setMinimumWidth(350) # 根据你的 UI 内容，350-400 比较合适


        # self.mw.left_dock.setWidget(self.mw.dock_panel)
        # self.mw.addDockWidget(Qt.LeftDockWidgetArea, self.mw.left_dock)
        # 1. 船坞状态面板 (左侧)
        self.mw.left_dock = QDockWidget("▼ 1号端：船坞 (锁定)", self.mw)
        # 💡 核心：只保留移动特性，去掉关闭和浮动功能，防止布局被破坏
        self.mw.left_dock.setFeatures(QDockWidget.DockWidgetMovable) 
        
        self.mw.dock_panel = DockPanelWidget()
        # 💡 核心：将 setMinimumWidth 升级为 setFixedWidth，锁死宽度
        self.mw.dock_panel.setFixedWidth(450) 
        
        self.mw.left_dock.setWidget(self.mw.dock_panel)
        self.mw.addDockWidget(Qt.LeftDockWidgetArea, self.mw.left_dock)

        # 2. 任务规划中心 (左侧 Tab)
        self.mw.mission_dock = QDockWidget("🧭 任务规划中心", self.mw)
        self.mw.mission_dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.mw.mission_dock.setWidget(self.mw.mission_panel)

        self.mw.mission_panel.setMinimumWidth(450) # 保持宽度一致


        self.mw.addDockWidget(Qt.LeftDockWidgetArea, self.mw.mission_dock)
        self.mw.tabifyDockWidget(self.mw.left_dock, self.mw.mission_dock)
        self.mw.left_dock.raise_()

        # # 3. 子船状态面板 (右侧)
        # self.mw.right_dock = QDockWidget("▼ 2号端：无人船 (可拖拽)", self.mw)
        # self.mw.right_dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        # self.mw.boat_panel = BoatPanelWidget()

        # self.mw.boat_panel.setMinimumWidth(350)


        # self.mw.right_dock.setWidget(self.mw.boat_panel)
        # self.mw.addDockWidget(Qt.RightDockWidgetArea, self.mw.right_dock)
        # 3. 子船状态面板 (右侧)
        self.mw.right_dock = QDockWidget("▼ 2号端：无人船 (锁定)", self.mw)
        # 💡 核心：限制特性，锁死宽度
        self.mw.right_dock.setFeatures(QDockWidget.DockWidgetMovable)
        
        self.mw.boat_panel = BoatPanelWidget()
        self.mw.boat_panel.setFixedWidth(450)
        
        self.mw.right_dock.setWidget(self.mw.boat_panel)
        self.mw.addDockWidget(Qt.RightDockWidgetArea, self.mw.right_dock)

    def _init_menubar(self):
        menubar = self.mw.menuBar()
        sys_menu = menubar.addMenu("系统(&S)")
        thrust_menu = menubar.addMenu("推进器配置...")
        
        action_config = QAction("⚙️ 全局算法与系统配置...", self.mw)
        action_config.triggered.connect(self.mw.config_dialog.show) 
        sys_menu.addAction(action_config)
    
        sys_menu.addSeparator()
        action_exit = QAction("❌ 退出上位机", self.mw)
        action_exit.triggered.connect(self.mw.close)
        sys_menu.addAction(action_exit)

        action_dock_thruster = QAction("⚙️ 船坞推进器配置 (1号端)", self.mw)
        action_dock_thruster.triggered.connect(self.mw.dock_thruster_dialog.show)
        thrust_menu.addAction(action_dock_thruster)

        action_boat_thruster = QAction("⚙️ 子船推进器配置 (2号端)", self.mw)
        action_boat_thruster.triggered.connect(self.mw.boat_thruster_dialog.show)
        thrust_menu.addAction(action_boat_thruster)

    def _init_toolbar(self):
        toolbar = QToolBar("全局控制")
        self.mw.addToolBar(toolbar)

        # 创建 Action 挂载到 mw，方便后续绑定信号
        self.mw.action_global_estop = QAction("🚨 全局紧急停机", self.mw)
        self.mw.action_global_estop.setToolTip("⚠️ 点击后强制关闭算法并切断所有动力，请谨慎使用")
        
        self.mw.action_sim_mode = QAction("🧪 仿真模拟模式", self.mw)
        self.mw.action_sim_mode.setCheckable(True)
        self.mw.action_sim_mode.setToolTip("开启后，指令将重定向至 UDP 网络而非物理串口")

        self.mw.action_show_basic_plot = QAction("📉 实时遥测曲线", self.mw)
        self.mw.action_show_basic_plot.setToolTip("查看航向、速度等基础传感器实时曲线")

        toolbar.addAction(self.mw.action_global_estop)
        toolbar.addSeparator()
        toolbar.addAction(self.mw.action_sim_mode)
        toolbar.addSeparator()

        # 🌐 [孪生底图] 一个控件同时表达"用哪个关卡"与"开/关"。
        #    列表项（关卡）由 MainWindow 按 scenes.json 动态填充（见 T6.1），
        #    因为那需要读取关卡配置；此处只建菜单与"关闭"项。
        self.mw.menu_twin_map = QMenu("🌐 孪生底图", self.mw)
        self.mw.action_twin_map_off = QAction("关闭孪生底图", self.mw)
        self.mw.action_twin_map_off.setCheckable(True)
        self.mw.action_twin_map_off.setToolTip("切回真实卫星地图")
        self.mw.menu_twin_map.addAction(self.mw.action_twin_map_off)
        toolbar.addAction(self.mw.menu_twin_map.menuAction())
        twin_btn = toolbar.widgetForAction(self.mw.menu_twin_map.menuAction())
        if twin_btn is not None:
            twin_btn.setPopupMode(QToolButton.InstantPopup)

        toolbar.addSeparator()
        toolbar.addAction(self.mw.action_show_basic_plot)

        toolbar.addSeparator() 
        toolbar.addWidget(QLabel("  🗺️ 视图模式："))
        self.mw.combo_view_mode = QComboBox()
        self.mw.combo_view_mode.addItems(["自动切换", "强制显示：宏观地图", "强制显示：微观雷达", "强制显示：3D 孪生视角"])
        toolbar.addWidget(self.mw.combo_view_mode)

    def _init_statusbar(self):
        self.mw.statusBar = QStatusBar()
        self.mw.setStatusBar(self.mw.statusBar)
        self.mw.statusBar.showMessage("系统就绪：UI界面构建完成。")

    def add_action_to_navigation_menu(self, action, menu_name):
        """将 Action 添加到指定的导航菜单中"""
        if menu_name == "姿态与导航":
            # 假设“姿态与导航”菜单在主窗口的菜单栏中
            nav_menu = self.mw.menuBar().findChild(QMenu, "姿态与导航")
            if nav_menu:
                nav_menu.addAction(action)
            else:
                print(f"❌ 未找到菜单: {menu_name}")
