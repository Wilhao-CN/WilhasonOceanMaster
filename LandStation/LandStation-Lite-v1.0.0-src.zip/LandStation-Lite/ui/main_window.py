# 文件路径: ui/main_window.py
import os
import math
import time
import json # 💡 [关键] 用于将坐标列表转为 JS 认识的字符串
import multiprocessing as mp
import socket
import subprocess
import pygame  # 🎮 手柄配对检测
from PyQt5.QtCore import QUrl, Qt, QTimer
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWebChannel import QWebChannel
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, 
                             QLabel, QDockWidget, QToolBar, QAction, QStatusBar,
                             QStackedWidget, QComboBox, QMessageBox)

# 1. 导入核心组件与工具
from core.Thread.zmq_video_thread import ZmqVideoThread
from core.protocol import USVProtocol        
from core.Managers.joystick_manager import JoystickManager
from core.data_logger import DataLogger      
from core.utils import CoordUtils
from core.Managers.mission_manager import MissionManager

# 2. 导入视觉系统
from vision.vision_manager import VisionManager
from vision.gui.vision_window import VisionWindow

# 3. 导入 UI 积木与遥测中心
from ui.widgets.oscilloscope.telemetry_center import TelemetryCenterWindow
from ui.widgets.oscilloscope.data_manager_panel import DataManagerPanel
from ui.ui_builder import UIBuilder

# 4. 导入三大管家与控制器
from controllers.dock_controller import DockController
from controllers.boat_controller import BoatController 
from core.Managers.control_dispatcher import ControlDispatcher

# 5. 🌐 孪生底图关卡配置（T4）—— 纯新增模块，读取失败时自动降级为空
from ui.map.twin_scene_config import TwinSceneConfig

# 版本号集中管理（工程根目录 _version.py），窗口标题 / 「关于」页共用同一来源
try:
    from _version import APP_TITLE
except Exception:  # noqa: BLE001
    APP_TITLE = "LandStation-Lite v1.0 · 双无人船协同控制上位机"


class USVGroundStation(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.resize(1400, 850)

        # ==========================================
        # 1. 核心状态变量初始化
        # ==========================================
        self.view_mode = "Auto"   
        self.dock_gps = None
        self.boat_gps = None
        self.dock_mid_gps = None   # 双天线中点 (距离显示/算法使用)
        self.boat_mid_gps = None   # 双天线中点 (距离显示/算法使用)
        self.boat_heading = None
        self.boat_hw_state = [0.0, 0.0] # 记录子船手柄视觉反馈状态
        self._last_map_update_dock = 0   # 船坞地图更新时间戳(ms)
        self._last_map_update_boat = 0   # 子船地图更新时间戳(ms)

        # ==========================================
        # 1b. 🌐 孪生底图视图状态（T6）
        #     【改造纪律】以下全部为"纯新增"，默认值使实船路径行为不变：
        #     twin_view_active=False ⇒ T7 范围校验与 T8 守卫都不生效。
        # ==========================================
        self.twin_view_active = False     # 是否正在显示孪生底图
        self._twin_bounds = None          # 当前关卡配置 dict（供 T7 范围校验）
        self._twin_current_scene = None   # 当前关卡名
        self._twin_scene_actions = {}     # {scene: QAction} 用于"打勾=当前关卡"
        self._twin_tx_active = False      # [T11] 最近是否真的发出过下行帧
        self._twin_tx_timer = None        # [T11] 把它落回 False 的定时器
        self._twin_tx_ts = 0.0            # [T11] 最近一次下发的时间戳
        
        # 视觉窗口实例容器
        self.vision_windows = {"dock": None, "boat": None}

        # 🎯 NOF 视觉状态：船坞摄像头 YOLO 检出 NOF（跟踪器确认 track_id）后用于居中伺服
        self._nof_consecutive_count = 0 # 🎯 连续识别到 NOF 的帧数（任意检出，用于 UI 指标）
        self._nof_confirmed_consecutive = 0  # 🎯 跟踪器确认(track_id)的连续帧数
        self.nof_area_threshold = 0.30  # 画框面积占比阈值（暂仅诊断参考）
        self.nof_label_keyword = "NOF"  # 目标类别名关键字
        self.nof_required_frames = 5    # 🎯 视觉确认所需的 NOF 连续帧数
        self.nof_dist_threshold = 3.0   # 🎯 距离上限（米），用于 UI 指标
        self.nof_dist_hold_seconds = 2.0  # 🎯 距离 < 阈值需持续的时间（秒）
        self._last_nof_log_time = 0.0   # NOF 检出状态节流日志时间戳

        # ==========================================
        # 2. 实例化全局数据总线与管家 (先于 UI 初始化)
        # ==========================================
        self.data_logger = DataLogger(self)
        # 🌐 孪生关卡配置（T4）：读取失败时 levels 为空，菜单会显示"无可用关卡"，
        #    不影响任何实船功能。
        self.twin_scene_config = TwinSceneConfig()
        self.data_manager = DataManagerPanel(self)
        self.mission_manager = MissionManager(self)
        self.vision_manager = VisionManager(self)
        self.joystick_manager = JoystickManager()

        # ==========================================
        # 3. 实例化独立弹窗与示波器
        # ==========================================
        self.telemetry_center = TelemetryCenterWindow()

        # ==========================================
        # 4. 呼叫 UI 工厂，一键拼装界面壳子
        # ==========================================
        # 执行完毕后，self 身上就挂载了 docking_panel, mission_panel 等所有积木
        self.ui_builder = UIBuilder(self)
        self.ui_builder.build_all()
        #☁️[新增] 云端孪生一键直连按钮
        self.action_remote_sim = QAction("🚀 一键启动数字孪生", self)
        self.action_remote_sim.setCheckable(True)
        self.action_remote_sim.triggered.connect(self._on_remote_sim_toggled)

        # 🎮 [新增] 手柄配对按钮（可切换：按下进入配对，弹起取消配对）
        self.action_joystick_pair = QAction("🎮 手柄配对", self)
        self.action_joystick_pair.setCheckable(True)
        self.action_joystick_pair.triggered.connect(self._on_joystick_pair_toggled)

        # ⚠️ [陷阱 1 修复] 这里**故意不再用任何菜单当插入锚点**。
        #
        # 原实现是「遍历工具栏找到 menu_mppi → insertAction 到它后面」。
        # 这不报错、不打日志，但一旦 menu_mppi 不存在（例如精简版删掉 MPPI），
        # 锚点变量恒为 None ⇒ 那个 if 永不成立 ⇒ 下面这些按钮**静默消失**，
        # 而"能启动"这种测试根本查不出来。
        #
        # ⇒ 改为直接往第一个工具栏追加。与任何菜单的存在性解耦。
        #    `_baseline/ui_assert.py` 会断言这些 action 的 associatedWidgets 非空。
        toolbars = self.findChildren(QToolBar)
        if toolbars:
            target_toolbar = toolbars[0]
            target_toolbar.addAction(self.action_remote_sim)     # 🚀 一键启动数字孪生
            target_toolbar.addAction(self.action_joystick_pair)  # 🎮 手柄配对
        # ==========================================
        # 5. 初始化核心控制器并连接仲裁器
        # ==========================================
        self._init_controllers()

        # 💡 [解耦核心] 实例化并启动控制仲裁器 (节拍器)
        self.control_dispatcher = ControlDispatcher(
            self.joystick_manager, 
            self.dock_controller, 
            self.boat_controller, 
            self.driving_console, 
            self.dock_panel, 
            parent=self
        )
        self.control_dispatcher.start()

        # 🎮 虚拟摇杆 → 控制节拍器缓存（隔离 PWM 回写，防止鼠标操控衰减）
        self.driving_console.sig_boat_joy_moved.connect(self.control_dispatcher.set_virtual_boat)
        self.driving_console.sig_dock_joy_moved.connect(self.control_dispatcher.set_virtual_dock)

        # ==========================================
        # 6. 其它外围线程与信号绑定
        # ==========================================
        # 3D 数字孪生拉流线程
        self.global_sim_thread = ZmqVideoThread(self)
        self.global_sim_thread.sig_frame_ready.connect(self._update_global_sim_frame)

        # 本机 Unity 数字孪生进程。仅结束由本次地面站启动的进程，避免误杀手动实例。
        self.local_sim_process = None
        self._owns_local_sim_process = False

        
        
        # 统一执行所有信号绑定
        self._bind_toolbar_signals()
        self._bind_joystick_signals()
        self._bind_mission_signals()
        self._setup_vision_integration()
        
        self.dock_controller.brain.sig_data_parsed.connect(self.mission_panel.feed_raw_gps)
        self.boat_controller.brain.sig_data_parsed.connect(self.mission_panel.feed_raw_gps)
        # 🏠 [一键返航] 地图标记信号
        self.dock_controller.brain.sig_return_home.connect(self._on_return_home_started)
        self.boat_controller.brain.sig_return_home.connect(self._on_boat_return_home_started)
        # 🚀 [新增] GPS校准下发 信号桥接
        self.mission_panel.sig_gps_calib_ready.connect(self.dock_controller._handle_gps_calib)
        self.mission_panel.sig_gps_calib_ready.connect(self.boat_controller._handle_gps_calib)

    def _init_controllers(self):
        """
        初始化核心控制器，并完成与数据总线、任务管理器的连线
        """
        # 1. 实例化控制器 (💡 注入 mission_manager 以支持 GPS 全局校准)
        self.boat_controller = BoatController(
            self.boat_panel, 
            self.driving_console, 
            self.config_dialog,
            self.mission_manager  # 🚀 [核心新增] 注入任务管理器
        )
        self.boat_controller.setParent(self)
        
        self.dock_controller = DockController(
            self.dock_panel, 
            self.driving_console, 
            self.config_dialog,
            self.mission_manager  # 🚀 [核心新增] 注入任务管理器
        )
        self.dock_controller.setParent(self)
        # 找到类似这部分的代码并修改：
# 5. 数据汇流落盘与遥测
        self.dock_controller.brain.sig_data_parsed.connect(self._log_dock_telemetry) # 修改这里
        self.boat_controller.brain.sig_data_parsed.connect(self._log_boat_telemetry) # 修改这里

        # 2. 监听紧急抢占与配置信号
        self.boat_controller.sig_manual_override.connect(self._handle_manual_override)
        self.dock_controller.sig_manual_override.connect(self._handle_manual_override)
        self.dock_controller.sig_cooperative_hold_fault.connect(
            self._handle_cooperative_hold_fault
        )

        self.config_dialog.sig_comm_mode_changed.connect(self._on_config_sim_mode_changed)
        self.config_dialog.sig_imu_deadband_req.connect(self._on_imu_deadband_apply)

        # 4. 数据流处理 (喂给全局地图)
        self.dock_controller.brain.sig_data_parsed.connect(self.update_dock_full_state)
        self.boat_controller.brain.sig_data_parsed.connect(self.update_boat_full_state)

        # 5. 数据汇流落盘与遥测
# 5. 数据汇流落盘与遥测 (修改为先经过主窗口拦截，贴上距离标签)
        self.dock_controller.brain.sig_data_parsed.connect(self._log_dock_telemetry)
        self.boat_controller.brain.sig_data_parsed.connect(self._log_boat_telemetry)
        # 📏 将 IMU 数据推送到视觉进程，供障碍物距离估计的光流补偿使用
        self.dock_controller.brain.sig_data_parsed.connect(self._send_imu_to_vision_dock)
        self.boat_controller.brain.sig_data_parsed.connect(self._send_imu_to_vision_boat)
        
        # 1. 连接通用遥测中心
        self.data_logger.sig_telemetry_broadcast.connect(self.telemetry_center.feed_data)

        # 遥测中心配置反向同步给记录仪
        self.telemetry_center.sig_whitelist_update.connect(self.data_logger.update_whitelist)
        # [V4.1 保存/显示分离] 保存时自动应用全字段白名单，不依赖 UI 勾选
        self.telemetry_center.sig_save_req.connect(self._on_save_toggled)

        # 🌐 [T11] 互锁提示：本机是否正在下发。
        #    sig_pwm_actual 在 send_control_ratios() 内发射，而后者是
        #    【所有】下行控制（手动摇杆 / 自动 P2P / 任务）的唯一出口，
        #    因此这里能无遗漏地捕获"刚刚真的发了一帧"。
        #    【改造纪律】只读信号，完全不改动控制链；
        #    _refresh_twin_status_hint 在非孪生视图下第一行就返回，
        #    故对实船状态栏零影响。
        self.boat_controller.comm.sig_pwm_actual.connect(
            lambda *_: self._note_twin_tx()
        )
        self.dock_controller.comm.sig_pwm_actual.connect(
            lambda *_: self._note_twin_tx()
        )

    # ==========================================
    def _on_save_toggled(self, active: bool):
        """
        [V4.1 保存/显示分离] 保存按钮回调。
        存盘前自动拉取全字段白名单（data_map 全部字段），
        确保 CSV 数据完整，与示波器显示勾选完全解耦。
        """
        if active:
            full_config = self.telemetry_center.get_full_field_config()
            self.data_logger.update_whitelist(full_config)
            self.data_logger.start_logging()
        else:
            self.data_logger.stop_logging()

    # 👇 把这两个函数随便放在 _init_controllers 下方
    def _log_dock_telemetry(self, data):
        """拦截船坞生肉数据，贴上实时的两船距离后再存盘和画图"""
        if hasattr(self, 'current_dist'):
            data['dist'] = self.current_dist
        self.data_logger.log_telemetry(data)

    def _log_boat_telemetry(self, data):
        """拦截子船生肉数据，贴上实时的两船距离后再存盘和画图"""
        if hasattr(self, 'current_dist'):
            data['dist'] = self.current_dist
        self.data_logger.log_telemetry(data)
    # ==========================================
    # 7. 信号绑定专区
    # ==========================================
    def _bind_toolbar_signals(self):
        """统一绑定工具栏信号"""
        self.action_global_estop.triggered.connect(self._on_global_estop_clicked)

        self.action_sim_mode.triggered.connect(self._on_sim_mode_action_triggered)
        self.action_show_basic_plot.triggered.connect(self._on_show_telemetry_center)
        self.combo_view_mode.currentIndexChanged.connect(self._on_view_mode_changed)

        # 🌐 [T5/T6.1] 孪生底图菜单：按 scenes.json 动态生成关卡项
        self._build_twin_scene_actions()
        self.action_twin_map_off.triggered.connect(self._on_twin_map_off)

    # ==========================================
    # 🌐 孪生底图（T5 / T6 / T6.1）—— 纯新增
    # ==========================================

    def _build_twin_scene_actions(self):
        """把每个关卡做成一个可打勾的菜单项，插到「关闭孪生底图」之前。

        用 partial 绑定关卡名，避免 lambda 闭包捕获循环变量导致"点哪个都是最后一关"。
        """
        from functools import partial

        menu = getattr(self, "menu_twin_map", None)
        if menu is None:
            return                      # UIBuilder 未建菜单（理论上不会发生）

        self._twin_scene_actions = {}
        for scene in self.twin_scene_config.names():
            act = QAction(scene, self)
            act.setCheckable(True)
            act.setToolTip(self._twin_tooltip_for(scene))
            act.triggered.connect(partial(self._on_twin_map_selected, scene))
            menu.insertAction(self.action_twin_map_off, act)
            self._twin_scene_actions[scene] = act

        if not self._twin_scene_actions:
            # 无可用关卡：给出明确提示而不是静默空白菜单
            empty = QAction("（无可用关卡：请检查 scenes.json）", self)
            empty.setEnabled(False)
            menu.insertAction(self.action_twin_map_off, empty)
            reason = self.twin_scene_config.error or "未知原因"
            menu.setToolTip(f"孪生底图不可用：{reason}")
            print(f"[TwinMap] 无可用关卡：{reason}")

        self._refresh_twin_menu_checks()

    def _twin_tooltip_for(self, scene: str) -> str:
        cfg = self.twin_scene_config
        lv = cfg.get(scene) or {}
        shape = cfg.bounds_shape(scene)
        r = cfg.navigable_radius(scene)
        shape_txt = "圆形" if shape == "circle" else "方形"
        ext = lv.get("sceneExtentMeters")
        parts = [f"切换到孪生底图：{scene}"]
        if ext:
            parts.append(f"底图范围 {float(ext):g} × {float(ext):g} m")
        if r:
            parts.append(f"{shape_txt}可航半径 {float(r):g} m")
        parts.append("切换后打点/指派将下发给数字孪生")
        return "\n".join(parts)

    def _refresh_twin_menu_checks(self):
        """打勾 = 当前关卡；同时维护"关闭"项的勾选状态。"""
        for scene, act in getattr(self, "_twin_scene_actions", {}).items():
            act.setChecked(scene == self._twin_current_scene)
        off = getattr(self, "action_twin_map_off", None)
        if off is not None:
            off.setChecked(not self.twin_view_active)

    def _on_twin_map_selected(self, scene: str):
        """菜单里选中某一关卡 → 切到该关卡的孪生底图。"""
        cfg = self.twin_scene_config.get(scene)
        if cfg is None:
            QMessageBox.warning(
                self, "缺少配置",
                f"未找到关卡 {scene} 的四角配置。\n"
                f"请检查 ui/map/twin_maps/scenes.json。")
            self._refresh_twin_menu_checks()
            return

        bounds = self.twin_scene_config.bounds_for_js(scene)
        image = self.twin_scene_config.image_for(scene)
        if not bounds or not image:
            QMessageBox.warning(self, "配置不完整",
                                f"关卡 {scene} 缺少四角或底图文件名。")
            self._refresh_twin_menu_checks()
            return

        self.twin_view_active = True
        self._twin_bounds = cfg
        self._twin_current_scene = scene

        # 防 switch_view_automatically 抢视图（与既有 view_mode 机制一致）
        self.view_mode = "Manual"
        self.view_stack.setCurrentIndex(0)

        js = ("showTwinMap(%s, %s, %s, %d);" % (
            json.dumps(scene),
            json.dumps(image),
            json.dumps(bounds),
            self.twin_scene_config.image_px(scene),
        ))
        self.map_view.page().runJavaScript(js)

        self._refresh_twin_menu_checks()
        self._refresh_twin_status_hint()
        self.statusBar.showMessage(
            f"🌐 已切到孪生底图：{self.twin_scene_config.describe(scene)}", 4000)
        # 临时提示 4 s 后会被 Qt 清空，届时恢复常驻的"关卡 + 下发状态"提示
        QTimer.singleShot(4200, self._refresh_twin_status_hint)

    def _on_twin_map_off(self):
        """菜单里选「关闭孪生底图」→ 回真实地图。"""
        self.twin_view_active = False
        self._twin_bounds = None
        self._twin_current_scene = None
        try:
            self.map_view.page().runJavaScript("showRealMap();")
        except Exception as exc:                      # noqa: BLE001 - 显示层，不致命
            print(f"[TwinMap] 切回真实地图失败: {exc}")
        self._refresh_twin_menu_checks()
        self._refresh_twin_status_hint()
        self.statusBar.showMessage("🌐 已切回真实地图", 3000)

    # ------------------------------------------------------------------ T7

    def _reject_if_outside_twin_bounds(self, lat, lon) -> bool:
        """孪生视图激活时，拒绝落在底图/可航范围外的点。

        返回 True 表示"已拒绝，调用方应立即 return"。
        【改造纪律】实船模式（twin_view_active=False）**第一行就返回 False**，
        因此对实船点击路径零影响。
        """
        if not self.twin_view_active or not self._twin_bounds:
            return False                          # 实船模式：完全不干预
        if lat is None or lon is None:
            return False

        b = self._twin_bounds
        try:
            lat = float(lat)
            lon = float(lon)
        except (TypeError, ValueError):
            return False

        scene = self._twin_current_scene or "孪生"
        shape = self.twin_scene_config.bounds_shape(scene)
        r = self.twin_scene_config.navigable_radius(scene)
        origin = self.twin_scene_config.origin(scene)

        # ─────────────────────────────────────────────────────────────
        # 【v5 口径】判据只有一条：**点落在底图范围外才拒绝**。
        #   ✅ 保留：|x| > 半边长 或 |z| > 半边长 → 拒绝
        #   ❌ 已删除："点在陆地上则拒绝" —— 用户决策：
        #      操作员在上位机有全局急停，允许把点打到岸上或暂时够不到的位置，
        #      不需要地图层拦截。L1 底图内**不做**水面/陆地划分。
        #   ⚠️ L1 图内四角与湖岸之间确实是陆地，可航水域只有中间约半径 22 m 的圆
        #      —— 这是**既定设计**，不是配准错误。
        # ─────────────────────────────────────────────────────────────

        # 分支 A：圆形判据（**当前两关都用 square，此分支保留供将来场景配置**）
        if shape == "circle" and r and origin:
            d_north = (lat - origin[0]) * 111320.0
            d_east = (lon - origin[1]) * 111320.0 * math.cos(math.radians(origin[0]))
            if math.hypot(d_north, d_east) > r:
                self._warn_twin_out_of_range(
                    f"该点超出孪生场景范围（圆形，半径 {r:g} m），已拒绝下发。")
                return True
            return False

        # 分支 B：方形判据（L1 ±50 / L2 ±200）—— 只看是否落在底图范围内
        try:
            if not (float(b["bottomLat"]) <= lat <= float(b["topLat"])
                    and float(b["leftLon"]) <= lon <= float(b["rightLon"])):
                self._warn_twin_out_of_range(
                    "该点落在孪生底图之外，已拒绝下发。")
                return True
            return False
        except (KeyError, TypeError, ValueError):
            pass

        # 最后回退：用半径
        if r and origin:
            d_north = (lat - origin[0]) * 111320.0
            d_east = (lon - origin[1]) * 111320.0 * math.cos(math.radians(origin[0]))
            if math.hypot(d_north, d_east) > r:
                self._warn_twin_out_of_range(
                    f"该点超出孪生场景可航范围（半径 {r:g} m），已拒绝下发。")
                return True
        return False

    def _warn_twin_out_of_range(self, text: str):
        """越界提示：状态栏 + 弹窗（弹窗只在孪生视图下出现）。"""
        self.statusBar.showMessage("⚠️ " + text.replace("\n", " "), 5000)
        QMessageBox.warning(self, "超出范围", text)

    def _reject_twin_points(self, coords) -> bool:
        """对一串航点逐点校验；任一点越界即整体拒绝。

        返回 True 表示"已拒绝"。coords 支持 [(lat,lon), ...] 或
        [{"lat":..,"lon":..}] 或 [[lat,lon], ...]。
        """
        if not self.twin_view_active or not self._twin_bounds:
            return False
        if coords is None:
            return False

        for item in coords:
            lat = lon = None
            try:
                if isinstance(item, dict):
                    lat, lon = item.get("lat"), item.get("lon")
                elif isinstance(item, (list, tuple)) and len(item) >= 2:
                    lat, lon = item[0], item[1]
                else:
                    lat, lon = getattr(item, "lat", None), getattr(item, "lon", None)
            except (TypeError, ValueError):
                continue
            if self._reject_if_outside_twin_bounds(lat, lon):
                return True
        return False

    # ------------------------------------------------------------------ T8

    def _twin_is_running(self) -> bool:
        """孪生当前是否在跑（本地或远端仿真）。"""
        try:
            if getattr(self, "local_sim_process", None) is not None:
                if self.local_sim_process.poll() is None:
                    return True
        except Exception:                             # noqa: BLE001
            pass
        act = getattr(self, "action_remote_sim", None)
        try:
            return bool(act is not None and act.isChecked())
        except Exception:                             # noqa: BLE001
            return False

    def _guard_twin_control(self) -> bool:
        """[T8] 返回 True 表示"已拦截"。

        背景（已实测）：底图切换是**纯显示**，不构成控制门禁 ——
        真实地图上打点同样会下发给孪生。用户决策：不做"在真实地图上控制孪生"。
        """
        if self.twin_view_active:
            return False                              # 孪生视图：放行
        if self._twin_is_running():                   # 真实地图 + 孪生在跑 → 拦截
            self.statusBar.showMessage(
                "⚠️ 孪生正在运行，但当前显示真实地图 —— 已阻止下发", 5000)
            QMessageBox.warning(
                self, "无法下发",
                "当前显示的是真实地图，而孪生正在运行。\n\n"
                "如需控制孪生，请先切换到「🌐 孪生底图」。")
            return True
        return False                                  # 实船模式：放行

    def _guard_twin_dispatch(self) -> bool:
        """T7 + T8 的统一前置守卫；返回 True 表示应中止本次下发。

        【重要】实船模式下这两道守卫都直接放行（第一行即返回），
        故对实船路径**零影响**。
        """
        if self._guard_twin_control():
            return True
        return False

    # ----------------------------------------------------------------- T11

    def _note_twin_tx(self):
        """[T11] 记录"刚刚发出了一帧下行指令"。

        本方法在下行帧发出时被调用（最密 5 Hz），因此：
        * 定时器**只创建一次**后反复 start()，避免每帧新建 QObject；
        * 仅在状态由"未下发"翻转为"下发中"时刷新状态栏，
          避免 5 Hz 刷屏。
        """
        self._twin_tx_ts = time.perf_counter()

        if not self._twin_tx_active:
            self._twin_tx_active = True
            self._refresh_twin_status_hint()          # 状态翻转才刷新

        if self._twin_tx_timer is None:
            timer = QTimer(self)
            timer.setSingleShot(True)
            # 0.6 s 略大于常用下行周期(200 ms)：持续发帧时会被不断续期，
            # 一旦停发约 0.6 s 后自动落回"本机未下发"。
            timer.timeout.connect(self._on_twin_tx_idle)
            self._twin_tx_timer = timer
        self._twin_tx_timer.start(600)

    def _on_twin_tx_idle(self):
        self._twin_tx_active = False
        self._refresh_twin_status_hint()

    def _refresh_twin_status_hint(self):
        """[T11] 状态栏显示"当前关卡 + 本机是否在下发"。

        【文案纪律】只陈述我方**确知**的事实：
          ✅ "本机正在下发中" / "本机未下发"
          ❌ 不写"Unity 内部链路正在跑" —— 我方无法确知，写了就是猜测。
        """
        if not self.twin_view_active:
            return                                    # 实船模式：不显示
        state = "本机正在下发中" if self._twin_tx_active else "本机未下发"
        scene = self._twin_current_scene or "(未选关卡)"
        self.statusBar.showMessage(f"🌐 孪生底图：{scene} ｜ {state}")

    def _bind_joystick_signals(self):
        """统一绑定手柄信号"""
        # 1. 核心坐标与按键微调信号连接 (仅做视觉反馈，不发指令)
        self.joystick_manager.joystick_axis_moved.connect(self._handle_hardware_axis)
        self.joystick_manager.dpad_req.connect(self._handle_hardware_dpad)

        # 2. 绑定初始化与急停请求
        self.joystick_manager.init_req.connect(self._handle_hardware_init)
        self.joystick_manager.estop_req.connect(self._on_global_estop_clicked)

        # 3. 状态提示
        self.joystick_manager.status_msg.connect(lambda msg: self.statusBar.showMessage(msg, 3000))

        # 🎮 [新增] 手柄配对信号
        self.joystick_manager.pairing_progress.connect(self._on_pairing_progress)
        self.joystick_manager.pairing_complete.connect(self._on_pairing_complete)

        # 4. 启动底层监控线程 (开始收发 USB 数据)
        self.joystick_manager.start()

    def _bind_mission_signals(self):
        """将任务面板的点击动作，翻译成让地图执行的 JS 脚本"""
        # 1. 现有的路径规划逻辑
        self.mission_panel.sig_start_edit.connect(
            lambda: self.map_view.page().runJavaScript("enterEditMode();")
        )

        # 🚀 新增 1：点击“点选直达”按钮时，通知地图切换模式
        # 注意：这里我们直接调用 JS 函数
        self.mission_panel.btn_point_go.clicked.connect(
            lambda: self.map_view.page().runJavaScript("enterPointGoMode();")
        )

        # 🚀 新增：到点稳停按钮逻辑
        self.mission_panel.btn_steady_hold.toggled.connect(self._on_steady_hold_toggled)

        self.mission_panel.sig_clear_draft.connect(
            lambda: self.map_view.page().runJavaScript("clearDraft();")
        )

        self.mission_panel.sig_save_draft.connect(
            lambda: self.map_view.page().runJavaScript("saveDraftPath();")
        )

        # --- 2. 🚀 新增 2：响应地图传回的单点直达坐标 ---
        self.mission_panel.map_bridge.sig_point_go_requested.connect(self._handle_point_go_logic)

        # 🚀 [新增] 监听任务列表点击，实现地图同步显示航线
        self.mission_panel.sig_preview_task.connect(self._on_mission_preview_requested)

        # 2. 位置识别模式切换 (互斥逻辑在 Panel 内部已处理)
        self.mission_panel.sig_toggle_identify.connect(self._handle_map_identify_toggle)
        
        # 3. 指派按钮逻辑连接
        self.mission_panel.btn_assign_dock.clicked.connect(self._on_assign_dock_clicked)
        self.mission_panel.btn_assign_boat.clicked.connect(self._on_assign_boat_clicked)
        
        # 4. 坐标识别结果回传日志
        self.mission_panel.map_bridge.sig_coord_identified.connect(
            lambda msg: self.dock_controller.panel.comm_panel.append_log(msg)
        )
        self.mission_panel.map_bridge.sig_coord_identified.connect(
            lambda msg: self.boat_controller.panel.comm_panel.append_log(msg)
        )

    # ==========================================
    # 8. 视觉与数字孪生集成专区
    # ==========================================
    def _setup_vision_integration(self):
        """将视频线程与视觉系统对接"""
        # 1. 物理挂载：把视频流的“水管”接到共享内存上
        self.vision_manager.link_video_threads(
            self.dock_controller.video_thread,
            self.boat_controller.video_thread
        )
        # 数字孪生模式使用独立 TCP 视频线程；同样挂到视觉共享内存，
        # 让专业视觉窗口及算法插件能读取当前仿真画面。
        self.vision_manager.link_video_threads(
            self.dock_controller.comm.sim_video_thread,
            self.boat_controller.comm.sim_video_thread,
        )

        # 2. 信号分拣：监听 AI 结果并分发
        self.vision_manager.sig_vision_results.connect(self._dispatch_vision_data)

        # 3. 劫持双击事件：覆盖掉原有的简单弹窗逻辑
        self.dock_panel.video_label.sig_double_clicked.disconnect() 
        self.dock_panel.video_label.sig_double_clicked.connect(
            lambda: self._open_vision_window("dock", "1号端：船坞专业视觉中心")
        )

        self.boat_panel.video_label.sig_double_clicked.disconnect()
        self.boat_panel.video_label.sig_double_clicked.connect(
            lambda: self._open_vision_window("boat", "2号端：子船专业视觉中心")
        )

    def _open_vision_window(self, target_id: str, title: str):
        """弹出视觉任务专业窗口 (优化版：动态尺寸适配)"""
        if self.vision_windows[target_id] is None:
            # 1. 先确定视频源，用当前链路的原生比例初始化视频区：
            #    实机 UDP 链路是 640×480 (4:3)；数字孪生 Unity 链路保持 16:9 不变。
            controller = (
                self.dock_controller if target_id == "dock"
                else self.boat_controller
            )
            v_thread = controller.comm.active_video_thread
            is_sim_link = bool(getattr(controller.comm, "is_simulation", False))
            win = VisionWindow(
                target_id,
                title,
                video_aspect=(16, 9) if is_sim_link else (4, 3),
            )
            win.add_algo_toggle("yolo_v8", "🚀 YOLO 目标检测")
            win.add_algo_toggle("aruco_dock", "🎯 ArUco 靠泊测距")

            # 🎮 控制源指示器：实时显示当前谁在控制船坞/小船
            win.set_control_source_providers(
                self.dock_controller.brain,
                self.boat_controller.brain,
            )
            
            # 2. 🚀 [核心连接] 开启大窗显示，并绑定动态尺寸反馈信号
            # 当用户拉伸大窗口时，后台线程会即时改变缩放比例
            win.start_video_display(v_thread)
            win.sig_resized.connect(v_thread.set_target_size)
            
            # 3. 绑定算法与关闭逻辑
            win.sig_toggle_algo.connect(self.vision_manager.toggle_algorithm)
            win.sig_update_algo_params.connect(self.vision_manager.update_algo_params)
            win.sig_closed.connect(lambda: self._on_vision_window_closed(target_id))

            # 💡 [控制对接]
            def _handle_docking_req(tgt, active):
                if tgt == "boat":
                    if active:
                        if self.dock_controller.nof_centering_active:
                            # 🎯 NOF 切换：船坞正在视觉居中伺服，跳过定艏保持，仅启用子船视觉 PID
                            self.boat_controller.set_vision_dock_active(True)
                        else:
                            can_hold, reason = (
                                self.dock_controller.can_start_cooperative_docking_hold()
                            )
                            if not can_hold:
                                QMessageBox.warning(
                                    win,
                                    "无法开始闭环对接",
                                    f"{reason}\n\n小船视觉闭环未启动。",
                                )
                                QTimer.singleShot(
                                    0, lambda: win.btn_dock_action.setChecked(False)
                                )
                                return
                            self.dock_controller.set_cooperative_docking_hold(True)
                            self.boat_controller.set_vision_dock_active(True)
                    else:
                        self.boat_controller.set_vision_dock_active(False)
                        self.dock_controller.set_cooperative_docking_hold(False)
                elif tgt == "dock":
                    self.dock_controller.set_vision_dock_active(active) # 预留给船坞的扩展

            win.sig_start_docking.connect(_handle_docking_req)

            def _handle_docking_guidance(tgt, guidance):
                # 只有子船摄像头的四码结果能够进入子船PID。
                if tgt == "boat":
                    self.boat_controller.update_vision_guidance(guidance)

            win.sig_docking_guidance.connect(_handle_docking_guidance)

            self.vision_windows[target_id] = win

        self.vision_windows[target_id].show()
        self.vision_windows[target_id].raise_()
        self.vision_windows[target_id].activateWindow()
        return self.vision_windows[target_id]

    def _dispatch_vision_data(self, result_packet):
        """将 AI 坐标投递给对应的视觉窗口并截获船的视觉数据供底层自控"""
        tid = result_packet["id"]
        if self.vision_windows[tid] and self.vision_windows[tid].isVisible():
            self.vision_windows[tid].on_vision_data_arrived(
                result_packet["data"], imu=result_packet.get("imu")
            )

        # 🎯 NOF 视觉：船坞摄像头检出 NOF 大框 → 逐帧推送偏移做居中伺服
        if tid == "dock":
            self._process_dock_nof(result_packet.get("data", []))
            
    # ==========================================
    # 🎯 NOF 视觉居中：检测 → 推送框中心偏移
    # ==========================================
    def _process_dock_nof(self, results):
        """分析船坞摄像头 YOLO 结果：逐帧推送 NOF 偏移供居中伺服使用。"""
        best_area = 0.0
        best_offset = None
        best_track_id = None

        for r in results:
            if getattr(r, "algo_id", None) != "yolo_v8":
                continue
            label = str(getattr(r, "label", "")).upper()
            if self.nof_label_keyword.upper() not in label:
                continue
            bbox = getattr(r, "bbox", None)
            if not bbox or len(bbox) < 4:
                continue
            try:
                x1, y1, x2, y2 = (float(v) for v in bbox[:4])
            except (TypeError, ValueError):
                continue
            w = max(0.0, x2 - x1)
            h = max(0.0, y2 - y1)
            area = w * h
            if area > best_area:
                best_area = area
                best_offset = ((x1 + x2) / 2.0) - 0.5
                best_track_id = (getattr(r, "extra", None) or {}).get("track_id")

        # 🎯 连续识别计数：任意 NOF 检出即累计，无检出清零（用于 UI 指标显示）
        if best_offset is not None:
            self._nof_consecutive_count += 1
        else:
            self._nof_consecutive_count = 0

        # 🎯 触发条件①：跟踪器确认(track_id)才算"识别到"，连续累计帧数
        if best_track_id is not None:
            self._nof_confirmed_consecutive += 1
        else:
            self._nof_confirmed_consecutive = 0

        # [诊断] 节流打印 NOF 检出状态
        now = time.monotonic()
        if now - self._last_nof_log_time >= 1.0:
            self._last_nof_log_time = now
            dist = getattr(self, "current_dist", None)
            dist_txt = "n/a" if dist is None else f"{float(dist):.1f}"
            print(
                f"[NOF] 面积={best_area:.2f} 偏移={best_offset} "
                f"track_id={best_track_id} 连续={self._nof_consecutive_count} "
                f"确认={self._nof_confirmed_consecutive}/{self.nof_required_frames} "
                f"两船距离={dist_txt}m"
            )

        self._refresh_nof_indicator()

        # NOF 居中伺服激活期间，逐帧把框中心偏移推给船坞大脑
        if self.dock_controller.nof_centering_active:
            if best_offset is not None:
                self.dock_controller.update_nof_offset(best_offset)
            # 无框时不推送，船坞大脑按超时自动停止转向

    def _refresh_nof_indicator(self):
        """🎯 更新「NOF 连续识别帧数」指标：状态栏常驻标签 + 船坞视觉窗口 HUD。"""
        count = self._nof_consecutive_count
        confirmed = getattr(self, "_nof_confirmed_consecutive", 0)
        dist = getattr(self, "current_dist", None)
        dist_txt = "n/a" if dist is None else f"{float(dist):.1f} m"
        text = (
            f"🎯 NOF 连续识别: {count} 帧 | "
            f"跟踪确认: {confirmed}/{self.nof_required_frames} 帧 | "
            f"两船距离: {dist_txt}"
        )

        # 状态栏常驻标签（懒创建）
        if not hasattr(self, "_lbl_nof_counter"):
            self._lbl_nof_counter = QLabel(text)
            self._lbl_nof_counter.setStyleSheet(
                "font-weight: bold; color: #00aa66; padding: 0 8px;"
            )
            # ui_builder.py 里把 self.statusBar 覆盖成了 QStatusBar 实例
            # （mw.statusBar = QStatusBar()），所以这里不能再当方法调用，
            # 否则抛 TypeError: 'QStatusBar' object is not callable。
            self.statusBar.addPermanentWidget(self._lbl_nof_counter)
        else:
            self._lbl_nof_counter.setText(text)

        # 船坞视觉窗口 HUD 同步
        win = self.vision_windows.get("dock")
        if win is not None and win.isVisible():
            win.hud_label.set_nof_consecutive(count)

    def _on_vision_window_closed(self, target_id):
        """窗口关闭时：算法停机 + 视频尺寸降频重置"""
        if target_id == "boat":
            self.boat_controller.set_vision_dock_active(False)
            self.dock_controller.set_cooperative_docking_hold(False)
        elif target_id == "dock":
            # 🎯 关闭船坞视觉窗口时，同步退出 NOF 视觉居中伺服
            self.dock_controller.set_nof_centering_active(False)
        # 1. 停止算法算力消耗
        self.vision_manager.toggle_algorithm(target_id, "yolo_v8", False)
        
        # 2. 🚀 [核心重置] 大窗关了，通知后台线程恢复为“侧边栏”的小尺寸，极大节省 CPU
        if target_id == "dock":
            self.dock_controller.comm.active_video_thread.set_target_size(
                self.dock_panel.video_label.size()
            )
        else:
            self.boat_controller.comm.active_video_thread.set_target_size(
                self.boat_panel.video_label.size()
            )
            
        self.vision_windows[target_id] = None

    def _update_global_sim_frame(self, qimg: QImage):
        """将 ZMQ 传来的数字孪生图像绘制到中央大幕布上"""
        pixmap = QPixmap.fromImage(qimg).scaled(
            self.sim_global_view.size(), 
            Qt.KeepAspectRatio, 
            Qt.FastTransformation
        )
        self.sim_global_view.setPixmap(pixmap)

    # ==========================================
    # 9. 视图与UI互动调度专区
    # ==========================================
    def _on_imu_deadband_apply(self, dock_val: float, boat_val: float):
        """IMU 角速度积分死区配置下发"""
        self.dock_controller.send_imu_deadband(dock_val)
        self.boat_controller.send_imu_deadband(boat_val)

    def _on_config_sim_mode_changed(self, mode_str):
        """当模式改变时，更新 UI 反馈和智能切换视图"""
        is_sim = (mode_str == 'network')
        
        self.action_sim_mode.setChecked(is_sim)
        msg = "🧪 当前处于仿真模式 (指令重定向，启动数字孪生视图)" if is_sim else "🔌 当前处于真实硬件模式"
        self.statusBar.showMessage(msg, 5000)

        if is_sim:
            # 💡 [核心修改]：不再写死 IP，而是从配置弹窗的输入框动态抓取
            target_ip = self.config_dialog.dock_ip_input.text().strip()
            
            # 保持 5002 端口不变，但使用用户填写的 IP
            self.global_sim_thread.set_connection_params(target_ip, 5002)
            self.global_sim_thread.start_video()
            
            self.combo_view_mode.setCurrentIndex(3)
        else:
            self.global_sim_thread.stop_video()
            self.sim_global_view.clear()
            self.sim_global_view.setText("等待 3D 数字孪生环境 (端口 5002) 画面接入...")
            self.combo_view_mode.setCurrentIndex(1)

    def _on_sim_mode_action_triggered(self, checked):
        """工具栏按钮被点击，同步配置弹窗"""
        if checked:
            self.config_dialog.radio_network.setChecked(True)
        else:
            self.config_dialog.radio_serial.setChecked(True)

    def _on_view_mode_changed(self, index):
        if index == 0: 
            self.view_mode = "Auto"
        else:
            self.view_mode = "Manual" 
            if index == 1: self.view_stack.setCurrentIndex(0) 
            elif index == 2: self.view_stack.setCurrentIndex(1) 
            elif index == 3: self.view_stack.setCurrentIndex(2)

    def switch_view_automatically(self, distance: float):
        if self.view_mode != "Auto": return 
        if distance < 20.0 and self.view_stack.currentIndex() != 1:
            self.view_stack.setCurrentIndex(1) 
        elif distance > 22.0 and self.view_stack.currentIndex() != 0:
            self.view_stack.setCurrentIndex(0) 
            
    def _on_show_telemetry_center(self):
        """📈 唤醒多轴遥测中心独立窗口"""
        if self.telemetry_center.isHidden():
            self.telemetry_center.show()
            self.statusBar.showMessage("✅ 已开启多轴遥测分析中心", 2000)
        else:
            self.telemetry_center.raise_()
            self.telemetry_center.activateWindow()

    # ==========================================
    # 10. 任务指派业务逻辑
    # ==========================================
    def _on_mission_preview_requested(self, coords):
        """
        💡 [核心新增] 响应列表点击，通知地图渲染已保存的航线
        """
        if not coords:
            return
            
        # 将 Python 列表转为 JSON 字符串，例如 [[lat1, lon1], [lat2, lon2]]
        js_coords = json.dumps(coords)
        # 调用 map.html 中的 renderMissionPath 函数
        js_code = f"renderMissionPath({js_coords});"
        self.map_view.page().runJavaScript(js_code)
        
        self.statusBar.showMessage(f"🗺️ 地图已加载选中的航线 (共 {len(coords)} 个航点)", 2000)
    def _handle_map_identify_toggle(self, active: bool):
        if active:
            self.map_view.page().runJavaScript("enterIdentifyMode();")
            self.statusBar.showMessage("🔍 地图模式：位置识别开启，点击地图查看坐标。")
        else:
            self.map_view.page().runJavaScript("exitIdentifyMode();")
            self.statusBar.showMessage("✅ 地图模式：已回到观察模式。")

    def _on_assign_dock_clicked(self):
        """将选中的路径指派给船坞 (0x01)"""
        # 🌐 [T8] 孪生视图守卫：真实地图 + 孪生在跑 → 拦截（实船模式直接放行）
        if self._guard_twin_control():
            return
        coords = self.mission_panel.get_selected_task_data()
        if coords:
            # 🌐 [T7] 孪生视图下逐点范围校验：任一点越界即整体拒绝
            if self._reject_twin_points(coords):
                return
            self.dock_controller.start_mission(coords)
            self.statusBar.showMessage(f"✅ 任务已下发至 1号船坞 (共 {len(coords)} 个点)", 3000)
        else:
            QMessageBox.warning(self, "指派失败", "请先在任务库中选择一个路径！")

    def _on_assign_boat_clicked(self):
        """将选中的路径指派给子船 (0x02)"""
        # 🌐 [T8] 孪生视图守卫
        if self._guard_twin_control():
            return
        coords = self.mission_panel.get_selected_task_data()
        if coords:
            # 🌐 [T7] 孪生视图下逐点范围校验
            if self._reject_twin_points(coords):
                return
            self.boat_controller.start_mission(coords)
            self.statusBar.showMessage(f"✅ 任务已下发至 2号子船 (共 {len(coords)} 个点)", 3000)
        else:
            QMessageBox.warning(self, "指派失败", "请先在任务库中选择一个路径！")

    # ==========================================
    # 🎯 🚀 新增：英雄联盟式“点选直达”业务逻辑
    # ==========================================
    def _on_steady_hold_toggled(self, checked: bool):
        if checked:
            self.map_view.page().runJavaScript("enterPointGoMode();")
        else:
            self.map_view.page().runJavaScript("exitPointGoMode();")
            self.dock_controller.handle_steady_hold_stop()
            self.mission_panel.btn_steady_hold.setText("📌 到点稳停")
            self.mission_panel.btn_steady_hold.setStyleSheet("")

    def _handle_point_go_logic(self, lat, lon):
        """
        处理来自地图的单点点击指令，直接指派给船坞。
        如果「到点稳停」模式激活，则走稳态逻辑。
        """
        # 🌐 [T8] 孪生视图守卫（实船模式直接放行，零影响）
        if self._guard_twin_control():
            return
        # 🌐 [T7] 孪生视图下范围校验
        if self._reject_if_outside_twin_bounds(lat, lon):
            return

        # 检查是否为到点稳停模式
        if self.mission_panel.btn_steady_hold.isChecked():
            self.dock_controller.handle_steady_hold_start(lat, lon)
            self.mission_panel.btn_steady_hold.setText("⚓ 稳停中...")
            self.mission_panel.btn_steady_hold.setStyleSheet(
                "background-color: #a5d6a7; color: green; font-weight: bold;"
            )
            msg = f"📌 [到点稳停] 目标已锁定: Lat {lat:.6f}, Lon {lon:.6f}，P2P 导航中..."
            self.statusBar.showMessage(msg, 3000)
            return

        # 1. 构造单点路径列表
        # 导航引擎 Navigator 需要接收一个列表，所以我们包一层中括号
        coords = [[lat, lon]]

        # 2. 直接下发给船坞控制器
        # 这会自动打断船坞当前的任何任务，并立即转向新目标点
        self.dock_controller.start_mission(coords)

        # 3. UI 反馈：在状态栏和船坞日志中显示
        msg = f"🎯 [点选直达] 船坞目标已锁定: Lat {lat:.6f}, Lon {lon:.6f}"
        self.statusBar.showMessage(msg, 3000)
        self.dock_controller.monitor.append_log(f"🚀 [Point-Go] 接收到单点直达指令，立即前往目标。")

    def _on_return_home_started(self, lat: float, lon: float):
        """🏠 船坞一键返航触发：在地图上标记返航停靠点"""
        js_code = f"showHomeMarker({lat}, {lon});"
        self.map_view.page().runJavaScript(js_code)
        self.statusBar.showMessage(
            f"🏠 [船坞一键返航] P2P返航中 → {lat:.6f}, {lon:.6f}", 5000
        )

    def _on_boat_return_home_started(self, lat: float, lon: float):
        """🏠 子船一键返航触发：在地图上标记返航停靠点"""
        js_code = f"showHomeMarker({lat}, {lon});"
        self.map_view.page().runJavaScript(js_code)
        self.statusBar.showMessage(
            f"🏠 [子船一键返航] P2P返航中 → {lat:.6f}, {lon:.6f}", 5000
        )

    # ==========================================
    # 11. 全局状态与地图更新逻辑
    # ==========================================
    def update_dock_full_state(self, data: dict):
        """船坞状态更新（由数据解析完毕的信号触发）"""
        # 地图更新限频 5Hz (200ms)
        now = int(time.time() * 1000)
        if now - self._last_map_update_dock >= 200:
            self._last_map_update_dock = now

            lat, lon = data["gps"]["lat"], data["gps"]["lon"]
            heading = data["imu"]["ekf_heading"]

            # 🟢 天线A+B中点：距离显示与算法实际使用位置
            gps_b = data.get("gps_B", {})
            if gps_b.get("lat") and gps_b.get("lon"):
                self.dock_mid_gps = ((lat + gps_b["lat"]) / 2.0,
                                     (lon + gps_b["lon"]) / 2.0)
            else:
                self.dock_mid_gps = None

            self.update_dock_global_state(lat, lon, heading)

            if self.dock_mid_gps is not None:
                js_b = f"updateDockPositionB({gps_b['lat']}, {gps_b['lon']});"
                self.map_view.page().runJavaScript(js_b)
                mid_lat, mid_lon = self.dock_mid_gps
                js_mid = f"updateDockMidPosition({mid_lat}, {mid_lon});"
                self.map_view.page().runJavaScript(js_mid)

            targets = data.get("targets", {})
            target_h = targets.get("heading")
            target_s = targets.get("speed", 0.0)
            js_intent = f"updateDockTargetIndicator({lat}, {lon}, {target_h if target_h is not None else 'null'}, {target_s});"
            self.map_view.page().runJavaScript(js_intent)

    def update_boat_full_state(self, data: dict):
        """子船状态更新（由数据解析完毕的信号触发）"""
        # 🎯 NOF 方位角兜底：把子船 GPS 中点实时桥接给船坞大脑
        gps_b = data.get("gps_B", {})
        if gps_b.get("lat") and gps_b.get("lon"):
            mid_lat = (data["gps"]["lat"] + gps_b["lat"]) / 2.0
            mid_lon = (data["gps"]["lon"] + gps_b["lon"]) / 2.0
            self.dock_controller.set_boat_position(mid_lat, mid_lon)

        # 地图更新限频 5Hz (200ms)
        now = int(time.time() * 1000)
        if now - self._last_map_update_boat >= 200:
            self._last_map_update_boat = now

            lat, lon = data["gps"]["lat"], data["gps"]["lon"]
            heading = data["imu"]["ekf_heading"]

            # 🟢 天线A+B中点：距离显示与算法实际使用位置
            gps_b = data.get("gps_B", {})
            if gps_b.get("lat") and gps_b.get("lon"):
                self.boat_mid_gps = ((lat + gps_b["lat"]) / 2.0,
                                     (lon + gps_b["lon"]) / 2.0)
            else:
                self.boat_mid_gps = None

            self.update_boat_global_state(lat, lon, heading)

            if self.boat_mid_gps is not None:
                js_b = f"updateBoatPositionB({gps_b['lat']}, {gps_b['lon']});"
                self.map_view.page().runJavaScript(js_b)
                mid_lat, mid_lon = self.boat_mid_gps
                js_mid = f"updateBoatMidPosition({mid_lat}, {mid_lon});"
                self.map_view.page().runJavaScript(js_mid)

            targets = data.get("targets", {})
            target_h = targets.get("heading")
            target_s = targets.get("speed", 0.0)
            js_intent = f"updateBoatTargetIndicator({lat}, {lon}, {target_h if target_h is not None else 'null'}, {target_s});"
            self.map_view.page().runJavaScript(js_intent)

    def update_dock_global_state(self, lat: float, lon: float, heading: float):
        self.dock_gps = (lat, lon)
        js_code = f"updateDockPosition({lat}, {lon}, {heading});"
        self.map_view.page().runJavaScript(js_code)
        self._try_compute_relative_state()

    def update_boat_global_state(self, lat: float, lon: float, heading: float):
        self.boat_gps = (lat, lon)
        self.boat_heading = heading 
        js_code = f"updateBoatPosition({lat}, {lon}, {heading});"
        self.map_view.page().runJavaScript(js_code)
        self._try_compute_relative_state()

    def _try_compute_relative_state(self):
        """计算两船相对距离与方位角，并更新雷达和UI视图"""
        # 💡 优先使用双天线中点，B 天线缺失时回退到天线A
        dock_pos = self.dock_mid_gps if self.dock_mid_gps is not None else self.dock_gps
        boat_pos = self.boat_mid_gps if self.boat_mid_gps is not None else self.boat_gps
        if dock_pos is not None and boat_pos is not None:
            dist, angle = CoordUtils.calculate_distance_and_bearing(
                dock_pos[0], dock_pos[1], 
                boat_pos[0], boat_pos[1]
            )
            
            # 💡 [核心修复]：把算出来的距离存到 MainWindow 的变量里
            self.current_dist = dist
            
            # 1. 视觉更新
            self.radar_view.update_targets(dist, angle, self.boat_heading)
            self.dock_panel.lbl_dist.setText(f"{dist:.1f} m")
            self.boat_panel.lbl_dist.setText(f"{dist:.1f} m")
            self.switch_view_automatically(dist)

            # 🚨🚨🚨 【必须删除这行毒瘤代码，绝不发假包裹】 🚨🚨🚨
            # self.data_logger.log_telemetry({"id": 0x01, "dist": dist})
    # ==========================================
    # 12. 硬件控制与UI反馈对接专区
    # ==========================================
    def _handle_hardware_axis(self, joy_idx, axis_idx, value):
        """
        💡 [解耦说明] 该函数现在仅负责手柄移动时的【视觉球反馈】。
        真正的指令下发和数字框刷新已交给 control_dispatcher 节拍器管家处理。
        🎮 使用角色映射查找，支持配对后动态切换。
        """
        dock_idx = self.joystick_manager.get_joystick_index('dock')
        boat_idx = self.joystick_manager.get_joystick_index('boat')

        if joy_idx == dock_idx: # 船坞
            if axis_idx == 1: # 纵向动力杆 A
                y_val = -value * 100
                self.driving_console.dock_joy_cruise.set_position_from_values(0, y_val)
            elif axis_idx == 2: # 转向杆 B
                x_val = value * 100
                self.driving_console.dock_joy_yaw.set_position_from_values(x_val, 0)
        elif joy_idx == boat_idx: # 子船杆 C
            if axis_idx == 2: self.boat_hw_state[0] = value * 100
            elif axis_idx == 1: self.boat_hw_state[1] = -value * 100
            self.driving_console.boat_joy.set_position_from_values(self.boat_hw_state[0], self.boat_hw_state[1])

    def _handle_hardware_dpad(self, joy_idx, x_dir, y_dir):
        """处理手柄十字键微调目标指令 (下发给控制器处理) 🎮 使用角色映射"""
        dock_idx = self.joystick_manager.get_joystick_index('dock')
        boat_idx = self.joystick_manager.get_joystick_index('boat')

        speed_step = y_dir * 0.1   # 上下键：每次拨动增减 0.1 m/s
        heading_step = x_dir * 1.0 # 左右键：每次拨动增减 1.0 度

        if joy_idx == dock_idx:
            self.dock_controller.step_target(speed_step, heading_step)
        elif joy_idx == boat_idx:
            self.boat_controller.step_target(speed_step, heading_step)

    def _handle_hardware_init(self, target_id):
        """处理手柄发出的初始化指令"""
        if target_id == 0x01:
            self.dock_controller._handle_init()
        elif target_id == 0x02:
            self.boat_controller._handle_init()

    # ==========================================
    # 🎮 手柄配对流程
    # ==========================================
    def _on_joystick_pair_toggled(self, checked: bool):
        """手柄配对按钮切换：按下→开始配对，弹起→取消配对"""
        if checked:
            # 检查是否有足够的手柄
            joy_count = pygame.joystick.get_count()
            if joy_count < 2:
                self.statusBar.showMessage("⚠️ 配对需要至少 2 个手柄，当前仅检测到 %d 个" % joy_count, 3000)
                self.action_joystick_pair.setChecked(False)
                return

            # 暂停控制节拍器（配对期间禁止下发指令）
            if hasattr(self, 'control_dispatcher'):
                self.control_dispatcher.stop()

            self.joystick_manager.start_pairing()
            self.statusBar.showMessage("🎮 进入手柄配对模式 — 请按状态栏提示操作", 2000)
        else:
            # 用户手动取消配对
            self.joystick_manager.cancel_pairing()
            if hasattr(self, 'control_dispatcher'):
                self.control_dispatcher.start()
            self.statusBar.showMessage("⚠️ 手柄配对已取消，恢复默认映射", 3000)

    def _on_pairing_progress(self, message: str, step: int):
        """配对进度更新 → 显示在状态栏"""
        self.statusBar.showMessage(message, 0)  # 0 = 持久显示直到下一条

    def _on_pairing_complete(self, mapping: dict):
        """配对完成 → 恢复控制节拍器并弹起按钮"""
        self.action_joystick_pair.setChecked(False)
        self.statusBar.showMessage("✅ 手柄配对完成！控制节拍器已恢复。", 5000)

        # 恢复控制节拍器
        if hasattr(self, 'control_dispatcher'):
            self.control_dispatcher.start()

    # ==========================================
    # 13. 高危抢占与急停逻辑
    # ==========================================
    def _on_global_estop_clicked(self):
        """🚨 [紧急] 全局急停逻辑：强制关闭算法并切断所有动力"""
        # 触发两个控制器的物理急停
        self.dock_controller.set_nof_centering_active(False)
        self.dock_controller._handle_estop()
        self.boat_controller._handle_estop()
        self.statusBar.showMessage("🚨 警告：已触发全局急停！算法已关闭，动力已切断！", 5000)

    def _handle_manual_override(self):
        """物理手柄接管时关闭视觉对接和船坞协同定艏。"""
        boat_vision = self.vision_windows.get("boat")
        if boat_vision is not None and boat_vision.btn_dock_action.isChecked():
            boat_vision.btn_dock_action.setChecked(False)
        else:
            self.boat_controller.set_vision_dock_active(False)
            self.dock_controller.set_cooperative_docking_hold(False)
        # 🎯 手动接管时同步退出船坞 NOF 视觉居中伺服
        self.dock_controller.set_nof_centering_active(False)

    def _handle_cooperative_hold_fault(self, reason: str):
        boat_vision = self.vision_windows.get("boat")
        if boat_vision is not None and boat_vision.btn_dock_action.isChecked():
            boat_vision.btn_dock_action.setChecked(False)
        else:
            self.boat_controller.set_vision_dock_active(False)
            self.dock_controller.set_cooperative_docking_hold(False)
        QMessageBox.warning(self, "协同靠泊已停止", str(reason))

    # ==========================================
    # 14. 🛑 终极安全退出机制 (解决一切僵尸进程)
    # ==========================================
    def closeEvent(self, event):
        """
        系统退出时的资源安全释放：确保所有后台进程和通信链路全部关闭，绝不留僵尸！
        """
        print("🛑 正在关闭系统，清理后台资源...")
        # 关闭上位机前，停止由本机地面站启动的数字孪生进程。
        if hasattr(self, 'action_remote_sim') and self.action_remote_sim.isChecked():
            self._stop_local_simulator(disconnect_links=False)
        # 1. 停止节拍器
        if hasattr(self, 'control_dispatcher'):
            self.control_dispatcher.stop()

        # 2. 停止上帝视角拉流
        if hasattr(self, 'global_sim_thread'):
            self.global_sim_thread.stop_video()

        # 3. 停止底层的数据和视频写入线程！切断源头。
        if hasattr(self, 'dock_controller'):
            self.dock_controller.serial_thread.close_port()
            self.dock_controller.network_thread.close_port()
            self.dock_controller.video_thread.stop_video()
            self.dock_controller.comm.sim_video_thread.stop_video()
            self.dock_controller.shutdown()  # 🧵 [方案三] 清理 Brain Worker 线程

        if hasattr(self, 'boat_controller'):
            self.boat_controller.serial_thread.close_port()
            self.boat_controller.network_thread.close_port()
            self.boat_controller.video_thread.stop_video()
            self.boat_controller.comm.sim_video_thread.stop_video()
            self.boat_controller.shutdown()  # 🧵 [方案三] 清理 Brain Worker 线程

        # 4. 切断视频流后，安全斩杀视觉算力进程并销毁共享内存
        if hasattr(self, 'vision_manager') and self.vision_manager:
            self.vision_manager.cleanup()

        # 5. [V4.1] 停止 DataLogger 后台落盘线程，确保缓冲数据全部写入磁盘
        if hasattr(self, 'data_logger'):
            self.data_logger.stop_logging() if self.data_logger.is_logging else None
            self.data_logger.cleanup()

        # 6. 停止实体手柄监控线程
        if hasattr(self, 'joystick_manager'):
            self.joystick_manager.stop()

        # 接受关闭事件，正式退出程序
        event.accept()
        print("✅ 系统资源已全部释放，安全退出。")


    # ==========================================
        # 添加 GPS 路径选项
        # ==========================================
        self.action_gps_path = QAction("GPS路径", self)
        self.action_gps_path.setCheckable(True)
        self.action_gps_path.triggered.connect(self._toggle_gps_path_logging)
        
        # 将 GPS 路径选项添加到工具栏或菜单
        self.ui_builder.add_action_to_navigation_menu(self.action_gps_path, "姿态与导航")

    def _toggle_gps_path_logging(self, checked):
        """切换 GPS 路径记录"""
        if checked:
            self.data_logger.start_gps_logging()
        else:
            self.data_logger.stop_gps_logging()

    # 绑定 GPS 数据记录信号
        self.dock_controller.brain.sig_data_parsed.connect(self._log_dock_gps)
        self.boat_controller.brain.sig_data_parsed.connect(self._log_boat_gps)

    def _log_dock_gps(self, data):
        """记录船坞的 GPS 数据（含天线B + UTC时间）"""
        gps_info = data.get("gps", {})
        if "lat" in gps_info and "lon" in gps_info:
            gps_b = data.get("gps_B", {})
            self.data_logger.log_gps_data(0x01,
                gps_info["lat"], gps_info["lon"],
                gps_b.get("lat"), gps_b.get("lon"),
                data.get("utc_time_A", 0), data.get("utc_time_B", 0))

    def _log_boat_gps(self, data):
        """记录船的 GPS 数据（含天线B + UTC时间）"""
        gps_info = data.get("gps", {})
        if "lat" in gps_info and "lon" in gps_info:
            gps_b = data.get("gps_B", {})
            self.data_logger.log_gps_data(0x02,
                gps_info["lat"], gps_info["lon"],
                gps_b.get("lat"), gps_b.get("lon"),
                data.get("utc_time_A", 0), data.get("utc_time_B", 0))
    # 📏 将 IMU 数据推送到视觉进程
    def _send_imu_to_vision_dock(self, parsed_data):
        imu = parsed_data.get("imu", {})
        if imu:
            self.vision_manager.send_imu("dock", imu)

    def _send_imu_to_vision_boat(self, parsed_data):
        imu = parsed_data.get("imu", {})
        if imu:
            self.vision_manager.send_imu("boat", imu)

    # ==========================================
    # 🖥️ 本机数字孪生一键控制专区
    # ==========================================
    # 🖥️ 数字孪生 EXE 查找：config/simulator.json 优先，其次是同级目录下的候选路径。
    # 以前这里写死成 workspace_root/"USV_dock_3"，换一版孪生构建目录名就失效，
    # 只能改代码。现在改成可配置，不再需要动源码。
    _SIM_CONFIG_FILE = os.path.join("config", "simulator.json")

    def _simulator_candidates(self):
        """按优先级返回去重后的候选孪生目录（绝对路径）。"""
        app_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        workspace_root = os.path.dirname(app_root)

        raw = []

        # 1) 配置文件指定的路径（最优先，缺省不存在）
        try:
            with open(self._SIM_CONFIG_FILE, "r", encoding="utf-8") as fh:
                configured = (json.load(fh).get("simulator_dir") or "").strip()
            if configured:
                raw.append(configured)
        except FileNotFoundError:
            pass
        except Exception as exc:  # noqa: BLE001 - 配置坏了不该拖垮启动
            print(f"⚠️ [数字孪生] 读取 {self._SIM_CONFIG_FILE} 失败: {exc}")

        # 2) 环境变量覆盖（方便临时/多套构建切换）
        env_dir = (os.environ.get("USV_SIM_DIR") or "").strip()
        if env_dir:
            raw.append(env_dir)

        # 3) 同级目录下的候选（相对地面站工程定位，换盘/换目录名都不受影响）
        #    V1 联调：开源版孪生（副本仓库）优先，旧版仓库与 USV_dock_3 保留兜底。
        raw.append(os.path.join(
            workspace_root, "USV5_GCS_BUILD_TEST_(With_Wheel) - 副本", "Build_GCS_Compatible"
        ))
        raw.append(os.path.join(
            workspace_root, "USV5_GCS_BUILD_TEST_(With_Wheel) - 副本", "Build_M5"
        ))
        raw.append(os.path.join(
            workspace_root, "USV5_GCS_BUILD_TEST_(With_Wheel)", "Build_GCS_Compatible"
        ))
        raw.append(os.path.join(workspace_root, "USV_dock_3"))

        # 去重（保持优先级顺序）：配置项常和默认候选指向同一目录
        candidates, seen = [], set()
        for path in raw:
            key = os.path.normcase(os.path.normpath(path))
            if key not in seen:
                seen.add(key)
                candidates.append(path)
        return candidates

    # 数字孪生 EXE 名：V1 起正式名为 USV_Sim2Real_Simulation_Platform.exe
    # （旧名 DDPG USVS.exe 已由孪生侧废弃，仅作旧构建回退）。
    # 同目录下两者并存时优先命中新名。
    _SIM_EXE_NAMES = (
        "USV_Sim2Real_Simulation_Platform.exe",
        "DDPG USVS.exe",
    )

    def _local_simulator_paths(self):
        """定位数字孪生 EXE 与其 gcs_target_ip.txt。

        注意：gcs_target_ip.txt 必须和 EXE 同目录（见孪生自带的
        GROUND_STATION_INTERFACE.md），所以两者都从同一个目录推出来。
        """
        candidates = self._simulator_candidates()
        for sim_dir in candidates:
            for exe_name in self._SIM_EXE_NAMES:
                exe_path = os.path.join(sim_dir, exe_name)
                if os.path.isfile(exe_path):
                    return exe_path, os.path.join(sim_dir, "gcs_target_ip.txt")

        # 都找不到：回退到首选路径，让调用方报出有意义的错误信息
        fallback = candidates[0] if candidates else ""
        return (
            os.path.join(fallback, self._SIM_EXE_NAMES[0]),
            os.path.join(fallback, "gcs_target_ip.txt"),
        )

    @staticmethod
    def _is_tcp_port_open(host: str, port: int, timeout: float = 0.2) -> bool:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            return False

    def _apply_local_sim_defaults(self):
        """统一地面站与 Unity EXE 的本机地址和固定端口。"""
        fields = {
            self.config_dialog.dock_ip_input: "127.0.0.1",
            self.config_dialog.boat_ip_input: "127.0.0.1",
            self.config_dialog.dock_port_tx: "8081",
            self.config_dialog.dock_port_rx: "8080",
            self.config_dialog.dock_port_video: "5001",
            self.config_dialog.boat_port_tx: "8888",
            self.config_dialog.boat_port_rx: "8889",
            self.config_dialog.boat_port_video: "5003",
        }
        for widget, value in fields.items():
            widget.setText(value)

    def _write_local_sim_target_ip(self) -> bool:
        """写入 EXE 原生支持的动态地面站 IP 文件。"""
        _exe_path, target_ip_path = self._local_simulator_paths()
        try:
            with open(target_ip_path, "w", encoding="utf-8") as target_file:
                target_file.write("127.0.0.1\n")
            return True
        except Exception as e:
            QMessageBox.critical(self, "配置错误", f"无法写入本机孪生 IP 配置：\n{e}")
            return False

    def _connect_local_sim_links(self):
        """启动 UDP 遥测/控制和 5001、5003 两路侧边视频。"""
        if not self.action_remote_sim.isChecked():
            return
        if not self.dock_controller.network_thread.is_running:
            self.dock_controller._handle_connect_network()
        if not self.boat_controller.network_thread.is_running:
            self.boat_controller._handle_connect_network()

    def _start_local_simulator(self) -> bool:
        exe_path, _target_ip_path = self._local_simulator_paths()
        if not os.path.isfile(exe_path):
            tried = "\n".join(f"  · {d}" for d in self._simulator_candidates())
            QMessageBox.critical(
                self,
                "启动失败",
                "找不到数字孪生程序。\n\n"
                f"当前解析到：\n{exe_path}\n\n"
                f"已尝试的目录（按优先级）：\n{tried}\n\n"
                f"可识别的程序名：{' / '.join(self._SIM_EXE_NAMES)}\n\n"
                "请把正确的目录填到 config/simulator.json 的 simulator_dir，\n"
                "或设置环境变量 USV_SIM_DIR。",
            )
            return False
        if not self._write_local_sim_target_ip():
            return False

        # 已手动启动时直接接入，不重复创建进程，也不会在停止时误杀该实例。
        if self._is_tcp_port_open("127.0.0.1", 5002):
            self.local_sim_process = None
            self._owns_local_sim_process = False
            return True

        try:
            creationflags = 0
            if os.name == "nt":
                creationflags = subprocess.CREATE_NO_WINDOW
            self.local_sim_process = subprocess.Popen(
                [
                    exe_path,
                    "-screen-fullscreen", "0",
                    "-screen-width", "640",
                    "-screen-height", "360",
                    "-force-d3d11",
                ],
                cwd=os.path.dirname(exe_path),
                creationflags=creationflags,
            )
            self._owns_local_sim_process = True
            # Unity Player 日志会在部分高刷屏上报告窗口化 VSync/时间步失效；
            # 窗口创建后轻微移动一次可让 Unity 重新读取正确的刷新节拍。
            if os.name == "nt":
                QTimer.singleShot(1500, self._nudge_local_sim_window)
            return True
        except Exception as exc:
            self.local_sim_process = None
            self._owns_local_sim_process = False
            QMessageBox.critical(self, "启动失败", f"无法启动数字孪生 EXE：\n{exc}")
            return False

    def _nudge_local_sim_window(self):
        """轻微移动 Unity 窗口，修复部分高刷屏下的窗口化时间步漂移。"""
        process = self.local_sim_process
        if process is None or process.poll() is not None or os.name != "nt":
            return
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            target_pid = int(process.pid)
            found = []

            @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
            def enum_callback(hwnd, _lparam):
                pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if pid.value == target_pid and user32.IsWindowVisible(hwnd):
                    found.append(hwnd)
                    return False
                return True

            user32.EnumWindows(enum_callback, 0)
            if not found:
                return
            rect = wintypes.RECT()
            if not user32.GetWindowRect(found[0], ctypes.byref(rect)):
                return
            flags = 0x0001 | 0x0004 | 0x0010  # NOSIZE | NOZORDER | NOACTIVATE
            user32.SetWindowPos(found[0], 0, rect.left + 1, rect.top, 0, 0, flags)
            user32.SetWindowPos(found[0], 0, rect.left, rect.top, 0, 0, flags)
        except Exception as exc:
            print(f"[孪生启动] Unity 窗口节拍刷新未执行: {exc}")

    def _stop_local_simulator(self, disconnect_links: bool = True):
        if disconnect_links:
            for controller in (self.dock_controller, self.boat_controller):
                controller.panel.stop_video_display()
                controller.comm.close_network_and_video()

        process = self.local_sim_process
        if self._owns_local_sim_process and process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3.0)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2.0)
        self.local_sim_process = None
        self._owns_local_sim_process = False

    def _on_remote_sim_toggled(self, checked):
        """一键启动/停止本机 Unity 数字孪生并接通全部链路。"""
        # 🌐 [T9] 孪生模式 → 日志改写到 data_logs_sim/；停止后自动恢复实船目录
        try:
            self.data_logger.use_sim_dir = bool(checked)
        except Exception as exc:                      # noqa: BLE001
            print(f"[TwinMap] 切换日志目录失败: {exc}")

        if checked:
            self._apply_local_sim_defaults()
            if not self._start_local_simulator():
                self.action_remote_sim.setChecked(False)
                return

            self.action_remote_sim.setText("🛑 停止数字孪生")
            self.action_sim_mode.setChecked(True)
            self.config_dialog.radio_network.setChecked(True)
            # radio 已经选中时不会再发 toggled，显式确保中央 5002 拉流启动。
            self._on_config_sim_mode_changed("network")
            QTimer.singleShot(800, self._connect_local_sim_links)
            self.statusBar.showMessage(
                "🚀 本机数字孪生已启动，正在连接 5001/5002/5003 三路画面...",
                8000,
            )
        else:
            self._stop_local_simulator()
            self.global_sim_thread.stop_video()
            self.sim_global_view.clear()
            self.sim_global_view.setText("等待 3D 数字孪生环境 (端口 5002) 画面接入...")
            self.statusBar.showMessage("🛑 本机数字孪生及通信链路已关闭", 5000)
            self.action_remote_sim.setText("🚀 一键启动数字孪生")
