# # # # 文件路径: ui/dialogs/thruster_limit_dialog.py

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
                             QLabel, QSpinBox, QDoubleSpinBox, QPushButton, QMessageBox, QGroupBox)
from PyQt5.QtCore import Qt
from core.protocol import USVProtocol

class ThrusterLimitDialog(QDialog):
    """
    推进器底层硬件配置弹窗 (V5.0 适配版)
    支持分机独立配置 (target_id) 和死区补偿 (Deadband)
    """
    def __init__(self, target_id: int, parent=None):
        super().__init__(parent)
        self.target_id = target_id
        
        # 动态设置窗口标题
        device_name = "1号船坞" if self.target_id == 0x01 else "2号子船"
        self.setWindowTitle(f"⚙️ 推进器安全与死区配置 - [{device_name}]")
        
        self.setMinimumWidth(650) # Trim校准列需要额外宽度
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        # 字典存储 4 个推进器的微调框：{ id: (min, max, pos, neg, trim) }
        self.spin_boxes = {} 

        self._init_ui()
        self._load_current_limits()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)

        # --- 1. 警告提示 ---
        info_label = QLabel("⚠️ 警告：此配置将直接修改底层死区补偿与物理限幅。\n设置不当可能导致推力突变或电机受损，请在测试水域操作！")
        info_label.setStyleSheet("color: #d9534f; font-weight: bold;")
        main_layout.addWidget(info_label)

        # --- 2. 核心配置区 ---
        group_box = QGroupBox("PWM 参数设置 (电调中立位为 1500)")
        grid = QGridLayout(group_box)
        grid.addWidget(QLabel("通道名称"), 0, 0)
        grid.addWidget(QLabel("安全下限 (Min)"), 0, 1)
        grid.addWidget(QLabel("安全上限 (Max)"), 0, 2)
        grid.addWidget(QLabel("反向死区 (Neg)"), 0, 3) # 往回拉(负向)起转补偿
        grid.addWidget(QLabel("正向死区 (Pos)"), 0, 4) # 往前推(正向)起转补偿
        grid.addWidget(QLabel("推力校准 (Trim)"), 0, 5) # 推进器个体差异补偿

        names = {1: "1 (左推)", 2: "2 (右推)", 3: "3 (预留)", 4: "4 (预留)"}

        for i in range(1, 5):
            lbl = QLabel(f"推进器 {names[i]}:")

            spin_min = QSpinBox()
            spin_min.setRange(1000, 1500)  # 下限一般不超过 1500
            spin_min.setSingleStep(10)

            spin_max = QSpinBox()
            spin_max.setRange(1500, 2000) # 上限一般不低于 1500
            spin_max.setSingleStep(10)

            spin_neg = QSpinBox()
            spin_neg.setRange(0, 300)     # 死区偏移量，0表示无补偿
            spin_neg.setSingleStep(5)

            spin_pos = QSpinBox()
            spin_pos.setRange(0, 300)
            spin_pos.setSingleStep(5)

            spin_trim = QDoubleSpinBox()
            spin_trim.setRange(0.50, 1.50)  # 推力校准系数
            spin_trim.setSingleStep(0.01)
            spin_trim.setDecimals(2)
            spin_trim.setValue(1.00)
            spin_trim.setToolTip(">1.0 增强推力，<1.0 减弱推力\n补偿推进器个体差异，默认 1.00 不调整")

            grid.addWidget(lbl, i, 0)
            grid.addWidget(spin_min, i, 1)
            grid.addWidget(spin_max, i, 2)
            grid.addWidget(spin_neg, i, 3)
            grid.addWidget(spin_pos, i, 4)
            grid.addWidget(spin_trim, i, 5)

            self.spin_boxes[i] = (spin_min, spin_max, spin_pos, spin_neg, spin_trim)

        main_layout.addWidget(group_box)

        # --- 3. 底部按钮区 ---
        btn_layout = QHBoxLayout()
        # === 新增代码开始 ===
        self.btn_full = QPushButton("🚀 一键拉满 (1300-1800)")
        self.btn_full.setStyleSheet("""
            QPushButton {
                background-color: #5bc0de; 
                color: white; 
                font-weight: bold; 
                border-radius: 4px;
                padding: 5px 15px;
            }
            QPushButton:hover { background-color: #31b0d5; }
        """)
        self.btn_full.clicked.connect(self._reset_to_full_range)
        btn_layout.addWidget(self.btn_full)
        # === 新增代码结束 ===
        btn_layout.addStretch()
        btn_save = QPushButton("✅ 应用并生效")
        btn_cancel = QPushButton("❌ 取消")
        
        btn_save.clicked.connect(self._save_limits)
        btn_cancel.clicked.connect(self.reject)
        
        btn_layout.addWidget(btn_save)
        btn_layout.addWidget(btn_cancel)
        main_layout.addLayout(btn_layout)

    def _load_current_limits(self):
        """打开弹窗时，根据 target_id 加载参数"""
        device_cfg = USVProtocol.USV_CONFIGS.get(self.target_id, {})

        for i in range(1, 5):
            # 兼容读取，防崩溃兜底
            defaults = {"min": 1300, "max": 1800, "pos": 0, "neg": 0, "eps": 5, "trim": 1.0}
            limits = device_cfg.get(i, defaults)

            self.spin_boxes[i][0].setValue(limits["min"])
            self.spin_boxes[i][1].setValue(limits["max"])
            self.spin_boxes[i][2].setValue(limits["pos"])
            self.spin_boxes[i][3].setValue(limits["neg"])
            self.spin_boxes[i][4].setValue(limits.get("trim", 1.0))



    def _reset_to_full_range(self):
        """
        [新增逻辑] 一键将所有推进器配置为物理极限值
        """
        for i in range(1, 5):
            # index 0:min, 1:max, 2:pos, 3:neg, 4:trim
            self.spin_boxes[i][0].setValue(1300)  # 下限拉满
            self.spin_boxes[i][1].setValue(1800)  # 上限拉满
            self.spin_boxes[i][2].setValue(0)     # 正死区清零
            self.spin_boxes[i][3].setValue(0)     # 负死区清零
            self.spin_boxes[i][4].setValue(1.00)  # Trim 恢复默认

        QMessageBox.information(self, "操作成功", "所有参数已重置为：\n下限: 1300 / 上限: 1800 / 死区: 0 / Trim: 1.00\n请点击[应用并生效]写入内核。")



    def _save_limits(self):
        """保存并更新到协议类全局字典"""
        for i in range(1, 5):
            val_min = self.spin_boxes[i][0].value()
            val_max = self.spin_boxes[i][1].value()
            val_pos = self.spin_boxes[i][2].value()
            val_neg = self.spin_boxes[i][3].value()
            val_trim = self.spin_boxes[i][4].value()

            # --- 核心安全校验 ---
            if val_min >= val_max:
                QMessageBox.warning(self, "参数错误", f"推进器 {i} 的下限必须小于上限！")
                return

            # 防止死区补偿直接越界
            if 1500 + val_pos > val_max:
                QMessageBox.warning(self, "死区冲突", f"推进器 {i} 的正向起跳点 (1500+{val_pos}) 已超过安全上限 ({val_max})！")
                return
            if 1500 - val_neg < val_min:
                QMessageBox.warning(self, "死区冲突", f"推进器 {i} 的反向起跳点 (1500-{val_neg}) 已低于安全下限 ({val_min})！")
                return

            # --- 应用更新 ---
            # 确保字典结构存在
            if self.target_id not in USVProtocol.USV_CONFIGS:
                USVProtocol.USV_CONFIGS[self.target_id] = {}
            if i not in USVProtocol.USV_CONFIGS[self.target_id]:
                USVProtocol.USV_CONFIGS[self.target_id][i] = {"eps": 5} # 保留默认容差

            USVProtocol.USV_CONFIGS[self.target_id][i]["min"] = val_min
            USVProtocol.USV_CONFIGS[self.target_id][i]["max"] = val_max
            USVProtocol.USV_CONFIGS[self.target_id][i]["pos"] = val_pos
            USVProtocol.USV_CONFIGS[self.target_id][i]["neg"] = val_neg
            USVProtocol.USV_CONFIGS[self.target_id][i]["trim"] = val_trim

        QMessageBox.information(self, "配置成功", "✅ 推进器参数已动态更新并生效！\n(含 Trim 推力校准) 后续下发的控制指令将应用新的规则。")
        self.accept()
