# 文件路径: ui/dialogs/config_dialog.py
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QTabWidget, QWhatsThis,QTextEdit,
                             QWidget, QGroupBox, QLabel, QComboBox,
                             QFormLayout, QRadioButton, QHBoxLayout, QLineEdit, QMessageBox,
                             QDoubleSpinBox, QPushButton, QScrollArea)

from PyQt5.QtCore import pyqtSignal, QEvent

# 版本与项目元信息集中在工程根目录的 _version.py
try:
    from _version import (__version__, APP_NAME, APP_DESCRIPTION,
                          LICENSE_NAME, NOTICE_FILE)
except Exception:  # noqa: BLE001 - 极端情况下不要在打开配置窗时崩掉
    __version__ = "1.0.0"
    APP_NAME = "LandStation-Lite"
    APP_DESCRIPTION = "USV 双船协同控制地面站（无人船 + 浮船坞）"
    LICENSE_NAME = "GPL v3"
    NOTICE_FILE = "THIRD_PARTY_NOTICES.md"


# 「关于系统」页的正文（HTML）。许可已定：GPL v3（完整条款见根目录 LICENSE）。
ABOUT_HTML = f"""
<h2 style="margin-bottom:2px;">{APP_NAME} <span style="color:#1976D2;">v{__version__}</span></h2>
<p style="color:#555;margin-top:0;">{APP_DESCRIPTION}</p>
<hr>

<h3>这是什么</h3>
<p>
一个用于<b>双无人船协同作业</b>的地面站上位机：
同时控制一艘<b>无人船（子船）</b>和一座<b>浮船坞</b>，
支持手动摇杆 / 手柄操控、自动定艏定速、航点任务规划与航迹跟踪、
摄像头画面与目标检测、以及 Unity 数字孪生联动。
</p>

<h3>已移除的功能（相对内部完整版）</h3>
<p style="color:#777;">
为保证开源版可读、可维护，完整版中的研究性模块已移除：
MPPI 规划器、PINN-MPC / PINN-LSTM-MPC、G-NPM 跟随控制器、
ESO 环境扰动观测器、温度场重建子应用、ArUco 自动靠泊闭环、
第二关孪生地图，以及各类论文实验产物。
</p>

<h3>许可</h3>
<p>
本工程许可：<b style="color:#C62828;">{LICENSE_NAME}</b><br>
<span style="color:#777;">
采用 GPL v3 是因为本工程依赖 PyQt5 / PyQtWebEngine（GPL v3 与商业双授权中选用 GPL 版）。
完整条款见工程根目录 <code>LICENSE</code>，第三方组件许可见 <code>{NOTICE_FILE}</code>。
</span>
</p>

<h3>第三方组件</h3>
<p>详见工程根目录的 <code>{NOTICE_FILE}</code>。主要组件：</p>
<ul>
  <li>PyQt5 / PyQtWebEngine —— GPL v3 或商业授权</li>
  <li>Leaflet —— BSD-2-Clause（地图渲染，已本地化以便离线使用）</li>
  <li>pyqtgraph —— MIT</li>
  <li>OpenCV (opencv-python) —— Apache-2.0</li>
  <li>NumPy —— BSD-3-Clause</li>
  <li>pygame —— LGPL-2.1</li>
  <li>pyserial —— BSD-3-Clause</li>
  <li>Ultralytics YOLOv8 —— <b>AGPL-3.0</b>（<i>可选</i>依赖，默认不安装）</li>
</ul>

<h3>运行环境</h3>
<ul>
  <li>Python 3.10 + PyQt5 5.15 + QtWebEngine 5.15</li>
  <li>🔴 <b>请勿把工程放在中文路径下</b> —— QtWebEngine 会静默启动失败</li>
  <li>必须在工程根目录启动（手柄配置用的是相对路径）</li>
</ul>

<p style="color:#999;margin-top:24px;">
如需报告问题或了解环境搭建步骤，请阅读工程根目录的
<code>README.md</code> 与 <code>环境配置说明.md</code>。
</p>
"""


class ConfigDialog(QDialog):
    """
    ====================================================================
    ⚙️ 全局系统与算法配置弹窗 (V10.2 安全熔断版)
    职责: 负责底层算法切换、通信模式管理。
    特性: 算法切换前强制弹窗确认，触发 Monitor 自动销毁旧调参窗。
    ====================================================================
    """
    # --- 1. 定义业务信号 ---
    sig_dock_algo_changed = pyqtSignal(str)  
    sig_boat_algo_changed = pyqtSignal(str)  
    sig_dock_nav_algo_changed = pyqtSignal(str)
    sig_boat_nav_algo_changed = pyqtSignal(str)
    sig_dock_nav_cruise_req = pyqtSignal(float)  # 船坞 P2P/LOS 领航巡航速度
    sig_boat_nav_cruise_req = pyqtSignal(float)  # 子船 P2P/LOS 领航巡航速度
    sig_comm_mode_changed = pyqtSignal(str)  
    sig_imu_deadband_req = pyqtSignal(float, float)  # (dock死区, boat死区) 单位 °/s
    def event(self, event):
        if event.type() == QEvent.EnterWhatsThisMode:
            QWhatsThis.leaveWhatsThisMode() 
            
            if self.help_panel.isVisible():
                # --- 关闭备忘录模式 ---
                self.help_panel.hide()
                # 关键：直接恢复到最初记录的宽度
                self.setFixedWidth(self.normal_width)
            else:
                # --- 打开备忘录模式 ---
                # 先记录一下关闭前的宽度（万一用户手动拉大过窗口）
                if not self.help_panel.isVisible():
                    self.normal_width = self.width()
                
                self.help_panel.show()
                # 扩展宽度：原宽度 + 备忘录宽度 + 布局间距
                self.setFixedWidth(self.normal_width + self.help_panel.width() + self.root_layout.spacing())
            
            return True
        return super().event(event)


    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("⚙️ 全局系统与算法配置")
        self.resize(550, 500)
        
        self.setModal(False) 

        # 💡 [核心新增] 缓存切换前的算法名称，用于用户取消时回滚
        self.last_dock_algo = "PID 经典控制"
        self.last_boat_algo = "PID 经典控制"

        # 1. 创建最底层的水平布局 (为了能横向伸缩)
        self.root_layout = QHBoxLayout(self)

        # 2. 将原有的 Tab 内容包裹在一个 Widget 里，作为左侧主体
        self.main_content = QWidget()
        self.content_layout = QVBoxLayout(self.main_content)
        self.tabs = QTabWidget()
        self.content_layout.addWidget(self.tabs)
        
        # 3. 创建右侧的帮助面板 (默认隐藏)
        self._init_side_help_panel()

        # 4. 把主体和帮助面板按顺序加入底层布局
        self.root_layout.addWidget(self.main_content)
        self.root_layout.addWidget(self.help_panel)

        # --- 2. 组装页面 ---
        self._init_algo_tab()     # 第1页：算法配置
        self._init_comm_tab()     # 第2页：通信配置
        self._init_dummy_tabs()   # 预留页面
        # [新增] 记录初始宽度，防止回缩时挤压 UI
        self.normal_width = self.width()
    def _init_side_help_panel(self):
        """初始化隐藏在右侧的备忘录面板"""
        self.help_panel = QGroupBox("📋 网络地址备忘录")
        self.help_panel.setFixedWidth(220) # 固定宽度，防止伸缩时变形
        help_v_layout = QVBoxLayout(self.help_panel)

        # 使用 QTextEdit 而不是 QLabel，因为它支持鼠标选择和复制
        self.memo_box = QTextEdit()
        self.memo_box.setReadOnly(True)  # 只读模式
        self.memo_box.setHtml(
            "<b style='color:#2196F3;'>仿真模式,智杰账号下：<br>"
            "<b style='color:#2196F3;'>服务器IP::</b><br>100.118.68.119<br>"
            "<b style='color:#4CAF50;'>监听船坞:8080;控制船坞:8081<br>"
            "<b style='color:#FF9800;'>监听船:8889;控制船:8888<br>"
            "<hr><i>💡 选中上方文字可直接 Ctrl+C 复制</i>"
        )
        
        help_v_layout.addWidget(self.memo_box)
        self.help_panel.hide() # 初始状态是隐藏的
    def _init_algo_tab(self):
        """第 1 页：算法配置 (落实安全拦截逻辑)"""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        tab_widget = QWidget()
        layout = QVBoxLayout(tab_widget)

        # ====== 1. 船坞闭环策略配置 ======
        dock_group = QGroupBox("▼ 1号端：船坞 (Dock) 闭环策略大脑")
        dock_layout = QFormLayout(dock_group)
        self.dock_combo_algo = QComboBox()
        self.dock_combo_algo.addItems([
            "PID 经典控制",
            "SMC 滑模控制 (预留)",
        ])
        # 💡 [修改] 拦截直接发射信号，改为先经过安全确认
        self.dock_combo_algo.currentTextChanged.connect(self._on_dock_algo_requested)
        dock_layout.addRow("🧠 决策算法选择:", self.dock_combo_algo)
        layout.addWidget(dock_group)

        # ====== 2. 子船闭环策略配置 ======
        boat_group = QGroupBox("▼ 2号端：无人船 (USV) 闭环策略大脑")
        boat_layout = QFormLayout(boat_group)
        self.boat_combo_algo = QComboBox()
        self.boat_combo_algo.addItems(["PID 经典控制", "SMC 滑模控制 (预留)"])
        # 💡 [修改] 拦截直接发射信号
        self.boat_combo_algo.currentTextChanged.connect(self._on_boat_algo_requested)
        boat_layout.addRow("🧠 决策算法选择:", self.boat_combo_algo)
        layout.addWidget(boat_group)

        # ====== 3. 全局路径跟踪算法 (领航引擎) ======
        nav_group = QGroupBox("🧭 全局路径跟踪算法 (高级领航)")
        nav_layout = QFormLayout(nav_group)
        self.combo_dock_nav_algo = QComboBox()
        self.combo_dock_nav_algo.addItems(["基础直达 (P2P)", "高级视线制导 (LOS)"])
        self.combo_dock_nav_algo.currentTextChanged.connect(self.sig_dock_nav_algo_changed.emit)

        self.combo_boat_nav_algo = QComboBox()
        self.combo_boat_nav_algo.addItems(["基础直达 (P2P)", "高级视线制导 (LOS)"])
        self.combo_boat_nav_algo.currentTextChanged.connect(self.sig_boat_nav_algo_changed.emit)

        nav_layout.addRow("1号端(船坞) 循迹算法:", self.combo_dock_nav_algo)
        nav_layout.addRow("2号端(子船) 循迹算法:", self.combo_boat_nav_algo)

        # --- 巡航速度配置 (P2P/LOS 领航默认速度，点“应用”生效) ---
        self.spin_dock_cruise = QDoubleSpinBox()
        self.spin_dock_cruise.setRange(0.0, 0.5)
        self.spin_dock_cruise.setSingleStep(0.01)
        self.spin_dock_cruise.setDecimals(2)
        self.spin_dock_cruise.setValue(0.30)
        self.spin_dock_cruise.setSuffix(" m/s")
        self.spin_boat_cruise = QDoubleSpinBox()
        self.spin_boat_cruise.setRange(0.0, 0.5)
        self.spin_boat_cruise.setSingleStep(0.01)
        self.spin_boat_cruise.setDecimals(2)
        self.spin_boat_cruise.setValue(0.30)
        self.spin_boat_cruise.setSuffix(" m/s")
        self.btn_apply_cruise = QPushButton("应用巡航速度")
        self.btn_apply_cruise.clicked.connect(self._on_cruise_apply)
        self.lbl_cruise_status = QLabel("范围 0–0.5 m/s（受领航器上限约束）")
        self.lbl_cruise_status.setStyleSheet("color:#777;")

        nav_layout.addRow("1号端(船坞) 巡航速度:", self.spin_dock_cruise)
        nav_layout.addRow("2号端(子船) 巡航速度:", self.spin_boat_cruise)
        cruise_row = QHBoxLayout()
        cruise_row.addWidget(self.btn_apply_cruise)
        cruise_row.addWidget(self.lbl_cruise_status)
        cruise_row.addStretch(1)
        nav_layout.addRow("", cruise_row)
        layout.addWidget(nav_group)

        # ====== 4. 陀螺仪角速度积分死区配置 ======
        imu_group = QGroupBox("〰 IMU 角速度积分死区 (°/s)")
        imu_layout = QVBoxLayout(imu_group)
        ctrl_row = QHBoxLayout()
        ctrl_row.addWidget(QLabel("船坞死区:"))
        self.spin_dock_deadband = QDoubleSpinBox()
        self.spin_dock_deadband.setRange(0.0, 2.0)
        self.spin_dock_deadband.setSingleStep(0.01)
        self.spin_dock_deadband.setDecimals(2)
        self.spin_dock_deadband.setValue(1.0)
        ctrl_row.addWidget(self.spin_dock_deadband)
        ctrl_row.addWidget(QLabel("子船死区:"))
        self.spin_boat_deadband = QDoubleSpinBox()
        self.spin_boat_deadband.setRange(0.0, 2.0)
        self.spin_boat_deadband.setSingleStep(0.01)
        self.spin_boat_deadband.setDecimals(2)
        self.spin_boat_deadband.setValue(1.0)
        ctrl_row.addWidget(self.spin_boat_deadband)
        self.btn_apply_deadband = QPushButton("确认配置")
        self.btn_apply_deadband.clicked.connect(self._on_deadband_apply)
        ctrl_row.addWidget(self.btn_apply_deadband)
        ctrl_row.addStretch(1)
        imu_layout.addLayout(ctrl_row)
        self.lbl_deadband_status = QLabel("")
        self.lbl_deadband_status.setStyleSheet("color: #4CAF50; font-weight: bold;")
        imu_layout.addWidget(self.lbl_deadband_status)
        layout.addWidget(imu_group)

        layout.addStretch(1)
        scroll.setWidget(tab_widget)
        self.tabs.addTab(scroll, "🧠 算法配置")

    # ==========================================
    # 🛡️ 安全切换逻辑 (核心新增)
    # ==========================================
    def _on_dock_algo_requested(self, new_algo):
        """船坞算法切换前的安全审计"""
        if new_algo == self.last_dock_algo: return

        reply = QMessageBox.question(
            self, "算法切换安全确认",
            f"⚠️ 确定将【船坞】控制算法切换为【{new_algo}】吗？\n\n为了防止参数误设，当前的实时调参窗口将自动关闭。",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.last_dock_algo = new_algo
            self.sig_dock_algo_changed.emit(new_algo) # 发射信号，触发 Controller 和 Monitor 的关闭逻辑
        else:
            # 用户拒绝：回滚 ComboBox 显示，且不触发信号
            self.dock_combo_algo.blockSignals(True)
            self.dock_combo_algo.setCurrentText(self.last_dock_algo)
            self.dock_combo_algo.blockSignals(False)

    def _on_boat_algo_requested(self, new_algo):
        """子船算法切换前的安全审计"""
        if new_algo == self.last_boat_algo: return

        reply = QMessageBox.question(
            self, "算法切换安全确认",
            f"⚠️ 确定将【子船】控制算法切换为【{new_algo}】吗？\n\n为了防止参数误设，当前的实时调参窗口将自动关闭。",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.last_boat_algo = new_algo
            self.sig_boat_algo_changed.emit(new_algo)
        else:
            self.boat_combo_algo.blockSignals(True)
            self.boat_combo_algo.setCurrentText(self.last_boat_algo)
            self.boat_combo_algo.blockSignals(False)

    # ==========================================
    # 📡 通信配置与其他页面 (保持 1:1 兼容)
    # ==========================================
    def _init_comm_tab(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        tab_widget = QWidget()
        layout = QVBoxLayout(tab_widget)
        mode_group = QGroupBox("🌐 全局运行模式选择")
        mode_layout = QHBoxLayout(mode_group)
        self.radio_serial = QRadioButton("🔌 真实硬件模式")
        self.radio_network = QRadioButton("🧪 仿真模拟模式")
        self.radio_serial.setChecked(True)
        mode_layout.addWidget(self.radio_serial)
        mode_layout.addWidget(self.radio_network)
        layout.addWidget(mode_group)

        self.net_group = QGroupBox("🔗 仿真/网络参数配置 (UDP)")
        net_layout = QVBoxLayout(self.net_group)
        
        # 船坞节点
        dock_net_group = QGroupBox("▼ 1号端：船坞 (Dock) 节点配置")
        d_lay = QFormLayout(dock_net_group)
        self.dock_ip_input = QLineEdit("100.86.158.35")
        self.dock_port_tx = QLineEdit("8881")
        self.dock_port_rx = QLineEdit("9993")
        self.dock_port_video = QLineEdit("9991")
        d_lay.addRow("目标 IP:", self.dock_ip_input)
        d_lay.addRow("指令下发端口 (TX):", self.dock_port_tx)
        d_lay.addRow("回传监听端口 (RX):", self.dock_port_rx)
        d_lay.addRow("视频接收端口 (Video):", self.dock_port_video)
        net_layout.addWidget(dock_net_group)

        # 子船节点
        boat_net_group = QGroupBox("▼ 2号端：无人船 (USV) 节点配置")
        b_lay = QFormLayout(boat_net_group)
        self.boat_ip_input = QLineEdit("100.114.50.101")
        self.boat_port_tx = QLineEdit("8882")
        self.boat_port_rx = QLineEdit("9994")
        self.boat_port_video = QLineEdit("9992")
        b_lay.addRow("目标 IP:", self.boat_ip_input)
        b_lay.addRow("指令下发端口 (TX):", self.boat_port_tx)
        b_lay.addRow("回传监听端口 (RX):", self.boat_port_rx)
        b_lay.addRow("视频接收端口 (Video):", self.boat_port_video)
        net_layout.addWidget(boat_net_group)

        layout.addWidget(self.net_group)
        layout.addStretch(1)
        scroll.setWidget(tab_widget)
        self.tabs.addTab(scroll, "📡 通信配置")
        self.radio_serial.toggled.connect(self._on_mode_toggled)

    def _on_mode_toggled(self, checked):
        """
        核心逻辑：切换运行模式时，自动填充对应的默认端口（IP 除外）
        """
        # 1. 判定当前选中的模式状态
        is_simulation = self.radio_network.isChecked()
        mode_str = 'network' if is_simulation else 'serial'

        # 2. 根据模式自动填充预设端口 (严格遵循备忘录与硬件默认值)
        if is_simulation:
            # 🧪 仿真模式默认值 (端口对齐备忘录)
            self.dock_ip_input.setText("127.0.0.1")
            self.boat_ip_input.setText("127.0.0.1")
            self.dock_port_tx.setText("8081")  # 控制船坞
            self.dock_port_rx.setText("8080")  # 监听船坞
            self.boat_port_tx.setText("8888")  # 控制船
            self.boat_port_rx.setText("8889")  # 监听船
            self.dock_port_video.setText("5001") # 仿真视频端口（船坞）
            self.boat_port_video.setText("5003") # 仿真视频端口（子船）
        else:
            # 🔌 真实硬件默认值 (还原初始化设定)
            self.dock_port_tx.setText("8881")
            self.dock_port_rx.setText("9993")
            self.boat_port_tx.setText("8882")
            self.boat_port_rx.setText("9994")
            self.dock_port_video.setText("9991")
            self.boat_port_video.setText("9992")
        
        # 3. 发送信号通知 MainWindow 切换路由
        self.sig_comm_mode_changed.emit(mode_str)

    def _init_dummy_tabs(self):
        # 「ℹ️ 关于系统」是真实内容页；「📄 系统日志」仍是预留页。
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(QLabel("【📄 系统日志】功能正在开发中..."))
        self.tabs.addTab(widget, "📄 系统日志")

        self.tabs.addTab(self._build_about_tab(), "ℹ️ 关于系统")

    def _build_about_tab(self):
        """ℹ️ 关于系统：版本号 / 许可 / 第三方组件 / 致谢。

        许可已定为 GPL v3（方案 A，因 PyQt5 采用 GPL v3 与商业双授权）。
        显示值来自 _version.LICENSE_NAME；完整条款见工程根目录 LICENSE。
        """
        widget = QWidget()
        outer = QVBoxLayout(widget)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        inner = QWidget()
        layout = QVBoxLayout(inner)

        info = QTextEdit()
        info.setReadOnly(True)
        info.setHtml(ABOUT_HTML)
        layout.addWidget(info)
        layout.addStretch()

        scroll.setWidget(inner)
        outer.addWidget(scroll)
        return widget

    def _on_cruise_apply(self):
        """读取两端巡航速度并分别发射信号，由各自 Controller 转给领航器。"""
        dock_speed = self.spin_dock_cruise.value()
        boat_speed = self.spin_boat_cruise.value()
        self.sig_dock_nav_cruise_req.emit(dock_speed)
        self.sig_boat_nav_cruise_req.emit(boat_speed)
        self.lbl_cruise_status.setText(
            f"已应用：船坞 {dock_speed:.2f} m/s · 子船 {boat_speed:.2f} m/s"
        )
        self.lbl_cruise_status.setStyleSheet("color:#4CAF50; font-weight:bold;")

    def _on_deadband_apply(self):
        """发射 IMU 死区配置信号"""
        dock_val = self.spin_dock_deadband.value()
        boat_val = self.spin_boat_deadband.value()
        self.sig_imu_deadband_req.emit(dock_val, boat_val)
        self.lbl_deadband_status.setText(
            f"已下发: 船坞 {dock_val:.2f} °/s (9字节), 子船 {boat_val:.2f} °/s (9字节)"
        )

