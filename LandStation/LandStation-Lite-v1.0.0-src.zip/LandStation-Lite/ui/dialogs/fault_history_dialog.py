"""船坞/子船通用故障历史窗口。"""

from __future__ import annotations

import csv
from datetime import datetime
from typing import Any, Dict, List, Optional

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QHeaderView,
)


SOURCE_LABELS = {
    "mcu": "MCU",
    "mcu_link": "MCU链路",
    "raspberry_pi": "树莓派",
    "4g": "4G",
}

# 表格最多展示的记录条数,防止故障历史过多时重绘阻塞 UI
MAX_DISPLAY_RECORDS = 1000


class FaultHistoryDialog(QDialog):
    refresh_requested = pyqtSignal()
    clear_requested = pyqtSignal()

    def __init__(self, device_name: str, parent=None):
        super().__init__(parent)
        self.device_name = device_name
        self._events: List[Dict[str, Any]] = []
        self._records: List[Dict[str, Any]] = []
        self._dirty = False

        self.setWindowTitle(f"{device_name} - 故障历史")
        self.resize(1050, 560)
        layout = QVBoxLayout(self)

        toolbar = QHBoxLayout()
        self.lbl_summary = QLabel("尚未同步故障历史")
        self.combo_filter = QComboBox()
        self.combo_filter.addItem("全部记录", "all")
        self.combo_filter.addItem("当前故障", "active")
        self.combo_filter.addItem("已恢复", "recovered")
        self.combo_filter.addItem("异常事件", "event")
        self.btn_refresh = QPushButton("🔄 立即同步")
        self.btn_export = QPushButton("导出 CSV")
        self.btn_clear = QPushButton("🗑 清空故障历史")
        toolbar.addWidget(self.lbl_summary)
        toolbar.addStretch()
        toolbar.addWidget(QLabel("筛选:"))
        toolbar.addWidget(self.combo_filter)
        toolbar.addWidget(self.btn_refresh)
        toolbar.addWidget(self.btn_export)
        toolbar.addWidget(self.btn_clear)
        layout.addLayout(toolbar)

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            ["状态", "来源", "故障类型", "发生时间", "恢复时间", "持续时间", "详情"]
        )
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setTextElideMode(Qt.ElideRight)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setSectionResizeMode(6, QHeaderView.Stretch)
        for column, width in enumerate((110, 90, 170, 150, 150, 100)):
            self.table.setColumnWidth(column, width)
        layout.addWidget(self.table)

        close_button = QPushButton("关闭")
        close_button.clicked.connect(self.close)
        bottom = QHBoxLayout()
        bottom.addStretch()
        bottom.addWidget(close_button)
        layout.addLayout(bottom)

        self.combo_filter.currentIndexChanged.connect(self._refresh_table)
        self.btn_refresh.clicked.connect(self.refresh_requested.emit)
        self.btn_export.clicked.connect(self._export_csv)
        self.btn_clear.clicked.connect(self._confirm_clear)

    @staticmethod
    def _parse_time(value: str) -> Optional[datetime]:
        if not value:
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None

    @classmethod
    def _format_time(cls, value: str) -> str:
        parsed = cls._parse_time(value)
        if parsed is None:
            return value or "—"
        return parsed.astimezone().strftime("%Y-%m-%d %H:%M:%S")

    @classmethod
    def _duration_text(cls, start: str, end: str) -> str:
        start_dt = cls._parse_time(start)
        end_dt = cls._parse_time(end)
        if start_dt is None or end_dt is None:
            return "—"
        seconds = max(0, int((end_dt - start_dt).total_seconds()))
        if seconds < 60:
            return f"{seconds}秒"
        minutes, seconds = divmod(seconds, 60)
        if minutes < 60:
            return f"{minutes}分{seconds}秒"
        hours, minutes = divmod(minutes, 60)
        return f"{hours}时{minutes}分"

    @staticmethod
    def _detail_text(event: Dict[str, Any]) -> str:
        detail = event.get("detail") or {}
        if isinstance(detail, dict):
            message = detail.get("message")
            extras = [
                f"{key}={value}"
                for key, value in detail.items()
                if key != "message" and value not in (None, "", [], {})
            ]
            parts = ([str(message)] if message else []) + extras
            return "；".join(parts) or "—"
        return str(detail)

    def _pair_events(self) -> List[Dict[str, Any]]:
        pending: Dict[str, Dict[str, Any]] = {}
        records: List[Dict[str, Any]] = []

        for event in self._events:
            source = str(event.get("source", "unknown"))
            event_type = str(event.get("event_type", ""))
            state = str(event.get("state", "event"))
            if event_type == "fault_transition" and state == "occurred":
                if source in pending:
                    previous = pending[source]
                    records.append(self._make_record(previous, None, "active"))
                pending[source] = event
            elif event_type == "fault_transition" and state == "recovered":
                started = pending.pop(source, None)
                records.append(self._make_record(started or event, event, "recovered"))
            elif event_type.startswith("unexpected_"):
                records.append(self._make_record(event, None, "event"))

        for event in pending.values():
            records.append(self._make_record(event, None, "active"))

        records.sort(key=lambda item: item.get("sort_time", ""), reverse=True)
        return records

    def _make_record(
        self,
        started: Dict[str, Any],
        recovered: Optional[Dict[str, Any]],
        status: str,
    ) -> Dict[str, Any]:
        source = str(started.get("source", "unknown"))
        event_type = str(started.get("event_type", ""))
        if event_type.startswith("unexpected_"):
            fault_type = {
                "unexpected_system_restart": "异常重启/掉电",
                "unexpected_logger_restart": "日志服务异常重启",
            }.get(event_type, event_type)
        else:
            fault_type = {
                "mcu": "MCU主动上报故障",
                "mcu_link": "MCU遥测中断/疑似掉电",
                "raspberry_pi": "树莓派系统故障",
                "4g": "4G/Tailscale故障",
            }.get(source, f"故障码 {started.get('fault_code', 0)}")

        start_time = str(started.get("event_time_utc", ""))
        end_time = str(recovered.get("event_time_utc", "")) if recovered else ""
        detail = self._detail_text(started)
        if recovered:
            recovery_detail = self._detail_text(recovered)
            if recovery_detail != "—":
                detail += f"；恢复信息: {recovery_detail}"
        return {
            "status": status,
            "source": SOURCE_LABELS.get(source, source),
            "fault_type": fault_type,
            "start": self._format_time(start_time),
            "end": self._format_time(end_time) if end_time else "—",
            "duration": self._duration_text(start_time, end_time) if end_time else "—",
            "detail": detail,
            "sort_time": start_time,
        }

    def set_events(self, events: List[Dict[str, Any]]) -> None:
        self._events = list(events or [])
        self._records = self._pair_events()
        total = len(self._records)
        active_count = sum(1 for item in self._records if item["status"] == "active")
        note = (
            f"；仅显示最近 {MAX_DISPLAY_RECORDS} 条"
            if total > MAX_DISPLAY_RECORDS
            else ""
        )
        self.lbl_summary.setText(
            f"共 {total} 条故障记录，当前故障 {active_count} 条{note}"
        )
        self._refresh_table()

    def set_sync_error(self, message: str) -> None:
        self.lbl_summary.setText(f"⚠ 同步失败：{message}")

    def _filtered_records(self) -> List[Dict[str, Any]]:
        selected = self.combo_filter.currentData()
        if selected == "all":
            return list(self._records)
        return [item for item in self._records if item["status"] == selected]

    def _rebuild_table(self) -> None:
        records = self._filtered_records()[:MAX_DISPLAY_RECORDS]
        status_map = {
            "active": ("❌ 当前故障", QColor("#c62828")),
            "recovered": ("✅ 已恢复", QColor("#2e7d32")),
            "event": ("⚠ 异常事件", QColor("#ef6c00")),
        }
        self.table.setUpdatesEnabled(False)
        self.table.blockSignals(True)
        try:
            self.table.setRowCount(len(records))
            for row, record in enumerate(records):
                status_text, color = status_map.get(
                    record["status"], (record["status"], QColor("#555555"))
                )
                values = [
                    status_text,
                    record["source"],
                    record["fault_type"],
                    record["start"],
                    record["end"],
                    record["duration"],
                    record["detail"],
                ]
                for column, value in enumerate(values):
                    item = QTableWidgetItem(str(value))
                    if column == 6:
                        item.setToolTip(str(value))
                    if column == 0:
                        item.setForeground(color)
                        item.setTextAlignment(Qt.AlignCenter)
                    self.table.setItem(row, column, item)
        finally:
            self.table.blockSignals(False)
            self.table.setUpdatesEnabled(True)

    def _refresh_table(self) -> None:
        """仅当窗口可见时才重建表格;隐藏时标记脏,等 showEvent 再刷。"""
        if not self.isVisible():
            self._dirty = True
            return
        self._rebuild_table()

    def showEvent(self, event) -> None:
        if self._dirty:
            self._dirty = False
            self._rebuild_table()
        super().showEvent(event)

    def _confirm_clear(self) -> None:
        reply = QMessageBox.question(
            self,
            "清空故障历史",
            "确定要清空本设备的故障历史吗?\n"
            "(仅清空上位机本地缓存,树莓派端数据不受影响)",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self.clear_requested.emit()

    def _export_csv(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self,
            "导出故障历史",
            f"{self.device_name}_fault_history.csv",
            "CSV 文件 (*.csv)",
        )
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            writer.writerow(["状态", "来源", "故障类型", "发生时间", "恢复时间", "持续时间", "详情"])
            for record in self._filtered_records():
                writer.writerow(
                    [
                        record["status"],
                        record["source"],
                        record["fault_type"],
                        record["start"],
                        record["end"],
                        record["duration"],
                        record["detail"],
                    ]
                )
