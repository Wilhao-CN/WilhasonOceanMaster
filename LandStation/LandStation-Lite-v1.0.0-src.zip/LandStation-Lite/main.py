"""USV 双船协同控制地面站 —— 启动入口。

Qt 环境变量这里全部改成「自动定位」，不再写死某一台电脑的绝对路径：
只要 PyQt5 / PyQtWebEngine 装在当前解释器里，就能自己找到 QtWebEngineProcess、
resources、translations 和 plugins。
"""

import os
import sys

os.environ.setdefault('KMP_DUPLICATE_LIB_OK', 'True')

# 💡 中文 Windows 控制台默认是 GBK(cp936)，而全项目有大量 emoji 日志
# （⚠️/✅/❌/🚀 ...）。这些字符在 GBK 下编码失败，会直接抛 UnicodeEncodeError
# 把启动流程打断（例如 vision/algorithms/yolo_v8/yolo_impl.py 的告警行）。
# 这里同时做两件事：
#   1) PYTHONIOENCODING 让本进程 + multiprocessing 子进程都用 UTF-8；
#   2) 直接把当前 stdout/stderr 重定向成 UTF-8，兼容被 IDE/终端重定向的情况。
os.environ.setdefault('PYTHONIOENCODING', 'utf-8')
for _stream_name in ('stdout', 'stderr'):
    _stream = getattr(sys, _stream_name, None)
    if _stream is not None and hasattr(_stream, 'reconfigure'):
        try:
            _stream.reconfigure(encoding='utf-8', errors='replace')
        except (ValueError, OSError):
            pass

# 💡 核心修复：解决中文路径识别与资源丢失问题
base_dir = os.path.dirname(os.path.abspath(__file__))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)


def _configure_qt_webengine() -> None:
    """自动定位 PyQt5 自带的 Qt5 目录并注入 QtWebEngine 需要的环境变量。

    早期的写法是把 qt5_dir 写死成 `C:\\Users\\<某人>\\...\\Python312\\...\\PyQt5\\Qt5`，
    换一台电脑就必然失效（QTWEBENGINEPROCESS_PATH / resources / locales 全部指向不
    存在的路径，地图控件起不来）。这里改成按 importlib 查真实安装位置。
    """
    try:
        import importlib.util

        spec = importlib.util.find_spec("PyQt5")
    except Exception as exc:  # pragma: no cover - 只在 PyQt5 缺失时触发
        print(f"[启动] 无法定位 PyQt5：{exc}")
        return

    if spec is None or not spec.origin:
        print("[启动] 未找到 PyQt5，请先执行：pip install -r requirements.txt")
        return

    # PyQt5/__init__.py -> PyQt5/Qt5
    qt5_dir = os.path.join(os.path.dirname(spec.origin), "Qt5")
    if not os.path.isdir(qt5_dir):
        # 少数安装方式把 Qt5 放在父级 site-packages 下
        qt5_dir = os.path.join(os.path.dirname(os.path.dirname(spec.origin)), "Qt5")
    if not os.path.isdir(qt5_dir):
        print(f"[启动] 未找到 Qt5 资源目录（期望位置：{qt5_dir}），地图控件可能不可用")
        return

    bin_dir = os.path.join(qt5_dir, "bin")
    resources_dir = os.path.join(qt5_dir, "resources")
    locales_dir = os.path.join(qt5_dir, "translations", "qtwebengine_locales")
    plugins_dir = os.path.join(qt5_dir, "plugins")

    # 1. 执行进程路径（解决 QtWebEngineProcess 启动失败）
    webengine_path = os.path.join(bin_dir, "QtWebEngineProcess.exe")
    os.environ["QTWEBENGINEPROCESS_PATH"] = webengine_path
    os.putenv("QTWEBENGINEPROCESS_PATH", webengine_path)  # 强制写入底层

    # 2. 窗口插件路径（解决 windows 平台插件报错）
    os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = plugins_dir

    # 3. 资源包路径（解决 "resources not found"）
    os.environ["QTWEBENGINE_RESOURCES_PATH"] = resources_dir

    # 4. 语言包路径（解决 "locales directory not found"）
    os.environ["QTWEBENGINE_LOCALES_PATH"] = locales_dir

    # 5. QtWebEngine 会把缓存写到 %LOCALAPPDATA%；路径含中文/无权限时改用工程内目录
    cache_dir = os.path.join(base_dir, "data_logs", ".qtwebengine_cache")
    if "QTWEBENGINE_DISK_CACHE_DIR" not in os.environ:
        try:
            os.makedirs(cache_dir, exist_ok=True)
            os.environ["QTWEBENGINE_DISK_CACHE_DIR"] = cache_dir
        except OSError:
            pass

    # 6. dll 搜索路径（解决 ICU data / ffmpeg 找不到）
    os.environ["PATH"] = bin_dir + os.pathsep + os.environ.get("PATH", "")


# 必须在设置完所有环境变量后，再导入 PyQt5 相关模块
_configure_qt_webengine()

# ⚠️ 请始终在工程根目录下启动（start_groundstation.bat 已 `cd /d %~dp0`）：
# core/Managers/joystick_manager.py 用的是相对路径 "config/joystick_mapping.json"，
# 在别处启动会新建一个空的 config 目录，手柄映射就丢了。

from PyQt5.QtCore import Qt, QCoreApplication  # noqa: E402
from PyQt5.QtWidgets import QApplication  # noqa: E402
from ui.main_window import USVGroundStation  # noqa: E402

# ============================================================================
# 🔴 [关键修复] QtWebEngine 必须在 QApplication 创建【之前】声明共享 OpenGL 上下文
# ============================================================================
# 症状（实测）：
#     地图区域完全空白，且**没有任何报错**。渲染进程探针给出
#         ❌❌ 渲染进程终止! status=-1 exitCode=18
#     `exitCode=18` 就是 Chromium 的 RESULT_CODE_KILLED_BAD_MESSAGE
#     （渲染进程收到非法 IPC 消息被杀）—— QtWebEngine 典型的初始化失败。
#
# 原因：
#     使用 QWebEngineView 时，Qt 要求进程级设置 AA_ShareOpenGLContexts，
#     否则 QtWebEngine 的 GPU/渲染子进程 channel 建立失败并崩溃。
#     本工程自己的校验脚本（Tools/verify_map_html.py、verify_t9_logging.py、
#     verify_twin_logic.py、_baseline/ui_baseline.py）**都设了这个属性**，
#     唯独正式入口 main.py 漏了 —— 所以校验全过、真机地图却是空白。
#
# 注意：必须在 QApplication 实例化之前调用，之后再设无效。
# ============================================================================
try:
    QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
    print("[启动] 已设置 Qt.AA_ShareOpenGLContexts（QtWebEngine 必需）")
except Exception as _exc:  # noqa: BLE001 - 属性设置失败不应阻断启动
    print(f"[启动] ⚠ 设置 AA_ShareOpenGLContexts 失败: {_exc}")


def main():
    # 实例化 QApplication
    app = QApplication(sys.argv)

    # 设置全局样式表
    app.setStyleSheet("""
        QGroupBox { font-weight: bold; border: 1px solid #ccc; border-radius: 5px; margin-top: 1ex; }
        QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 3px; }
        QPushButton { padding: 5px; }
    """)

    # 实例化并显示主窗口
    window = USVGroundStation()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
