# LandStation-Lite

**USV 双船协同控制地面站** —— 同时控制一艘**无人船（子船）**和一座**浮船坞**的上位机。

支持手动摇杆 / 物理手柄操控、自动定艏定速、航点任务规划与航迹跟踪、摄像头画面与目标检测、
以及 **Unity 数字孪生**联动（2D 正交底图 + 3D 实时画面）。

---

## ⚠️ 三条必读（不遵守就起不来）

| # | 规则 | 为什么 |
|---|---|---|
| 1 | 🔴 **工程路径必须纯 ASCII**，例如 `D:\LandStation-Lite`<br>**不要**放在 `D:\我的项目\地面站` 这类中文路径下 | QtWebEngine 读取中文路径会失败，**静默打不开地图**（退出码 `0x80000003`），且**不报错** |
| 2 | 🔴 **必须在工程根目录启动** | 手柄配置用的是相对路径 `config/joystick_mapping.json`，换目录会新建空配置、手柄映射丢失 |
| 3 | 🔴 首次运行前先跑一次环境自检 | 见下面的「快速开始」第 4 步 |

> **本仓库的目录名 `LandStation Lite` 含空格是允许的**（已验证），但**中文绝对不行**。

---

## 这是什么

```
┌──────────────────────────────────────────────────────────────┐
│                     LandStation-Lite                         │
│                                                              │
│   任务规划中心        ┌─────────────┐        遥测 / 曲线      │
│   （打点/巡线）  ←→   │  地图 + 孪生  │  ←→    （示波器）       │
│                      └─────────────┘                         │
│         ↓                    ↓                   ↓           │
│   ┌───────────────┐   ┌───────────────┐   ┌──────────────┐  │
│   │ 船坞控制器      │   │ 子船控制器     │   │ 视觉进程      │  │
│   │ (独立 QThread)  │   │ (独立 QThread) │   │ (独立进程)    │  │
│   └───────────────┘   └───────────────┘   └──────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**保留的核心能力**：

- **数字孪生**：Unity 正交俯视底图（2D）、3D 实时画面（端口 5002）
- **状态面板**：两船遥测、故障状态、链路延迟
- **摄像头画面**：真实视频 + 可选 YOLO 目标检测（NOF 浮标识别与视觉居中）
- **任务规划**：地图打点、巡线、任务保存/导入导出
- **遥测显示**：实时曲线、CSV 落盘
- **手柄 / 虚拟摇杆**：物理手柄配对、虚拟摇杆操控
- **安全急停**：全局紧急停机（独立于其它一切逻辑）

**已移除的研究性模块**（为让开源版可读可维护）：

> MPPI 规划器 · PINN-MPC / PINN-LSTM-MPC · G-NPM 跟随控制器 · ESO 环境扰动观测器 ·
> 温度场重建子应用 · ArUco 自动靠泊闭环 · 第二关孪生地图 · 各类论文实验产物

> ℹ️ 注意区分：**「NOF 视觉居中」保留了**（用 YOLO 检出的大框做转向伺服）；
> 删除的是 **ArUco 四码识别 + PnP + 自动靠泊闭环**。

---

## 快速开始

### 1. 准备 Python 3.10

```bat
py -3.10 --version
```

没有的话从 [python.org](https://www.python.org/downloads/release/python-31011/) 装一个。

### 2. 创建虚拟环境

```bat
cd /d D:\LandStation-Lite
py -3.10 -m venv venv_usv
```

### 3. 安装依赖

```bat
venv_usv\Scripts\python.exe -m pip install -r requirements.txt
```

国内网络慢的话加镜像：

```bat
venv_usv\Scripts\python.exe -m pip install -r requirements.txt ^
    -i https://pypi.tuna.tsinghua.edu.cn/simple ^
    --trusted-host pypi.tuna.tsinghua.edu.cn
```

### 4. 环境自检（**别跳过**）

```bat
venv_usv\Scripts\python.exe Tools\check_env.py
```

看到 `✅ 环境自检通过` 才算配好。它会逐个检查依赖、Qt 平台插件链、以及主窗口能否导入。

### 5. 启动

**双击 `start_groundstation.bat`** 即可。

> Windows 可能弹一次"无法验证发布者"——这是对**未签名 `.bat`** 的常规提示，点 **"运行(R)"**。

---

## 可选依赖：YOLO 目标检测

**默认不装**深度学习框架。不装也能正常启动，只是视觉窗口里的「🚀 YOLO 目标检测」勾选框会加载失败
（控制台给出一行提示，不影响其它功能）。

要启用（NOF 浮标识别 / 视觉居中 / 目标框选）：

```bat
venv_usv\Scripts\python.exe -m pip install -r requirements-optional.txt
```

> ⚠️ **Ultralytics 采用 AGPL-3.0 许可**。只在本机/内部使用无影响；若要**对外发布或作为网络服务提供**，
> AGPL 的传染性条款可能要求你一并开源。**发布前请与导师/法务确认。**
> 详见 `THIRD_PARTY_NOTICES.md`。

---

## 端口一览

| 用途 | 船坞 | 子船 |
|---|---|---|
| **指令下发 (TX)** | 8881 | 8882 |
| **回传监听 (RX)** | 9993 | 9994 |
| **视频接收** | 9991 | 9992 |

| 用途 | 端口 |
|---|---|
| 孪生视频 · 船坞视角 | 5001 |
| 孪生视频 · 3D 全局视角 | 5002 |
| 孪生视频 · 子船视角 | 5003 |

**仿真模式**下端口会自动切换（船坞 8081/8080，视频走 5001/5002/5003）。

端口可在「⚙️ 全局算法与系统配置 → 📡 通信配置」里改。

---

## 接入 Unity 数字孪生

地面站通过 **TCP 拉流**接收 Unity 侧的画面，通过**网络指令**下发控制。

> **V1（开源版）孪生**：产品名 / 主程序 = **`USV_Sim2Real_Simulation_Platform.exe`**
> （旧名 `DDPG USVS.exe` 已废弃，本方代码新名优先、旧名回退）；
> **OPC UA 与 NDI 已移除**（V1 起），三路视频**一直走 TCP 5001/5002/5003，不受影响**。
> 联调口径 R1–R10 与 12 项验收清单见 [`docs/联调_数字孪生V1_M5口径与验收.md`](docs/联调_数字孪生V1_M5口径与验收.md)。

1. **改 IP**：在「📡 通信配置」里填 Unity 主机 IP
2. **启仿真模式**：点工具栏 `🧪 仿真模拟模式`
   - 指令改走 UDP 网络（而非物理串口）
   - 孪生视频线程开始监听 5001 / 5002 / 5003
3. **切视图**：工具栏「🗺️ 视图模式」

| 视图模式 | 内容 |
|---|---|
| 自动切换 | 两船距离 < 20 m 时自动切微观雷达 |
| 强制显示：宏观地图 | 2D 地图（含**孪生底图**） |
| 强制显示：微观雷达 | 近距离雷达视图 |
| **强制显示：3D 孪生视角** | Unity 的 3D 实时画面（端口 5002） |

**2D 孪生底图**：工具栏 `🌐 孪生底图 → Level1_Pool`
（底图与四角经纬度配置在 `ui/map/twin_maps/scenes.json`）

---

## 操作速览

| 操作 | 位置 |
|---|---|
| 🚨 全局紧急停机 | 工具栏（切断所有动力） |
| 🧪 仿真模拟模式 | 工具栏 |
| 🌐 孪生底图 | 工具栏 → 选关卡 |
| 🚀 一键启动数字孪生 | 工具栏 |
| 🎮 手柄配对 | 工具栏 |
| 📉 实时遥测曲线 | 工具栏 |
| 任务规划 / 打点 / 保存 | 右侧「任务规划中心」 |
| 算法 / 通信 / 关于 | 菜单「系统」→ ⚙️ 全局算法与系统配置 |
| 推进器配置 | 菜单「推进器配置...」 |

---

## 两个 PID 的隐藏约定

调试 PID 时**务必注意**（这是很容易踩的坑）：

```
HeadingPIDController.compute   输出 = raw / 100，再 clamp(±1)
StandardPIDController.compute  输出 = raw / 100，再 clamp(±1)
```

也就是说 **PID 增益是"百分数"量纲**，不是归一化量纲。
调参时看到的数字与实际输出差 100 倍。

（另一处相关约定：`Tools/trace_path_following.py` 的文档字符串里有完整说明。）

---

## 项目结构

```
LandStation-Lite/
├── main.py                      启动入口（含 Qt/WebEngine 环境配置）
├── start_groundstation.bat      推荐启动方式
├── run_start_with_log.bat       带日志捕获的启动方式（排查问题用）
├── requirements.txt             必需依赖
├── requirements-optional.txt    可选依赖（YOLO）
├── _version.py                  版本号集中定义
├── missions.json                任务（⚠️ 发布前已替换为演示数据）
│
├── ui/                          界面层
│   ├── main_window.py           主窗口与业务装配
│   ├── ui_builder.py            界面组装工厂
│   ├── map/map.html             Leaflet 地图页（含孪生底图切换）
│   ├── map/leaflet/             Leaflet 本地副本（离线可用）
│   └── map/twin_maps/           孪生底图 + 关卡配置
│
├── controllers/                 控制器层（外观）
│   ├── boat_controller.py / dock_controller.py
│   ├── boat/  boat_brain.py · boat_worker.py · boat_comm.py · boat_monitor.py
│   └── dock/  dock_brain.py · dock_worker.py · dock_comm.py · dock_monitor.py
│
├── core/                        核心层
│   ├── protocol.py              🔴 通信协议（33 B 下行 / 59·65 B 上行）
│   ├── data_logger.py           CSV 落盘
│   ├── Managers/                调度、任务、导航、手柄
│   ├── Thread/                  串口 / 网络 / 视频线程
│   ├── PID_controller/          PID 实现
│   └── vision/                  视觉对接决策层
│
├── vision/                      视觉算力进程
│   └── algorithms/yolo_v8/      YOLO 目标检测（含自训权重）
│
├── Tools/                       工具与回归自检
│   ├── check_env.py             ⭐ 环境自检
│   ├── verify_twin_all.py       ⭐ 孪生一键回归（6 组）
│   ├── package_release.py       ⭐ 开源打包（排除大目录 + 隐私门禁）
│   └── verify_trace_tool.py     ⭐ 控制链数字对齐
│
└── docs/                      联调口径与验收（随包唯一文档：联调_数字孪生V1_M5口径与验收.md）
```

---

## 回归自检（改代码后请跑）

```bat
set PYTHONUTF8=1

venv_usv\Scripts\python.exe Tools\verify_trace_tool.py       rem 控制链数字（30 项）
venv_usv\Scripts\python.exe Tools\verify_twin_all.py         rem 孪生 6 组
venv_usv\Scripts\python.exe Tools\check_env.py                rem 环境
```

改动**通信协议**相关代码后，务必确认协议逐字节未变 —— 数字孪生侧的兼容性完全依赖它。

---

## 常见问题

### 地图区域一片空白，且没有任何报错

**头号原因：QtWebEngine 渲染进程没起来。**

按顺序查：

1. 启动时看终端有没有 `🗺 [地图] loadFinished(ok=True)`
2. 若看到 `🗺 [地图] ❌❌ 渲染进程终止! ... exitCode=18` → 就是这个问题
3. 检查 `main.py` 里是否有这一行（**必须在 `QApplication` 创建之前**）：
   ```python
   QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
   ```
4. 检查 `start_groundstation.bat` 里的：
   ```bat
   set "QTWEBENGINE_CHROMIUM_FLAGS=--disable-gpu-sandbox --disable-gpu --no-sandbox --disable-software-rasterizer"
   ```

> 想用硬件加速时，可先把 `--disable-gpu` 去掉试试。

**二号原因：路径含中文** → 见开头的「三条必读」。

### 启动就崩 / 闪退

跑 `run_start_with_log.bat`，它会把**完整输出**写到 `_baseline/startup_log.txt`，比看黑窗口可靠。

### 手柄没反应

1. 先跑 `venv_usv\Scripts\python.exe Tools\joystick_tester.py` 确认系统能识别手柄
2. 再用工具栏 `🎮 手柄配对` 绑定角色
3. 配置存在 `config/joystick_mapping.json`（**必须在工程根目录启动**才会读写它）

### 想换孪生底图

改 `ui/map/twin_maps/scenes.json`（四角经纬度 + 图片文件名），把底图 PNG 放进同目录即可。
菜单项是**按这个 JSON 动态生成**的，不用改代码。

---

## 许可

**本项目许可：GPL v3** —— 完整条款见根目录 [`LICENSE`](LICENSE)。

> **为什么是 GPL v3**：本工程依赖 **PyQt5 / PyQtWebEngine**，它们采用 **GPL v3 与商业双授权**。
> GPL v3 具有传染性 —— 使用 GPL 版 PyQt5 发布时，整个工程必须采用 GPL v3 兼容许可。
> 本项目已选定 **方案 A（接受 GPL v3）**：零成本，适合学术 / 开源 / 内部用途。
> （另两个选项：购买 Qt 商业授权可自选 MIT/Apache；迁移 PySide6（LGPL）需改代码并重新验收 —— 均未采用。）

`Copyright (C) 2026 LandStation-Lite contributors`

⚠️ **另注意**：可选依赖 **Ultralytics YOLOv8 采用 AGPL-3.0**。只在本机/内部使用无影响；
若要**对外发布或作为网络服务提供**，AGPL 的传染性条款可能要求你一并开源 —— **发布前请与导师/法务确认**。

**第三方组件及其许可**见 `THIRD_PARTY_NOTICES.md`。

---

## 相关文档

| 文件 | 内容 |
|---|---|
| `环境配置说明.md` | 环境搭建的详细说明 |
| `docs/联调_数字孪生V1_M5口径与验收.md` | 与 Unity 数字孪生的联调口径与 12 项验收清单 |
