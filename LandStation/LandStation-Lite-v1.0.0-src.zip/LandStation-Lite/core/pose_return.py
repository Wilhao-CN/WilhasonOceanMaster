import math

from core.utils import CoordUtils


class PoseReturnGuidance:
    """Two-stage guidance used only by the repeat-test reset procedure."""

    def __init__(self):
        self.stop()

    def stop(self):
        self.active = False
        self.phase = "idle"
        self.target_lat = 0.0
        self.target_lon = 0.0
        self.target_heading = 0.0
        self.approach_lat = 0.0
        self.approach_lon = 0.0
        self.position_tolerance = 1.0
        self.approach_distance = 4.0
        self.cruise_speed = 0.25
        self.final_speed = 0.12

    def start(self, target_lat: float, target_lon: float, target_heading: float,
              position_tolerance: float = 1.0, approach_distance: float = 4.0,
              cruise_speed: float = 0.25, final_speed: float = 0.12):
        self.target_lat = float(target_lat)
        self.target_lon = float(target_lon)
        self.target_heading = float(target_heading)
        self.position_tolerance = max(0.2, float(position_tolerance))
        self.approach_distance = max(2.0, float(approach_distance))
        self.cruise_speed = max(0.05, float(cruise_speed))
        self.final_speed = max(0.03, min(float(final_speed), self.cruise_speed))

        # Move backwards from the target along its desired heading.
        heading_rad = math.radians(self.target_heading)
        north_m = -self.approach_distance * math.cos(heading_rad)
        east_m = -self.approach_distance * math.sin(heading_rad)
        self.approach_lat = self.target_lat + north_m / 111320.0
        lon_scale = 111320.0 * max(0.1, math.cos(math.radians(self.target_lat)))
        self.approach_lon = self.target_lon + east_m / lon_scale

        self.phase = "approach"
        self.active = True

    def update(self, curr_lat: float, curr_lon: float, curr_heading: float) -> dict:
        if not self.active:
            return {
                "active": False, "phase": "idle", "target_heading": curr_heading,
                "target_speed": 0.0, "distance": 0.0,
            }

        previous_phase = self.phase
        if self.phase == "approach":
            approach_dist, _ = CoordUtils.calculate_distance_and_bearing(
                curr_lat, curr_lon, self.approach_lat, self.approach_lon
            )
            if approach_dist <= max(1.5, self.position_tolerance * 1.5):
                self.phase = "final"

        target_dist, target_bearing = CoordUtils.calculate_distance_and_bearing(
            curr_lat, curr_lon, self.target_lat, self.target_lon
        )

        if self.phase == "align" and target_dist > self.position_tolerance * 1.2:
            self.phase = "final"

        if self.phase == "approach":
            nav_lat, nav_lon = self.approach_lat, self.approach_lon
            distance, bearing = CoordUtils.calculate_distance_and_bearing(
                curr_lat, curr_lon, nav_lat, nav_lon
            )
            speed = self.cruise_speed
        elif target_dist <= self.position_tolerance:
            self.phase = "align"
            distance = target_dist
            bearing = self.target_heading
            speed = 0.0
        else:
            self.phase = "final"
            distance = target_dist
            bearing = target_bearing
            speed = self.final_speed

        # Turn first when the vessel is pointing far away from the return corridor.
        heading_error = abs(CoordUtils.get_heading_diff(curr_heading, bearing))
        if speed > 0.0:
            if heading_error >= 100.0:
                speed = 0.0
            elif heading_error >= 60.0:
                speed *= 0.35

        return {
            "active": True,
            "phase": self.phase,
            "phase_changed": previous_phase != self.phase,
            "target_heading": bearing,
            "target_speed": speed,
            "distance": distance,
            "distance_to_start": target_dist,
        }
