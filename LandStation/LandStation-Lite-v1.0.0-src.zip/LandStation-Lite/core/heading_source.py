"""Helpers for selecting which uploaded heading drives a control loop."""

HEADING_SOURCE_EKF = "ekf"
HEADING_SOURCE_DUAL_GPS = "dual_gps"


def select_control_heading(imu_data: dict, source: str = HEADING_SOURCE_EKF) -> float:
    """Return the requested heading without filtering or transition handling."""
    key = "dual_heading" if source == HEADING_SOURCE_DUAL_GPS else "ekf_heading"
    return float(imu_data[key])
