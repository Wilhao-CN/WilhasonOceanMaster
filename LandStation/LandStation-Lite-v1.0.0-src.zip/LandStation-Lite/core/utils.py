# 文件路径: core/utils.py
import math

class CoordUtils:
    """
    经纬度坐标与物理距离运算工具类
    解耦目标：让控制器和算法无需依赖 MainWindow 即可计算位置关系
    """

    @staticmethod
    def calculate_distance_and_bearing(lat1, lon1, lat2, lon2):
        """
        计算两点间的距离（米）和方位角（度）
        采用大圆距离公式 (Haversine formula)
        """
        R = 6371000.0  # 地球平均半径 (米)
        phi1, phi2 = math.radians(lat1), math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lon2 - lon1)

        # 1. 计算距离 (Haversine)
        a = math.sin(delta_phi / 2.0)**2 + \
            math.cos(phi1) * math.cos(phi2) * \
            math.sin(delta_lambda / 2.0)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        distance = R * c

        # 2. 计算方位角 (Bearing)
        y = math.sin(delta_lambda) * math.cos(phi2)
        x = math.cos(phi1) * math.sin(phi2) - \
            math.sin(phi1) * math.cos(phi2) * math.cos(delta_lambda)
        
        theta = math.atan2(y, x)
        # 将弧度转换为 0-360 度的方位角
        bearing_deg = math.degrees(theta)
        return distance, CoordUtils.normalize_angle(bearing_deg)
        
    
    @staticmethod
    def normalize_angle(angle):
        """
        💡 新增：将角度统一缩放到 [-180, 180] 范围
        """
        while angle > 180.0: angle -= 360.0
        while angle <= -180.0: angle += 360.0
        return angle
    
    @staticmethod
    def get_heading_diff(current_heading, target_heading):
        """
        计算两个角度之间的最小差值（带符号）
        用于解决 0/360 度环绕问题
        例如：从 350度 转向 10度，应返回 +20度 而不是 -340度
        """
        diff = target_heading - current_heading
        while diff > 180: diff -= 360
        while diff < -180: diff += 360
        return diff
    @staticmethod
    def calculate_turn_angle(p1, p2, p3):
        """
        💡 新增：计算由三个点构成的航道转角
        p1: 上一航点, p2: 当前目标点, p3: 下一航点
        返回：p1-p2 段与 p2-p3 段之间的方位角差值（绝对值）
        """
        if not p1 or not p2 or not p3:
            return 0.0
            
        # 计算第一段的方位角
        _, bearing1 = CoordUtils.calculate_distance_and_bearing(p1[0], p1[1], p2[0], p2[1])
        # 计算第二段的方位角
        _, bearing2 = CoordUtils.calculate_distance_and_bearing(p2[0], p2[1], p3[0], p3[1])
        
        # 返回两条航线之间的转角绝对值
        return abs(CoordUtils.get_heading_diff(bearing1, bearing2))
    