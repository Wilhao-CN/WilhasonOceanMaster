# 文件路径: core/PID_controller/pid_controller.py

from core.base_algorithm import BaseAlgorithm
from PyQt5.QtWidgets import QWidget, QFormLayout, QDoubleSpinBox
from core.utils import CoordUtils  # ✅ 修改点：引入工具类
class HeadingPIDController(BaseAlgorithm):
    def __init__(self, kp=3.0, ki=0.1, kd=1.5, max_integral=200.0, deadband=5.0):
        super().__init__()
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.max_integral = max_integral
        self.deadband = deadband  # 💡 死区参数（默认5度）
        self.integral = 0.0
        self.last_error = 0.0

    def reset(self):
        self.integral = 0.0
        self.last_error = 0.0

    def compute(self, current_heading: float, target_heading: float, dt: float) -> float:
        """针对 -180~180 范围优化的角度 PID"""
        if dt <= 0.0: return 0.0

        # ✅ 修改点：强制对反馈值和目标值进行最后的归一化校验，确保计算基准一致
        current_heading = CoordUtils.normalize_angle(current_heading)
        target_heading = CoordUtils.normalize_angle(target_heading)

        # 1. 计算误差并进行角度标准化 (Shortest Path 逻辑)
        error = target_heading - current_heading
        # 💡 确保误差始终在 -180 到 180 之间，适合处理跨越 ±180 边界的情况
        while error > 180.0: error -= 360.0
        while error < -180.0: error += 360.0

        # 2. 💡 [核心修改] 死区判定逻辑
        # 如果误差小于死区，则认为已到达，强制清空误差和积分项，防止抖动
        if abs(error) < self.deadband:
            error = 0.0
            self.integral = 0.0
        else:
            # 只有在死区外才累加积分
            self.integral += error * dt
            self.integral = max(-self.max_integral, min(self.max_integral, self.integral)) 
        
        # 3. PID 计算
        p_out = self.kp * error
        i_out = self.ki * self.integral
        derivative = (error - self.last_error) / dt
        d_out = self.kd * derivative
        self.last_error = error

        # 4. 归一化输出
        raw_output = p_out + i_out + d_out
        return max(-1.0, min(1.0, raw_output / 100.0))

    def get_tuning_widget(self, parent=None) -> QWidget:
        """增加死区调节的 UI 面板"""
        container = QWidget(parent)
        layout = QFormLayout(container)
        layout.setContentsMargins(5, 5, 5, 5)

        # Kp, Ki, Kd 调节 (保持原代码逻辑)
        spn_p = QDoubleSpinBox(); spn_p.setRange(-100.0, 100.0); spn_p.setSingleStep(0.1); spn_p.setValue(self.kp)
        spn_p.valueChanged.connect(lambda v: setattr(self, 'kp', v))
        layout.addRow("艏向 P (比例):", spn_p)

        spn_i = QDoubleSpinBox(); spn_i.setRange(-20.0, 20.0); spn_i.setSingleStep(0.01); spn_i.setValue(self.ki)
        spn_i.valueChanged.connect(lambda v: setattr(self, 'ki', v))
        layout.addRow("艏向 I (积分):", spn_i)

        spn_d = QDoubleSpinBox(); spn_d.setRange(-50.0, 50.0); spn_d.setSingleStep(0.1); spn_d.setValue(self.kd)
        spn_d.valueChanged.connect(lambda v: setattr(self, 'kd', v))
        layout.addRow("艏向 D (微分):", spn_d)

        # 💡 [核心新增] 死区调节框
        spn_db = QDoubleSpinBox()
        spn_db.setRange(0.0, 30.0); spn_db.setSingleStep(0.5); spn_db.setValue(self.deadband)
        spn_db.setSuffix(" °")
        spn_db.valueChanged.connect(lambda v: setattr(self, 'deadband', v))
        layout.addRow("控制死区 (Deadband):", spn_db)

        # 积分限幅
        spn_limit = QDoubleSpinBox(); spn_limit.setRange(0.0, 9999.0); spn_limit.setSingleStep(10.0); spn_limit.setValue(self.max_integral)
        spn_limit.valueChanged.connect(lambda v: setattr(self, 'max_integral', v))
        layout.addRow("积分抗饱和限幅:", spn_limit)

        return container
        # super().__init__()
        # self.kp = kp
        # self.ki = ki
        # self.kd = kd
        # self.max_integral = max_integral
        # self.integral = 0.0
        # self.last_error = 0.0



class StandardPIDController(BaseAlgorithm):
    def __init__(self, kp=150.0, ki=10.0, kd=0.0, max_integral=50.0):
        super().__init__()
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.max_integral = max_integral
        self.integral = 0.0
        self.last_error = 0.0

    def compute(self, current_value, target_value, dt):
        if dt <= 0.0: return 0.0

        error = target_value - current_value
        self.integral += error * dt
        self.integral = max(-self.max_integral, min(self.max_integral, self.integral))

        derivative = (error - self.last_error) / dt
        self.last_error = error

        pid_out = self.kp * error + self.ki * self.integral + self.kd * derivative
        return max(-1.0, min(1.0, pid_out / 100.0))

    def get_tuning_widget(self, parent=None) -> QWidget:
        container = QWidget(parent)
        layout = QFormLayout(container)
        layout.setContentsMargins(5, 5, 5, 5)

        spn_p = QDoubleSpinBox(); spn_p.setRange(-10000.0, 10000.0); spn_p.setSingleStep(10.0); spn_p.setValue(self.kp)
        spn_p.valueChanged.connect(lambda v: setattr(self, 'kp', v))
        layout.addRow("速度 P (比例):", spn_p)

        spn_i = QDoubleSpinBox(); spn_i.setRange(-10000.0, 10000.0); spn_i.setSingleStep(10.0); spn_i.setValue(self.ki)
        spn_i.valueChanged.connect(lambda v: setattr(self, 'ki', v))
        layout.addRow("速度 I (积分):", spn_i)
        spn_d = QDoubleSpinBox()
        spn_d.setRange(-10000.0, 10000.0); spn_d.setSingleStep(10.0); spn_d.setValue(self.kd)
        spn_d.valueChanged.connect(lambda v: setattr(self, 'kd', v))
        layout.addRow("速度 D (微分):", spn_d)

        spn_limit = QDoubleSpinBox(); spn_limit.setRange(0.0, 9999.0); spn_limit.setSingleStep(10.0); spn_limit.setValue(self.max_integral)
        spn_limit.valueChanged.connect(lambda v: setattr(self, 'max_integral', v))
        layout.addRow("积分抗饱和限幅:", spn_limit)

        return container

