# 文件路径: core/Thread/zmq_video_thread.py
"""Unity 数字孪生 TCP 视频接收线程。

文件名保留为 ``zmq_video_thread.py`` 是为了兼容现有导入。当前打包的
Unity EXE 使用原生 TCP，而不是 ZMQ。每帧格式为：

    little-endian float64 timestamp + uint32 jpeg_size + jpeg bytes
"""

import os
import socket
import struct
import time

import cv2
import numpy as np
from PyQt5.QtCore import QMutex, QMutexLocker, QSize, QThread, pyqtSignal
from PyQt5.QtGui import QImage


class ZmqVideoThread(QThread):
    """兼容旧类名的数字孪生原生 TCP 拉流线程。"""

    sig_frame_ready = pyqtSignal(QImage)
    sig_error = pyqtSignal(str)

    HEADER_SIZE = 12
    MAX_FRAME_SIZE = 32 * 1024 * 1024
    RECONNECT_DELAY_SEC = 0.5
    # Unity 发送端本身已严格限制为 30 FPS。接收端必须逐帧处理；若再用
    # ``elapsed >= 1 / 30`` 判断，网络时间抖动会把接近 30 FPS 的帧误判为
    # “过快”并隔帧丢弃，最终只剩约 15~16 FPS。
    MAX_DISPLAY_FPS = 30.0
    # Unity 三路 RenderTexture 当前均按 sRGB 输出，JPEG 解码后已经是可直接
    # 显示的 8 位颜色。这里不能再次做 gamma 提亮，否则会造成发白、低对比度
    # 和三维窗口/地面站色彩明显不一致。

    def __init__(self, parent=None):
        super().__init__(parent)
        self.target_ip = "127.0.0.1"
        self.listen_port = 5001
        self.is_running = False

        self.latest_qimage = None
        self.target_size = QSize(640, 480)
        self.mutex = QMutex()
        self.shm_buffer = None
        self._socket = None
        self._last_reported_error = None

        self.record_mutex = QMutex()
        self.is_recording = False
        self.video_writer = None
        self.record_filepath = ""
        self.record_fps = 20

        self._fps_frame_count = 0
        self._fps_last_time = time.time()
        self.current_fps = 0.0
        self.display_interval_ms = round(1000 / self.MAX_DISPLAY_FPS)

    def set_connection_params(self, ip: str, port: int):
        self.target_ip = str(ip).strip() or "127.0.0.1"
        self.listen_port = int(port)

    def set_shm_buffer(self, buffer):
        self.shm_buffer = buffer

    def set_target_size(self, size):
        """保留旧接口；显示尺寸由各个 QWidget 独立处理，不再缩小共享原帧。"""
        with QMutexLocker(self.mutex):
            if isinstance(size, QSize):
                self.target_size = size
            elif isinstance(size, (list, tuple)) and len(size) == 2:
                self.target_size = QSize(int(size[0]), int(size[1]))

    def start_video(self):
        if not self.is_running:
            self.is_running = True
            self.start()

    def stop_video(self):
        self.is_running = False
        active_socket = self._socket
        if active_socket is not None:
            try:
                active_socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                active_socket.close()
            except OSError:
                pass
        self.stop_recording()
        if self.isRunning():
            self.wait(3000)

    def start_recording(self, filepath, fps=20):
        with QMutexLocker(self.record_mutex):
            self.record_filepath = filepath
            self.record_fps = fps
            self.is_recording = True
            directory = os.path.dirname(filepath)
            if directory:
                os.makedirs(directory, exist_ok=True)
            print(f"🎬 [孪生录像] 准备录像: {filepath}")

    def stop_recording(self):
        with QMutexLocker(self.record_mutex):
            self.is_recording = False
            if self.video_writer is not None:
                self.video_writer.release()
                self.video_writer = None
                print("🛑 [孪生录像] 录像已保存并关闭。")

    def _recv_exact(self, sock, size):
        data = bytearray()
        while self.is_running and len(data) < size:
            try:
                chunk = sock.recv(size - len(data))
            except socket.timeout:
                continue
            if not chunk:
                raise ConnectionError("推流端已断开连接")
            data.extend(chunk)
        if len(data) != size:
            raise ConnectionError("视频线程已停止")
        return bytes(data)

    def _report_error_once(self, message):
        if message != self._last_reported_error:
            self._last_reported_error = message
            self.sig_error.emit(message)

    def _process_frame(self, jpeg_bytes, source_timestamp=None):
        nparr = np.frombuffer(jpeg_bytes, np.uint8)
        raw_image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if raw_image is None:
            raise ValueError("收到无法解码的 JPEG 帧")

        self._fps_frame_count += 1
        now = time.time()
        elapsed = now - self._fps_last_time
        if elapsed >= 1.0:
            self.current_fps = self._fps_frame_count / elapsed
            self._fps_frame_count = 0
            self._fps_last_time = now

        with QMutexLocker(self.record_mutex):
            if self.is_recording:
                if self.video_writer is None:
                    height, width = raw_image.shape[:2]
                    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                    self.video_writer = cv2.VideoWriter(
                        self.record_filepath,
                        fourcc,
                        self.record_fps,
                        (width, height),
                    )
                self.video_writer.write(raw_image)

        if self.shm_buffer:
            self.shm_buffer.write(raw_image, timestamp=source_timestamp)

        # 始终保留 Unity 发送的完整分辨率。主界面小预览和专业视觉大窗口
        # 共享同一接收线程，若在这里按某个控件尺寸预缩放，另一个大窗口会
        # 把小图重新放大，造成明显模糊。各控件在绘制阶段各自缩放即可。
        rgb_image = cv2.cvtColor(raw_image, cv2.COLOR_BGR2RGB)
        new_h, new_w, channels = rgb_image.shape
        qimg = QImage(
            rgb_image.data,
            new_w,
            new_h,
            channels * new_w,
            QImage.Format_RGB888,
        ).copy()

        with QMutexLocker(self.mutex):
            self.latest_qimage = qimg
        self.sig_frame_ready.emit(qimg)

    def run(self):
        address = f"{self.target_ip}:{self.listen_port}"
        while self.is_running:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._socket = sock
            sock.settimeout(0.5)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            try:
                sock.connect((self.target_ip, self.listen_port))
                self._last_reported_error = None
                print(f"✅ [孪生视频] TCP 已连接: {address}")

                while self.is_running:
                    header = self._recv_exact(sock, self.HEADER_SIZE)
                    source_timestamp, frame_size = struct.unpack("<dI", header)
                    if not 0 < frame_size <= self.MAX_FRAME_SIZE:
                        raise ValueError(f"非法视频帧长度: {frame_size}")
                    jpeg_bytes = self._recv_exact(sock, frame_size)
                    self._process_frame(jpeg_bytes, source_timestamp)
            except (ConnectionError, OSError, ValueError, struct.error) as exc:
                if self.is_running:
                    self._report_error_once(
                        f"⚠️ 数字孪生视频 {address} 暂不可用，正在重连: {exc}"
                    )
            finally:
                try:
                    sock.close()
                except OSError:
                    pass
                if self._socket is sock:
                    self._socket = None

            if self.is_running:
                time.sleep(self.RECONNECT_DELAY_SEC)

        print(f"🔴 [孪生视频] TCP {address} 已关闭")

    def get_latest_frame(self):
        with QMutexLocker(self.mutex):
            return self.latest_qimage
