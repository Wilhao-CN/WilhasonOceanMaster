# 文件路径: core/Thread/network_thread.py

import socket
import select
import time
from PyQt5.QtCore import QThread, pyqtSignal, QMutex, QMutexLocker
from core.link_latency import (
    TYPE_COMMAND_ACK,
    TYPE_PONG,
    TYPE_TELEMETRY_STAMP,
    LatencyTracker,
    is_latency_packet,
    pack_command,
    pack_ping,
    unpack_packet,
)
from core.protocol import USVProtocol

class NetworkThread(QThread):
    """
    网络 UDP 通信底层线程 (串口线程的“网络版替身”)
    负责在虚拟局域网(Tailscale)内收发 4G 数据。
    """
    # ==========================================
    # 1. 定义信号 (必须和 SerialThread 100% 保持一致！)
    # ==========================================
    data_received = pyqtSignal(bytes)    
    error_occurred = pyqtSignal(str)     
    connection_status = pyqtSignal(bool) 
    remote_status_changed = pyqtSignal(bool)  # 树莓派真实遥测在线状态
    valid_network_frame_received = pyqtSignal()
    sig_frame_received = pyqtSignal(bytes) # 输出完整的旧版或温度扩展帧
    sig_debug_log = pyqtSignal(str)
    latency_updated = pyqtSignal(dict)

    LATENCY_PORTS = {0x01: 8892, 0x02: 8893}
    PROBE_INTERVAL_SEC = 0.5
    PROBE_TIMEOUT_SEC = 2.0

    def __init__(self, parent=None, device_id: int = 0):
        super().__init__(parent)
        self.device_id = int(device_id)
        self.udp_socket = None
        self.latency_socket = None
        self.is_running = False         
        self.mutex = QMutex()           
        
        # 💡 网络特有属性
        self.target_ip = ""      # 树莓派的 Tailscale IP
        self.target_port = 0     # 树莓派接收指令的端口 (TX)
        self.local_port = 0      # 地面站监听回传的端口 (RX)
        
        self.buffer = bytearray()
        self.remote_online = False
        self.remote_status_known = False
        self.last_valid_frame_time = None
        self.remote_timeout_sec = 3.0
        self._listen_started_time = None
        self.latency_tracker = LatencyTracker()
        self._latency_sequence = 0
        self._pending_probes = {}
        self._last_probe_time = 0.0
        self._last_pong_time = None
        self._last_metrics_emit = 0.0

    # ==========================================
    # 2. 对外暴露的方法 (完美兼容原有控制器的调用习惯)
    # ==========================================
    def connect_network(self, target_ip: str, target_port: int, local_port: int):
        """尝试建立 UDP 监听并启动线程 (替代原有的 open_port)"""
        self.target_ip = target_ip
        self.target_port = target_port
        self.local_port = local_port
        self.remote_online = False
        self.remote_status_known = False
        self.last_valid_frame_time = None
        self._listen_started_time = time.monotonic()
        self.buffer.clear()
        self._reset_latency_state()
        
        try:
            # 创建 UDP 套接字
            self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # 绑定本地端口，用于接收树莓派发来的传感器数据
            self.udp_socket.bind(("0.0.0.0", self.local_port))
            self.udp_socket.setblocking(False)
            self.latency_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.latency_socket.bind(("0.0.0.0", 0))
            self.latency_socket.setblocking(False)
            if hasattr(socket, "SIO_UDP_CONNRESET"):
                # Windows 会把对端端口不可达的 ICMP 转成 WinError 10054。
                # 仿真启动阶段端口存在短暂竞态，不能因此杀死遥测线程。
                self.udp_socket.ioctl(socket.SIO_UDP_CONNRESET, False)
                self.latency_socket.ioctl(socket.SIO_UDP_CONNRESET, False)
            
            self.is_running = True
            self.connection_status.emit(True) # 广播：网络连接成功！
            self.start()                      # 启动后台 run() 监听
            return True
        except Exception as e:
            if self.udp_socket:
                self.udp_socket.close()
                self.udp_socket = None
            if self.latency_socket:
                self.latency_socket.close()
                self.latency_socket = None
            self.error_occurred.emit(f"绑定 UDP 端口 [{local_port}] 失败: {str(e)}")
            return False

    def close_port(self):
        """安全关闭 Socket 并停止线程 (名字保持与串口一致)"""
        self.is_running = False 
        self.wait()             
        
        if self.udp_socket:
            self.udp_socket.close()
            self.udp_socket = None
        if self.latency_socket:
            self.latency_socket.close()
            self.latency_socket = None

        if self.remote_online or self.remote_status_known:
            self.remote_status_changed.emit(False)
        self.remote_online = False
        self.remote_status_known = False
        self.last_valid_frame_time = None
        self._listen_started_time = None
        self._reset_latency_state()
        self.connection_status.emit(False) 

    def _reset_latency_state(self):
        self.latency_tracker.reset()
        self._pending_probes.clear()
        self._last_probe_time = 0.0
        self._last_pong_time = None
        self._last_metrics_emit = 0.0
        self.latency_updated.emit(self.latency_tracker.snapshot(False))

    def _next_latency_sequence(self):
        self._latency_sequence = (self._latency_sequence + 1) & 0xFFFFFFFF
        return self._latency_sequence

    def _peer_supports_latency(self, now=None):
        if self._last_pong_time is None:
            return False
        current = time.monotonic() if now is None else now
        return current - self._last_pong_time <= self.PROBE_TIMEOUT_SEC

    def _send_latency_probe_if_due(self):
        now = time.monotonic()
        if now - self._last_probe_time < self.PROBE_INTERVAL_SEC:
            return
        latency_port = self.LATENCY_PORTS.get(self.device_id)
        if not latency_port:
            return
        sequence = self._next_latency_sequence()
        sent_ns = time.time_ns()
        packet = pack_ping(self.device_id, sequence, sent_ns)
        self.latency_socket.sendto(packet, (self.target_ip, latency_port))
        self._pending_probes[sequence] = now
        self.latency_tracker.record_probe_sent()
        self._last_probe_time = now

    def _expire_latency_probes(self):
        now = time.monotonic()
        expired = [
            sequence
            for sequence, sent_at in self._pending_probes.items()
            if now - sent_at > self.PROBE_TIMEOUT_SEC
        ]
        for sequence in expired:
            self._pending_probes.pop(sequence, None)
            self.latency_tracker.record_probe_lost()

    def _emit_latency_metrics(self, force=False):
        now = time.monotonic()
        if not force and now - self._last_metrics_emit < 0.5:
            return
        supported = self._peer_supports_latency(now)
        self.latency_updated.emit(self.latency_tracker.snapshot(supported))
        self._last_metrics_emit = now

    def _handle_latency_packet(self, raw_data: bytes):
        packet = unpack_packet(raw_data)
        if packet is None or packet["device_id"] != self.device_id:
            return False

        now_ns = time.time_ns()
        packet_type = packet["type"]
        if packet_type == TYPE_PONG:
            self._pending_probes.pop(packet["sequence"], None)
            self.latency_tracker.record_pong(
                packet["origin_ns"],
                packet["received_ns"],
                packet["replied_ns"],
                now_ns,
            )
            self._last_pong_time = time.monotonic()
        elif packet_type == TYPE_TELEMETRY_STAMP:
            self.latency_tracker.record_upload(packet["sent_ns"], now_ns)
        elif packet_type == TYPE_COMMAND_ACK:
            self.latency_tracker.record_download(
                packet["origin_ns"], packet["received_ns"]
            )
        else:
            return True

        self._emit_latency_metrics()
        return True

    def _drain_latency_socket(self):
        if not self.latency_socket:
            return
        while True:
            try:
                raw_data, _ = self.latency_socket.recvfrom(256)
                if is_latency_packet(raw_data):
                    self._handle_latency_packet(raw_data)
            except (BlockingIOError, socket.timeout):
                break
            except OSError:
                # A legacy peer may answer the probe with ICMP port-unreachable.
                # This socket is isolated so telemetry/control remain unaffected.
                break

    def _mark_valid_remote_frame(self):
        self.last_valid_frame_time = time.monotonic()
        self.valid_network_frame_received.emit()
        if not self.remote_online:
            self.remote_online = True
            self.remote_status_known = True
            self.remote_status_changed.emit(True)

    def _check_remote_timeout(self):
        now = time.monotonic()
        if not self.remote_status_known and self._listen_started_time is not None:
            if now - self._listen_started_time >= self.remote_timeout_sec:
                self.remote_status_known = True
                self.remote_status_changed.emit(False)
            return
        if not self.remote_online or self.last_valid_frame_time is None:
            return
        if now - self.last_valid_frame_time >= self.remote_timeout_sec:
            self.remote_online = False
            self.remote_status_changed.emit(False)

    def send_data(self, data: bytes,flush: bool = False):
        """发送数据：通过 UDP 直接扔给树莓派的 IP 和端口"""
        if self.udp_socket and self.is_running:
            try:
                payload = data
                if self.device_id and self._peer_supports_latency():
                    payload = pack_command(
                        self.device_id,
                        self._next_latency_sequence(),
                        time.time_ns(),
                        data,
                    )
                with QMutexLocker(self.mutex):
                    # UDP 不需要建立连接，直接 sendto 目标地址
                    self.udp_socket.sendto(payload, (self.target_ip, self.target_port))
            except Exception as e:
                self.error_occurred.emit(f"UDP 发送数据失败: {str(e)}")
        else:
            self.error_occurred.emit("网络未连接，无法发送指令！")

    # ==========================================
    # 3. 核心后台监听逻辑
    # ==========================================
    def run(self):
        self.sig_debug_log.emit(f"🟢 [网络底层] UDP 监听线程已启动，正在监听本地端口: {self.local_port}")
        
        while self.is_running and self.udp_socket:
            try:
                self._send_latency_probe_if_due()
                readable, _, _ = select.select(
                    [self.udp_socket, self.latency_socket], [], [], 0.1
                )
                if self.latency_socket in readable:
                    self._drain_latency_socket()
                if self.udp_socket not in readable:
                    self._expire_latency_probes()
                    self._emit_latency_metrics()
                    self._check_remote_timeout()
                    continue
                # 尝试接收数据，最大读取 1024 字节
                raw_data, addr = self.udp_socket.recvfrom(1024)
                
                if raw_data:
                    if is_latency_packet(raw_data):
                        self._handle_latency_packet(raw_data)
                        self._expire_latency_probes()
                        continue
                    # UDP 通常一个包就是完整的一帧，但为了极度安全，
                    # 我们依然复用你在串口里写的那套完美的“找包逻辑”！
                    self.buffer.extend(raw_data)
                    
                    for frame in USVProtocol.extract_sensor_frames(self.buffer):
                        self._mark_valid_remote_frame()
                        self.sig_frame_received.emit(frame)
                    self._check_remote_timeout()
                            
            except socket.timeout:
                # UDP timeout 是正常的（说明这 0.1 秒内树莓派没发数据），直接 continue 即可
                self._expire_latency_probes()
                self._emit_latency_metrics()
                self._check_remote_timeout()
                continue
            except ConnectionResetError as e:
                if getattr(e, "winerror", None) == 10054:
                    self.sig_debug_log.emit(
                        "⚠️ [网络底层] 对端端口暂未就绪，忽略 WinError 10054 并继续监听"
                    )
                    continue
                raise
            except OSError as e:
                if getattr(e, "winerror", None) == 10054:
                    self.sig_debug_log.emit(
                        "⚠️ [网络底层] 对端端口暂未就绪，忽略 WinError 10054 并继续监听"
                    )
                    continue
                if self.is_running:
                    self.sig_debug_log.emit(f"❌ [网络底层] UDP 循环发生异常: {e}")
                break
            except Exception as e:
                if self.is_running:
                    self.sig_debug_log.emit(f"❌ [网络底层] UDP 循环发生异常: {e}")
                    if self.remote_online:
                        self.remote_online = False
                        self.remote_status_known = True
                        self.remote_status_changed.emit(False)
                break

        self.sig_debug_log.emit("🔴 [网络底层] UDP 监听线程已安全退出。")
