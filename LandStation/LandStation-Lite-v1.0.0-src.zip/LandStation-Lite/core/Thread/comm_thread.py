# 文件路径: core/Thread/comm_thread.py

import serial
import time
from PyQt5.QtCore import QThread, pyqtSignal, QMutex, QMutexLocker
from core.protocol import USVProtocol
# A. 为什么要用 QThread (多线程)？
# 程序需要死死盯着串口，随时看有没有无人船发来的数据。
# 如果我们把这个"死循环监听"放在主程序（UI）里，主程序就会被卡死，你的界面会瞬间变成"未响应"，按钮按不了，画面动不了。
# 所以，我们派出了一个"子线程" (SerialThread)，让它在后台默默蹲守，主程序该干嘛干嘛。
# B. 跨次元通信：信号 (pyqtSignal)
# 子线程在后台拿到了数据，怎么交给主界面的日志框显示呢？在 PyQt 中，子线程绝对不能直接去修改 UI 界面，否则程序会直接崩溃！
class SerialThread(QThread):
    # ==========================================
    # 1. 定义信号 (Signals) - 与外界沟通的桥梁
    # ==========================================
    data_received = pyqtSignal(bytes)    # 接收到数据时触发，携带 bytes 数据
    # 这段代码定义了一个信号。你可以把它理解为子线程手里的"对讲机"。当子线程读到数据时，
    # 它大喊一声 self.data_received.emit(data)。主界面事先把自己的耳朵（槽函数）凑到了对讲机上，
    # 一听到响动，主界面自己去更新 UI。
    error_occurred = pyqtSignal(str)     # 发生异常时触发，携带错误信息
    connection_status = pyqtSignal(bool) # 连接状态改变时触发 (True:已连接, False:已断开)
    # 当底层拼出一个完整的旧版或温度扩展上报帧时，发射这个信号
    sig_frame_received = pyqtSignal(bytes)
    # 💡 专门用于向 UI 界面发送 Debug 文本的信号
    sig_debug_log = pyqtSignal(str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.serial_port = serial.Serial()
        self.serial_port.timeout = 0.1  # 设置读取超时时间，防止死锁
        self.is_running = False         # 控制线程循环的标志位，默认关闭
        self.mutex = QMutex()           # 互斥锁，保证多线程收发数据的安全
        # 💡 2. 新增：字节缓冲区，专门用来对付"粘包"和"断包"
        self.buffer = bytearray()

    # ==========================================
    # 2. 对外暴露的方法 (供主界面 UI 调用)
    # ==========================================
    def open_port(self, port_name, baudrate):
        """尝试打开串口并启动监听线程"""
        try:
            # 配置串口的命令
            self.serial_port.port = port_name
            self.serial_port.baudrate = baudrate
            self.serial_port.open()
            # 如果成功打开，标识位设为 True，广播连接成功的消息，并启动线程
            if self.serial_port.is_open:
                self.is_running = True
                self.connection_status.emit(True) # 广播：连接成功！
                self.start()                      # 启动 QThread 底层的 run() 方法
                return True
        except Exception as e:
            self.error_occurred.emit(f"打开串口 [{port_name}] 失败: {str(e)}")
            return False

    def close_port(self):
        """安全关闭串口并停止线程"""
        self.is_running = False # 停止 run() 中的死循环
        self.wait()             # 阻塞等待子线程彻底结束，防止崩溃

        if self.serial_port.is_open:
            self.serial_port.close()

        self.connection_status.emit(False) # 广播：连接已断开



    def send_data(self, data: bytes, flush: bool = False):
        if self.serial_port.is_open:
            try:
                # 🛡️ 依然使用你原有的互斥锁，确保操作原子性
                with QMutexLocker(self.mutex):

                    # 💡 如果开启了 flush，我们在"拿住锁"的状态下清空缓冲区
                    if flush:
                        self.serial_port.reset_output_buffer()

                    # 💡 紧接着写入最新数据，中间不会被任何其他线程插队
                    self.serial_port.write(data)

            except Exception as e:
                self.error_occurred.emit(f"发送数据失败: {str(e)}")
        else:
            self.error_occurred.emit("串口未打开，无法发送指令！请先连接串口。")
    def flush_output(self):
        """强制清空缓冲区，也必须受锁保护"""
        if self.serial_port.is_open:
            with QMutexLocker(self.mutex): # 🛡️ 加锁，防止清空时别的线程正在写入
                self.serial_port.reset_output_buffer()
    # ==========================================
    # 3. 核心子线程 (只在后台默默运行)
    # ==========================================
# ==========================================
    # 3. 核心子线程 (只在后台默默运行)
    # ==========================================
    def run(self):
        # 侦察兵 1 号：报告线程启动
        self.sig_debug_log.emit("🟢 [底层] 串口监听线程已启动，正在蹲守数据...")

        while self.is_running and self.serial_port and self.serial_port.is_open:
            try:
                # 看看串口里现在有几个字节在排队
                waiting = self.serial_port.in_waiting
                if waiting > 0:
                    # 全部读出来，塞进我们的缓冲区肚子里
                    raw_data = self.serial_port.read(waiting)
                    self.buffer.extend(raw_data)

                    # 侦察兵 2 号：报告收到了新数据，以及肚子里积攒了多少
                    self.sig_debug_log.emit(f"📥 [底层] 串口读入 {waiting} 字节，当前缓冲区总长度: {len(self.buffer)}")

                    # 兼容船坞 0xBB/59 字节与子船双温度 0xBD/65 字节，
                    # 同时处理粘包、半包、垃圾字节和校验失败后的重新同步。
                    for frame in USVProtocol.extract_sensor_frames(self.buffer):
                        self.sig_frame_received.emit(frame)
                else:
                    # 串口里没数据时，稍微睡 10 毫秒
                    time.sleep(0.01)

            except Exception as e:
                print(f"[串口线程报错] {e}")
                break

        # 侦察兵 6 号：报告线程退出
        self.sig_debug_log.emit("🔴 [底层] 串口监听线程已安全退出。")

            # 极为重要：微微休眠 10 毫秒，释放 CPU 控制权，否则你的电脑 CPU 会瞬间 100%
            # time.sleep(0.01)
            #这是极其重要的一句代码！while True 如果没有任何阻挡，一秒钟能执行几百万次，
            # 你的电脑风扇会立刻狂转，CPU 占用率飙升到 100%。加上 time.sleep(0.01)，
            # 意味着每次循环后让 CPU 休息 10 毫秒。这 10 毫秒对人类来说毫无察觉，
            # 但对 CPU 来说简直是放了个长假，瞬间让性能消耗降到最低。
