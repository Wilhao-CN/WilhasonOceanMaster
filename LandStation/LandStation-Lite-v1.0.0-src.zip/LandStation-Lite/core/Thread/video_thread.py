# 文件路径: core/Thread/video_thread.py
import os
import cv2
import time
import socket
import numpy as np
from PyQt5.QtCore import QThread, pyqtSignal, QSize, QMutex, QMutexLocker
from PyQt5.QtGui import QImage

class VideoThread(QThread):
    """
    后台视频接收线程 (V5.1 兼容性优化版)
    优化：后台执行缩放，UI 仅负责贴图，100% 兼容原有 API。
    """
    sig_frame_ready = pyqtSignal(QImage)
    sig_error = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.listen_port = 9991
        self.is_running = False
        
        # 💡 保持原有属性名，确保外界访问不失效
        self.latest_qimage = None
        self.target_size = QSize(440, 330)  # 默认匹配面板宽度 (~440px)，防止撑出滚动条
        
        self.mutex = QMutex()
        self.shm_buffer = None 
        
        # --- 新增录像相关属性 ---
        self.record_mutex = QMutex()
        self.is_recording = False
        self.video_writer = None
        self.record_filepath = ""
        self.record_fps = 20

        # --- 📊 实时帧率统计 ---
        self._fps_frame_count = 0
        self._fps_last_time = time.time()
        self.current_fps = 0.0

    def set_listen_port(self, port: int):
        self.listen_port = port

    def set_shm_buffer(self, buffer):
        self.shm_buffer = buffer

    def set_target_size(self, size):
        """
        兼容性接口：支持传入 QSize 或元组
        由 Controller 在连接网络或窗口尺寸变化时调用
        """
        with QMutexLocker(self.mutex):
            if isinstance(size, QSize):
                self.target_size = size
            elif isinstance(size, (list, tuple)) and len(size) == 2:
                self.target_size = QSize(size[0], size[1])

    def start_video(self):
        if not self.is_running:
            self.is_running = True
            self.start()

    def stop_video(self):
        self.is_running = False
        self.stop_recording() # 防呆设计：线程停止时自动停止录像
        self.wait()

    # --- 新增：高清录像核心 API ---
    def start_recording(self, filepath, fps=20):
        with QMutexLocker(self.record_mutex):
            self.record_filepath = filepath
            self.record_fps = fps
            self.is_recording = True
            # 注意：这里只设标志位，不初始化 VideoWriter。真实尺寸要在取到第一帧时才能确定
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            print(f"🎬 [录像引擎] 准备录像: {filepath}")

    def stop_recording(self):
        with QMutexLocker(self.record_mutex):
            self.is_recording = False
            if self.video_writer is not None:
                self.video_writer.release()
                self.video_writer = None
                print("🛑 [录像引擎] 录像已安全保存并关闭。")
    # ------------------------------

    def run(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.bind(("0.0.0.0", self.listen_port))
            sock.setblocking(False)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 2 * 1024 * 1024) 
            print(f"✅ [视频引擎] 启动。AI 通路: 640x480, UI 通路: 动态缩放")
        except Exception as e:
            self.sig_error.emit(f"❌ 绑定端口 {self.listen_port} 失败: {e}")
            return

        while self.is_running:
            try:
                latest_data = None
                while True:
                    try:
                        data, _ = sock.recvfrom(65535)
                        latest_data = data
                    except (BlockingIOError, socket.error):
                        break

                if latest_data is None:
                    time.sleep(0.005)
                    continue
                
                # 1. 解码原始 BGR 帧
                nparr = np.frombuffer(latest_data, np.uint8)
                raw_image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                if raw_image is None: continue

                # 📊 统计实时帧率 (每秒更新一次)
                self._fps_frame_count += 1
                now = time.time()
                elapsed = now - self._fps_last_time
                if elapsed >= 1.0:
                    self.current_fps = self._fps_frame_count / elapsed
                    self._fps_frame_count = 0
                    self._fps_last_time = now
                
                # --- 新增: 🎥 高清无损录像分流 ---
                with QMutexLocker(self.record_mutex):
                    if self.is_recording:
                        if self.video_writer is None:
                            # 基于第一帧的实际尺寸动态开机
                            h, w = raw_image.shape[:2]
                            fourcc = cv2.VideoWriter_fourcc(*'mp4v') # type: ignore
                            self.video_writer = cv2.VideoWriter(self.record_filepath, fourcc, self.record_fps, (w, h))
                            print(f"🎬 [录像引擎] 捕获第一帧 {w}x{h}，开始写入...")
                        self.video_writer.write(raw_image)
                # -------------------------------

                # 2. ⚡ AI 分流：将原始 BGR 图片写入共享内存（YOLO 专用）
                if self.shm_buffer:
                    self.shm_buffer.write(raw_image, timestamp=now)

                # 3. 🎨 UI 分流：在后台完成缩放工作
                with QMutexLocker(self.mutex):
                    target_w = self.target_size.width()
                    target_h = self.target_size.height()

                h, w = raw_image.shape[:2]
                if (w, h) != (target_w, target_h) and target_w > 0:
                    # 使用 INTER_LINEAR 算法，平衡画质与 CPU 消耗
                    display_frame = cv2.resize(raw_image, (target_w, target_h), interpolation=cv2.INTER_LINEAR)
                else:
                    display_frame = raw_image

                # 4. 转换为 RGB 格式并封装为 QImage
                rgb_image = cv2.cvtColor(display_frame, cv2.COLOR_BGR2RGB)
                new_h, new_w, ch = rgb_image.shape
                
                # 💡 copy() 在后台线程执行，不会阻塞主线程 UI
                qimg = QImage(rgb_image.data, new_w, new_h, ch * new_w, QImage.Format_RGB888).copy()

                # 5. 更新缓存并抛出信号
                with QMutexLocker(self.mutex):
                    self.latest_qimage = qimg
                
                self.sig_frame_ready.emit(qimg)    

            except Exception as e:
                print(f"⚠️ [视频引擎] 异常: {e}")
                time.sleep(0.01)

        sock.close()

    def get_latest_frame(self):
        """UI 拉流接口"""
        with QMutexLocker(self.mutex):
            return self.latest_qimage
