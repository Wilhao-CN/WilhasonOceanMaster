# 文件路径: core/data_logger.py
import os
import csv
import time
import threading
from datetime import datetime
from PyQt5.QtCore import QObject, pyqtSignal, QTimer, QThread

# ============================================================
# 🧵 后台落盘工作线程 (V4.1 优化: 解除主线程 I/O 阻塞)
# ============================================================
class _FlushWorker(QObject):
    """
    独立 QObject，运行在专用 QThread 中，负责所有 CSV 文件的磁盘写入。
    通过信号槽接收待写入数据，避免主线程被文件 I/O 阻塞。
    """
    sig_flush_requested = pyqtSignal(dict)   # {dev_id: (filepath, rows)}

    def __init__(self, parent=None):
        super().__init__(parent)
        self.sig_flush_requested.connect(self._do_flush)

    def _do_flush(self, pending: dict):
        """在后台线程中批量写入磁盘"""
        for dev_id, (filepath, rows) in pending.items():
            if not rows or not filepath:
                continue
            try:
                with open(filepath, mode='a', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerows(rows)
            except Exception as e:
                print(f"❌ [DataLogger] 设备 {dev_id:02X} 批量落盘失败: {e}")


class DataLogger(QObject):
    """
    📊 高性能分流数据记录仪 (V4.1 优化版)
    职责：
    1. 【双机分流】：将船坞和子船数据独立保存到不同文件夹。
    2. 【防空值强制落盘】：点击保存瞬间立即建立文件与表头。
    3. 【GPS 兼容】：完整保留底层高频独立采集通道。

    V4.1 优化：
    - 广播信号可控：log_telemetry 增加 broadcast 参数，高频内部遥测不再触发示波器刷新
    - 后台落盘：_flush_buffer 将文件 I/O 委托给后台线程，主线程不再阻塞
    - 广播独立开关：broadcast_enabled 允许运行时关闭全局广播以降低负载
    """
    sig_telemetry_broadcast = pyqtSignal(dict)

    # Both dock (0x01) and boat (0x02) now use the same dual-temperature
    # uplink. These fields are mandatory on disk and must not depend on the
    # oscilloscope checkbox/whitelist state.
    TEMPERATURE_LOG_FIELDS = (
        ("Water Temperature 01 (°C)", ["temperatures", "sensor_01", "water_c"]),
        ("Temperature 01 Valid", ["temperatures", "sensor_01", "valid"]),
        ("Temperature 01 Error Code", ["temperatures", "sensor_01", "error_code"]),
        ("Water Temperature 02 (°C)", ["temperatures", "sensor_02", "water_c"]),
        ("Temperature 02 Valid", ["temperatures", "sensor_02", "valid"]),
        ("Temperature 02 Error Code", ["temperatures", "sensor_02", "error_code"]),
    )

    def __init__(self, parent=None):
        super().__init__(parent)
        self.log_dir = "data_logs"
        # 🌐 [T9] 孪生模式日志分离。
        #    【改造纪律】use_sim_dir 默认 False ⇒ 实船写入路径逐字节不变。
        #    仅当孪生模式开启时由 MainWindow 置 True，日志改写到 data_logs_sim/。
        self.log_dir_sim = "data_logs_sim"
        self.use_sim_dir = False
        self.is_logging = False
        self.whitelist = {}

        # --- 0. 广播独立开关 (V4.1 新增) ---
        self.broadcast_enabled = True

        # --- 1. 常规遥感分流缓冲与文件句柄 ---
        self.buffers = {0x01: [], 0x02: []}
        self.current_files = {0x01: None, 0x02: None}
        self.headers_written = {0x01: False, 0x02: False}

        # --- 2. GPS 独立路径采集专属状态变量 ---
        self.gps_logging_active = False
        self.gps_csv_files = {}

        # --- 3. 后台落盘线程 (V4.1: 解除主线程 I/O 阻塞) ---
        self._flush_thread = QThread(self)
        self._flush_worker = _FlushWorker()
        self._flush_worker.moveToThread(self._flush_thread)
        self._flush_thread.start()

        # --- 5. 硬盘冲刷定时器 (每 2 秒收集缓冲，交由后台线程落盘) ---
        self.flush_timer = QTimer(self)
        self.flush_timer.timeout.connect(self._flush_buffer)
        self.flush_timer.start(2000)

        # --- 6. 固定间隔采样定时器 (200ms) ---
        self.cache = {0x01: None, 0x02: None}
        self.sample_timer = QTimer(self)
        self.sample_timer.timeout.connect(self._sample_and_buffer)
        self.sample_interval_ms = 200

    def _ensure_temperature_log_fields(self):
        """Append missing temperature columns to dock and boat CSV schemas."""
        for dev_id in (0x01, 0x02):
            fields = self.whitelist.setdefault(dev_id, [])
            existing_paths = {tuple(path) for _name, path in fields}
            for display_name, path in self.TEMPERATURE_LOG_FIELDS:
                if tuple(path) not in existing_paths:
                    fields.append((display_name, list(path)))
                    existing_paths.add(tuple(path))

    def update_whitelist(self, config: dict):
        """解析 UI 传来的勾选白名单，预编译数据提取路径"""
        processed_whitelist = {}
        for dev_id, items in config.items():
            processed_whitelist[dev_id] = []
            for display_name, path_str in items:
                path_list = path_str.split('/')
                processed_whitelist[dev_id].append((display_name, path_list))
        self.whitelist = processed_whitelist
        self._ensure_temperature_log_fields()
        # Keep console output ASCII-safe because some Windows deployments still
        # use a GBK code page and raise UnicodeEncodeError on emoji.
        print("[DataLogger] logging field whitelist updated.")

    def start_logging(self, session_name="experiment"):
        """开始常规遥测数据记录 (点击 GUI 保存按钮时触发)"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # 防止用户没点确定导致白名单缺失
        if 0x01 not in self.whitelist: self.whitelist[0x01] = []
        if 0x02 not in self.whitelist: self.whitelist[0x02] = []
        self._ensure_temperature_log_fields()

        # 为船坞、子船分别创建子文件夹
        # 🌐 [T9] 孪生模式改写 data_logs_sim/；实船仍写 data_logs/（默认）
        base_dir = self.log_dir_sim if self.use_sim_dir else self.log_dir
        for dev_id, sub_folder in [(0x01, "dock"), (0x02, "boat")]:
            target_dir = os.path.join(base_dir, sub_folder)
            if not os.path.exists(target_dir):
                os.makedirs(target_dir)

            self.current_files[dev_id] = os.path.join(target_dir, f"{sub_folder}_{timestamp}.csv")
            self.buffers[dev_id].clear()
            self.headers_written[dev_id] = False
            self.cache[dev_id] = None

            # 核心修复：立刻在硬盘上把文件和表头建出来
            self._write_header(dev_id)

        self.is_logging = True
        self.sample_timer.start(self.sample_interval_ms)
        print(f"🚀 [DataLogger] 开启分流存盘：dock & boat 独立文件夹和文件已创建！采样间隔: {self.sample_interval_ms}ms")

    def stop_logging(self):
        """停止记录，并冲刷残留缓存"""
        self.sample_timer.stop()
        self.is_logging = False
        self._flush_buffer()
        self.cache = {0x01: None, 0x02: None}
        print(f"🛑 [DataLogger] 记录已停止，常规遥测文件已安全封口。")

    def log_telemetry(self, telemetry_data: dict, broadcast: bool = True):
        """
        处理高速遥测包 (已通过 MainWindow 拦截器贴上距离 dist 标签)

        参数:
            telemetry_data: 遥测数据字典
            broadcast: 是否触发示波器广播。高频内部遥测应设为 False 以避免不必要渲染。
        """
        if not telemetry_data:
            return

        # 1. 广播给示波器实时显示 (V4.1: 仅在广播开关开启且调用者要求广播时)
        if broadcast and self.broadcast_enabled:
            self.sig_telemetry_broadcast.emit(telemetry_data)

        if not self.is_logging:
            return

        dev_id = telemetry_data.get("id")
        if dev_id not in [0x01, 0x02]:
            return

        # 2. 只更新缓存，不直接写缓冲 —— 由 sample_timer 定时采样
        self.cache[dev_id] = telemetry_data

    def _sample_and_buffer(self):
        """200ms 定时器回调：从缓存中取出最新数据，合并视觉遥测后写入缓冲"""
        if not self.is_logging:
            return

        for dev_id in [0x01, 0x02]:
            data = self.cache.get(dev_id)
            if data is None:
                continue

            current_time_str = datetime.now().strftime("%H:%M:%S.%f")[:-3]
            row = [current_time_str, time.time(), f"0x{dev_id:02X}"]
            for _display_name, path_list in self.whitelist.get(dev_id, []):
                val = self._get_value_fast(data, path_list)
                row.append(val if val is not None else "N/A")
            self.buffers[dev_id].append(row)

    def _write_header(self, dev_id):
        """将表头写入硬盘，创建物理文件"""
        header = ["LocalTime", "UnixTime", "DeviceID"]
        header += [item[0] for item in self.whitelist.get(dev_id, [])]

        try:
            with open(self.current_files[dev_id], mode='w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(header)
            self.headers_written[dev_id] = True
        except Exception as e:
            print(f"❌ [DataLogger] {dev_id:02X} 文件创建与表头写入失败: {e}")

    def _flush_buffer(self):
        """
        [V4.1] 收集缓冲数据，交由后台线程落盘。
        主线程只做 buffer 快照交换（O(1) 引用替换），文件 I/O 完全异步。
        """
        if not self.is_logging:
            return

        # 构建待写入快照：原子交换 buffer，主线程立刻释放
        pending = {}
        for dev_id in [0x01, 0x02]:
            if not self.buffers[dev_id] or not self.current_files[dev_id]:
                continue
            pending[dev_id] = (self.current_files[dev_id], self.buffers[dev_id][:])
            self.buffers[dev_id].clear()

        if not pending:
            return

        # 通过信号槽跨线程投递到后台落盘线程
        self._flush_worker.sig_flush_requested.emit(pending)

    def _get_value_fast(self, data, path_list):
        """O(1) 极速字典深层路径提取"""
        try:
            temp = data
            for part in path_list:
                if part.isdigit():
                    temp = temp[int(part)]
                else:
                    temp = temp[part]
            return temp
        except:
            return None

    def cleanup(self):
        """
        [V4.1] 安全退出：停止落盘线程。
        由 MainWindow.closeEvent 调用，确保后台线程正确退出。
        """
        self._flush_thread.quit()
        self._flush_thread.wait(2000)

    # ====================================================================
    # 📍 GPS 专属路径采集区
    # ====================================================================
    def start_gps_logging(self):
        self.gps_logging_active = True
        save_dir = "gps_paths"
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.gps_csv_files[0x01] = os.path.join(save_dir, f"dock_gps_{timestamp}.csv")
        self.gps_csv_files[0x02] = os.path.join(save_dir, f"boat_gps_{timestamp}.csv")

        headers = ["timestamp", "lat", "lon", "utc_time_A", "utc_time_B"]
        for path in self.gps_csv_files.values():
            with open(path, mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(headers)
        print("🔴 [GPS 采集] 开启！")

    def stop_gps_logging(self):
        self.gps_logging_active = False
        print("⏹️ [GPS 采集] 结束！")

    def log_gps_data(self, dev_id: int, lat: float, lon: float,
                     lat_b: float = None, lon_b: float = None,
                     utc_time_a: int = 0, utc_time_b: int = 0):
        if not self.gps_logging_active:
            return
        if dev_id not in self.gps_csv_files:
            return

        row = [time.time(), lat, lon, utc_time_a, utc_time_b]
        if lat_b is not None and lon_b is not None:
            row.extend([lat_b, lon_b])
        try:
            with open(self.gps_csv_files[dev_id], mode='a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(row)
        except:
            pass
