"""树莓派故障历史同步线程与上位机本地 SQLite 缓存。"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from PyQt5.QtCore import QThread, pyqtSignal


class FaultHistoryCache:
    def __init__(self, db_path: str = "data_logs/fault_history.sqlite3"):
        path = Path(db_path)
        if not path.is_absolute():
            path = Path.cwd() / path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db_path = str(path)
        self._lock = threading.RLock()
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def _initialize(self) -> None:
        with self._lock, closing(self._connect()) as conn, conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS remote_fault_events (
                    local_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id INTEGER NOT NULL,
                    device_name TEXT NOT NULL,
                    store_id TEXT NOT NULL,
                    remote_event_id INTEGER NOT NULL,
                    boot_id TEXT NOT NULL,
                    event_time_utc TEXT NOT NULL,
                    monotonic_ms INTEGER NOT NULL,
                    source TEXT NOT NULL,
                    fault_code INTEGER NOT NULL,
                    state TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    detail_json TEXT NOT NULL,
                    synced_at_utc TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(device_id, store_id, remote_event_id)
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS fault_sync_state (
                    device_id INTEGER PRIMARY KEY,
                    store_id TEXT NOT NULL,
                    last_event_id INTEGER NOT NULL,
                    updated_at_utc TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_remote_fault_device_time "
                "ON remote_fault_events(device_id, event_time_utc)"
            )

    def prepare_sync(self, device_id: int, store_id: str, latest_id: int) -> int:
        """返回同步游标；远端数据库变化或回退时自动从 0 开始。"""
        with self._lock, closing(self._connect()) as conn, conn:
            row = conn.execute(
                "SELECT store_id, last_event_id FROM fault_sync_state "
                "WHERE device_id = ?",
                (int(device_id),),
            ).fetchone()
            reset = (
                row is None
                or str(row["store_id"]) != str(store_id)
                or int(latest_id) < int(row["last_event_id"])
            )
            if reset:
                conn.execute(
                    """
                    INSERT INTO fault_sync_state(device_id, store_id, last_event_id)
                    VALUES (?, ?, 0)
                    ON CONFLICT(device_id) DO UPDATE SET
                        store_id = excluded.store_id,
                        last_event_id = 0,
                        updated_at_utc = CURRENT_TIMESTAMP
                    """,
                    (int(device_id), str(store_id)),
                )
                return 0
            return int(row["last_event_id"])

    def save_events(
        self,
        device_id: int,
        device_name: str,
        store_id: str,
        events: List[Dict[str, Any]],
    ) -> int:
        max_id = 0
        with self._lock, closing(self._connect()) as conn, conn:
            for event in events:
                remote_id = int(event.get("event_id", 0) or 0)
                if remote_id <= 0:
                    continue
                detail = event.get("detail")
                if detail is None:
                    detail = event.get("detail_json", {})
                if isinstance(detail, str):
                    try:
                        detail = json.loads(detail)
                    except json.JSONDecodeError:
                        detail = {"raw": detail}
                conn.execute(
                    """
                    INSERT OR IGNORE INTO remote_fault_events(
                        device_id, device_name, store_id, remote_event_id,
                        boot_id, event_time_utc, monotonic_ms, source,
                        fault_code, state, event_type, detail_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        int(device_id),
                        str(device_name),
                        str(store_id),
                        remote_id,
                        str(event.get("boot_id", "")),
                        str(event.get("event_time_utc", "")),
                        int(event.get("monotonic_ms", 0) or 0),
                        str(event.get("source", "unknown")),
                        int(event.get("fault_code", 0) or 0),
                        str(event.get("state", "event")),
                        str(event.get("event_type", "unknown")),
                        json.dumps(
                            detail or {},
                            ensure_ascii=False,
                            separators=(",", ":"),
                            default=str,
                        ),
                    ),
                )
                max_id = max(max_id, remote_id)

            if max_id:
                conn.execute(
                    """
                    INSERT INTO fault_sync_state(device_id, store_id, last_event_id)
                    VALUES (?, ?, ?)
                    ON CONFLICT(device_id) DO UPDATE SET
                        store_id = excluded.store_id,
                        last_event_id = MAX(last_event_id, excluded.last_event_id),
                        updated_at_utc = CURRENT_TIMESTAMP
                    """,
                    (int(device_id), str(store_id), max_id),
                )
        return max_id

    def events_for_device(self, device_id: int, limit: int = 5000) -> List[Dict[str, Any]]:
        safe_limit = max(1, min(int(limit), 20000))
        with self._lock, closing(self._connect()) as conn, conn:
            rows = conn.execute(
                """
                SELECT * FROM (
                    SELECT * FROM remote_fault_events
                    WHERE device_id = ?
                    ORDER BY local_id DESC LIMIT ?
                ) ORDER BY event_time_utc ASC, local_id ASC
                """,
                (int(device_id), safe_limit),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            try:
                item["detail"] = json.loads(item.pop("detail_json"))
            except (TypeError, json.JSONDecodeError):
                item["detail"] = {}
            result.append(item)
        return result

    def clear_events(self, device_id: int) -> int:
        """删除某设备的全部本地故障事件;保留同步游标,避免重拉旧数据。"""
        with self._lock, closing(self._connect()) as conn, conn:
            cursor = conn.execute(
                "DELETE FROM remote_fault_events WHERE device_id = ?",
                (int(device_id),),
            )
        return int(cursor.rowcount)

    def fault_count(self, device_id: int) -> int:
        with self._lock, closing(self._connect()) as conn, conn:
            row = conn.execute(
                """
                SELECT COUNT(*) AS count FROM remote_fault_events
                WHERE device_id = ? AND (
                    state = 'occurred' OR event_type LIKE 'unexpected_%'
                )
                """,
                (int(device_id),),
            ).fetchone()
        return int(row["count"])


class FaultHistoryClient(QThread):
    health_received = pyqtSignal(dict)
    health_unavailable = pyqtSignal(str)
    history_updated = pyqtSignal(list, int)
    sync_log = pyqtSignal(str)

    def __init__(
        self,
        device_id: int,
        device_name: str,
        db_path: str = "data_logs/fault_history.sqlite3",
        parent=None,
    ):
        super().__init__(parent)
        self.device_id = int(device_id)
        self.device_name = str(device_name)
        self.cache = FaultHistoryCache(db_path)
        self._lock = threading.RLock()
        self._wake = threading.Event()
        self._stop_event = threading.Event()
        self._target_ip = ""
        self._target_port = 8891
        self._force_sync = False
        self._poll_interval = 2.0
        self._failure_count = 0
        self._unavailable_emitted = False

    def configure_target(self, ip: str, port: int = 8891) -> None:
        with self._lock:
            changed = self._target_ip != str(ip).strip() or self._target_port != int(port)
            self._target_ip = str(ip).strip()
            self._target_port = int(port)
            self._force_sync = True
            if changed:
                self._failure_count = 0
                self._unavailable_emitted = False
        self._wake.set()

    def clear_target(self) -> None:
        with self._lock:
            self._target_ip = ""
            self._force_sync = False
            self._failure_count = 0
            self._unavailable_emitted = False
        self._wake.set()

    def request_refresh(self) -> None:
        with self._lock:
            self._force_sync = True
        self._wake.set()

    def local_events(self) -> List[Dict[str, Any]]:
        return self.cache.events_for_device(self.device_id)

    def clear_history(self) -> None:
        """清空本地故障历史缓存(树莓派端数据不受影响),并通知 UI 刷新。"""
        self.cache.clear_events(self.device_id)
        self.history_updated.emit(
            self.local_events(), self.cache.fault_count(self.device_id)
        )

    def stop(self) -> None:
        self._stop_event.set()
        self._wake.set()

    def _target(self) -> Tuple[str, int, bool]:
        with self._lock:
            force = self._force_sync
            self._force_sync = False
            return self._target_ip, self._target_port, force

    @staticmethod
    def _get_json(url: str, timeout: float = 2.0) -> Dict[str, Any]:
        request = Request(url, headers={"Accept": "application/json"})
        try:
            with urlopen(request, timeout=timeout) as response:
                if response.status != 200:
                    raise RuntimeError(f"HTTP状态码 {response.status}")
                raw = response.read(5 * 1024 * 1024 + 1)
        except HTTPError as exc:
            raise RuntimeError(f"HTTP {exc.code}") from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise RuntimeError(str(exc)) from exc
        if len(raw) > 5 * 1024 * 1024:
            raise RuntimeError("故障历史响应超过5MB")
        payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, dict):
            raise RuntimeError("故障历史响应不是JSON对象")
        return payload

    def _sync_events(
        self,
        base_url: str,
        health: Dict[str, Any],
        force: bool,
    ) -> int:
        latest_id = int(health.get("latest_event_id", 0) or 0)
        store_id = str(health.get("store_id") or "legacy")
        cursor = self.cache.prepare_sync(self.device_id, store_id, latest_id)
        synced = 0

        while not self._stop_event.is_set() and cursor < latest_id:
            payload = self._get_json(
                f"{base_url}/fault-events?after={cursor}&limit=200"
            )
            payload_store_id = str(payload.get("store_id") or store_id)
            if payload_store_id != store_id:
                store_id = payload_store_id
                cursor = self.cache.prepare_sync(self.device_id, store_id, latest_id)
            events = payload.get("events") or []
            if not isinstance(events, list) or not events:
                break
            saved_cursor = self.cache.save_events(
                self.device_id,
                str(payload.get("device_name") or self.device_name),
                store_id,
                events,
            )
            if saved_cursor <= cursor:
                break
            synced += len(events)
            cursor = saved_cursor
            latest_id = int(payload.get("latest_event_id", latest_id) or latest_id)

        if synced or force:
            events = self.local_events()
            self.history_updated.emit(events, self.cache.fault_count(self.device_id))
        return synced

    def run(self) -> None:
        next_poll = 0.0
        while not self._stop_event.is_set():
            ip, port, force = self._target()
            if not ip:
                self._wake.wait(0.5)
                self._wake.clear()
                continue

            now = time.monotonic()
            if not force and now < next_poll:
                self._wake.wait(min(0.5, next_poll - now))
                self._wake.clear()
                continue

            base_url = f"http://{ip}:{port}"
            try:
                health = self._get_json(f"{base_url}/health")
                if int(health.get("device_id", -1)) != self.device_id:
                    raise RuntimeError(
                        f"设备ID不匹配: 期望{self.device_id}, "
                        f"收到{health.get('device_id')}"
                    )
                self._failure_count = 0
                self._unavailable_emitted = False
                self.health_received.emit(health)
                synced = self._sync_events(base_url, health, force)
                if synced:
                    self.sync_log.emit(f"已补拉 {synced} 条故障事件")
            except Exception as exc:
                self._failure_count += 1
                if self._failure_count >= 2 and not self._unavailable_emitted:
                    self._unavailable_emitted = True
                    self.health_unavailable.emit(str(exc))

            next_poll = time.monotonic() + self._poll_interval

        self.sync_log.emit("故障历史同步线程已停止")
