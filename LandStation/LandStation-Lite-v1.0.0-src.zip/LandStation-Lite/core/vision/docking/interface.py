"""
对接系统集成接口
与 BoatBrain 的约定和通信协议
"""

from PyQt5.QtCore import pyqtSignal, QObject, QThread
import traceback

try:
    from .localization import DockingLocalizationEngine
    from .docking_controller import VisualDockingController
    from .constants import *
except ImportError:
    from localization import DockingLocalizationEngine
    from docking_controller import VisualDockingController
    from constants import *


class DockingSystemInterface(QObject):
    """
    对接系统的公共接口
    
    这个类是对接系统与 BoatBrain 之间的通信层
    所有与 BoatBrain 的信息交换都通过这个接口进行
    """
    
    # 信号定义
    docking_status_changed = pyqtSignal(str)  # 状态变化信号
    control_command_updated = pyqtSignal(dict)  # 控制命令更新
    error_occurred = pyqtSignal(str)  # 错误信号
    docking_complete = pyqtSignal(bool)  # 对接完成信号
    
    def __init__(self, camera_matrix=None, dist_coeffs=None):
        """
        初始化对接系统接口
        
        参数：
            camera_matrix: 相机内参矩阵（来自相机标定）
            dist_coeffs: 畸变系数
        """
        super().__init__()
        
        # 初始化定位引擎
        self.localization_engine = DockingLocalizationEngine(
            camera_matrix=camera_matrix,
            dist_coeffs=dist_coeffs
        )
        
        # 初始化对接控制器
        self.docking_controller = VisualDockingController()
        
        # 模式标志
        self.is_docking_mode = False  # 对接模式是否激活
        self.is_initialized = False
        
        # 调试模式
        self.debug_mode = True
    
    def initialize(self, camera_matrix=None, dist_coeffs=None):
        """
        初始化对接系统
        
        参数：
            camera_matrix: 相机内参
            dist_coeffs: 畸变系数
        """
        try:
            self.localization_engine = DockingLocalizationEngine(
                camera_matrix=camera_matrix,
                dist_coeffs=dist_coeffs
            )
            self.is_initialized = True
            self._emit_status("初始化完成")
            return True
        except Exception as e:
            self._emit_error(f"初始化失败: {str(e)}")
            return False
    
    def start_docking(self):
        """
        开始对接任务
        
        调用者：BoatBrain（通过 UI 或自动任务）
        
        返回：success, message
        """
        
        if not self.is_initialized:
            return False, "系统未初始化"
        
        try:
            self.is_docking_mode = True
            result = self.docking_controller.start_docking()
            self._emit_status(result.get('status', '对接已启动'))
            return True, "对接已启动"
        except Exception as e:
            self._emit_error(f"启动对接失败: {str(e)}")
            return False, str(e)
    
    def process_vision_frame(self, detections, timestamp=None, current_heading=0.0):
        """
        处理单帧视觉数据
        
        调用者：视觉处理线程（vision_manager）
        
        输入：
            detections: {
                "码1": {"corners": [...], "confidence": ...},
                ...
            }
            timestamp: 帧时间戳
            current_heading: 当前船的航向
        
        返回：{
            "control_command": {...},
            "state": str,
            "feedback": {...}
        }
        """
        
        if not self.is_docking_mode:
            return None, "对接模式未启动"
        
        try:
            # 步骤1: 使用定位引擎处理视觉数据
            localization_result = self.localization_engine.update(
                detections, timestamp=timestamp
            )
            
            if not localization_result.get('success', False):
                # 定位失败
                if self.debug_mode:
                    print(f"[DockingInterface] 定位失败: {localization_result.get('reason', 'unknown')}")
                return None, "定位失败"
            
            # 步骤2: 使用对接控制器计算控制命令
            controller_result = self.docking_controller.update(
                localization_result, current_heading
            )
            
            # 步骤3: 提取控制命令
            control_command = controller_result.get('control', {})
            current_state = controller_result.get('current_state', '未知')
            
            # 步骤4: 发出信号
            self.control_command_updated.emit(control_command)
            
            # 步骤5: 检查对接完成
            if current_state == "DOCKING_COMPLETE":
                self.docking_complete.emit(True)
                self.is_docking_mode = False
            
            # 返回完整的反馈信息
            feedback = {
                "state": current_state,
                "control": control_command,
                "position": localization_result.get('filtered_state', {}),
                "quality": localization_result.get('quality', {}),
                "debug": controller_result.get('debug', {})
            }
            
            return control_command, feedback
            
        except Exception as e:
            error_msg = f"处理视觉帧异常: {str(e)}\n{traceback.format_exc()}"
            self._emit_error(error_msg)
            return None, error_msg
    
    def abort_docking(self, reason="用户中止"):
        """
        中止对接任务
        
        调用者：BoatBrain（用户点击停止按钮）
        
        返回：success
        """
        
        try:
            self.docking_controller.abort_docking(reason)
            self.is_docking_mode = False
            self._emit_status(f"对接已中止: {reason}")
            return True
        except Exception as e:
            self._emit_error(f"中止对接失败: {str(e)}")
            return False
    
    def get_control_command(self, localization_result, current_heading=0.0):
        """
        快速获取单个控制命令
        
        简化版接口，当不需要完整的反馈信息时使用
        
        输入：
            localization_result: 定位结果
            current_heading: 当前航向
        
        返回：{
            "surge": float,
            "sway": float,
            "yaw": float,
            ...
        }
        """
        
        try:
            result = self.docking_controller.update(
                localization_result, current_heading
            )
            return result.get('control', {})
        except Exception as e:
            self._emit_error(f"获取控制命令失败: {str(e)}")
            return {"surge": 0.0, "sway": 0.0, "yaw": 0.0}
    
    def get_docking_status(self):
        """
        获取对接系统当前状态
        
        调用者：UI 返回显示用户对接进度
        
        返回：{
            "is_active": bool,
            "state": str,
            "progress": float,  # 0-100%
            "message": str,
            "debug": {...}
        }
        """
        
        try:
            controller_status = self.docking_controller.get_status()
            
            # 根据状态估计进度
            state = controller_status.get('current_state', 'idle')
            if state == 'idle':
                progress = 0.0
            elif state == 'initializing':
                progress = 10.0
            elif state == 'stage1':
                progress = 30.0
            elif state == 'stage2':
                progress = 60.0
            elif state == 'stage3':
                progress = 85.0
            elif state == 'complete':
                progress = 100.0
            else:
                progress = 0.0
            
            return {
                "is_active": self.is_docking_mode,
                "state": state,
                "progress": progress,
                "total_iterations": controller_status.get('total_iterations', 0),
                "debug": {
                    "recent_states": controller_status.get('recent_states', []),
                    "stage_status": controller_status.get('stage_status', {})
                }
            }
        except Exception as e:
            self._emit_error(f"获取状态失败: {str(e)}")
            return {
                "is_active": False,
                "state": "error",
                "progress": 0.0,
                "error": str(e)
            }
    
    def reset(self):
        """重置对接系统"""
        try:
            self.docking_controller.reset()
            self.localization_engine.reset()
            self.is_docking_mode = False
            self._emit_status("系统已重置")
        except Exception as e:
            self._emit_error(f"重置失败: {str(e)}")
    
    # ========== 私有方法和信号处理 ==========
    
    def _emit_status(self, message):
        """发出状态信号"""
        self.docking_status_changed.emit(message)
        if self.debug_mode:
            print(f"[DockingInterface] {message}")
    
    def _emit_error(self, message):
        """发出错误信号"""
        self.error_occurred.emit(message)
        if self.debug_mode:
            print(f"[DockingInterface] ❌ {message}")
    
    # ========== 与 BoatBrain 的集成点 ==========
    
    def on_joystick_override(self):
        """
        用户操作摇杆时的回调
        （立即中止对接）
        """
        if self.is_docking_mode:
            self.abort_docking("用户操作摇杆")
    
    def on_emergency_stop(self):
        """
        紧急停止时的回调
        """
        self.abort_docking("紧急停止激活")
        # 发送紧急停止信号
        self.error_occurred.emit("紧急停止")
    
    def on_mode_switch(self, new_mode):
        """
        模式切换时的回调
        （从对接模式切换到其他模式时）
        """
        if new_mode != "docking" and self.is_docking_mode:
            self.abort_docking(f"切换模式: {new_mode}")
