"""
工具函数和滤波器模块
包含统一的滤波器接口、坐标转换辅助函数等
"""

import math
import numpy as np


# ═══════════════════════════════════════════════════════
# 统一的滤波器基类
# ═══════════════════════════════════════════════════════

class BaseFilter:
    """滤波器的基类接口"""
    
    def filter(self, value, timestamp=None):
        """对值进行滤波"""
        raise NotImplementedError
    
    def reset(self):
        """重置滤波器"""
        raise NotImplementedError


class OneEuroFilter(BaseFilter):
    """
    OneEuro 滤波器
    
    用于平滑高频抖动（如船在海浪中摇晃）
    保留低频信号（船的实际运动）
    
    参考论文：
    "1€ Filter: A Simple Speed-dependent Low-pass Filter for Noisy Input in Interactive Systems"
    https://cristal.univ-lille.fr/~casiez/1euro/
    """
    
    def __init__(self, min_cutoff=1.0, beta=0.0, d_cutoff=1.0):
        """
        初始化 OneEuro 滤波器
        
        参数：
            min_cutoff: 最小截断频率 (Hz)，取 0.08Hz 用于海浪补偿
            beta: 速度相关系数 (0~1)，取 0.005 用于缓慢运动
            d_cutoff: 微分截断频率 (Hz)，取 1.0
        
        典型参数示例（海上环境）：
            min_cutoff = 0.08 Hz    # 周期 12.5 秒，抑制海浪频率
            beta = 0.005            # 速度弱相关
            d_cutoff = 1.0 Hz       # 微分项频率
        """
        
        self.min_cutoff = min_cutoff
        self.beta = beta
        self.d_cutoff = d_cutoff
        
        # 低频滤波器
        self.x_filter = LowPassFilter(
            cutoff=min_cutoff, d_cutoff=d_cutoff
        )
        
        # 微分（速度）滤波器
        self.dx_filter = LowPassFilter(
            cutoff=d_cutoff, d_cutoff=d_cutoff
        )
        
        # 状态
        self.last_x = None
        self.last_timestamp = None
    
    def filter(self, value, timestamp=None):
        """对值进行一欧滤波"""
        if self.last_x is None:
            self.last_x = value
            self.last_timestamp = timestamp or 0.0
            return value
        
        # 计算采样时间间隔
        if timestamp is not None:
            dt = max(0.001, timestamp - self.last_timestamp)
            self.last_timestamp = timestamp
        else:
            dt = 0.05  # 默认 50ms
        
        # 计算速度（微分）
        dx = (value - self.last_x) / dt
        filtered_dx = self.dx_filter.filter_value(dx, dt)
        
        # 自适应截断频率
        cutoff = self.min_cutoff + self.beta * abs(filtered_dx)
        self.x_filter.set_cutoff(cutoff)
        
        # 滤波值
        filtered_x = self.x_filter.filter_value(value, dt)
        self.last_x = filtered_x
        
        return filtered_x
    
    def reset(self):
        """重置滤波器"""
        self.x_filter.reset()
        self.dx_filter.reset()
        self.last_x = None
        self.last_timestamp = None


class LowPassFilter(BaseFilter):
    """一阶低通滤波器"""
    
    def __init__(self, cutoff=1.0, d_cutoff=1.0):
        """
        初始化低通滤波器
        
        参数：
            cutoff: 截断频率 (Hz)
            d_cutoff: 微分截断频率 (Hz)
        """
        self.cutoff = cutoff
        self.d_cutoff = d_cutoff
        self.prev_value = None
    
    def filter_value(self, value, dt):
        """对单个值进行低通滤波"""
        if self.prev_value is None:
            self.prev_value = value
            return value
        
        alpha = self._compute_alpha(dt)
        filtered = alpha * value + (1.0 - alpha) * self.prev_value
        self.prev_value = filtered
        
        return filtered
    
    def filter(self, value, timestamp=None):
        """接口方法"""
        return self.filter_value(value, 0.05)
    
    def _compute_alpha(self, dt):
        """计算滤波系数"""
        tau = 1.0 / (2.0 * math.pi * self.cutoff)
        return dt / (tau + dt)
    
    def set_cutoff(self, cutoff):
        """更新截断频率"""
        self.cutoff = cutoff
    
    def reset(self):
        """重置滤波器"""
        self.prev_value = None


class KalmanFilter1D(BaseFilter):
    """
    一维卡尔曼滤波器
    
    可用于替代 OneEuro 滤波器的备选方案
    """
    
    def __init__(self, process_variance=0.001, measurement_variance=0.1):
        """
        初始化卡尔曼滤波器
        
        参数：
            process_variance: 过程噪声 q
            measurement_variance: 测量噪声 r
        """
        self.q = process_variance
        self.r = measurement_variance
        
        self.x = 0.0        # 状态估计
        self.p = 1.0        # 误差协方差
        self.k_gain = 0.0   # 卡尔曼增益
    
    def filter(self, measurement, timestamp=None):
        """用新测量值更新卡尔曼滤波器"""
        # 预测步骤
        p_predict = self.p + self.q
        
        # 更新步骤
        self.k_gain = p_predict / (p_predict + self.r)
        self.x = self.x + self.k_gain * (measurement - self.x)
        self.p = (1.0 - self.k_gain) * p_predict
        
        return self.x
    
    def reset(self):
        """重置滤波器"""
        self.x = 0.0
        self.p = 1.0
        self.k_gain = 0.0


# ═══════════════════════════════════════════════════════
# 通用工具函数
# ═══════════════════════════════════════════════════════

def clamp(value, min_val, max_val):
    """限制值在范围内"""
    return max(min_val, min(max_val, value))


def normalize_angle(angle_rad):
    """将角度正规化到 [-π, π]"""
    while angle_rad > math.pi:
        angle_rad -= 2 * math.pi
    while angle_rad < -math.pi:
        angle_rad += 2 * math.pi
    return angle_rad


def deg_to_rad(angle_deg):
    """度数转弧度"""
    return angle_deg * math.pi / 180.0


def rad_to_deg(angle_rad):
    """弧度转度数"""
    return angle_rad * 180.0 / math.pi


def distance_2d(x1, y1, x2, y2):
    """2D距离计算"""
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)


def distance_3d(x1, y1, z1, x2, y2, z2):
    """3D距离计算"""
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)


def moving_average_filter(values, window_size=3):
    """简单的移动平均滤波"""
    if len(values) < window_size:
        return values
    
    filtered = []
    for i in range(len(values)):
        start = max(0, i - window_size // 2)
        end = min(len(values), i + window_size // 2 + 1)
        avg = sum(values[start:end]) / (end - start)
        filtered.append(avg)
    
    return filtered


def interpolate_linear(v1, v2, t):
    """线性插值"""
    return v1 + (v2 - v1) * t

