"""
统一的多阶段对接控制器
整合原有的 Stage1/2/3 控制器，提供统一的控制接口
"""

import math
import numpy as np

try:
    from .constants import *
except ImportError:
    from constants import *


class BaseStageController:
    """
    多阶段控制器的基类
    提供通用的 PID 计算、积分饱和、归一化等功能
    """
    
    def __init__(self, stage_name, stage_config):
        """
        初始化基类
        
        Args:
            stage_name: str，阶段名称 ("STAGE1", "STAGE2", "STAGE3")
            stage_config: dict，该阶段的配置参数
        """
        self.stage_name = stage_name
        self.config = stage_config
        
        # PID 参数
        self.k_lateral = stage_config.get('k_lateral', 0.5)
        self.k_yaw = stage_config.get('k_yaw', 0.3)
        self.k_distance = stage_config.get('k_distance', 0.4)
        self.k_lat_d = stage_config.get('k_lat_d', 0.0)
        
        # 目标速度
        self.target_speed = stage_config.get('target_speed', 0.1)
        
        # 积分状态
        self.lateral_integral = 0.0
        self.yaw_integral = 0.0
        self.distance_integral = 0.0
        
        # 微分项的历史值
        self.prev_lateral_error = 0.0
        self.prev_yaw_error = 0.0
        self.prev_distance_error = 0.0
        
        # 统计
        self.iteration_count = 0
        self.dt = 0.05  # 默认控制周期 50ms
    
    def _pid_control(self, error, integral_state, prev_error, kp, ki, kd, 
                     integral_limit=None, output_limit=1.0):
        """
        通用 PID 控制计算
        
        Args:
            error: 当前误差
            integral_state: 积分累积值
            prev_error: 上一步的误差（用于微分项）
            kp, ki, kd: PID 系数
            integral_limit: tuple，积分限制 (min, max)
            output_limit: 输出限制范围
        
        Returns:
            tuple: (output, updated_integral, derivative)
        """
        # P 项
        p_term = kp * error
        
        # I 项
        integral_state += error * self.dt
        if integral_limit:
            integral_state = np.clip(integral_state, integral_limit[0], integral_limit[1])
        i_term = ki * integral_state if ki > 0 else 0.0
        
        # D 项
        derivative = (error - prev_error) / self.dt if self.dt > 0 else 0.0
        d_term = kd * derivative if kd > 0 else 0.0
        
        # 总输出
        output = np.clip(p_term + i_term + d_term, -output_limit, output_limit)
        
        return output, integral_state, derivative
    
    def _emergency_stop(self, reason):
        """紧急停止"""
        return {
            "surge": 0.0,
            "sway": 0.0,
            "yaw": 0.0,
            "debug": {
                "stage": self.stage_name,
                "error": reason,
                "control": "EMERGENCY_STOP"
            }
        }
    
    def reset(self):
        """重置控制器状态"""
        self.lateral_integral = 0.0
        self.yaw_integral = 0.0
        self.distance_integral = 0.0
        self.prev_lateral_error = 0.0
        self.prev_yaw_error = 0.0
        self.prev_distance_error = 0.0
        self.iteration_count = 0
    
    def get_status(self):
        """获取控制器状态"""
        return {
            "stage": self.stage_name,
            "iteration_count": self.iteration_count,
            "integral_states": {
                "lateral": self.lateral_integral,
                "yaw": self.yaw_integral,
                "distance": self.distance_integral
            },
            "parameters": self.config
        }


class Stage1Controller(BaseStageController):
    """
    第1阶段：远距离接近（> 0.5m）
    粗网格控制，主要调整方向和速度
    """
    
    def __init__(self):
        """初始化第1阶段控制器"""
        config = {
            'k_lateral': STAGE1_LATERAL_KP,
            'k_yaw': STAGE1_YAW_KP,
            'k_distance': STAGE1_DISTANCE_KP,
            'target_speed': STAGE1_TARGET_SPEED
        }
        super().__init__("STAGE1_DISTANT_APPROACH", config)
    
    def compute_control(self, localization_result, current_heading=0.0):
        """
        计算第1阶段控制命令
        
        输入：
            localization_result: 来自定位引擎的状态
            current_heading: 当前船头方向
        
        输出：控制命令字典
        """
        self.iteration_count += 1
        
        if not localization_result.get('success', False):
            return self._emergency_stop("定位失败")
        
        # 提取状态信息
        filtered_state = localization_result.get('filtered_state', {})
        distance = filtered_state.get('distance_to_dock', float('inf'))
        lateral = filtered_state.get('lateral_offset', 0.0)
        height = filtered_state.get('height_offset', 0.0)
        
        quality = localization_result.get('quality', {})
        num_markers = quality.get('num_markers', 0)
        
        debug_info = {
            'iteration': self.iteration_count,
            'distance': distance,
            'lateral': lateral,
            'height': height,
            'num_markers': num_markers,
            'actions': []
        }
        
        # ========== 纵向控制 ==========
        if distance > 0.7:
            surge = self.target_speed
            debug_info['actions'].append('全速前进')
        elif distance > 0.5:
            surge = self.target_speed * 0.7
            debug_info['actions'].append('降速接近')
        else:
            surge = self.target_speed * 0.3
            debug_info['actions'].append('低速接近')
        
        surge = np.clip(surge / self.target_speed, -1.0, 1.0)
        
        # ========== 横向控制（PID） ==========
        sway, self.lateral_integral, _ = self._pid_control(
            lateral, self.lateral_integral, self.prev_lateral_error,
            self.k_lateral, 0.02, 0.01,
            integral_limit=(-0.3, 0.3)
        )
        self.prev_lateral_error = lateral
        
        if abs(lateral) > 0.1:
            debug_info['actions'].append(f'横向纠正: {lateral:.3f}m')
        
        # ========== 偏航控制 ==========
        yaw_error = lateral / distance if distance > 0.1 else 0.0
        yaw, self.yaw_integral, _ = self._pid_control(
            yaw_error, self.yaw_integral, self.prev_yaw_error,
            self.k_yaw, 0.01, 0.0,
            integral_limit=(-0.2, 0.2)
        )
        self.prev_yaw_error = yaw_error
        
        # ========== 安全检查 ==========
        if abs(height) > 0.1:
            surge *= 0.7
            debug_info['actions'].append(f'高度偏差过大: {height:.3f}m，降速')
        
        return {
            "surge": surge,
            "sway": sway,
            "yaw": yaw,
            "debug": debug_info
        }


class Stage2Controller(BaseStageController):
    """
    第2阶段：精密对齐（0.1m ~ 0.5m）
    多码传感，精密侧向和纵向控制
    """
    
    def __init__(self):
        """初始化第2阶段控制器"""
        config = {
            'k_lateral': STAGE2_LATERAL_KP,
            'k_yaw': STAGE2_YAW_KP,
            'k_distance': STAGE2_DISTANCE_KP,
            'target_speed': STAGE2_TARGET_SPEED
        }
        super().__init__("STAGE2_ALIGNMENT", config)
        
        # 对齐检查
        self.lateral_aligned_frames = 0
        self.alignment_threshold = STAGE2_ALIGNMENT_THRESHOLD
    
    def compute_control(self, localization_result, current_heading=0.0):
        """计算第2阶段控制命令"""
        self.iteration_count += 1
        
        if not localization_result.get('success', False):
            return self._emergency_stop("定位失败")
        
        filtered_state = localization_result.get('filtered_state', {})
        distance = filtered_state.get('distance_to_dock', float('inf'))
        lateral = filtered_state.get('lateral_offset', 0.0)
        height = filtered_state.get('height_offset', 0.0)
        
        quality = localization_result.get('quality', {})
        num_markers = quality.get('num_markers', 0)
        pnp_error = quality.get('pnp_error', float('inf'))
        
        debug_info = {
            'iteration': self.iteration_count,
            'distance': distance,
            'lateral': lateral,
            'height': height,
            'num_markers': num_markers,
            'pnp_error': pnp_error,
            'alignment_ready': False,
            'actions': []
        }
        
        # ========== 阶段转换检查 ==========
        if distance < STAGE2_TO_STAGE3_THRESHOLD:
            debug_info['actions'].append('距离 < 0.1m，升级到第3阶段')
            return {
                "surge": 0.01,
                "sway": 0.0,
                "yaw": 0.0,
                "stage_transition": "to_STAGE3",
                "debug": debug_info
            }
        
        if distance > 0.5:
            debug_info['actions'].append('距离 > 0.5m，降级到第1阶段')
            return {
                "surge": 0.0,
                "sway": 0.0,
                "yaw": 0.0,
                "stage_transition": "to_STAGE1",
                "debug": debug_info
            }
        
        if num_markers < 3:
            debug_info['actions'].append('警告：标记不足')
        
        # ========== 纵向控制 ==========
        distance_error = distance - STAGE2_TARGET_DISTANCE
        surge, self.distance_integral, _ = self._pid_control(
            -distance_error, self.distance_integral, self.prev_distance_error,
            self.k_distance, 0.01, 0.005,
            integral_limit=(-0.1, 0.1)
        )
        self.prev_distance_error = distance_error
        surge = np.clip(surge, 0.0, self.target_speed) / 0.25
        
        # ========== 横向控制 ==========
        sway, self.lateral_integral, _ = self._pid_control(
            lateral, self.lateral_integral, self.prev_lateral_error,
            self.k_lateral, 0.05, 0.02,
            integral_limit=(-0.2, 0.2)
        )
        self.prev_lateral_error = lateral
        
        # 检查对齐
        if abs(lateral) < self.alignment_threshold:
            self.lateral_aligned_frames += 1
            alignment_ready = self.lateral_aligned_frames > 5
        else:
            self.lateral_aligned_frames = 0
            alignment_ready = False
        
        if alignment_ready:
            debug_info['actions'].append('✓ 横向对齐完成')
        
        debug_info['alignment_ready'] = alignment_ready
        
        # ========== 偏航控制 ==========
        yaw_error = (lateral / distance * 2.0) if distance > 0.1 else 0.0
        yaw, self.yaw_integral, _ = self._pid_control(
            yaw_error, self.yaw_integral, self.prev_yaw_error,
            self.k_yaw, 0.02, 0.0,
            integral_limit=(-0.15, 0.15)
        )
        self.prev_yaw_error = yaw_error
        
        return {
            "surge": surge,
            "sway": sway,
            "yaw": yaw,
            "alignment_ready": alignment_ready,
            "debug": debug_info
        }
    
    def reset(self):
        """重置控制器"""
        super().reset()
        self.lateral_aligned_frames = 0


class Stage3Controller(BaseStageController):
    """
    第3阶段：精细进入（< 0.1m）
    严格的PID控制，安全着陆
    """
    
    def __init__(self):
        """初始化第3阶段控制器"""
        config = {
            'k_lateral': STAGE3_LATERAL_KP,
            'k_lat_d': STAGE3_LATERAL_KD,
            'k_yaw': STAGE3_YAW_KP,
            'target_speed': STAGE3_CREEP_SPEED
        }
        super().__init__("STAGE3_PRECISE_ENTRY", config)
        
        # 安全监控
        self.lateral_violation_frames = 0
        self.distance_violation_frames = 0
        self.fully_entered_frames = 0
        self.docking_success = False
    
    def compute_control(self, localization_result, current_heading=0.0):
        """计算第3阶段控制命令"""
        self.iteration_count += 1
        
        if not localization_result.get('success', False):
            return self._emergency_stop("定位失败")
        
        filtered_state = localization_result.get('filtered_state', {})
        distance = filtered_state.get('distance_to_dock', float('inf'))
        lateral = filtered_state.get('lateral_offset', 0.0)
        height = filtered_state.get('height_offset', 0.0)
        fully_entered = filtered_state.get('fully_entered', False)
        
        quality = localization_result.get('quality', {})
        num_markers = quality.get('num_markers', 0)
        pnp_error = quality.get('pnp_error', float('inf'))
        
        debug_info = {
            'iteration': self.iteration_count,
            'distance': distance,
            'lateral': lateral,
            'height': height,
            'num_markers': num_markers,
            'pnp_error': pnp_error,
            'docking_complete': False,
            'emergency_triggered': False,
            'actions': []
        }
        
        # ========== 严重失败检查 ==========
        if num_markers < 3:
            debug_info['actions'].append('⚠️ 标记不足，无法继续')
            return self._emergency_stop("标记不足")
        
        if pnp_error > 8.0:
            debug_info['actions'].append('⚠️ PnP 质量太差')
            return self._emergency_stop("PnP质量不足")
        
        if distance > 0.15:
            debug_info['actions'].append('⚠️ 距离过大，应在STAGE2')
            return {
                "surge": 0.0,
                "sway": 0.0,
                "yaw": 0.0,
                "stage_transition": "to_STAGE2",
                "debug": debug_info,
                "emergency_stop": False,
                "docking_complete": False
            }
        
        # 横向安全检查
        if abs(lateral) > STAGE3_LATERAL_LIMIT:
            self.lateral_violation_frames += 1
            debug_info['actions'].append(f'⚠️ 横向超限: {lateral:.3f}m')
            if self.lateral_violation_frames > 3:
                debug_info['actions'].append('❌ 横向超限过久，紧急停止')
                return self._emergency_stop(f"横向超限 {lateral:.3f}m")
        else:
            self.lateral_violation_frames = 0
        
        # 高度安全检查
        if abs(height) > STAGE3_HEIGHT_LIMIT:
            debug_info['actions'].append(f'⚠️ 高度超限: {height:.3f}m')
            return self._emergency_stop(f"高度超限 {height:.3f}m")
        
        # ========== 自适应纵向控制 ==========
        if distance < 0.05:
            surge = 0.02
            debug_info['actions'].append('🔴 超近距离，极限爬行')
        elif distance < 0.08:
            surge = 0.04
            debug_info['actions'].append('🟠 接近距离，低速爬行')
        else:
            surge = self.target_speed
            debug_info['actions'].append(f'🟡 爬行速度: {surge*100:.1f}cm/s')
        
        if distance < DISTANCE_EMERGENCY_THRESHOLD:
            debug_info['actions'].append('✓ 已进入安全距离')
            if fully_entered:
                self.fully_entered_frames += 1
                if self.fully_entered_frames > 2:
                    debug_info['docking_complete'] = True
                    debug_info['actions'].append('🎉 停靠完成！')
                    self.docking_success = True
            surge = 0.005
        
        surge = np.clip(surge / 0.25, -1.0, 1.0)
        
        # ========== 横向修正（PID） ==========
        sway, self.lateral_integral, _ = self._pid_control(
            lateral, self.lateral_integral, self.prev_lateral_error,
            self.k_lateral, 0.05, self.k_lat_d,
            integral_limit=(-0.1, 0.1)
        )
        self.prev_lateral_error = lateral
        
        if abs(lateral) > 0.02:
            debug_info['actions'].append(f'→ 横向修正: {lateral*100:.1f}cm')
        
        # ========== 偏航控制 ==========
        if distance > 0.05:
            yaw_error = math.atan(lateral / max(distance, 0.01))
        else:
            yaw_error = 0.0
        
        yaw, self.yaw_integral, _ = self._pid_control(
            yaw_error, self.yaw_integral, self.prev_yaw_error,
            self.k_yaw, 0.01, 0.0,
            integral_limit=(-0.1, 0.1)
        )
        self.prev_yaw_error = yaw_error
        
        return {
            "surge": surge,
            "sway": sway,
            "yaw": yaw,
            "docking_complete": self.docking_success,
            "emergency_stop": False,
            "debug": debug_info
        }
    
    def reset(self):
        """重置控制器"""
        super().reset()
        self.lateral_violation_frames = 0
        self.distance_violation_frames = 0
        self.fully_entered_frames = 0
        self.docking_success = False
    
    def get_status(self):
        """获取控制器状态"""
        status = super().get_status()
        status.update({
            "docking_success": self.docking_success,
            "safety_violations": {
                "lateral": self.lateral_violation_frames,
                "distance": self.distance_violation_frames
            }
        })
        return status
