"""
PnP (Perspective-n-Point) 位姿求解器
使用代码已检测的多个二维码的位置，求解相机的位姿
"""

import cv2
import numpy as np

try:
    from .constants import *
except ImportError:
    from constants import *


class PnPSolver:
    """
    PnP 求解器：从码位置求解相机在船坞中的位置
    
    基于 OpenCV 的 solvePnP 和 solvePnPRansac
    """
    
    def __init__(self, camera_matrix=None, dist_coeffs=None):
        """
        初始化 PnP 求解器
        
        Args:
            camera_matrix: 3×3 内参矩阵，如果为 None 使用默认值
            dist_coeffs: 5×1 畸变系数，如果为 None 使用无畸变
        """
        
        # 相机内参
        if camera_matrix is None:
            self.camera_matrix = np.array([
                [CAMERA_FX, 0, CAMERA_CX],
                [0, CAMERA_FY, CAMERA_CY],
                [0, 0, 1]
            ], dtype=np.float32)
        else:
            self.camera_matrix = camera_matrix
        
        # 畸变系数
        if dist_coeffs is None:
            self.dist_coeffs = np.array(CAMERA_DIST_COEFFS, dtype=np.float32).reshape(-1, 1)
        else:
            self.dist_coeffs = dist_coeffs
        
        # 码的标准 3D 位置（船坞坐标系）
        self.marker_3d_positions = {
            "码1": np.array([-0.320, +0.410, 0.0], dtype=np.float32),
            "码2": np.array([+0.320, +0.410, 0.0], dtype=np.float32),
            "码3": np.array([+0.320, -0.410, 0.0], dtype=np.float32),
            "码4": np.array([-0.320, -0.410, 0.0], dtype=np.float32),
            "码5": np.array([0.000, -0.410, 0.0], dtype=np.float32)
        }
    
    def solve_pose(self, detections):
        """
        从检测到的码的位置求解相机位姿
        
        输入：detections = {
            "码1": {
                "corners": [[u1, v1], [u2, v2], [u3, v3], [u4, v4]],
                "confidence": 0.95
            },
            ...
        }
        
        输出：{
            "success": bool,
            "camera_x": float,
            "camera_y": float,
            "camera_z": float,
            "camera_position": np.ndarray [x, y, z],
            "rotation_matrix": 3×3,
            "euler_angles": [pitch, yaw, roll],
            "reprojection_error": float,
            "markers_used": list,
            "num_markers": int
        }
        """
        
        # 检查检测数量
        if len(detections) < 3:
            return {
                "success": False,
                "reason": "insufficient_markers",
                "num_markers": len(detections)
            }
        
        # 收集 3D 和 2D 点
        object_points = []
        image_points = []
        used_markers = []
        
        for marker_name, detection in detections.items():
            if marker_name in self.marker_3d_positions:
                # 3D 点（船坞坐标系）
                object_points.append(self.marker_3d_positions[marker_name])
                
                # 2D 点（图像坐标）：计算码的中心
                if "corners" in detection:
                    corners = np.array(detection["corners"], dtype=np.float32)
                    center = corners.mean(axis=0)
                    image_points.append(center)
                    used_markers.append(marker_name)
        
        if len(object_points) < 3:
            return {
                "success": False,
                "reason": "valid_points_insufficient"
            }
        
        object_points = np.array(object_points, dtype=np.float32)
        image_points = np.array(image_points, dtype=np.float32)
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 使用 RANSAC 增强鲁棒性
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        success = False
        rvec = None
        tvec = None
        inliers = None
        
        try:
            # 首先尝试 RANSAC（更鲁棒，能处理离群值）
            success, rvec, tvec, inliers = cv2.solvePnPRansac(
                object_points,
                image_points,
                self.camera_matrix,
                self.dist_coeffs,
                flags=cv2.SOLVEPNP_EPNP,
                reprojectionError=8.0,  # 像素
                confidence=0.99,
                iterationsCount=100
            )
            
            if not success or inliers is None:
                # RANSAC 失败，使用普通 PnP
                success, rvec, tvec = cv2.solvePnP(
                    object_points,
                    image_points,
                    self.camera_matrix,
                    self.dist_coeffs,
                    flags=cv2.SOLVEPNP_EPNP,
                    useExtrinsicGuess=False
                )
        except Exception as e:
            return {
                "success": False,
                "reason": f"pnp_error: {str(e)}"
            }
        
        if not success or rvec is None or tvec is None:
            return {
                "success": False,
                "reason": "pnp_failed"
            }
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 提取位姿信息
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        # 旋转向量 → 旋转矩阵
        rmat, _ = cv2.Rodrigues(rvec)
        
        # tvec 是船坞原点相对于相机的位置
        # 我们需要相机相对于船坞的位置（反向）
        camera_pos = -rmat.T @ tvec
        
        # 旋转矩阵 → 欧拉角
        euler = cv2.RQDecomp3x3(rmat)[0]
        
        # 计算重投影误差（质量指标）
        reprojection_error = self._calc_reprojection_error(
            object_points, image_points, rvec, tvec
        )
        
        return {
            "success": True,
            "camera_x": float(camera_pos[0, 0]),
            "camera_y": float(camera_pos[1, 0]),
            "camera_z": float(camera_pos[2, 0]),
            "camera_position": camera_pos.flatten(),
            "rotation_matrix": rmat,
            "euler_angles": euler,
            "reprojection_error": float(reprojection_error),
            "markers_used": used_markers,
            "num_markers": len(used_markers),
            "rvec": rvec,
            "tvec": tvec
        }
    
    def _calc_reprojection_error(self, obj_pts, img_pts, rvec, tvec):
        """
        计算重投影误差
        
        返回值越小说明定位质量越好
        
        Args:
            obj_pts: 3D 点
            img_pts: 2D 点
            rvec: 旋转向量
            tvec: 平移向量
        
        Returns:
            float: 平均重投影误差
        """
        
        try:
            proj_pts, _ = cv2.projectPoints(
                obj_pts, rvec, tvec, self.camera_matrix, self.dist_coeffs
            )
            
            # 计算欧几里得距离
            errors = np.linalg.norm(
                img_pts - proj_pts.reshape(-1, 2), axis=1
            )
            
            return float(np.mean(errors))
        except:
            return float('inf')
    
    def get_camera_matrix(self):
        """获取相机矩阵"""
        return self.camera_matrix.copy()
    
    def set_camera_matrix(self, camera_matrix):
        """设置相机矩阵（用于标定更新）"""
        self.camera_matrix = camera_matrix
    
    def validate_pose(self, pose_result):
        """
        验证 PnP 求解结果的有效性
        
        Returns:
            dict: {
                'valid': bool,
                'reason': str,
                'reprojection_error_quality': 'good'|'ok'|'bad',
                'num_markers_quality': 'excellent'|'good'|'fair'
            }
        """
        
        if not pose_result.get('success', False):
            return {
                'valid': False,
                'reason': 'pnp_failed'
            }
        
        # 检查重投影误差
        error = pose_result.get('reprojection_error', float('inf'))
        if error < 2:
            error_quality = 'good'
        elif error < 5:
            error_quality = 'ok'
        else:
            error_quality = 'bad'
        
        # 检查码数量
        num_markers = pose_result.get('num_markers', 0)
        if num_markers >= 5:
            marker_quality = 'excellent'
        elif num_markers >= 4:
            marker_quality = 'good'
        else:
            marker_quality = 'fair'
        
        # 综合判断
        valid = (error_quality != 'bad') and (marker_quality != 'fair')
        
        return {
            'valid': valid,
            'reason': 'ok' if valid else f'error_quality={error_quality}, marker_quality={marker_quality}',
            'reprojection_error_quality': error_quality,
            'num_markers_quality': marker_quality,
            'reprojection_error': error,
            'num_markers': num_markers
        }
