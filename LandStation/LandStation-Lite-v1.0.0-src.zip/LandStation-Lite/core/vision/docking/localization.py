"""
高层定位引擎
整合所有定位逻辑，输出船的状态信息
"""

import numpy as np

try:
    from .constants import *
    from .pnp_solver import PnPSolver
    from .coordinate_transform import CoordinateTransformer
    from .geometry import ValidationHelper
    from .utils import OneEuroFilter
except ImportError:
    from constants import *
    from pnp_solver import PnPSolver
    from coordinate_transform import CoordinateTransformer
    from geometry import ValidationHelper
    from utils import OneEuroFilter


class DockingLocalizationEngine:
    """
    统一的对接定位引擎
    
    输入：视觉检测结果（多个码的位置）
    输出：船的状态信息（距离、偏移、阶段等）
    """
    
    def __init__(self, camera_matrix=None, dist_coeffs=None):
        """
        初始化定位引擎
        
        Args:
            camera_matrix: 相机内参矩阵
            dist_coeffs: 畸变系数
        """
        
        # 初始化各个子模块
        self.pnp_solver = PnPSolver(camera_matrix, dist_coeffs)
        self.transformer = CoordinateTransformer()
        self.validator = ValidationHelper()
        
        # 初始化 OneEuro 滤波器（平滑海浪晃动）
        self.distance_filter = OneEuroFilter(
            min_cutoff=FILTER_MIN_CUTOFF,
            beta=FILTER_BETA,
            d_cutoff=FILTER_D_CUTOFF
        )
        
        self.lateral_filter = OneEuroFilter(
            min_cutoff=FILTER_MIN_CUTOFF,
            beta=FILTER_BETA,
            d_cutoff=FILTER_D_CUTOFF
        )
        
        # 状态历史（用于滤波）
        self.last_state = None
        self.lost_frames_count = 0
    
    def update(self, detections, timestamp=None):
        """
        主更新入口：从视觉检测结果计算船的当前位置
        
        输入：
            detections: {
                "码1": {"corners": [...], "confidence": 0.95, ...},
                "码2": {...},
                ...
            }
            timestamp: float，当前时间戳（用于滤波）
        
        输出：{
            "success": bool,
            "stage": str,
            "ship_state": {...},
            "filtered_state": {...},
            "confidence": float,
            "num_markers": int,
            "validation": {...},
            "debug_info": {...}
        }
        """
        
        if not detections or len(detections) < 2:
            self.lost_frames_count += 1
            return self._handle_marker_loss()
        
        # 重置丢失计数
        self.lost_frames_count = 0
        
        # 步骤 1: PnP 求解摄像头位置
        pnp_result = self.pnp_solver.solve_pose(detections)
        
        if not pnp_result.get("success", False):
            return self._handle_pnp_failure(pnp_result)
        
        # 步骤 2: 验证 PnP 结果
        pnp_validation = self.pnp_solver.validate_pose(pnp_result)
        
        if not pnp_validation.get('valid', False):
            # PnP 失败，使用预测值
            return self._use_prediction()
        
        # 步骤 3: 将相机位置转换为船的状态
        camera_y = pnp_result["camera_y"]
        camera_x = pnp_result["camera_x"]
        camera_z = pnp_result["camera_z"]
        
        ship_state = self.transformer.camera_position_to_ship_state(
            camera_y, camera_x, camera_z
        )
        
        # 步骤 4: 验证船的状态（安全检查）
        state_validation = self._validate_ship_state(ship_state)
        
        if not state_validation['all_valid']:
            # 某些指标超限
            print(f"⚠️ 船状态异常: {state_validation['issues']}")
        
        # 步骤 5: 使用 OneEuro 滤波平滑（针对海浪晃动）
        filtered_state = self._apply_filtering(
            ship_state, timestamp
        )
        
        # 记录当前状态
        self.last_state = filtered_state
        
        # 步骤 6: 返回完整的定位结果
        return {
            "success": True,
            "stage": filtered_state['stage'],
            
            # 原始测量值
            "raw_state": {
                "distance": ship_state['distance_to_dock'],
                "lateral": ship_state['lateral_offset'],
                "height": ship_state['height_offset']
            },
            
            # 滤波后的值（用于控制）
            "filtered_state": {
                "distance": filtered_state['distance_to_dock'],
                "lateral": filtered_state['lateral_offset'],
                "height": filtered_state['height_offset'],
                "stage": filtered_state['stage']
            },
            
            # 质量指标
            "quality": {
                "pnp_error": pnp_result.get('reprojection_error', float('inf')),
                "num_markers": pnp_result.get('num_markers', 0),
                "pnp_validation": pnp_validation
            },
            
            # 验证信息
            "validation": state_validation,
            
            # 调试信息
            "debug_info": {
                "timestamp": timestamp,
                "camera_position": [camera_x, camera_y, camera_z],
                "markers_used": pnp_result.get('markers_used', []),
                "euler_angles": pnp_result.get('euler_angles', None)
            }
        }
    
    def _handle_marker_loss(self):
        """处理标记丢失的情况"""
        
        if self.lost_frames_count > MAX_MARKER_LOSS_FRAMES:
            return {
                "success": False,
                "reason": "marker_loss_timeout",
                "lost_frames": self.lost_frames_count,
                "last_state": self.last_state
            }
        
        # 使用预测值
        if self.last_state:
            return {
                "success": True,
                "reason": "using_prediction",
                "predicted_state": self.last_state,
                "confidence": 0.5  # 低置信度
            }
        
        return {
            "success": False,
            "reason": "no_state_history"
        }
    
    def _handle_pnp_failure(self, pnp_result):
        """处理 PnP 求解失败"""
        return {
            "success": False,
            "reason": f"pnp_failed: {pnp_result.get('reason', 'unknown')}",
            "pnp_result": pnp_result
        }
    
    def _use_prediction(self):
        """使用预测值（当新测量无效时）"""
        if self.last_state:
            return {
                "success": True,
                "reason": "using-filtered_prediction",
                "state": self.last_state,
                "confidence": 0.3  # 很低的置信度
            }
        return {"success": False, "reason": "no_prediction_available"}
    
    def _validate_ship_state(self, ship_state):
        """验证船的状态是否有效"""
        
        issues = []
        
        # 检查距离
        dist_validation = self.validator.validate_camera_position(
            ship_state['camera_y']
        )
        if not dist_validation['valid']:
            issues.append(dist_validation['reason'])
        
        # 检查横向偏移
        lat_validation = self.validator.validate_lateral_offset(
            ship_state['lateral_offset']
        )
        if not lat_validation['valid']:
            issues.append(lat_validation['reason'])
        
        # 检查高度
        height_validation = self.validator.validate_height_offset(
            ship_state['height_offset']
        )
        if not height_validation['valid']:
            issues.append(height_validation['reason'])
        
        return {
            'all_valid': len(issues) == 0,
            'issues': issues,
            'distance_valid': dist_validation['valid'],
            'lateral_valid': lat_validation['valid'],
            'height_valid': height_validation['valid']
        }
    
    def _apply_filtering(self, ship_state, timestamp):
        """
        应用 OneEuro 滤波器平滑船的位置
        """
        
        # 对距离和横向偏移进行滤波
        if timestamp is not None:
            # 使用时间戳（精确）
            filtered_distance = self.distance_filter.filter(
                ship_state['distance_to_dock'],
                timestamp=timestamp
            )
            filtered_lateral = self.lateral_filter.filter(
                ship_state['lateral_offset'],
                timestamp=timestamp
            )
        else:
            # 不使用时间戳（近似）
            filtered_distance = self.distance_filter.filter(
                ship_state['distance_to_dock']
            )
            filtered_lateral = self.lateral_filter.filter(
                ship_state['lateral_offset']
            )
        
        # 构建滤波后的状态
        filtered_state = ship_state.copy()
        filtered_state['distance_to_dock'] = filtered_distance
        filtered_state['lateral_offset'] = filtered_lateral
        
        return filtered_state
    
    def reset(self):
        """重置定位引擎（用于新的对接任务）"""
        self.distance_filter.reset()
        self.lateral_filter.reset()
        self.last_state = None
        self.lost_frames_count = 0
