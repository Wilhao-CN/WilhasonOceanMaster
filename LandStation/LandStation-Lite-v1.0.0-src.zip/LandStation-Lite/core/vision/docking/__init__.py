"""
视觉对接系统包
提供统一的接口和导出
"""

# 导出核心类
from .constants import *
from .geometry import (
    DockGeometry,
    ShipGeometry,
    ValidationHelper
)
from .coordinate_transform import CoordinateTransformer
from .pnp_solver import PnPSolver
from .localization import DockingLocalizationEngine
from .utils import OneEuroFilter, LowPassFilter, KalmanFilter1D
from .docking_stages import Stage1Controller, Stage2Controller, Stage3Controller
from .docking_controller import (
    VisualDockingController,
    DockingState
)
from .interface import DockingSystemInterface

__all__ = [
    # 常量
    'SHIP_LENGTH',
    'CAMERA_DIST_FROM_BOW',
    'DOCK_LENGTH',
    'DOCK_WIDTH',
    
    # 几何模块
    'DockGeometry',
    'ShipGeometry',
    'ValidationHelper',
    
    # 转换
    'CoordinateTransformer',
    
    # PnP
    'PnPSolver',
    
    # 定位
    'DockingLocalizationEngine',
    
    # 滤波
    'OneEuroFilter',
    'LowPassFilter',
    'KalmanFilter1D',
    
    # 控制器
    'Stage1Controller',
    'Stage2Controller',
    'Stage3Controller',
    'VisualDockingController',
    'DockingState',
    
    # 接口
    'DockingSystemInterface'
]

# 版本信息
__version__ = "1.0.0"
__author__ = "LandStation Team"
__description__ = "视觉对接系统 - 基于 ArUco 标记的自动停靠"

# 简化的初始化函数（给 BoatBrain 使用）
def create_docking_system(camera_matrix=None, dist_coeffs=None):
    """
    创建一个完整的对接系统实例
    
    这是给 BoatBrain 的快速初始化接口
    
    参数：
        camera_matrix: 相机内参矩阵
        dist_coeffs: 畸变系数
    
    返回：DockingSystemInterface 实例
    
    使用示例：
        # 在 BoatBrain 中
        from core.vision.docking import create_docking_system
        
        docking = create_docking_system(camera_matrix, dist_coeffs)
        
        # 开始对接
        success, msg = docking.start_docking()
        
        # 处理视觉帧
        control_cmd, feedback = docking.process_vision_frame(
            detections, timestamp, heading
        )
    """
    return DockingSystemInterface(
        camera_matrix=camera_matrix,
        dist_coeffs=dist_coeffs
    )
