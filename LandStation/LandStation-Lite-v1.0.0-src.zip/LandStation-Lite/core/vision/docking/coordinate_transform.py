"""
坐标系统转换模块
处理相机坐标系、船坞坐标系、船坐标系之间的转换
"""

import numpy as np

try:
    from .constants import *
    from .geometry import ShipGeometry, DockGeometry
except ImportError:
    from constants import *
    from geometry import ShipGeometry, DockGeometry


class CoordinateTransformer:
    """
    统一的坐标系转换器
    """
    
    def __init__(self):
        """初始化转换器"""
        self.ship_geom = ShipGeometry()
        self.dock_geom = DockGeometry()
    
    def camera_position_to_ship_state(self, camera_y, camera_x=0.0, camera_z=0.0):
        """
        从摄像头位置转换为船的状态
        
        输入：
            camera_y: float，摄像头在船坞坐标系中的 Y 坐标
            camera_x: float，摄像头的 X 坐标（默认 0，在中线）
            camera_z: float，摄像头的 Z 坐标（高度）
        
        输出：
            dict: {
                'ship_bow_y': 船头位置,
                'ship_center_y': 船的中心位置,
                'lateral_offset': 横向中心偏差,
                'distance_to_dock': 距码5还有多远,
                'fully_entered': 是否完全进入,
                'camera_y': 摄像头位置,
                'stage': 当前所处阶段
            }
        """
        
        # 计算船的位置
        ship_pos = self.ship_geom.calculate_ship_bow_from_camera(camera_y)
        
        # 计算距码5的距离
        dock_rear_y = -DOCK_LENGTH / 2
        distance_to_dock = dock_rear_y - ship_pos['ship_bow_y']
        
        # 判断阶段
        stage = self._determine_stage(distance_to_dock)
        
        return {
            'ship_bow_y': ship_pos['ship_bow_y'],
            'ship_center_y': ship_pos['ship_center_y'],
            'ship_stern_y': ship_pos['ship_stern_y'],
            'lateral_offset': camera_x,  # 假设摄像头在中线，X 偏移即为横向偏差
            'distance_to_dock': distance_to_dock,
            'height_offset': camera_z - CAMERA_HEIGHT,  # 高度差
            'fully_entered': distance_to_dock < 0,
            'camera_y': camera_y,
            'camera_x': camera_x,
            'camera_z': camera_z,
            'stage': stage
        }
    
    def ship_state_to_control_feedback(self, ship_state):
        """
        将船的状态转换为控制反馈信息
        
        输出用于 UI 显示和对接控制的信息
        """
        
        return {
            'distance_mm': ship_state['distance_to_dock'] * 1000,
            'lateral_mm': ship_state['lateral_offset'] * 1000,
            'height_mm': ship_state['height_offset'] * 1000,
            'stage': ship_state['stage'],
            'progress_percent': self._calculate_progress(ship_state['distance_to_dock'])
        }
    
    def _determine_stage(self, distance_to_dock):
        """判断当前处于哪个阶段"""
        if distance_to_dock > STAGE1_TARGET_DISTANCE:
            return "STAGE1_DISTANT_APPROACH"
        elif distance_to_dock > STAGE2_TARGET_DISTANCE:
            return "STAGE2_ALIGNMENT"
        elif distance_to_dock > 0:
            return "STAGE3_PRECISE_ENTRY"
        else:
            return "DOCKING_COMPLETE"
    
    def _calculate_progress(self, distance_to_dock):
        """计算对接进度百分比"""
        if distance_to_dock > STAGE1_TARGET_DISTANCE:
            return 0
        elif distance_to_dock < 0:
            return 100
        else:
            # 在工作距离内的进度线性计算
            progress = (STAGE1_TARGET_DISTANCE - distance_to_dock) / STAGE1_TARGET_DISTANCE * 100
            return max(0, min(100, progress))
    
    def relative_position_from_markers(self, marker_detections):
        """
        从多个已检测的码的位置推断相对位置
        
        输入：marker_detections = {
            "码1": {'detected': True, 'image_x': ..., 'image_y': ...},
            ...
        }
        
        输出：相机相对于船坞的估计位置
        """
        
        # 统计检测到的码
        detected_markers = [m for m, info in marker_detections.items() if info.get('detected', False)]
        
        if len(detected_markers) == 0:
            return None
        
        # 根据不同码的组合推断位置
        if any(m in detected_markers for m in ["码3", "码4", "码5"]):
            # 能看到后方的码，说明在最后阶段
            stage = "FINAL_APPROACH"
        elif any(m in detected_markers for m in ["码1", "码2"]):
            # 能看到前方的码，说明还很远
            stage = "INITIAL_APPROACH"
        else:
            stage = "MID_APPROACH"
        
        return {
            'detected_markers': detected_markers,
            'estimated_stage': stage,
            'num_visible': len(detected_markers)
        }
