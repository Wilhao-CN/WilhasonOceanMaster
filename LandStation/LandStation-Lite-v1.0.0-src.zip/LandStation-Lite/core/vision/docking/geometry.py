"""
船坞和船的几何关系模型
定义几何体、碰撞检测、位置验证等功能
"""

import numpy as np

try:
    from .constants import *
except ImportError:
    from constants import *


class DockGeometry:
    """
    船坞的几何模型
    定义了码的标准位置、船坞的内部空间等
    """
    
    def __init__(self):
        """初始化船坞几何"""
        self.dock_length = DOCK_LENGTH
        self.dock_width = DOCK_WIDTH
        
        # 码的标准位置（字典形式便于查询）
        self.marker_positions = MARKER_POSITIONS
        
        # 预编译为 numpy 数组（便于向量计算）
        self.marker_positions_array = np.array([
            self.marker_positions["码1"],
            self.marker_positions["码2"],
            self.marker_positions["码3"],
            self.marker_positions["码4"],
            self.marker_positions["码5"]
        ], dtype=np.float32)
    
    def get_marker_position(self, marker_id):
        """
        获取指定码的世界坐标
        
        Args:
            marker_id: str，码的 ID（"码1" 至 "码5"）
        
        Returns:
            tuple: (x, y, z) 坐标，如果不存在返回 None
        """
        return self.marker_positions.get(marker_id, None)
    
    def get_all_marker_positions(self):
        """获取所有码的位置（numpy 数组形式）"""
        return self.marker_positions_array
    
    def is_point_inside_dock(self, x, y):
        """
        判断 (x, y) 点是否在船坞内部
        
        Args:
            x, y: float，坐标值
        
        Returns:
            bool: True 表示在内部
        """
        # 船坞范围: x in [-0.32, 0.32], y in [-0.41, 0.41]
        inside_x = -self.dock_width/2 <= x <= self.dock_width/2
        inside_y = -self.dock_length/2 <= y <= self.dock_length/2
        
        return inside_x and inside_y
    
    def is_point_near_dock_rear(self, x, y, threshold=0.05):
        """
        判断点是否接近船坞后方（码3、码4、码5 的位置）
        
        Args:
            x, y: float，坐标
            threshold: float，距离阈值 (m)
        
        Returns:
            bool
        """
        rear_y = -self.dock_length/2
        return abs(y - rear_y) < threshold and abs(x) < self.dock_width/2 + threshold


class ShipGeometry:
    """
    船的几何模型
    定义了船的尺寸、摄像头位置等
    """
    
    def __init__(self):
        """初始化船的几何"""
        self.ship_length = SHIP_LENGTH
        self.ship_width = SHIP_WIDTH
        self.ship_height = SHIP_HEIGHT
        
        self.camera_dist_from_bow = CAMERA_DIST_FROM_BOW
        self.camera_dist_from_stern = CAMERA_DIST_FROM_STERN
        self.camera_height = CAMERA_HEIGHT
    
    def calculate_camera_position_in_dock(self, ship_bow_y):
        """
        给定船头的 Y 坐标，计算摄像头在船坞坐标系中的位置
        
        Args:
            ship_bow_y: float，船头在船坞坐标系中的 Y 坐标
        
        Returns:
            dict: {
                'x': 0.0,
                'y': camera_y,
                'z': camera_height,
                'ship_bow_y': ship_bow_y
            }
        """
        # 摄像头距离船头 0.485m，所以：
        # camera_y = ship_bow_y + camera_dist_from_bow
        
        camera_y = ship_bow_y + self.camera_dist_from_bow
        
        return {
            'x': 0.0,  # 假设摄像头在船的中线上
            'y': camera_y,
            'z': self.camera_height,
            'ship_bow_y': ship_bow_y
        }
    
    def calculate_ship_bow_from_camera(self, camera_y):
        """
        反向计算：从摄像头的 Y 坐标推算船头位置
        
        Args:
            camera_y: float，摄像头的 Y 坐标
        
        Returns:
            dict: {
                'ship_bow_y': float,
                'ship_stern_y': float,
                'ship_center_y': float
            }
        """
        ship_bow_y = camera_y - self.camera_dist_from_bow
        ship_stern_y = ship_bow_y - self.ship_length
        ship_center_y = ship_bow_y - self.ship_length / 2
        
        return {
            'ship_bow_y': ship_bow_y,
            'ship_stern_y': ship_stern_y,
            'ship_center_y': ship_center_y
        }
    
    def get_ship_bounding_box(self, ship_bow_y):
        """
        获取船的边界框（用于碰撞检测）
        
        Args:
            ship_bow_y: float，船头位置
        
        Returns:
            dict: {
                'x_min', 'x_max',
                'y_min', 'y_max',
                'z_min', 'z_max'
            }
        """
        ship_stern_y = ship_bow_y - self.ship_length
        
        return {
            'x_min': -self.ship_width / 2,
            'x_max': +self.ship_width / 2,
            'y_min': ship_stern_y,
            'y_max': ship_bow_y,
            'z_min': 0.0,
            'z_max': self.ship_height
        }
    
    def is_ship_fully_inside_dock(self, ship_bow_y, threshold=0.05):
        """
        判断船是否已完全进入船坞
        
        Args:
            ship_bow_y: float，船头位置
            threshold: float，容差
        
        Returns:
            bool
        """
        # 船头进入码5/3/4 所在的平面后便认为完全进入
        dock_rear_y = -DOCK_LENGTH / 2
        return ship_bow_y < (dock_rear_y + threshold)


class ValidationHelper:
    """
    验证和检查的辅助类
    """
    
    def __init__(self):
        self.dock_geom = DockGeometry()
        self.ship_geom = ShipGeometry()
    
    def validate_camera_position(self, camera_y):
        """
        验证摄像头位置是否在合理范围内
        
        Args:
            camera_y: float，摄像头 Y 坐标
        
        Returns:
            dict: {
                'valid': bool,
                'reason': str,
                'distance_to_dock': float
            }
        """
        # 摄像头应该距码5 >= 0.2m，<= 2.5m
        distance_to_rear = -DOCK_LENGTH/2 - camera_y
        
        if distance_to_rear < MIN_WORKING_DISTANCE:
            return {
                'valid': False,
                'reason': 'TOO_CLOSE',
                'distance_to_dock': distance_to_rear
            }
        elif distance_to_rear > MAX_WORKING_DISTANCE:
            return {
                'valid': False,
                'reason': 'TOO_FAR',
                'distance_to_dock': distance_to_rear
            }
        else:
            return {
                'valid': True,
                'reason': 'OK',
                'distance_to_dock': distance_to_rear
            }
    
    def validate_lateral_offset(self, lateral_offset):
        """验证横向偏移是否在安全范围内"""
        if abs(lateral_offset) > LATERAL_EMERGENCY_THRESHOLD:
            return {
                'valid': False,
                'reason': 'LATERAL_OVERFLOW',
                'offset': lateral_offset
            }
        return {'valid': True, 'reason': 'OK'}
    
    def validate_height_offset(self, height_offset):
        """验证高度差是否在安全范围内"""
        if abs(height_offset) > HEIGHT_EMERGENCY_THRESHOLD:
            return {
                'valid': False,
                'reason': 'HEIGHT_MISMATCH',
                'offset': height_offset
            }
        return {'valid': True, 'reason': 'OK'}
