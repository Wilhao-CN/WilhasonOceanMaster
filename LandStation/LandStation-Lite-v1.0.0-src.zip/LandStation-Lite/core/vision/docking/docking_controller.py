"""
主对接控制器
协调三个阶段的状态机
"""

from enum import Enum

try:
    from .docking_stages import Stage1Controller, Stage2Controller, Stage3Controller
    from .constants import *
except ImportError:
    from docking_stages import Stage1Controller, Stage2Controller, Stage3Controller
    from constants import *


class DockingState(Enum):
    """对接状态枚举"""
    IDLE = "idle"                          # 空闲
    INITIALIZING = "initializing"          # 初始化
    STAGE1_DISTANT_APPROACH = "stage1"     # 第1阶段：远距离接近
    STAGE2_ALIGNMENT = "stage2"            # 第2阶段：精密对齐
    STAGE3_PRECISE_ENTRY = "stage3"        # 第3阶段：精细进入
    DOCKING_COMPLETE = "complete"          # 停靠完成
    ERROR = "error"                        # 错误状态
    ABORTED = "aborted"                    # 中止


class VisualDockingController:
    """
    视觉对接系统主控制器
    
    职责：
    1. 管理对接状态机
    2. 根据距离选择合适的控制器
    3. 处理转换逻辑
    4. 提供统一的控制接口
    """
    
    def __init__(self):
        """初始化对接控制器"""
        
        # 当前状态
        self.state = DockingState.IDLE
        
        # 三个阶段的控制器
        self.stage1 = Stage1Controller()
        self.stage2 = Stage2Controller()
        self.stage3 = Stage3Controller()
        
        self.current_stage_controller = None
        
        # 统计信息
        self.total_iterations = 0
        self.state_changes = []
        self.error_log = []
        
        # 配置参数
        self.enable_logging = True
    
    def start_docking(self):
        """开始对接任务"""
        self.reset()
        self.state = DockingState.INITIALIZING
        self._log_state_change("开始对接任务")
        return {"status": "docking_started", "state": self.state.value}
    
    def update(self, localization_result, current_heading=0.0):
        """
        主控制循环
        
        输入：
            localization_result: 来自定位引擎的状态信息
            current_heading: 当前船的航向（弧度或度数）
        
        输出：{
            "control_command": {...},
            "current_state": str,
            "debug": {...}
        }
        """
        
        self.total_iterations += 1
        
        # 状态机逻辑
        if self.state == DockingState.IDLE:
            return {"control": self._no_control(), "state": "IDLE"}
        
        elif self.state == DockingState.INITIALIZING:
            return self._handle_initialization(localization_result)
        
        elif self.state == DockingState.STAGE1_DISTANT_APPROACH:
            return self._handle_stage1(localization_result, current_heading)
        
        elif self.state == DockingState.STAGE2_ALIGNMENT:
            return self._handle_stage2(localization_result, current_heading)
        
        elif self.state == DockingState.STAGE3_PRECISE_ENTRY:
            return self._handle_stage3(localization_result, current_heading)
        
        elif self.state == DockingState.DOCKING_COMPLETE:
            return {"control": self._no_control(), "state": "DOCKING_COMPLETE"}
        
        elif self.state == DockingState.ERROR:
            return {
                "control": self._e_stop(),
                "state": "ERROR",
                "error_log": self.error_log[-1]
            }
        
        elif self.state == DockingState.ABORTED:
            return {"control": self._no_control(), "state": "ABORTED"}
        
        else:
            return {"control": self._no_control(), "state": "UNKNOWN"}
    
    def _handle_initialization(self, localization_result):
        """处理初始化状态"""
        
        if not localization_result.get('success', False):
            self._log("⏳ 等待有效定位...")
            return {
                "control": self._no_control(),
                "state": "INITIALIZING",
                "message": "等待定位"
            }
        
        # 检查是否有足够的标记
        num_markers = localization_result.get('quality', {}).get('num_markers', 0)
        if num_markers < 2:
            self._log(f"⏳ 标记数量不足 ({num_markers}/2)")
            return {
                "control": self._no_control(),
                "state": "INITIALIZING",
                "message": "标记数量不足"
            }
        
        # 初始化完成，进入第1阶段
        self._transition_to_stage(DockingState.STAGE1_DISTANT_APPROACH)
        
        return {
            "control": self._no_control(),
            "state": "STAGE1_DISTANT_APPROACH",
            "message": "初始化完成，进入第1阶段"
        }
    
    def _handle_stage1(self, localization_result, current_heading):
        """处理第1阶段"""
        
        if not localization_result.get('success', False):
            return {
                "control": self._e_stop(),
                "state": "ERROR",
                "reason": "定位失败"
            }
        
        # 调用第1阶段控制器
        control_result = self.stage1.compute_control(
            localization_result, current_heading
        )
        
        # 检查是否应该转换到第2阶段
        if control_result.get('stage_transition') == "STAGE1_to_STAGE2":
            self._transition_to_stage(DockingState.STAGE2_ALIGNMENT)
            return {
                "control": self._no_control(),
                "state": "STAGE2_ALIGNMENT",
                "message": "进入第2阶段"
            }
        
        return {
            "control": control_result,
            "current_state": DockingState.STAGE1_DISTANT_APPROACH.value,
            "debug": control_result.get('debug', {})
        }
    
    def _handle_stage2(self, localization_result, current_heading):
        """处理第2阶段"""
        
        if not localization_result.get('success', False):
            return {
                "control": self._e_stop(),
                "state": "ERROR",
                "reason": "定位失败"
            }
        
        # 调用第2阶段控制器
        control_result = self.stage2.compute_control(
            localization_result, current_heading
        )
        
        # 检查状态转换
        if control_result.get('stage_transition') == "STAGE2_to_STAGE1":
            # 距离太远，回到第1阶段
            self._transition_to_stage(DockingState.STAGE1_DISTANT_APPROACH)
            return {
                "control": self._no_control(),
                "state": "STAGE1_DISTANT_APPROACH",
                "message": "距离太远，回到第1阶段"
            }
        
        if control_result.get('stage_transition') == "STAGE2_to_STAGE3":
            # 距离足够近，进入第3阶段
            self._transition_to_stage(DockingState.STAGE3_PRECISE_ENTRY)
            return {
                "control": self._no_control(),
                "state": "STAGE3_PRECISE_ENTRY",
                "message": "进入第3阶段"
            }
        
        # 检查对齐状态
        alignment_ready = control_result.get('alignment_ready', False)
        if alignment_ready:
            self._log("✓ 对齐完成，准备进入第3阶段")
        
        return {
            "control": control_result,
            "current_state": DockingState.STAGE2_ALIGNMENT.value,
            "alignment_ready": alignment_ready,
            "debug": control_result.get('debug', {})
        }
    
    def _handle_stage3(self, localization_result, current_heading):
        """处理第3阶段"""
        
        if not localization_result.get('success', False):
            return {
                "control": self._e_stop(),
                "state": "ERROR",
                "reason": "定位失败"
            }
        
        # 调用第3阶段控制器
        control_result = self.stage3.compute_control(
            localization_result, current_heading
        )
        
        # 检查紧急停止
        if control_result.get('emergency_stop', False):
            self.state = DockingState.ERROR
            error_msg = control_result.get('debug', {}).get('error', '未知错误')
            self._log(f"❌ 第3阶段紧急停止: {error_msg}")
            return {
                "control": self._e_stop(),
                "state": "ERROR",
                "reason": error_msg
            }
        
        # 检查是否停靠完成
        if control_result.get('docking_complete', False):
            self._transition_to_stage(DockingState.DOCKING_COMPLETE)
            self._log("🎉 对接成功完成！")
            return {
                "control": self._no_control(),
                "state": "DOCKING_COMPLETE",
                "message": "对接成功"
            }
        
        return {
            "control": control_result,
            "current_state": DockingState.STAGE3_PRECISE_ENTRY.value,
            "debug": control_result.get('debug', {})
        }
    
    def abort_docking(self, reason="用户中止"):
        """中止对接任务"""
        self._log(f"中止对接: {reason}")
        self.state = DockingState.ABORTED
        return {"status": "aborted", "reason": reason}
    
    def _transition_to_stage(self, new_state):
        """转换到新的状态"""
        old_state = self.state
        self.state = new_state
        self._log_state_change(f"{old_state.value} → {new_state.value}")
    
    def _log_state_change(self, message):
        """记录状态变化"""
        if self.enable_logging:
            self.state_changes.append({
                "iteration": self.total_iterations,
                "message": message
            })
            self._log(f"[状态转换] {message}")
    
    def _log(self, message):
        """记录日志"""
        if self.enable_logging:
            print(f"[DockingController] {message}")
    
    def reset(self):
        """重置所有控制器"""
        self.state = DockingState.IDLE
        self.stage1.reset()
        self.stage2.reset()
        self.stage3.reset()
        self.total_iterations = 0
        self.state_changes = []
        self.error_log = []
    
    def _no_control(self):
        """不输出任何控制（空闲）"""
        return {
            "surge": 0.0,
            "sway": 0.0,
            "yaw": 0.0
        }
    
    def _e_stop(self):
        """紧急停止"""
        return {
            "surge": 0.0,
            "sway": 0.0,
            "yaw": 0.0,
            "emergency_stop": True
        }
    
    def get_status(self):
        """获取对接系统状态"""
        return {
            "current_state": self.state.value,
            "total_iterations": self.total_iterations,
            "state_changes": len(self.state_changes),
            "stage_status": {
                "stage1": self.stage1.get_status(),
                "stage2": self.stage2.get_status(),
                "stage3": self.stage3.get_status()
            },
            "recent_states": self.state_changes[-5:] if self.state_changes else []
        }
