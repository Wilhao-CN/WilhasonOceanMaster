"""Read-only control-source inspector for the vision HUD.

Reads the live control flags from the boat/dock brains and returns a short
label plus a detail string describing what is actually driving each vessel
right now.  This module only *inspects* state — it never mutates it and never
emits control signals, so it is safe to call from the UI thread on a timer.

The priority order below mirrors the real decision order inside
``BoatBrain``/``DockBrain`` (mission/navigation > visual > PID auto > manual).
"""

from __future__ import annotations

from typing import Optional, Tuple


def _flag(obj, name: str, default: bool = False) -> bool:
    return bool(getattr(obj, name, default))


def _pose_active(brain) -> bool:
    pose = getattr(brain, "pose_return", None)
    return bool(getattr(pose, "active", False))


def describe_boat_control(brain) -> Tuple[str, str]:
    """Return ``(mode_label, detail)`` describing what is driving the 子船 (boat)."""
    if brain is None:
        return ("--", "控制大脑未连接")

    if _flag(brain, "vision_docking_active"):
        return ("视觉对接 (ArUco)", "四码引导 → 速度/艏向 PID 闭环")

    if _flag(brain, "is_mission_active"):
        return ("任务导航", "航点 P2P/LOS 领航")

    if _pose_active(brain):
        return ("一键返航", "P2P 返回停靠点")

    auto_h = _flag(brain, "auto_heading_active")
    auto_s = _flag(brain, "auto_speed_active")
    if auto_h or auto_s:
        parts = []
        if auto_h:
            parts.append("定艏")
        if auto_s:
            parts.append("定速")
        return ("自动 PID", " + ".join(parts))

    return ("手动", "手柄 / 驾驶台直推")


def describe_dock_control(brain) -> Tuple[str, str]:
    """Return ``(mode_label, detail)`` describing what is driving the 船坞 (dock)."""
    if brain is None:
        return ("--", "控制大脑未连接")

    if _flag(brain, "nof_centering_active"):
        return ("NOF 视觉居中", "视觉居中优先，失锁退方位角 PID")

    if _flag(brain, "is_mission_active"):
        return ("任务导航", "航点 / 到点稳停 P2P 领航")

    if _pose_active(brain):
        return ("一键返航", "P2P 返回停靠点")

    if _flag(brain, "docking_hold_active"):
        return ("协同定艏保持", "子船视觉对接时锁定艏向")

    auto_h = _flag(brain, "auto_heading_active")
    auto_s = _flag(brain, "auto_speed_active")
    if auto_h or auto_s:
        parts = []
        if auto_h:
            parts.append("定艏")
        if auto_s:
            parts.append("定速")
        return ("自动 PID", " + ".join(parts))

    return ("手动", "手柄 / 驾驶台直推")
