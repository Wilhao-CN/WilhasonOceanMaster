"""Pure-computation heading controller used to validate visual docking guidance.

This module intentionally has no communication or actuator dependencies.  Its
outputs are advisory values for the UI until the visual controller has been
validated on recorded and live data.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import time
from typing import Optional


def _clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


@dataclass(frozen=True)
class ShadowHeadingOutput:
    """One advisory shadow-control sample."""

    pos_angle_deg: float
    filtered_angle_deg: float
    error_deg: float
    angle_rate_deg_s: float
    yaw_command: float
    left_command: float
    right_command: float
    surge_permission: float
    action: str


class ShadowHeadingController:
    """Convert signed ArUco bearing angle into advisory differential thrust.

    Coordinate convention used by the current camera pipeline:
    - negative PosAngle: marker is left of the camera, suggest a left turn;
    - positive PosAngle: marker is right of the camera, suggest a right turn.

    No value returned by this class is sent to hardware.
    """

    def __init__(
        self,
        *,
        target_bias_deg: float = 0.0,
        max_angle_deg: float = 25.0,
        deadband_deg: float = 2.0,
        stop_surge_angle_deg: float = 15.0,
        kp: float = 0.85,
        kd: float = 0.12,
        filter_alpha: float = 0.30,
        derivative_alpha: float = 0.25,
        rate_scale_deg_s: float = 60.0,
    ):
        self.target_bias_deg = float(target_bias_deg)
        self.max_angle_deg = max(1.0, float(max_angle_deg))
        self.deadband_deg = max(0.0, float(deadband_deg))
        self.stop_surge_angle_deg = max(
            self.deadband_deg + 0.1, float(stop_surge_angle_deg)
        )
        self.kp = float(kp)
        self.kd = float(kd)
        self.filter_alpha = _clamp(float(filter_alpha), 0.0, 1.0)
        self.derivative_alpha = _clamp(float(derivative_alpha), 0.0, 1.0)
        self.rate_scale_deg_s = max(1.0, float(rate_scale_deg_s))

        self._last_time = None
        self._filtered_angle = None
        self._filtered_rate = 0.0

    def reset(self) -> None:
        """Forget filter history after disable or target loss."""
        self._last_time = None
        self._filtered_angle = None
        self._filtered_rate = 0.0

    def update(
        self, pos_angle_deg: float, timestamp: float | None = None
    ) -> ShadowHeadingOutput:
        """Calculate one shadow sample without causing any external side effect."""
        now = time.monotonic() if timestamp is None else float(timestamp)
        measured = _clamp(
            float(pos_angle_deg), -self.max_angle_deg, self.max_angle_deg
        )

        if self._filtered_angle is None or self._last_time is None:
            filtered = measured
            filtered_rate = 0.0
        else:
            dt = _clamp(now - self._last_time, 1.0 / 120.0, 0.5)
            filtered = (
                self.filter_alpha * measured
                + (1.0 - self.filter_alpha) * self._filtered_angle
            )
            raw_rate = (filtered - self._filtered_angle) / dt
            filtered_rate = (
                self.derivative_alpha * raw_rate
                + (1.0 - self.derivative_alpha) * self._filtered_rate
            )

        self._last_time = now
        self._filtered_angle = filtered
        self._filtered_rate = filtered_rate

        error = filtered - self.target_bias_deg
        normalized_error = _clamp(
            error / self.max_angle_deg, -1.0, 1.0
        )
        normalized_rate = _clamp(
            filtered_rate / self.rate_scale_deg_s, -1.0, 1.0
        )
        yaw_command = _clamp(
            self.kp * normalized_error + self.kd * normalized_rate,
            -1.0,
            1.0,
        )

        abs_error = abs(error)
        if abs_error <= self.deadband_deg:
            yaw_command = 0.0
            action = "保持艏向"
        elif error < 0.0:
            action = "建议左转"
        else:
            action = "建议右转"

        # Advisory only: full permission while aligned, then linearly reduce
        # forward motion to zero at 15 degrees.
        if abs_error <= self.deadband_deg:
            surge_permission = 1.0
        elif abs_error >= self.stop_surge_angle_deg:
            surge_permission = 0.0
        else:
            surge_permission = 1.0 - (
                (abs_error - self.deadband_deg)
                / (self.stop_surge_angle_deg - self.deadband_deg)
            )

        # Positive yaw means right turn: left thruster forward, right reverse.
        return ShadowHeadingOutput(
            pos_angle_deg=float(pos_angle_deg),
            filtered_angle_deg=filtered,
            error_deg=error,
            angle_rate_deg_s=filtered_rate,
            yaw_command=yaw_command,
            left_command=yaw_command,
            right_command=-yaw_command,
            surge_permission=_clamp(surge_permission, 0.0, 1.0),
            action=action,
        )


def _wrap_degrees(angle_deg: float) -> float:
    """Normalize a heading error to [-180, 180)."""
    return (float(angle_deg) + 180.0) % 360.0 - 180.0


@dataclass(frozen=True)
class ShadowSupervisorOutput:
    """Advisory output from the loss/reacquisition safety supervisor."""

    state: str
    vision_age_ms: Optional[float]
    tracking_method: str
    locked_frames: int
    pos_angle_deg: Optional[float]
    filtered_angle_deg: Optional[float]
    target_yaw_command: float
    smoothed_yaw_command: float
    left_command: float
    right_command: float
    target_surge_permission: float
    smoothed_surge_permission: float
    imu_hold_active: bool
    imu_heading_deg: Optional[float]
    imu_target_heading_deg: Optional[float]
    action: str


class ShadowDockingSupervisor:
    """Shadow-only visual-loss state machine with bumpless command shaping.

    State progression:
        TRACKING -> DEGRADED -> LOST -> REACQUIRE -> TRACKING

    ``aruco_locked`` is the only direct measurement. Short gaps may be bridged
    by ``flow_track``; two consecutive ``inertial_guess`` samples force the
    state into DEGRADED. This class has no actuator dependencies.
    """

    TRACKING = "TRACKING"
    DEGRADED = "DEGRADED"
    LOST = "LOST"
    REACQUIRE = "REACQUIRE"
    DOCKED = "DOCKED"

    def __init__(
        self,
        heading_controller: ShadowHeadingController | None = None,
        *,
        degraded_after_s: float = 0.20,
        lost_after_s: float = 0.60,
        tracking_window_frames: int = 6,
        required_locked_frames: int = 3,
        degraded_surge_cap: float = 0.40,
        yaw_ramp_up_per_s: float = 2.0,
        yaw_ramp_down_per_s: float = 2.0,
        surge_ramp_up_per_s: float = 2.0,
        surge_ramp_down_per_s: float = 2.5,
        imu_heading_kp: float = 0.04,
        imu_yaw_rate_kd: float = 0.02,
    ):
        self.heading_controller = heading_controller or ShadowHeadingController()
        self.degraded_after_s = max(0.01, float(degraded_after_s))
        self.lost_after_s = max(
            self.degraded_after_s + 0.01, float(lost_after_s)
        )
        self.tracking_window_frames = max(1, int(tracking_window_frames))
        self.required_locked_frames = max(
            1,
            min(int(required_locked_frames), self.tracking_window_frames),
        )
        self.degraded_surge_cap = _clamp(float(degraded_surge_cap), 0.0, 1.0)
        self.yaw_ramp_up_per_s = max(0.01, float(yaw_ramp_up_per_s))
        self.yaw_ramp_down_per_s = max(0.01, float(yaw_ramp_down_per_s))
        self.surge_ramp_up_per_s = max(0.01, float(surge_ramp_up_per_s))
        self.surge_ramp_down_per_s = max(0.01, float(surge_ramp_down_per_s))
        self.imu_heading_kp = float(imu_heading_kp)
        self.imu_yaw_rate_kd = float(imu_yaw_rate_kd)
        self.reset()

    def reset(self) -> None:
        self.heading_controller.reset()
        self.state = self.LOST
        self._last_step_time = None
        self._last_locked_time = None
        self._locked_frames = 0
        self._method_window = deque(maxlen=self.tracking_window_frames)
        self._last_heading_output = None
        self._last_tracking_method = "none"
        self._last_target_yaw = 0.0
        self._last_target_surge = 0.0
        self._smoothed_yaw = 0.0
        self._smoothed_surge = 0.0
        self._imu_target_heading = None

    def _record_frame_method(self, method: str) -> None:
        self._method_window.append(str(method))
        self._locked_frames = sum(
            item == "aruco_locked" for item in self._method_window
        )

    def _has_consecutive_inertial_predictions(self) -> bool:
        return (
            len(self._method_window) >= 2
            and self._method_window[-1] == "inertial_guess"
            and self._method_window[-2] == "inertial_guess"
        )

    def _window_is_tracking_ready(self, now: float) -> bool:
        if self._last_locked_time is None:
            return False
        direct_is_fresh = now - self._last_locked_time <= self.degraded_after_s
        return (
            self._locked_frames >= self.required_locked_frames
            and direct_is_fresh
            and not self._has_consecutive_inertial_predictions()
        )

    def _reacquire_action(self) -> str:
        return (
            f"窗口锁定 {self._locked_frames}/{self.required_locked_frames} "
            f"（最近{self.tracking_window_frames}帧）"
        )

    @staticmethod
    def _slew(
        current: float,
        target: float,
        dt: float,
        ramp_up_per_s: float,
        ramp_down_per_s: float,
    ) -> float:
        if dt <= 0.0:
            return current
        crossing_zero = current * target < 0.0
        reducing_magnitude = abs(target) < abs(current)
        rate = ramp_down_per_s if crossing_zero or reducing_magnitude else ramp_up_per_s
        max_delta = rate * dt
        return current + _clamp(target - current, -max_delta, max_delta)

    def update(
        self,
        pos_angle_deg: float | None = None,
        *,
        tracking_method: str | None = None,
        imu_heading_deg: float | None = None,
        yaw_rate_deg_s: float | None = None,
        surge_limit: float | None = None,
        force_stop: bool = False,
        timestamp: float | None = None,
    ) -> ShadowSupervisorOutput:
        """Advance the supervisor using a new vision sample or watchdog tick.

        ``tracking_method=None`` means a watchdog tick without a new frame.
        Use ``tracking_method='missing'`` for an explicit empty vision frame.
        """
        now = time.monotonic() if timestamp is None else float(timestamp)
        if self._last_step_time is None:
            dt = 0.0
        else:
            dt = _clamp(now - self._last_step_time, 0.0, 0.5)
        self._last_step_time = now

        method = tracking_method or "watchdog"
        direct_locked = method == "aruco_locked" and pos_angle_deg is not None
        explicit_loss = tracking_method in {
            "flow_track", "inertial_guess", "missing"
        }

        heading_value = None
        if imu_heading_deg is not None:
            heading_value = _wrap_degrees(imu_heading_deg)
        yaw_rate_value = 0.0 if yaw_rate_deg_s is None else float(yaw_rate_deg_s)

        if direct_locked:
            self._record_frame_method(method)
            heading_output = self.heading_controller.update(pos_angle_deg, now)
            self._last_heading_output = heading_output
            self._last_locked_time = now
            self._last_tracking_method = method
            if heading_value is not None:
                self._imu_target_heading = _wrap_degrees(
                    heading_value + heading_output.error_deg
                )

            if self.state == self.TRACKING:
                pass
            elif self._window_is_tracking_ready(now):
                self.state = self.TRACKING
            else:
                self.state = self.REACQUIRE

            if self.state == self.TRACKING:
                target_yaw = heading_output.yaw_command
                target_surge = heading_output.surge_permission
                action = heading_output.action
            else:
                target_yaw = 0.0
                target_surge = 0.0
                action = self._reacquire_action()
        else:
            if explicit_loss:
                self._record_frame_method(method)
                self._last_tracking_method = method

            age_s = None
            if self._last_locked_time is not None:
                age_s = max(0.0, now - self._last_locked_time)

            tracking_ready = self._window_is_tracking_ready(now)
            repeated_inertial = self._has_consecutive_inertial_predictions()

            if tracking_ready and self.state != self.TRACKING:
                self.state = self.TRACKING
            elif age_s is None or age_s >= self.lost_after_s:
                if self.state != self.LOST:
                    # Do not allow direct detections from before a long loss to
                    # satisfy the sliding-window reacquisition requirement.
                    self._method_window.clear()
                    self._locked_frames = 0
                self.state = self.LOST
            elif age_s >= self.degraded_after_s or repeated_inertial:
                self.state = self.DEGRADED
            elif self.state == self.LOST:
                self.state = self.REACQUIRE
            # Inside the 200 ms grace period, isolated flow/missing frames do
            # not knock an established TRACKING state into DEGRADED.

            if self.state == self.TRACKING and self._last_heading_output is not None:
                target_yaw = self._last_target_yaw
                if explicit_loss:
                    target_surge = min(
                        self._last_target_surge, self.degraded_surge_cap
                    )
                    action = "短时回退容错"
                else:
                    target_surge = self._last_target_surge
                    action = "视觉帧间保持"
            elif self.state == self.REACQUIRE:
                target_yaw = 0.0
                target_surge = 0.0
                action = self._reacquire_action()
            elif self.state == self.DEGRADED:
                if heading_value is not None and self._imu_target_heading is not None:
                    heading_error = _wrap_degrees(
                        self._imu_target_heading - heading_value
                    )
                    target_yaw = _clamp(
                        self.imu_heading_kp * heading_error
                        - self.imu_yaw_rate_kd * yaw_rate_value,
                        -1.0,
                        1.0,
                    )
                    action = "IMU短时保艏，平滑减推"
                else:
                    remaining = max(
                        0.0,
                        1.0 - (age_s or 0.0) / self.lost_after_s,
                    )
                    target_yaw = self._last_target_yaw * remaining
                    action = "无IMU，转向指令衰减"

                if age_s is not None and age_s <= self.degraded_after_s:
                    target_surge = min(
                        self._last_target_surge, self.degraded_surge_cap
                    )
                else:
                    target_surge = 0.0
            else:
                target_yaw = 0.0
                target_surge = 0.0
                action = "目标丢失，平滑回中"

        if surge_limit is not None:
            target_surge = min(
                target_surge,
                _clamp(float(surge_limit), 0.0, 1.0),
            )
        if force_stop:
            self.state = self.DOCKED
            target_yaw = 0.0
            target_surge = 0.0
            action = "到位锁存，平滑停车"

        self._last_target_yaw = _clamp(target_yaw, -1.0, 1.0)
        self._last_target_surge = _clamp(target_surge, 0.0, 1.0)
        self._smoothed_yaw = self._slew(
            self._smoothed_yaw,
            self._last_target_yaw,
            dt,
            self.yaw_ramp_up_per_s,
            self.yaw_ramp_down_per_s,
        )
        self._smoothed_surge = self._slew(
            self._smoothed_surge,
            self._last_target_surge,
            dt,
            self.surge_ramp_up_per_s,
            self.surge_ramp_down_per_s,
        )

        vision_age_ms = None
        if self._last_locked_time is not None:
            vision_age_ms = max(0.0, now - self._last_locked_time) * 1000.0

        last_heading = self._last_heading_output
        imu_hold_active = (
            self.state == self.DEGRADED
            and heading_value is not None
            and self._imu_target_heading is not None
        )
        return ShadowSupervisorOutput(
            state=self.state,
            vision_age_ms=vision_age_ms,
            tracking_method=self._last_tracking_method,
            locked_frames=self._locked_frames,
            pos_angle_deg=(
                None if pos_angle_deg is None else float(pos_angle_deg)
            ),
            filtered_angle_deg=(
                None if last_heading is None else last_heading.filtered_angle_deg
            ),
            target_yaw_command=self._last_target_yaw,
            smoothed_yaw_command=self._smoothed_yaw,
            left_command=self._smoothed_yaw,
            right_command=-self._smoothed_yaw,
            target_surge_permission=self._last_target_surge,
            smoothed_surge_permission=self._smoothed_surge,
            imu_hold_active=imu_hold_active,
            imu_heading_deg=heading_value,
            imu_target_heading_deg=self._imu_target_heading,
            action=action,
        )
