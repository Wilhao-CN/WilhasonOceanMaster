"""Pure-computation four-marker docking phase and target selection.

The planner consumes per-marker camera-frame translations and produces one
virtual target for the existing shadow heading supervisor. It never emits a
control signal and has no actuator dependencies.

Marker layout (two entrance-gate markers + two end-wall markers):
  - ID0 / ID1: entrance gate pair
  - ID2 / ID3: end-wall pair
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import math
from typing import Iterable, Optional


def _clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


@dataclass(frozen=True)
class DockMarkerObservation:
    marker_id: int
    tx_cm: float
    tz_cm: float
    tracking_method: str
    confidence: float = 1.0


@dataclass(frozen=True)
class ThreeMarkerGuidance:
    phase: str
    target_label: str
    observed_ids: tuple[int, ...]
    pos_angle_deg: Optional[float]
    distance_cm: Optional[float]
    tracking_method: str
    confidence: float
    surge_limit: float
    docked: bool
    gate_pair_valid: bool
    action: str
    single_marker: bool = False


class ThreeMarkerDockingPlanner:
    """Select ID0+ID1 gate guidance, then ID2+ID3 end-wall guidance.

    Geometry (centimetres):
      - ID0/ID1 centre spacing: 62
      - ID2/ID3 centre spacing: 30
      - entrance plane to end-wall plane: 80
      - camera to bow: 10
      - desired bow clearance: 10

    Therefore the latched stop target is camera-to-end-wall ``10 + 10 = 20`` cm.
    """

    SEARCH_GATE = "SEARCH_GATE"
    ALIGN_GATE = "ALIGN_GATE"
    ENTER_GATE = "ENTER_GATE"
    TRACK_END = "TRACK_END"
    DOCKED = "DOCKED"

    def __init__(
        self,
        *,
        left_marker_id: int = 0,
        right_marker_id: int = 1,
        end_left_marker_id: int = 2,
        end_right_marker_id: int = 3,
        gate_marker_spacing_cm: float = 62.0,
        end_marker_spacing_cm: float = 30.0,
        dock_depth_cm: float = 80.0,
        camera_to_bow_cm: float = 10.0,
        bow_clearance_cm: float = 10.0,
        pair_spacing_tolerance_cm: float = 15.0,
        enter_prepare_distance_cm: float = 120.0,
        enter_alignment_deg: float = 8.0,
        end_track_distance_cm: float = 80.0,
        docked_alignment_deg: float = 3.5,
        decision_window_frames: int = 6,
        decision_required_frames: int = 3,
        docked_window_frames: int = 8,
        docked_required_frames: int = 5,
    ):
        self.left_marker_id = int(left_marker_id)
        self.right_marker_id = int(right_marker_id)
        self.end_left_marker_id = int(end_left_marker_id)
        self.end_right_marker_id = int(end_right_marker_id)
        self.gate_marker_spacing_cm = max(1.0, float(gate_marker_spacing_cm))
        self.end_marker_spacing_cm = max(1.0, float(end_marker_spacing_cm))
        self.dock_depth_cm = max(1.0, float(dock_depth_cm))
        self.camera_to_bow_cm = max(0.0, float(camera_to_bow_cm))
        self.bow_clearance_cm = max(0.0, float(bow_clearance_cm))
        self.stop_distance_cm = self.camera_to_bow_cm + self.bow_clearance_cm
        self.pair_spacing_tolerance_cm = max(
            1.0, float(pair_spacing_tolerance_cm)
        )
        self.enter_prepare_distance_cm = max(
            self.dock_depth_cm, float(enter_prepare_distance_cm)
        )
        self.enter_alignment_deg = max(0.1, float(enter_alignment_deg))
        self.end_track_distance_cm = max(
            self.stop_distance_cm, float(end_track_distance_cm)
        )
        self.docked_alignment_deg = max(0.1, float(docked_alignment_deg))

        decision_window_frames = max(1, int(decision_window_frames))
        self.decision_required_frames = max(
            1, min(int(decision_required_frames), decision_window_frames)
        )
        docked_window_frames = max(1, int(docked_window_frames))
        self.docked_required_frames = max(
            1, min(int(docked_required_frames), docked_window_frames)
        )
        self._alignment_window = deque(maxlen=decision_window_frames)
        self._end_window = deque(maxlen=decision_window_frames)
        self._docked_window = deque(maxlen=docked_window_frames)
        self.reset()

    def reset(self) -> None:
        self.phase = self.SEARCH_GATE
        self._latched_distance_cm = None
        self._latched_angle_deg = None
        self._alignment_window.clear()
        self._end_window.clear()
        self._docked_window.clear()

    @staticmethod
    def _method_quality(method: str) -> int:
        return {
            "aruco_locked": 3,
            "flow_track": 2,
            "inertial_guess": 1,
        }.get(str(method), 0)

    @classmethod
    def _combined_method(cls, *observations: DockMarkerObservation) -> str:
        if not observations:
            return "missing"
        worst = min(
            observations,
            key=lambda item: cls._method_quality(item.tracking_method),
        )
        return worst.tracking_method

    @classmethod
    def _worst_method(cls, *methods: str) -> str:
        """Return the lowest-quality tracking method among merged pair methods."""
        if not methods:
            return "missing"
        return min(methods, key=cls._method_quality)

    @staticmethod
    def _bearing(tx_cm: float, tz_cm: float) -> float:
        return math.degrees(math.atan2(float(tx_cm), float(tz_cm)))

    def _select_by_id(
        self, observations: Iterable[DockMarkerObservation]
    ) -> dict[int, DockMarkerObservation]:
        selected: dict[int, DockMarkerObservation] = {}
        valid_ids = {
            self.left_marker_id,
            self.right_marker_id,
            self.end_left_marker_id,
            self.end_right_marker_id,
        }
        for raw in observations:
            try:
                observation = DockMarkerObservation(
                    marker_id=int(raw.marker_id),
                    tx_cm=float(raw.tx_cm),
                    tz_cm=float(raw.tz_cm),
                    tracking_method=str(raw.tracking_method),
                    confidence=_clamp(float(raw.confidence), 0.0, 1.0),
                )
            except (TypeError, ValueError, AttributeError):
                continue
            if observation.marker_id not in valid_ids or observation.tz_cm <= 0.0:
                continue
            previous = selected.get(observation.marker_id)
            rank = (
                self._method_quality(observation.tracking_method),
                observation.confidence,
            )
            if previous is None or rank > (
                self._method_quality(previous.tracking_method),
                previous.confidence,
            ):
                selected[observation.marker_id] = observation
        return selected

    def _gate_target(self, selected):
        left = selected.get(self.left_marker_id)
        right = selected.get(self.right_marker_id)
        if left is None or right is None:
            return None
        tx_cm = 0.5 * (left.tx_cm + right.tx_cm)
        tz_cm = 0.5 * (left.tz_cm + right.tz_cm)
        return {
            "tx_cm": tx_cm,
            "tz_cm": tz_cm,
            "angle_deg": self._bearing(tx_cm, tz_cm),
            "method": self._combined_method(left, right),
            "confidence": min(left.confidence, right.confidence),
        }

    def _end_target(self, selected):
        """Merge the two end-wall markers (ID2+ID3) into a virtual midpoint.

        Mirrors ``_gate_target``: both end markers must be present (no spacing
        validation — the midpoint is taken whenever both are seen).
        """
        end_left = selected.get(self.end_left_marker_id)
        end_right = selected.get(self.end_right_marker_id)
        if end_left is None or end_right is None:
            return None
        tx_cm = 0.5 * (end_left.tx_cm + end_right.tx_cm)
        tz_cm = 0.5 * (end_left.tz_cm + end_right.tz_cm)
        return {
            "tx_cm": tx_cm,
            "tz_cm": tz_cm,
            "angle_deg": self._bearing(tx_cm, tz_cm),
            "method": self._combined_method(end_left, end_right),
            "confidence": min(end_left.confidence, end_right.confidence),
        }

    @staticmethod
    def _blend_targets(gate, end, end_weight: float):
        weight = _clamp(end_weight, 0.0, 1.0)
        return {
            "tx_cm": (1.0 - weight) * gate["tx_cm"] + weight * end["tx_cm"],
            "tz_cm": (1.0 - weight) * gate["tz_cm"] + weight * end["tz_cm"],
        }

    def _empty_guidance(self, observed_ids, gate_pair_valid=False):
        action = {
            self.SEARCH_GATE: "等待入口双码 ID0+ID1",
            self.ALIGN_GATE: "入口双码不足，等待恢复",
            self.ENTER_GATE: "穿越入口目标暂失",
            self.TRACK_END: "终点双码(ID2+ID3)丢失，等待安全重捕",
            self.DOCKED: "已到位，停车状态锁存",
        }[self.phase]
        return ThreeMarkerGuidance(
            phase=self.phase,
            target_label="--",
            observed_ids=observed_ids,
            pos_angle_deg=None,
            distance_cm=None,
            tracking_method="missing",
            confidence=0.0,
            surge_limit=0.0,
            docked=self.phase == self.DOCKED,
            gate_pair_valid=gate_pair_valid,
            action=action,
        )

    def _docked_guidance(self, observed_ids, gate_pair_valid=False):
        distance = self._latched_distance_cm
        distance_text = "--" if distance is None else f"{distance:.1f} cm"
        return ThreeMarkerGuidance(
            phase=self.DOCKED,
            target_label="ID2+ID3",
            observed_ids=observed_ids,
            pos_angle_deg=self._latched_angle_deg,
            distance_cm=distance,
            tracking_method="latched",
            confidence=1.0,
            surge_limit=0.0,
            docked=True,
            gate_pair_valid=gate_pair_valid,
            action=f"已到位，停车锁存（终点双码 {distance_text}）",
        )

    def _single_marker_target(self, selected, first_id, second_id, half_spacing_cm):
        """当一对码里「恰好一个」是 aruco_locked 时，估算该对的虚拟中点。

        只有 ``aruco_locked`` 才采信。两个都锁定（完整成对）或两个都没锁定
        时返回 None（不做单码退化）。缺失/未锁定的伙伴码位于中点另一侧、相距
        一个整间距，因此把目标横坐标向缺失码方向平移半个间距：
          - 船坞左侧码 (ID0/ID2) 在相机画面里靠右 (tx 更大)，缺的是相机左侧码
            → 目标向左平移 (减半间距)；
          - 船坞右侧码 (ID1/ID3) 在相机画面里靠左 (tx 更小)，缺的是相机右侧码
            → 目标向右平移 (加半间距)。
        """
        first = selected.get(first_id)
        second = selected.get(second_id)
        first_locked = first is not None and first.tracking_method == "aruco_locked"
        second_locked = second is not None and second.tracking_method == "aruco_locked"
        if first_locked == second_locked:
            return None  # 成对或全缺，都不做单码退化
        obs = first if first_locked else second
        marker_id = first_id if first_locked else second_id
        if marker_id in (self.left_marker_id, self.end_left_marker_id):
            tx_cm = obs.tx_cm - half_spacing_cm
        else:
            tx_cm = obs.tx_cm + half_spacing_cm
        return {
            "marker_id": marker_id,
            "tx_cm": tx_cm,
            "tz_cm": obs.tz_cm,
            "angle_deg": self._bearing(tx_cm, obs.tz_cm),
            "method": obs.tracking_method,
            "confidence": obs.confidence,
        }

    def _single_marker_guidance(self, observed_ids, target):
        """单码退化：只给转向、纵向推力归零，靠差速原地转找回另一码。"""
        return ThreeMarkerGuidance(
            phase=self.phase,
            target_label=f"ID{target['marker_id']}单码",
            observed_ids=observed_ids,
            pos_angle_deg=target["angle_deg"],
            distance_cm=target["tz_cm"],
            tracking_method=target["method"],
            confidence=target["confidence"],
            surge_limit=0.0,
            docked=False,
            gate_pair_valid=False,
            single_marker=True,
            action="单码原地转向，找回另一码",
        )

    def update(
        self, observations: Iterable[DockMarkerObservation]
    ) -> ThreeMarkerGuidance:
        selected = self._select_by_id(observations)
        observed_ids = tuple(sorted(selected))
        gate = self._gate_target(selected)
        end = self._end_target(selected)

        if self.phase == self.DOCKED:
            return self._docked_guidance(observed_ids, gate is not None)

        # 🎯 终点对优先：只要 ID2+ID3 两个都在（任意跟踪方式）就直接追终点。
        # 入口对(ID0/ID1)仅在终点对不可见时作为前期辅助（对准 + 接近）。
        if end is not None:
            self.phase = self.TRACK_END

        if self.phase == self.SEARCH_GATE and gate is not None:
            self.phase = self.ALIGN_GATE

        if self.phase == self.ALIGN_GATE:
            aligned = bool(
                gate is not None
                and gate["method"] == "aruco_locked"
                and gate["tz_cm"] <= self.enter_prepare_distance_cm
                and abs(gate["angle_deg"]) <= self.enter_alignment_deg
            )
            self._alignment_window.append(aligned)
            if sum(self._alignment_window) >= self.decision_required_frames:
                self.phase = self.ENTER_GATE

        if self.phase == self.ENTER_GATE:
            end_ready = bool(
                end is not None
                and end["method"] == "aruco_locked"
                and end["tz_cm"] <= self.end_track_distance_cm
            )
            self._end_window.append(end_ready)
            if sum(self._end_window) >= self.decision_required_frames:
                self.phase = self.TRACK_END

        if self.phase == self.TRACK_END:
            end_angle = None if end is None else end["angle_deg"]
            docked_sample = bool(
                end is not None
                and end["method"] == "aruco_locked"
                and end["tz_cm"] <= self.stop_distance_cm
                and abs(end_angle) <= self.docked_alignment_deg
            )
            self._docked_window.append(docked_sample)
            if sum(self._docked_window) >= self.docked_required_frames:
                self.phase = self.DOCKED
                self._latched_distance_cm = end["tz_cm"]
                self._latched_angle_deg = end_angle
                return self._docked_guidance(observed_ids, gate is not None)

        if self.phase in {self.SEARCH_GATE, self.ALIGN_GATE}:
            if gate is None:
                single = self._single_marker_target(
                    selected, self.left_marker_id, self.right_marker_id,
                    self.gate_marker_spacing_cm / 2.0,
                )
                if single is not None:
                    return self._single_marker_guidance(observed_ids, single)
                return self._empty_guidance(observed_ids)
            return ThreeMarkerGuidance(
                phase=self.phase,
                target_label="ID0+ID1",
                observed_ids=observed_ids,
                pos_angle_deg=gate["angle_deg"],
                distance_cm=gate["tz_cm"],
                tracking_method=gate["method"],
                confidence=gate["confidence"],
                surge_limit=0.6,
                docked=False,
                gate_pair_valid=True,
                action="对准入口双码中点",
            )

        if self.phase == self.ENTER_GATE:
            if gate is not None and end is not None:
                end_weight = _clamp(
                    (self.enter_prepare_distance_cm - gate["tz_cm"]) / 50.0,
                    0.0,
                    1.0,
                )
                target = self._blend_targets(gate, end, end_weight)
                target_label = "入口→终点双码"
                tracking_method = self._worst_method(
                    gate["method"], end["method"]
                )
                confidence = min(gate["confidence"], end["confidence"])
            elif gate is not None:
                target = gate
                target_label = "ID0+ID1"
                tracking_method = gate["method"]
                confidence = gate["confidence"]
            elif end is not None:
                target = {"tx_cm": end["tx_cm"], "tz_cm": end["tz_cm"]}
                target_label = "ID2+ID3"
                tracking_method = end["method"]
                confidence = end["confidence"]
            else:
                single = (
                    self._single_marker_target(
                        selected, self.left_marker_id, self.right_marker_id,
                        self.gate_marker_spacing_cm / 2.0,
                    )
                    or self._single_marker_target(
                        selected, self.end_left_marker_id, self.end_right_marker_id,
                        self.end_marker_spacing_cm / 2.0,
                    )
                )
                if single is not None:
                    return self._single_marker_guidance(observed_ids, single)
                return self._empty_guidance(observed_ids)
            return ThreeMarkerGuidance(
                phase=self.phase,
                target_label=target_label,
                observed_ids=observed_ids,
                pos_angle_deg=self._bearing(target["tx_cm"], target["tz_cm"]),
                distance_cm=target["tz_cm"],
                tracking_method=tracking_method,
                confidence=confidence,
                surge_limit=0.4,
                docked=False,
                gate_pair_valid=gate is not None,
                action="平滑穿越入口",
            )

        if end is None:
            single = self._single_marker_target(
                selected, self.end_left_marker_id, self.end_right_marker_id,
                self.end_marker_spacing_cm / 2.0,
            )
            if single is not None:
                return self._single_marker_guidance(observed_ids, single)
            return self._empty_guidance(observed_ids, gate is not None)
        end_angle = end["angle_deg"]
        remaining = max(0.0, end["tz_cm"] - self.stop_distance_cm)
        surge_limit = 0.35 * _clamp(remaining / 22.0, 0.0, 1.0)
        return ThreeMarkerGuidance(
            phase=self.phase,
            target_label="ID2+ID3",
            observed_ids=observed_ids,
            pos_angle_deg=end_angle,
            distance_cm=end["tz_cm"],
            tracking_method=end["method"],
            confidence=end["confidence"],
            surge_limit=surge_limit,
            docked=False,
            gate_pair_valid=gate is not None,
            action=f"减速靠近，目标距离 {self.stop_distance_cm:.0f} cm",
        )
