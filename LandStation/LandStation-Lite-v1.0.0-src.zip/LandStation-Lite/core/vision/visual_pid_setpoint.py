"""Generate bumpless speed and heading setpoints for visual docking PID loops."""

from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Optional


def _clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


def _normalize_heading(heading_deg: float) -> float:
    """Normalize an absolute heading to the ground station's signed range."""
    return (float(heading_deg) + 180.0) % 360.0 - 180.0


def _heading_error(target_deg: float, current_deg: float) -> float:
    return (float(target_deg) - float(current_deg) + 180.0) % 360.0 - 180.0


@dataclass(frozen=True)
class VisualPIDSetpoint:
    phase: str
    control_state: str
    raw_speed_m_s: float
    target_speed_m_s: float
    raw_heading_deg: float
    target_heading_deg: float
    heading_correction_deg: float
    action: str


class VisualPIDSetpointGenerator:
    """Outer-loop guidance for the existing speed and heading PID controllers."""

    def __init__(
        self,
        *,
        heading_gain: float = 0.70,
        max_heading_correction_deg: float = 10.0,
        heading_rate_limit_deg_s: float = 5.0,
        speed_rise_limit_m_s2: float = 0.10,
        speed_fall_limit_m_s2: float = 0.10,
        align_speed_m_s: float = 0.20,
        enter_speed_m_s: float = 0.20,
        track_speed_m_s: float = 0.20,
        angle_stop_deg: float = 10.0,
        slowdown_start_cm: float = 42.0,
        stop_distance_cm: float = 20.0,
        min_speed_m_s: float = 0.15,
        max_speed_m_s: float = 0.25,
        speed_floor_angle_deg: float = 2.5,
        speed_floor_release_cm: float = 45.0,
    ):
        self.heading_gain = float(heading_gain)
        self.max_heading_correction_deg = max(
            0.1, float(max_heading_correction_deg)
        )
        self.heading_rate_limit_deg_s = max(0.1, float(heading_rate_limit_deg_s))
        self.speed_rise_limit_m_s2 = max(0.001, float(speed_rise_limit_m_s2))
        self.speed_fall_limit_m_s2 = max(0.001, float(speed_fall_limit_m_s2))
        self.align_speed_m_s = max(0.0, float(align_speed_m_s))
        self.enter_speed_m_s = max(0.0, float(enter_speed_m_s))
        self.track_speed_m_s = max(0.0, float(track_speed_m_s))
        self.angle_stop_deg = max(0.1, float(angle_stop_deg))
        self.slowdown_start_cm = max(float(slowdown_start_cm), float(stop_distance_cm) + 0.1)
        self.stop_distance_cm = max(0.0, float(stop_distance_cm))
        # 💡 前进速度下限/上限：下限只在"跟踪正常 + 姿态在容差内 + 远离码头"时生效，
        # 一旦姿态超差或进入末端减速区立即交还原有的角度/距离因子（保留停车能力）。
        self.min_speed_m_s = max(0.0, float(min_speed_m_s))
        self.max_speed_m_s = max(self.min_speed_m_s, float(max_speed_m_s))
        self.speed_floor_angle_deg = max(0.0, float(speed_floor_angle_deg))
        self.speed_floor_release_cm = max(
            float(stop_distance_cm), float(speed_floor_release_cm)
        )
        self._speed_floor_phases = ("ALIGN_GATE", "ENTER_GATE", "TRACK_END")
        self.reset()

    def reset(
        self,
        *,
        current_heading_deg: float = 0.0,
        current_speed_m_s: float = 0.0,
        timestamp: float | None = None,
    ) -> None:
        self._last_time = time.monotonic() if timestamp is None else float(timestamp)
        self._target_heading = _normalize_heading(current_heading_deg)
        self._target_speed = _clamp(current_speed_m_s, 0.0, self.max_speed_m_s)

    def _phase_speed(
        self,
        phase: str,
        pos_angle_deg: Optional[float],
        distance_cm: Optional[float],
    ) -> float:
        if pos_angle_deg is None:
            return 0.0
        angle_factor = _clamp(
            1.0 - abs(float(pos_angle_deg)) / self.angle_stop_deg,
            0.0,
            1.0,
        )
        if phase == "ALIGN_GATE":
            base_speed = self.align_speed_m_s
        elif phase == "ENTER_GATE":
            base_speed = self.enter_speed_m_s
        elif phase == "TRACK_END":
            base_speed = self.track_speed_m_s
            if distance_cm is None:
                return 0.0
            distance_factor = _clamp(
                (float(distance_cm) - self.stop_distance_cm)
                / (self.slowdown_start_cm - self.stop_distance_cm),
                0.0,
                1.0,
            )
            base_speed *= distance_factor
        else:
            return 0.0
        return base_speed * angle_factor

    def _apply_speed_floor(
        self,
        raw_speed: float,
        phase: str,
        pos_angle_deg: Optional[float],
        distance_cm: Optional[float],
    ) -> float:
        """把已算出的原始速度抬到 [min, max] 区间内。

        🛡️ 安全前提（任一不满足就原样返回，绝不在"该停"的时刻抬速）：
        - 调用方已确认控制状态为 TRACKING 且非单码（否则本函数不被调用）；
        - 相位属于已识别的推进相位；
        - |pos_angle| 在容差内 —— 姿态歪了就交还给角度因子（原地转向）；
        - 距离在释放线以外 —— 末端减速段不受下限影响（保留 20 cm 停车能力）。
        """
        if self.min_speed_m_s <= 0.0:
            return raw_speed
        if pos_angle_deg is None or abs(float(pos_angle_deg)) > self.speed_floor_angle_deg:
            return raw_speed
        if str(phase) not in self._speed_floor_phases:
            return raw_speed
        if distance_cm is not None and float(distance_cm) < self.speed_floor_release_cm:
            return raw_speed
        return _clamp(raw_speed, self.min_speed_m_s, self.max_speed_m_s)

    def update(
        self,
        *,
        phase: str,
        control_state: str,
        pos_angle_deg: float | None,
        distance_cm: float | None,
        current_heading_deg: float,
        single_marker: bool = False,
        timestamp: float | None = None,
    ) -> VisualPIDSetpoint:
        now = time.monotonic() if timestamp is None else float(timestamp)
        dt = _clamp(now - self._last_time, 0.0, 0.5)
        self._last_time = now
        current_heading = _normalize_heading(current_heading_deg)

        tracking = control_state == "TRACKING"
        degraded = control_state == "DEGRADED"
        if tracking and pos_angle_deg is not None:
            correction = _clamp(
                self.heading_gain * float(pos_angle_deg),
                -self.max_heading_correction_deg,
                self.max_heading_correction_deg,
            )
            raw_heading = _normalize_heading(current_heading + correction)
            raw_speed = (
                0.0 if single_marker
                else self._phase_speed(phase, pos_angle_deg, distance_cm)
            )
            if not single_marker:
                raw_speed = self._apply_speed_floor(
                    raw_speed, phase, pos_angle_deg, distance_cm
                )
            action = (
                "单码原地转向（无推进）"
                if single_marker else "视觉目标送入速度/艏向PID"
            )
        elif degraded:
            correction = _heading_error(self._target_heading, current_heading)
            raw_heading = self._target_heading
            raw_speed = 0.0
            action = "视觉降级：保持艏向，目标速度缓降"
        else:
            correction = 0.0
            raw_heading = current_heading
            raw_speed = 0.0
            action = "视觉未锁定：目标速度归零"

        max_speed_delta = (
            self.speed_rise_limit_m_s2 if raw_speed > self._target_speed
            else self.speed_fall_limit_m_s2
        ) * dt
        self._target_speed += _clamp(
            raw_speed - self._target_speed,
            -max_speed_delta,
            max_speed_delta,
        )
        if self._target_speed < 1e-4:
            self._target_speed = 0.0

        heading_delta = _heading_error(raw_heading, self._target_heading)
        heading_step = self.heading_rate_limit_deg_s * dt
        self._target_heading = _normalize_heading(
            self._target_heading
            + _clamp(heading_delta, -heading_step, heading_step)
        )

        return VisualPIDSetpoint(
            phase=str(phase),
            control_state=str(control_state),
            raw_speed_m_s=raw_speed,
            target_speed_m_s=self._target_speed,
            raw_heading_deg=raw_heading,
            target_heading_deg=self._target_heading,
            heading_correction_deg=correction,
            action=action,
        )
