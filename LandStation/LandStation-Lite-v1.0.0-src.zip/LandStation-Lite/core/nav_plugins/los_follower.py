# 文件路径: core/nav_plugins/los_follower.py

import math
import time
from core.nav_plugins.base_follower import BasePathFollower
from core.utils import CoordUtils

class LOSFollower(BasePathFollower):
    """
    LOS 视线制导追踪器 — 基于 Fossen, Breivik & Skjetne (2003)
    "Line-of-Sight Path Following of Underactuated Marine Craft"

    核心原理：
    1. 以船体当前位置为圆心，半径 R = n * Lpp + V * speed_gain 画包围圆。
    2. 求该圆与当前航线段的交点，取靠近目标航点一侧的交点作为 LOS 虚拟目标点。
    3. 船头对准该 LOS 点，即 ψ_los = atan2(y_los - y, x_los - x)。
    4. 参考模型 (一阶低通滤波) 平滑航点切换时的航向跳变。
    5. 速度与制导完全解耦，由外部独立指定。

    增强特性 (v2):
    6. 速度自适应包围圆：R = n*Lpp + V*speed_gain，速度快时前瞻更远。
    7. 转弯预判混合：检测到前方急弯时，提前将 LOS 参考线从当前段过渡到下一段。
    """
    def __init__(self, ship_length=1.0, n_ship_lengths=2.5, heading_tc=0.3,
                 speed_gain=3.0, turn_anticipation_angle=25.0):
        """
        :param ship_length: 船长 Lpp (米)，决定包围圆基准半径
        :param n_ship_lengths: 视距倍数 n，基准包围圆半径 R_base = n * Lpp
        :param heading_tc: 航向参考模型时间常数 T (秒)，越小响应越快
        :param speed_gain: 速度前瞻增益 (秒)，R = R_base + V * speed_gain，设 0 禁用速度自适应
        :param turn_anticipation_angle: 触发转弯预判的最小转角 (度)，设 180 禁用预判
        """
        self.Lpp = ship_length
        self.n = n_ship_lengths
        self.R_base = n_ship_lengths * ship_length  # 基准包围圆半径 (论文 Eq.3)
        self.T = heading_tc                           # 低通滤波时间常数 (论文 Fig.2)
        self.speed_gain = speed_gain                  # 速度前瞻增益 (秒)
        self.turn_anticipation_angle = turn_anticipation_angle  # 预判触发角 (度)

        # 参考模型状态 (一阶低通)
        self._filt_heading = None   # 滤波后的航向
        self._last_time = None      # 上次更新时间
        self._last_prev_wp = None   # 用于检测航段切换
        self._last_target_wp = None

    # ------------------------------------------------------------------
    def _compute_segment_los(self, curr_pos, seg_start, seg_end, adaptive_R):
        """
        计算单段航线的原始 LOS 目标航向 (不含滤波)。

        :param curr_pos:  船当前位置 (lat, lon)
        :param seg_start: 航段起点 (lat, lon)
        :param seg_end:   航段终点 (lat, lon)
        :param adaptive_R: 自适应包围圆半径 (米)
        :return: LOS 目标航向 (度, [-180, 180])
        """
        prev_lat, prev_lon = seg_start
        target_lat, target_lon = seg_end
        curr_lat, curr_lon = curr_pos

        # 航线基准方位角
        _, path_bearing = CoordUtils.calculate_distance_and_bearing(
            prev_lat, prev_lon, target_lat, target_lon
        )

        # 船体相对航段起点的距离与方位
        boat_dist, boat_bearing = CoordUtils.calculate_distance_and_bearing(
            prev_lat, prev_lon, curr_lat, curr_lon
        )

        # 横向误差 XTE (带符号)
        angle_diff_deg = CoordUtils.get_heading_diff(path_bearing, boat_bearing)
        xte = boat_dist * math.sin(math.radians(angle_diff_deg))

        # 圆-线交点法 (论文 Eq.3-4)
        abs_xte = abs(xte)
        if abs_xte < adaptive_R:
            lookahead = math.sqrt(adaptive_R ** 2 - xte ** 2)
        else:
            lookahead = 0.01

        # LOS 修正角 = atan2(y_e, sqrt(R^2 - y_e^2))
        correction_deg = math.degrees(math.atan2(xte, lookahead))

        # 最终目标航向 = 航线基准角 - 修正角 (论文 Eq.1)
        return CoordUtils.normalize_angle(path_bearing - correction_deg)

    # ------------------------------------------------------------------
    def compute_target(self, curr_pos, prev_wp, target_wp, default_speed,
                       next_wp=None, curr_heading=0.0):
        curr_lat, curr_lon = curr_pos
        prev_lat, prev_lon = prev_wp
        target_lat, target_lon = target_wp

        # 退化：单点或起步阶段，直接对准目标
        if prev_wp == target_wp or prev_wp == curr_pos:
            _, bearing = CoordUtils.calculate_distance_and_bearing(
                curr_lat, curr_lon, target_lat, target_lon
            )
            return bearing, default_speed

        # ------ 1. 速度自适应包围圆半径 ------
        # R = n*Lpp + V * speed_gain  (speed_gain=0 退化为固定半径)
        adaptive_R = self.R_base + default_speed * self.speed_gain

        # ------ 2. 当前航段 LOS 计算 ------
        target_heading = self._compute_segment_los(
            curr_pos, prev_wp, target_wp, adaptive_R
        )

        # ------ 3. 转弯预判：混合下一航段 LOS ------
        if next_wp is not None:
            turn_angle = CoordUtils.calculate_turn_angle(prev_wp, target_wp, next_wp)

            if turn_angle > self.turn_anticipation_angle:
                # 预判区域半径 = adaptive_R × (转角 / 90°)
                # 转角越大区域越宽，90°弯预判半径 = adaptive_R
                R_anticipation = adaptive_R * (turn_angle / 90.0)

                dist_to_target, _ = CoordUtils.calculate_distance_and_bearing(
                    curr_lat, curr_lon, target_lat, target_lon
                )

                if dist_to_target < R_anticipation:
                    # 混合权重：线性 0 (刚进入) → 1 (到达航点)
                    blend = 1.0 - (dist_to_target / R_anticipation)
                    blend = max(0.0, min(1.0, blend))

                    # 计算下一航段的 LOS 航向
                    next_los_heading = self._compute_segment_los(
                        curr_pos, target_wp, next_wp, adaptive_R
                    )

                    # 混合两段航向
                    diff = CoordUtils.get_heading_diff(target_heading, next_los_heading)
                    target_heading = CoordUtils.normalize_angle(
                        target_heading + blend * diff
                    )

        # ------ 4. 参考模型：一阶低通滤波 (论文 Fig.2 的简化实现) ------
        filtered = self._apply_reference_model(target_heading, prev_wp, target_wp)

        return filtered, default_speed

    # ------------------------------------------------------------------
    def _apply_reference_model(self, raw_heading, prev_wp, target_wp):
        """
        论文 Fig.2 参考模型的简化实现：一阶低通滤波器。
        检测到航段切换时自动重置，避免旧状态污染新航段。
        """
        now = time.time()

        # 航段切换检测
        segment_changed = (prev_wp != self._last_prev_wp or
                           target_wp != self._last_target_wp)
        self._last_prev_wp = prev_wp
        self._last_target_wp = target_wp

        if segment_changed or self._filt_heading is None or self._last_time is None:
            self._filt_heading = raw_heading
            self._last_time = now
            return raw_heading

        dt = now - self._last_time
        self._last_time = now

        if dt <= 0 or dt > 1.0:
            # 异常时间步进，跳过滤波
            self._filt_heading = raw_heading
            return raw_heading

        # 一阶低通: α = exp(-dt/T), 输出 = α * 旧值 + (1-α) * 新值
        alpha = math.exp(-dt / self.T)
        diff = CoordUtils.get_heading_diff(self._filt_heading, raw_heading)
        self._filt_heading = CoordUtils.normalize_angle(
            self._filt_heading + (1.0 - alpha) * diff
        )
        return self._filt_heading
