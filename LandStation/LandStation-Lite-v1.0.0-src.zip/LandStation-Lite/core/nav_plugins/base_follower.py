# 文件路径: core/nav_plugins/base_follower.py

class BasePathFollower:
    """
    路径跟踪算法基类 (插座协议)
    所有的算法插件都必须继承这个类，并实现 compute_target 方法。
    """
    
    def compute_target(self, curr_pos, prev_wp, target_wp, default_speed, next_wp=None, curr_heading=0.0):
        """
        计算目标航向和目标速度
        
        :param curr_pos: tuple (lat, lon) 船体当前真实坐标
        :param prev_wp: tuple (lat, lon) 上一个航点坐标
        :param target_wp: tuple (lat, lon) 当前正在前往的目标航点坐标
        :param default_speed: float 默认期望速度
        :param next_wp: tuple (lat, lon) 💡 [新增] 下一个航点，用于曲率预判
        :param curr_heading: float 💡 [新增] 船体当前真实航向，用于偏航减速
        :return: tuple (target_heading, target_speed)
        """
        raise NotImplementedError("算法插件必须实现 compute_target 方法！")