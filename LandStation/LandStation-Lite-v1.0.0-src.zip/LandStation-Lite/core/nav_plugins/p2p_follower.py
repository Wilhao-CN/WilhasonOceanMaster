# 文件路径: core/nav_plugins/p2p_follower.py

from core.nav_plugins.base_follower import BasePathFollower
from core.utils import CoordUtils

class PointToPointFollower(BasePathFollower):
    """
    基础插件：两点直达追踪器 (Point-to-Point)
    逻辑：完全复用旧版逻辑，不考虑侧向偏航，永远把船头对准当前目标点。
    """
    
    def compute_target(self, curr_pos, prev_wp, target_wp, default_speed, next_wp=None, curr_heading=0.0):
        # 拆解当前位置和目标位置的经纬度
        curr_lat, curr_lon = curr_pos
        target_lat, target_lon = target_wp
        
        # 基础直达算法不关心上一个点(prev_wp)，直接算两点之间的绝对直线方位角
        _, bearing = CoordUtils.calculate_distance_and_bearing(
            curr_lat, curr_lon, target_lat, target_lon
        )
        
        # 返回计算好的航向，速度保持系统下发的默认期望速度
        return bearing, default_speed