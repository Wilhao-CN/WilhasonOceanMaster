# 文件路径: core/managers/mission_manager.py
import json
import os
from PyQt5.QtCore import QObject, pyqtSignal

class MissionTask:
    """标准任务数据模型"""
    def __init__(self, task_id, name, coords):
        self.task_id = task_id
        self.name = name
        self.coords = coords  # 格式: [[lat1, lon1], [lat2, lon2], ...]
        self.status = "Idle"  # Idle, Executing, Completed

    def to_dict(self):
        """将对象转为字典，方便序列化为 JSON"""
        return {
            "task_id": self.task_id,
            "name": self.name,
            "coords": self.coords
        }

class MissionManager(QObject):
    """
    独立任务管理器 (核心逻辑层)
    职责：
    1. 管理所有路径数据，实现任务的持久化存储。
    2. [新增] 管理 GPS 校准偏移量，支持持久化存储。
    """
    # 当任务库或校准值发生变化时通知 UI 刷新
    sig_missions_changed = pyqtSignal()
    # 当某个任务被指派给实体时触发
    sig_task_assigned = pyqtSignal(str, list, int) # 任务名, 坐标列表, 目标ID(0x01/0x02)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._missions = {} # 存储 MissionTask 对象，Key 为任务 ID
        self._task_counter = 1
        
        # GPS偏移量存储 (格式: {"A": [dlat, dlon], "B": [dlat, dlon]})
        self._gps_offsets = {
            "dock": {"A": [0.0, 0.0], "B": [0.0, 0.0]},
            "boat": {"A": [0.0, 0.0], "B": [0.0, 0.0]}
        }
        
        # 持久化配置文件路径
        # 💡 关键修复：使用绝对路径锚定到项目根目录，避免因启动时的工作目录不同
        #    (cwd) 导致读/写错别的 missions.json（例如空的那个），从而看不到历史轨迹。
        #    mission_manager.py 位于 <项目根>/core/Managers/ 下，故向上 3 层即项目根。
        _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.storage_path = os.path.join(_project_root, "missions.json")
        
        # 启动时自动从磁盘加载历史数据
        self.load_from_disk()

    # ==========================================
    # 🎯 GPS 校准偏置管理接口
    # ==========================================
    def update_gps_offset(self, target_id, lat_off, lon_off, antenna="A"):
        """更新指定目标/天线的 GPS 偏移量并保存到磁盘"""
        key = "dock" if target_id in [0x01, "dock"] else "boat"
        self._gps_offsets[key][antenna] = [float(lat_off), float(lon_off)]

        print(f"📡 [MissionManager] {key} 天线{antenna} 偏移更新: "
              f"Lat {lat_off:.8f}, Lon {lon_off:.8f}")

        self.save_to_disk()
        self.sig_missions_changed.emit()

    def get_gps_offset(self, target_id, antenna="A"):
        """供 Brain 获取当前修正值"""
        key = "dock" if target_id in [0x01, "dock"] else "boat"
        return self._gps_offsets.get(key, {}).get(antenna, [0.0, 0.0])

    # ==========================================
    # 📂 任务路径管理 (原有逻辑保持)
    # ==========================================
    def add_new_mission(self, coords, name=None):
        if not name:
            name = f"航点任务_{self._task_counter:02d}"
        
        task_id = f"task_{self._task_counter}"
        new_task = MissionTask(task_id, name, coords)
        
        self._missions[task_id] = new_task
        self._task_counter += 1
        
        self.sig_missions_changed.emit()
        self.save_to_disk()
        return task_id

    def get_all_missions(self):
        return self._missions

    def get_mission_coords(self, task_id):
        task = self._missions.get(task_id)
        return task.coords if task else []

    def delete_mission(self, task_id):
        if task_id in self._missions:
            del self._missions[task_id]
            self.sig_missions_changed.emit()
            self.save_to_disk()

    # ==========================================
    # 💾 持久化读写逻辑 (重构以支持 Offsets)
    # ==========================================
    def save_to_disk(self):
        """将当前内存中的任务库和校准值写入 JSON 文件"""
        try:
            # 💡 结构升级：将任务和偏移量分开存放
            full_data = {
                "tasks": {tid: task.to_dict() for tid, task in self._missions.items()},
                "gps_offsets": self._gps_offsets
            }
            with open(self.storage_path, "w", encoding="utf-8") as f:
                json.dump(full_data, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"❌ [持久化] 写入任务文件失败: {e}")

    def load_from_disk(self):
        """从磁盘加载历史任务数据与校准值"""
        if not os.path.exists(self.storage_path):
            return
            
        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                
                # 💡 兼容性检查：如果是新版带 "tasks" 键的结构
                if isinstance(data, dict) and "tasks" in data:
                    mission_entries = data["tasks"]
                    # 读取校准偏移 (兼容旧版扁平格式)
                    raw_offsets = data.get("gps_offsets", {})
                    default_offsets = {
                        "dock": {"A": [0.0, 0.0], "B": [0.0, 0.0]},
                        "boat": {"A": [0.0, 0.0], "B": [0.0, 0.0]}
                    }
                    self._gps_offsets = default_offsets.copy()
                    for dev in ("dock", "boat"):
                        val = raw_offsets.get(dev)
                        if isinstance(val, dict) and "A" in val:
                            self._gps_offsets[dev] = val
                        elif isinstance(val, list):
                            # 兼容旧版 [dlat, dlon] → 写入 A, B 归零
                            self._gps_offsets[dev]["A"] = val
                else:
                    # 兼容旧版本：整个文件就是一个任务字典
                    mission_entries = data
                
                # 恢复 MissionTask 对象实例
                for tid, t_dict in mission_entries.items():
                    task = MissionTask(
                        t_dict["task_id"], 
                        t_dict["name"], 
                        t_dict.get("coords", [])
                    )
                    self._missions[tid] = task
                
                # 智能恢复计数器
                if self._missions:
                    ids = []
                    for tid in self._missions.keys():
                        if "_" in tid:
                            try:
                                ids.append(int(tid.split("_")[1]))
                            except (ValueError, IndexError):
                                continue
                    if ids:
                        self._task_counter = max(ids) + 1
            
            self.sig_missions_changed.emit()
        except Exception as e:
            print(f"❌ [持久化] 加载历史数据失败: {e}")