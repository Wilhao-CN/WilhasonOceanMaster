# 文件路径: core/managers/joystick_manager.py
import os
import json
import pygame
from PyQt5.QtCore import QThread, pyqtSignal, QMutex, QMutexLocker

class JoystickManager(QThread):
    # --- 原有信号 ---
    joystick_axis_moved = pyqtSignal(int, int, float)
    init_req = pyqtSignal(int)
    estop_req = pyqtSignal()
    status_msg = pyqtSignal(str)
    dpad_req = pyqtSignal(int, int, int)

    # --- 🎮 [新增] 手柄配对相关信号 ---
    pairing_progress = pyqtSignal(str, int)   # message, step (0=开始, 1=船坞配对中, 2=子船配对中, 3=完成)
    pairing_complete = pyqtSignal(dict)       # 配对完成，发射 role->index 映射

    def __init__(self):
        super().__init__()
        self.running = True
        self.deadzone = 0.1
        self.threshold = 0.005

        self.last_axes_values = {}
        self.mutex = QMutex()
        self.latest_state = {}

        self.last_button_states = {}
        self.last_hat_states = {}
        self.joysticks = []

        # --- 🎮 [新增] 角色映射系统 ---
        self.config_dir = "config"
        self.config_file = os.path.join(self.config_dir, "joystick_mapping.json")
        # role_to_index: {'dock': 0, 'boat': 1}  — 角色 → 手柄硬件索引
        self.role_to_index = {}
        # joystick_info: {0: {'guid': '...', 'name': '...'}, 1: {...}}  — 硬件索引 → 设备信息
        self.joystick_info = {}

        # --- 🎮 [新增] 配对状态机 ---
        self._pairing_mode = False
        self._pairing_target = None      # 'dock' or 'boat'
        self._pairing_assigned = set()   # 已分配的硬件索引
        self._pairing_button_idx = 3     # Y键 (Xbox: Y=3, PS: △=3, Nintendo: X=3)
        self._pairing_button_last = {}   # 配对按键的上一帧状态 (用于边沿检测)

        # 启动时加载历史映射
        self._load_mapping()

        pygame.init()
        pygame.joystick.init()

    # ==========================================
    # 🎮 角色映射 API（供 ControlDispatcher 等调用）
    # ==========================================
    def get_joystick_index(self, role: str) -> int:
        """
        根据角色名获取手柄硬件索引。
        未配对时回退默认值 dock=0, boat=1。
        注意：此方法不加锁 — role_to_index 仅在配对时修改（配对期间
        轴信号/节拍器均被屏蔽，不存在并发写入），joysticks 列表在运行期间稳定。
        """
        if role in self.role_to_index:
            idx = self.role_to_index[role]
            if idx < len(self.joysticks):
                return idx
        # 回退到硬编码默认值
        return 0 if role == "dock" else 1

    def get_axis_value(self, joy_idx, axis_idx):
        """供控制器绕过信号，直接获取最新的手柄数值"""
        with QMutexLocker(self.mutex):
            return self.latest_state.get((joy_idx, axis_idx), 0.0)

    def is_pairing(self) -> bool:
        """查询当前是否处于配对模式"""
        return self._pairing_mode

    # ==========================================
    # 🎮 配对模式控制
    # ==========================================
    def start_pairing(self):
        """进入配对模式：清空映射，等待用户依次按下Y键来绑定"""
        self._pairing_mode = True
        self._pairing_target = 'dock'
        self._pairing_assigned = set()
        self._pairing_button_last = {}  # 重置按键状态记录
        self.role_to_index = {}
        self.pairing_progress.emit("🎮 请按下【船坞】手柄的 Y 键...", 0)

    def cancel_pairing(self):
        """取消配对，恢复上次保存的映射"""
        self._pairing_mode = False
        self._pairing_target = None
        self._pairing_assigned = set()
        self._pairing_button_last = {}
        self._load_mapping()
        self.pairing_progress.emit("⚠️ 配对已取消，恢复上次映射", 3)

    # ==========================================
    # 🎮 配置文件持久化
    # ==========================================
    def _load_mapping(self):
        """从 JSON 配置文件加载手柄角色映射"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    data = json.load(f)
                # 数据格式: {"dock": {"guid": "...", "name": "..."}, "boat": {...}}
                # 这里暂存设备信息，在检测到实际手柄后再解析为索引
                self._saved_device_info = data
            except Exception:
                self._saved_device_info = {}
        else:
            self._saved_device_info = {}

    def _save_mapping(self):
        """将当前映射持久化到 JSON 配置文件"""
        os.makedirs(self.config_dir, exist_ok=True)
        data = {}
        for role, idx in self.role_to_index.items():
            if idx in self.joystick_info:
                data[role] = self.joystick_info[idx]
        try:
            with open(self.config_file, 'w') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            self.status_msg.emit(f"💾 手柄映射已保存至 {self.config_file}")
        except Exception as e:
            self.status_msg.emit(f"⚠️ 保存手柄映射失败: {e}")

    def _resolve_saved_mapping(self):
        """
        根据已保存的设备信息，尝试匹配当前检测到的手柄。
        匹配规则：按 GUID 精确匹配；若两个手柄 GUID 相同（同型号），
        则按保存时的角色顺序分配当前索引（先 dock 后 boat）。
        """
        if not self._saved_device_info:
            return

        detected = self.joystick_info  # {idx: {guid, name}}

        # 按 GUID 分组当前检测到的手柄
        guid_to_indices = {}
        for idx, info in detected.items():
            guid = info['guid']
            guid_to_indices.setdefault(guid, []).append(idx)

        dock_info = self._saved_device_info.get('dock', {})
        boat_info = self._saved_device_info.get('boat', {})

        dock_guid = dock_info.get('guid', '')
        boat_guid = boat_info.get('guid', '')

        assigned = set()
        new_mapping = {}

        if dock_guid and dock_guid in guid_to_indices:
            available = [i for i in guid_to_indices[dock_guid] if i not in assigned]
            if available:
                new_mapping['dock'] = available[0]
                assigned.add(available[0])

        if boat_guid and boat_guid in guid_to_indices:
            available = [i for i in guid_to_indices[boat_guid] if i not in assigned]
            if available:
                new_mapping['boat'] = available[0]
                assigned.add(available[0])

        # 如果 GUID 匹配失败（同型号手柄或设备换了），使用顺序回退
        unassigned = [i for i in detected.keys() if i not in assigned]
        for role in ('dock', 'boat'):
            if role not in new_mapping and unassigned:
                new_mapping[role] = unassigned.pop(0)

        if new_mapping:
            self.role_to_index = new_mapping
            name_dock = detected.get(new_mapping.get('dock', -1), {}).get('name', '?')
            name_boat = detected.get(new_mapping.get('boat', -1), {}).get('name', '?')
            self.status_msg.emit(
                f"🎮 已加载手柄映射 | 船坞: [{new_mapping.get('dock', '?')}]{name_dock}  "
                f"| 子船: [{new_mapping.get('boat', '?')}]{name_boat}"
            )

    # ==========================================
    # 主循环
    # ==========================================
    def run(self):
        _tick = 0  # 内层循环计数器，用于定期重扫手柄

        while self.running:
            joy_count = pygame.joystick.get_count()
            if joy_count == 0:
                self.status_msg.emit("未检测到 USB 手柄...")
                self.msleep(1000)
                pygame.joystick.init()
                continue

            # 初始化所有手柄
            self.joysticks = []
            self.joystick_info = {}
            for i in range(joy_count):
                try:
                    joy = pygame.joystick.Joystick(i)
                    joy.init()
                    self.joysticks.append(joy)
                    # 🎮 记录设备身份信息
                    try:
                        guid = joy.get_guid()
                    except Exception:
                        guid = ""
                    try:
                        name = joy.get_name()
                    except Exception:
                        name = f"Joystick {i}"
                    self.joystick_info[i] = {'guid': guid, 'name': name}
                    self.status_msg.emit(f"🎮 手柄 [{i}] 已连接: {name} (GUID: {guid})")

                    for b in range(joy.get_numbuttons()):
                        self.last_button_states[(i, b)] = False
                except Exception:
                    continue

            # 🎮 尝试从历史配置文件恢复角色映射
            self._resolve_saved_mapping()

            _tick = 0

            # 核心监听循环
            while self.running and pygame.joystick.get_count() > 0:
                pygame.event.pump()

                # 🔄 [关键修复] 每 1 秒检查一次手柄数量是否变化
                # 如果新插入了手柄（或掉线了），跳出内层循环，回到外层重新扫描初始化
                _tick += 1
                if _tick % 50 == 0:  # 50 * 20ms = 1 秒
                    current_count = pygame.joystick.get_count()
                    if current_count != len(self.joysticks):
                        self.status_msg.emit(
                            f"🔄 检测到手柄数量变化 ({len(self.joysticks)} → {current_count})，重新扫描..."
                        )
                        break  # 跳出内层循环，回到外层重新初始化

                for i, joy in enumerate(self.joysticks):
                    # --- 1. 处理轴数据 ---
                    for axis_idx in range(joy.get_numaxes()):
                        val = joy.get_axis(axis_idx)
                        if abs(val) < self.deadzone:
                            val = 0.0

                        with QMutexLocker(self.mutex):
                            self.latest_state[(i, axis_idx)] = val

                        # 差分检查：正常模式下发射信号（配对模式下屏蔽）
                        if not self._pairing_mode:
                            last_val = self.last_axes_values.get((i, axis_idx), 0.0)
                            if abs(val - last_val) > self.threshold:
                                self.joystick_axis_moved.emit(i, axis_idx, val)
                                self.last_axes_values[(i, axis_idx)] = val

                    # --- 1.5 处理十字键 (配对模式下屏蔽) ---
                    if not self._pairing_mode:
                        for hat_idx in range(joy.get_numhats()):
                            curr_hat = joy.get_hat(hat_idx)
                            last_hat = self.last_hat_states.get((i, hat_idx), (0, 0))

                            if curr_hat != last_hat and curr_hat != (0, 0):
                                self.dpad_req.emit(i, curr_hat[0], curr_hat[1])

                            self.last_hat_states[(i, hat_idx)] = curr_hat

                    # --- 2. 处理按键 ---
                    if self._pairing_mode:
                        # 🎮 配对模式：检测 Y 键按下来识别手柄
                        self._check_pairing_button(joy, i)
                    else:
                        # 正常模式：使用角色映射处理 init/estop 按键
                        dock_idx = self.role_to_index.get('dock', 0)
                        boat_idx = self.role_to_index.get('boat', 1)

                        if i == dock_idx:
                            self._check_button(joy, i, 1, lambda: self.init_req.emit(0x01))
                            self._check_button(joy, i, 2, lambda: self.estop_req.emit())
                        elif i == boat_idx:
                            self._check_button(joy, i, 1, lambda: self.init_req.emit(0x02))
                            self._check_button(joy, i, 2, lambda: self.estop_req.emit())

                self.msleep(20)  # 50Hz 采样

        pygame.joystick.quit()

    def _check_button(self, joy, joy_idx, btn_idx, callback):
        if btn_idx >= joy.get_numbuttons():
            return
        curr_state = bool(joy.get_button(btn_idx))
        last_state = self.last_button_states.get((joy_idx, btn_idx), False)
        if curr_state and not last_state:
            callback()
        self.last_button_states[(joy_idx, btn_idx)] = curr_state

    def _check_pairing_button(self, joy, joy_idx):
        """
        🎮 配对模式：检测 Y 键（默认索引 3）按下事件。
        边沿触发：仅在「未按下→按下」的瞬间触发一次，避免按住重复触发。
        """
        btn = self._pairing_button_idx
        if btn >= joy.get_numbuttons():
            return
        curr_state = bool(joy.get_button(btn))
        last_state = self._pairing_button_last.get(joy_idx, False)

        if curr_state and not last_state:
            # Y 键被按下 → 绑定当前目标角色
            if joy_idx in self._pairing_assigned:
                return  # 已经分配过，忽略

            self._pairing_assigned.add(joy_idx)
            self.role_to_index[self._pairing_target] = joy_idx

            joy_name = self.joystick_info.get(joy_idx, {}).get('name', f'Joystick {joy_idx}')
            if self._pairing_target == 'dock':
                self._pairing_target = 'boat'
                self.pairing_progress.emit(
                    f"✅ 船坞已绑定: [{joy_idx}]{joy_name}  —  请按下【子船】手柄的 Y 键...", 1
                )
            else:
                # 配对完成
                self._pairing_mode = False
                self._pairing_target = None
                self._save_mapping()
                dock_idx = self.role_to_index.get('dock', '?')
                boat_idx = self.role_to_index.get('boat', '?')
                dock_name = self.joystick_info.get(dock_idx, {}).get('name', '?')
                boat_name = self.joystick_info.get(boat_idx, {}).get('name', '?')
                self.pairing_complete.emit(self.role_to_index.copy())
                self.pairing_progress.emit(
                    f"🎉 配对完成！船坞: [{dock_idx}]{dock_name}  |  子船: [{boat_idx}]{boat_name}", 2
                )

        self._pairing_button_last[joy_idx] = curr_state

    def stop(self):
        self.running = False
        self.wait()
