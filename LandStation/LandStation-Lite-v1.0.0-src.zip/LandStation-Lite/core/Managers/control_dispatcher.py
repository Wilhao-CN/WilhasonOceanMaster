# 文件路径: core/managers/control_dispatcher.py
from PyQt5.QtCore import QObject, QTimer

class ControlDispatcher(QObject):
    """
    ⏱️ 全局控制节拍器 & 仲裁器
    职责：统一仲裁并下发控制指令，彻底解耦 UI 线程与物理控制。
    """
    def __init__(self, joystick_manager, dock_controller, boat_controller, driving_console, dock_panel, parent=None):
        super().__init__(parent)
        # 1. 保存各方势力的引用
        self.joystick = joystick_manager
        self.dock_ctrl = dock_controller
        self.boat_ctrl = boat_controller
        self.console = driving_console
        self.dock_panel = dock_panel  # 用于读取下发频率 (interval)

        # 2. 状态变量 (从原主窗口搬迁过来)
        self.dock_joy_active = False
        self.boat_joy_active = False
        self.dock_hw_engaged = False
        self.boat_hw_engaged = False

        # 🎮 虚拟摇杆状态缓存（隔离 PWM 回写污染，防止鼠标操控衰减）
        self._virtual_boat_x = 0.0
        self._virtual_boat_y = 0.0
        self._virtual_dock_x = 0.0
        self._virtual_dock_y = 0.0

        # 3. 核心节拍器
        self.hw_control_timer = QTimer(self)
        self.hw_control_timer.timeout.connect(self._dispatch_hardware_control)

    def start(self, interval_ms=50):
        """启动控制循环"""
        self.hw_control_timer.start(interval_ms)

    def stop(self):
        """停止控制循环"""
        self.hw_control_timer.stop()

    # ==========================================
    # 🎮 虚拟摇杆缓存接口（隔离 PWM 回写）
    # ==========================================
    def set_virtual_boat(self, x: float, y: float):
        """虚拟摇杆移动时更新缓存（不受 PWM 回写污染）"""
        self._virtual_boat_x = x
        self._virtual_boat_y = y

    def set_virtual_dock(self, x: float, y: float):
        """虚拟摇杆移动时更新缓存（不受 PWM 回写污染）"""
        self._virtual_dock_x = x
        self._virtual_dock_y = y

    def _dispatch_hardware_control(self):
        """🧬 [安全增强版节拍器] 兼容零点刹车、自动模式拦截、实体/虚拟双控优先级"""
        # --- 1. 动态同步发送间隔 ---
        interval_ms = int(self.dock_panel.comm_panel.get_interval_sec() * 1000)
        if self.hw_control_timer.interval() != interval_ms:
            self.hw_control_timer.setInterval(interval_ms)

        # 依次处理两艘船
        self._safe_unified_send(self.dock_ctrl, "dock")
        self._safe_unified_send(self.boat_ctrl, "boat")

    def _safe_unified_send(self, controller, ship_type):
        """内部逻辑：在保持原有安全逻辑的前提下，接入自动模式和虚拟摇杆"""
        
        # A. 优先级 1：自动控制 (由第一步改造的缓存提供数据)
        auto_params = controller.get_auto_control_params()
        if auto_params:
            controller.comm.send_control_ratios(*auto_params[:4], flush=True)
            return

        # B. 优先级 2：安全锁检查 (如果 UI 面板上了锁，拒绝一切手动操作)
        if not self.console.lock_checkbox.isChecked():
            return

        # C. 优先级 3：获取控制输入（实体手柄 vs 虚拟摇杆）
        is_hardware_active = False 
        
        # 先读实体手柄 (通过角色映射查找硬件索引，支持配对后动态切换)
        joy_idx = self.joystick.get_joystick_index(ship_type)
        if ship_type == "dock":
            x_hw = self.joystick.get_axis_value(joy_idx, 2) * 100
            y_hw = -self.joystick.get_axis_value(joy_idx, 1) * 100
            is_active_flag = "dock_joy_active"
            hw_engaged_flag = "dock_hw_engaged"
        else:
            x_hw = self.joystick.get_axis_value(joy_idx, 2) * 100
            y_hw = -self.joystick.get_axis_value(joy_idx, 1) * 100
            is_active_flag = "boat_joy_active"
            hw_engaged_flag = "boat_hw_engaged"

        # 获取上一帧实体手柄的状态
        hw_engaged_last_frame = getattr(self, hw_engaged_flag, False)

        # 💡 核心修复：精确判断实体手柄的“发力”与“松手瞬间”
        if abs(x_hw) > 1 or abs(y_hw) > 1:
            # 状态 1：实体手柄正在发力
            is_hardware_active = True
            x, y = x_hw, y_hw
            setattr(self, hw_engaged_flag, True)
        elif hw_engaged_last_frame:
            # 状态 2：实体手柄刚刚归中！强制输出 0 触发刹车，并重置 UI
            is_hardware_active = True
            x, y = 0.0, 0.0
            setattr(self, hw_engaged_flag, False)
        else:
            # 状态 3：实体手柄一直安静，交由鼠标操作 UI 接管
            is_hardware_active = False
            if ship_type == "dock":
                x = self._virtual_dock_x
                y = self._virtual_dock_y
            else:
                x = self._virtual_boat_x
                y = self._virtual_boat_y

        # D. 执行带有“零点刹车”保护的下发逻辑
        was_active = getattr(self, is_active_flag, False)

        if abs(x) > 1 or abs(y) > 1:
            # 正常操控：下发指令
            controller._handle_joystick(x, y, flush=True)
            
            # 仅实体手柄操作时，同步刷新屏幕 UI 摇杆显示
            if is_hardware_active:
                if ship_type == "dock": self.console.sync_dock_ui(x, y)
                else: self.console.sync_boat_ui(x, y)
                
            setattr(self, is_active_flag, True)
        elif was_active:
            # 💡 零点刹车逻辑：捕获回中瞬间，下发一次 1500，并确保 UI 归中
            controller._handle_joystick(0.0, 0.0, flush=True)
            if ship_type == "dock": self.console.sync_dock_ui(0.0, 0.0)
            else: self.console.sync_boat_ui(0.0, 0.0)
            setattr(self, is_active_flag, False)