# 文件路径: core/navigator.py

from core.utils import CoordUtils
from core.nav_plugins.base_follower import BasePathFollower
from core.nav_plugins.p2p_follower import PointToPointFollower
from core.nav_plugins.los_follower import LOSFollower

class MissionNavigator:
    """
    任务导航引擎大管家 (完全解耦版)
    职责：只负责打卡裁判、状态流转和分发计算任务。
    """
    def __init__(self, arrival_threshold=1.0, default_speed=0.1, max_speed=0.5):
        self.mission_path = []
        self.current_wp_index = -1
        self.arrival_threshold = arrival_threshold
        self.default_speed = default_speed
        self.max_speed = max_speed  # 🛡️ 船体物理速度上限
        self.is_active = False
        self.start_pos = None 
        
        self.algorithms = {}
        self.active_algo = None
        
        self.register_algorithm("基础直达 (P2P)", PointToPointFollower())
        self.register_algorithm("高级视线制导 (LOS)", LOSFollower(ship_length=1.0, n_ship_lengths=2.0, heading_tc=0.3))
        
        self.switch_algorithm("基础直达 (P2P)")

    def register_algorithm(self, name: str, algo_instance: BasePathFollower):
        """注册算法插头"""
        self.algorithms[name] = algo_instance

    def switch_algorithm(self, name: str):
        """动态切换算法"""
        if name in self.algorithms:
            self.active_algo = self.algorithms[name]
        else:
            print(f"⚠️ [领航引擎] 切换失败：未找到算法 '{name}'")

    def set_path(self, path):
        if not path:
            self.is_active = False
            return
        self.mission_path = path
        self.current_wp_index = 0
        self.is_active = True
        self.start_pos = None 

    def stop(self):
        self.is_active = False
        self.current_wp_index = -1
        self.start_pos = None

    def update(self, curr_lat, curr_lon, curr_heading=0.0):
        """
        引擎核心流转：打包数据 -> 检查打卡 -> 委派计算
        💡 [修改] 增加 curr_heading 输入，用于支持算法的偏航减速预判
        """
        if not self.is_active or self.current_wp_index >= len(self.mission_path):
            return None, 0.0, 0.0, True

        curr_pos = (curr_lat, curr_lon)
        target_wp = self.mission_path[self.current_wp_index]
        
        if self.start_pos is None:
            self.start_pos = curr_pos

        # 1. 裁判打卡：只算距离
        dist, _ = CoordUtils.calculate_distance_and_bearing(
            curr_lat, curr_lon, target_wp[0], target_wp[1]
        )

        if dist < self.arrival_threshold:
            self.current_wp_index += 1
            if self.current_wp_index < len(self.mission_path):
                # 递归更新获取新航段指令
                return self.update(curr_lat, curr_lon, curr_heading)
            else:
                self.stop()
                return 0.0, 0.0, dist, True

        # 2. 提取上一个航点 (构建虚拟轨道)
        if self.current_wp_index == 0:
            prev_wp = self.start_pos
        else:
            prev_wp = self.mission_path[self.current_wp_index - 1]

        # 💡 [核心新增] 提取下一个航点，用于算法的“曲率预判”减速逻辑
        next_wp = None
        if self.current_wp_index + 1 < len(self.mission_path):
            next_wp = self.mission_path[self.current_wp_index + 1]

        # 3. 委派计算：首航段自动降级为 P2P，避免远距离 LOS 包围圆失效
        #    原因：首航段 prev_wp = start_pos（船起始位），船走得越远，
        #    boat_dist 越大，GPS 噪声被杠杆放大后 XTE 极易超包围圆半径，
        #    导致 LOS 持续 90° 垂直切入、无法稳定到达目标。
        algo = self.algorithms["基础直达 (P2P)"] if self.current_wp_index == 0 else self.active_algo
        target_heading, target_speed = algo.compute_target(
            curr_pos, prev_wp, target_wp, self.default_speed,
            next_wp=next_wp, curr_heading=curr_heading
        )

        # 🛡️ 外环出口限幅：钳位到船体物理上限
        target_speed = min(target_speed, self.max_speed)

        return target_heading, target_speed, dist, False