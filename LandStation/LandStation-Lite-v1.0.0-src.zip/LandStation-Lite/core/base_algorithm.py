# 文件路径: core/base_algorithm.py
from PyQt5.QtWidgets import QWidget

class BaseAlgorithm:
    """
    [插件化基类] 所有底层控制算法（PID, SMC, MPC等）的祖先
    """
    def compute(self, *args, **kwargs):
        """核心计算逻辑：由子类实现"""
        raise NotImplementedError

    def reset(self):
        """重置内部状态（如积分项、缓存等）"""
        pass

    def get_tuning_widget(self, parent=None) -> QWidget:
        """
        🧬 [UI 插槽接口] 
        职责：返回一个包含调参控件的 QWidget。
        冲突检查：默认为 None，不影响任何现有算法的计算逻辑。
        """
        return None