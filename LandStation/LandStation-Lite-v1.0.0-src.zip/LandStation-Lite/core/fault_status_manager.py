"""合并 MCU 遥测、树莓派健康接口和网络在线状态。"""

import time
from typing import Any, Dict, Optional

from PyQt5.QtCore import QObject, pyqtSignal

from core.fault_codes import (
    FAULT_4G,
    FAULT_MCU,
    FAULT_RASPBERRY_PI,
    decode_mcu_faults,
)


class FaultStatusManager(QObject):
    status_changed = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.network_enabled = False
        self.remote_online: Optional[bool] = None
        self.health_available = False
        self.health: Dict[str, Any] = {}
        self.mcu_seen = False
        self.mcu_fault_code = 0
        self.last_mcu_update = 0.0
        self._last_mcu_emit = 0.0
        self.health_error = ""

    def set_network_enabled(self, enabled: bool) -> None:
        self.network_enabled = bool(enabled)
        if not enabled:
            self.remote_online = None
            self.health_available = False
            self.health = {}
            self.health_error = ""
        self._emit()

    def update_remote_online(self, online: bool) -> None:
        self.remote_online = bool(online)
        if not online:
            self.health_available = False
        self._emit()

    def update_mcu_fault(self, raw_fault_code: int) -> None:
        now = time.monotonic()
        value = int(raw_fault_code or 0) & 0xFF
        changed = not self.mcu_seen or value != self.mcu_fault_code
        self.mcu_seen = True
        self.mcu_fault_code = value
        self.last_mcu_update = now
        if changed or (self.remote_online is False and now - self._last_mcu_emit >= 1.0):
            self._last_mcu_emit = now
            self._emit()

    def update_health(self, health: Dict[str, Any]) -> None:
        self.health = dict(health or {})
        self.health_available = True
        self.health_error = ""
        self._emit()

    def health_unavailable(self, reason: str) -> None:
        self.health_available = False
        self.health_error = str(reason or "健康服务不可达")
        self._emit()

    @staticmethod
    def _state_active(health: Dict[str, Any], source: str) -> bool:
        for item in health.get("fault_states", []) or []:
            if item.get("source") != source:
                continue
            return item.get("active") is not False
        return False

    @staticmethod
    def _state_detail(health: Dict[str, Any], source: str) -> str:
        for item in health.get("fault_states", []) or []:
            if item.get("source") != source:
                continue
            if item.get("active") is False:
                continue
            detail = item.get("detail") or {}
            return str(detail.get("message") or "检测到故障")
        return "检测到故障"

    def snapshot(self) -> Dict[str, Any]:
        remote_flags = int(self.health.get("current_fault_code", 0) or 0)

        mcu_fresh = self.mcu_seen and (
            not self.network_enabled
            or self.remote_online is not False
            or time.monotonic() - self.last_mcu_update <= 2.0
        )
        mcu_link_fault = self.health_available and self._state_active(
            self.health, "mcu_link"
        )
        mcu_reported_fault = self.health_available and self._state_active(
            self.health, "mcu"
        )

        if mcu_link_fault:
            text = self._state_detail(self.health, "mcu_link")
            reasons = decode_mcu_faults(self.mcu_fault_code)
            if reasons:
                text += "；最后已知故障：" + "、".join(reasons)
            elif mcu_reported_fault:
                text += "；最后已知故障：" + self._state_detail(
                    self.health, "mcu"
                )
            mcu = {"state": "fault", "text": text}
        elif mcu_reported_fault:
            mcu = {
                "state": "fault",
                "text": self._state_detail(self.health, "mcu"),
            }
        elif self.mcu_fault_code and mcu_fresh:
            reasons = decode_mcu_faults(self.mcu_fault_code)
            mcu = {
                "state": "fault",
                "text": "、".join(reasons) or f"未知故障 0x{self.mcu_fault_code:02X}",
            }
        elif self.health_available and remote_flags & FAULT_MCU:
            mcu = {
                "state": "fault",
                "text": self._state_detail(self.health, "mcu"),
            }
        elif mcu_fresh:
            mcu = {"state": "normal", "text": "正常"}
        else:
            reasons = decode_mcu_faults(self.mcu_fault_code)
            text = "遥测状态未知"
            if reasons:
                text += "；最后已知故障：" + "、".join(reasons)
            mcu = {"state": "unknown", "text": text}

        if not self.network_enabled:
            pi = {"state": "disabled", "text": "未启用远端诊断"}
            network = {"state": "disabled", "text": "未启用远端诊断"}
        elif self.health_available:
            pi = (
                {
                    "state": "fault",
                    "text": self._state_detail(self.health, "raspberry_pi"),
                }
                if remote_flags & FAULT_RASPBERRY_PI
                else {"state": "normal", "text": "正常"}
            )
            network = (
                {
                    "state": "fault",
                    "text": self._state_detail(self.health, "4g"),
                }
                if remote_flags & FAULT_4G
                else {"state": "normal", "text": "正常"}
            )
        else:
            unknown_text = (
                "远端失联，待重连诊断"
                if self.remote_online is False
                else self.health_error or "等待健康数据"
            )
            pi = {"state": "unknown", "text": unknown_text}
            network = {"state": "unknown", "text": unknown_text}

        components = {"mcu": mcu, "raspberry_pi": pi, "4g": network}
        states = {item["state"] for item in components.values()}
        if "fault" in states:
            overall = "fault"
            overall_text = "存在故障"
        elif self.network_enabled and self.remote_online is False:
            overall = "offline"
            overall_text = "远端失联，等待重连诊断"
        elif "unknown" in states:
            overall = "unknown"
            overall_text = "部分状态未知"
        elif states <= {"normal", "disabled"} and "normal" in states:
            overall = "normal"
            overall_text = "正常"
        else:
            overall = "unknown"
            overall_text = "尚未连接"

        return {
            "overall": overall,
            "overall_text": overall_text,
            "remote_online": self.remote_online,
            "network_enabled": self.network_enabled,
            "components": components,
            "health": dict(self.health),
        }

    def _emit(self) -> None:
        self.status_changed.emit(self.snapshot())
