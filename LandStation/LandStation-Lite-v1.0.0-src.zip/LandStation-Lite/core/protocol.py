# # 文件路径: core/protocol.py
import struct

class USVProtocol:
    """
    无人船/船坞 通信协议管理类 (V6.0 4通道全动态版)
    支持多机独立配置：限幅 (Limits) + 死区补偿 (Deadband Offset)
    核心改进：
    1. 开放全部 4 路推进器通道，支持船坞 (0x01) 的 1/4 主推与 2/3 转向逻辑。
    2. 兼容子船 (0x02) 的双推模式，只需将 pwm3, pwm4 设为 1500 即可。
    """

    # 上行遥测帧：旧版 0xBB/59 字节；船坞/子船双温度版 0xBD/65 字节。
    LEGACY_UPLINK_HEADER = 0xBB
    DUAL_TEMPERATURE_UPLINK_HEADER = 0xBD
    UPLINK_TAIL = 0xCC
    LEGACY_UPLINK_LENGTH = 59
    DUAL_TEMPERATURE_UPLINK_LENGTH = 65
    BASE_SENSOR_PAYLOAD_LENGTH = 57
    TEMPERATURE_VALID_MASK = 0x80
    TEMPERATURE_ERROR_MASK = 0x0F
    UPLINK_FRAME_LENGTHS = {
        LEGACY_UPLINK_HEADER: LEGACY_UPLINK_LENGTH,
        DUAL_TEMPERATURE_UPLINK_HEADER: DUAL_TEMPERATURE_UPLINK_LENGTH,
    }

    @classmethod
    def _decode_temperature(cls, raw_temperature, status):
        """把一组温度原始值/状态字节转换成上位机数据结构。"""
        if raw_temperature is None or status is None:
            return {
                "water_c": None,
                "raw": None,
                "valid": False,
                "error_code": None,
                "status": None,
            }

        valid = bool(status & cls.TEMPERATURE_VALID_MASK)
        return {
            "water_c": raw_temperature / 10.0 if valid else None,
            "raw": raw_temperature,
            "valid": valid,
            "error_code": status & cls.TEMPERATURE_ERROR_MASK,
            "status": status,
        }

    @classmethod
    def get_sensor_frame_length(cls, header: int):
        """根据上行帧头返回完整帧长；未知帧头返回 None。"""
        return cls.UPLINK_FRAME_LENGTHS.get(header)

    @classmethod
    def is_sensor_frame_valid(cls, data: bytes) -> bool:
        """验证上行遥测帧的长度、帧尾和累加校验和。"""
        if not data:
            return False

        expected_length = cls.get_sensor_frame_length(data[0])
        if expected_length is None or len(data) != expected_length:
            return False
        if data[-1] != cls.UPLINK_TAIL:
            return False

        return (sum(data[:-2]) & 0xFF) == data[-2]

    @classmethod
    def extract_sensor_frames(cls, buffer: bytearray) -> list:
        """
        从串口/UDP 共用缓冲区中提取所有完整遥测帧。

        函数会原地消费已解析帧和无效字节；遇到半包时保留数据等待下一批字节。
        """
        frames = []
        while buffer:
            frame_length = cls.get_sensor_frame_length(buffer[0])
            if frame_length is None:
                del buffer[0]
                continue

            if len(buffer) < frame_length:
                break

            frame = bytes(buffer[:frame_length])
            if cls.is_sensor_frame_valid(frame):
                frames.append(frame)
                del buffer[:frame_length]
            else:
                # 帧头命中但校验失败，只丢一个字节并继续搜索下一帧头。
                del buffer[0]

        return frames

    # ==========================================
    # 物理配置：支持 1-4 号推进器独立参数(V7.0 斜率补偿版)
    # ==========================================
    USV_CONFIGS = {
        0x01: { # 1号端：船坞 (Dock)
            1: {"min": 1000, "max": 2000, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400, "eps": 0.01, "trim": 1.0}, # 主推L (限幅 1000-2000)
            2: {"min": 1300, "max": 1700, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400, "eps": 0.01, "trim": 1.0}, # 转向A
            3: {"min": 1300, "max": 1700, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400, "eps": 0.01, "trim": 1.0}, # 转向B
            4: {"min": 1000, "max": 2000, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400, "eps": 0.01, "trim": 1.0}, # 主推R (限幅 1000-2000)
        },
        0x02: { # 2号端：无人船 (Boat) — 4 推进器 (与船坞同构)
            1: {"min": 1300, "max": 1800, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400, "eps": 0.01, "trim": 1.0}, # 主推L
            2: {"min": 1400, "max": 1600, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400, "eps": 0.01, "trim": 1.0}, # 转向A
            3: {"min": 1400, "max": 1600, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400, "eps": 0.01, "trim": 1.0}, # 转向B
            4: {"min": 1300, "max": 1800, "pos": 0, "neg": 0, "slope_pos": 400, "slope_neg": 400, "eps": 0.01, "trim": 1.0}, # 主推R
        }
    }

    # ==========================================
    # 推进器物理映射：力(N) → PWM（厂家标定二次拟合，过中位点1500）
    # ==========================================
    @staticmethod
    def force_to_pwm(force_n: float) -> int:
        """
        根据推进器厂家标定数据，将力(N)直接换算为PWM
        二次多项式分段拟合，自动过中位点 (Force=0, PWM=1500)
        """
        if force_n > 0:
            pwm = -0.65914714 * force_n * force_n + 37.584549 * force_n + 1500.0
        elif force_n < 0:
            pwm = -0.73450941 * force_n * force_n + 14.967582 * force_n + 1500.0
        else:
            return 1500
        return max(1000, min(2000, int(pwm)))

    @staticmethod
    def _calc_checksum(data: bytes) -> int:
        """计算校验和：累加所有字节并取低8位"""
        return sum(data) & 0xFF

    # 推进器物理参数（力→PWM 标定区间为 1300~1800，正反向力对称）
    # 注：船坞 1/4 号主推限幅已放宽到 1000~2000，但 ratio=±1.0 仍只映射到 1800/1300，
    #     标定区间之外的 PWM 需由 PWM 直通模式(手柄/视觉)或 |ratio|>1.0 才能触发。
    _MAX_FORCE_POS = 9.5974  # 正向力 (N)，ratio=1.0 → PWM=1800
    _MAX_FORCE_NEG = 9.2045  # 反向力 (N)，ratio=-1.0 → PWM=1300

    @staticmethod
    def _apply_compensation(target_id: int, thruster_idx: int, val: float) -> int:
        """
        [核心] 推进器补偿引擎 (V9.0 Trim校准版)
        支持双输入模式：
        - 原始 PWM (int/float, >500)：手柄/PWM直驱，透传仅做限幅 + trim校准
        - 归一化比例 (float, -1.0~1.0)：控制算法输出，经力→PWM 拟合曲线转换 + trim校准

        💡 trim 校准系数 (默认 1.0)：>1.0 增强推力，<1.0 减弱推力，补偿推进器个体差异
        对两种模式统一生效
        """
        default_cfg = {"min": 1300, "max": 1800, "eps": 0.01, "trim": 1.0}
        ship_configs = USVProtocol.USV_CONFIGS.get(target_id, {})
        cfg = ship_configs.get(thruster_idx, default_cfg)
        trim = cfg.get("trim", 1.0)

        # --- 模式 1：原始 PWM 直通 (手柄/视觉靠泊) ---
        if isinstance(val, (int, float)) and val > 500:
            # Trim 校准：以 1500 为基准等比例缩放偏差，方向不变
            if trim != 1.0:
                val = 1500 + (val - 1500) * trim
            return max(cfg["min"], min(cfg["max"], int(val)))

        # --- 模式 2：比例 → 力 → PWM (控制算法输出) ---
        ratio = float(val)
        if abs(ratio) <= cfg["eps"]:
            return 1500

        # Trim 校准：比例缩放
        ratio *= trim

        if ratio > 0:
            force_n = ratio * USVProtocol._MAX_FORCE_POS
        else:
            force_n = ratio * USVProtocol._MAX_FORCE_NEG

        pwm = USVProtocol.force_to_pwm(force_n)
        # 反桨补偿：镜像 PWM (3000-pwm)，保证左右推力曲线对称
        if cfg.get("reverse", False):
            pwm = 3000 - pwm
        return max(cfg["min"], min(cfg["max"], pwm))


    @staticmethod
    def pack_control_cmd(target_id: int, mode: int, 
                         pwm1: float, pwm2: float, pwm3: float, pwm4: float, 
                         relays: list, imu_en: int = 0x01, imu_ms: int = 200, 
                         gps_en: int = 0x01, gps_ms: int = 200) -> bytes:
        """
        [下发] 万能动态控制指令打包器 (33字节 V6.0 协议)
        💡 维护说明：pwm1-4 现在支持输入 PWM(1000-2000) 或 比例(-1.0~1.0)
        """
        # 1. 动力限幅与补偿：对 4 路通道分别处理 (此处逻辑已在内部实现双模兼容)
        p1 = USVProtocol._apply_compensation(target_id, 1, pwm1)
        p2 = USVProtocol._apply_compensation(target_id, 2, pwm2)
        p3 = USVProtocol._apply_compensation(target_id, 3, pwm3)
        p4 = USVProtocol._apply_compensation(target_id, 4, pwm4)

        # 状态判定：1500 停止(1)，其他 运行(2)
        s1 = 1 if p1 == 1500 else 2
        s2 = 1 if p2 == 1500 else 2
        s3 = 1 if p3 == 1500 else 2
        s4 = 1 if p4 == 1500 else 2

        # 2. 构造 31 字节 Payload (格式串严格匹配硬件要求)
        fmt = '> B B B 6B B H B H B H B H H H B H B H'
        payload = struct.pack(
            fmt,
            0xAA,           # Byte 0: 帧头
            target_id,      # Byte 1: 目标 ID
            mode,           # Byte 2: 控制模式
            *relays,        # Byte 3-8: 继电器状态
            
            s1, p1,         # Byte 9-11: 推进器 1 (船坞L / 子船L)
            s2, p2,         # Byte 12-14: 推进器 2 (船坞转向A / 子船R)
            s3, p3,         # Byte 15-17: 推进器 3 (船坞转向B / 子船预留)
            s4, p4,         # Byte 18-20: 推进器 4 (船坞R / 子船预留)
            1500, 1500,     # Byte 21-24: 舵机 1 & 2 (预留)
            
            imu_en, imu_ms, # Byte 25-27: IMU 控制
            gps_en, gps_ms  # Byte 28-30: GPS 控制
        )

        # 3. 追加校验和与帧尾 (共33字节)
        checksum = USVProtocol._calc_checksum(payload)
        return payload + struct.pack('>BB', checksum, 0x55)


    @staticmethod
    def get_init_cmd(target_id: int) -> bytes:
        """[下发] 系统初始化指令：所有通道归中"""
        return USVProtocol.pack_control_cmd(
            target_id=target_id,
            mode=0x00,
            pwm1=1500, pwm2=1500, pwm3=1500, pwm4=1500,
            relays=[1, 1, 1, 1, 1, 1],
            imu_en=0x01, imu_ms=50,
            gps_en=0x01, gps_ms=50
        )

    @staticmethod
    def get_estop_cmd(target_id: int) -> bytes:
        """[下发] 动力急停指令：所有通道强制 1500"""
        return USVProtocol.pack_control_cmd(
            target_id=target_id,
            mode=0x00,
            pwm1=1500, pwm2=1500, pwm3=1500, pwm4=1500,
            relays=[0, 0, 0, 0, 1, 0],
            imu_en=0x00, imu_ms=0,
            gps_en=0x00, gps_ms=0
        )

    @staticmethod
    def parse_sensor_data(data: bytes) -> dict:
        """[接收] 解析旧版 59 字节或船坞/子船双温度 65 字节回传帧。"""
        if not USVProtocol.is_sensor_frame_valid(data):
            return None

        # 两种帧的 Byte 0~56 完全一致；校验和、帧尾和扩展字段单独处理。
        fmt = '>5B4H7h2iB2iBI2I'

        try:
            unpacked = struct.unpack(fmt, data[:USVProtocol.BASE_SENSOR_PAYLOAD_LENGTH])

            # 拼出 EKF 融合艏向: Byte35(低) + Byte44(高) → int16 LE → deg
            ekf_low  = unpacked[18]
            ekf_high = unpacked[21]
            ekf_raw  = (ekf_high << 8) | ekf_low
            if ekf_raw >= 0x8000:
                ekf_raw -= 0x10000
            ekf_heading = ekf_raw / 100.0

            is_dual_temperature_frame = (
                data[0] == USVProtocol.DUAL_TEMPERATURE_UPLINK_HEADER
            )
            if is_dual_temperature_frame:
                temperature_01 = USVProtocol._decode_temperature(
                    struct.unpack_from('>h', data, 57)[0], data[59]
                )
                temperature_02 = USVProtocol._decode_temperature(
                    struct.unpack_from('>h', data, 60)[0], data[62]
                )
            else:
                temperature_01 = USVProtocol._decode_temperature(None, None)
                temperature_02 = USVProtocol._decode_temperature(None, None)

            return {
                "id": unpacked[1],
                "mode": unpacked[2],
                "battery": unpacked[3],
                "fault_code": unpacked[4],
                "pwm": [unpacked[5], unpacked[6], unpacked[7], unpacked[8]],
                "imu": {
                    "dual_heading": unpacked[9]/100.0,
                    "imu_vel_x": unpacked[10]/100.0,  # 复用roll字段，实为IMU X轴积分速度(m/s)
                    "heading": unpacked[11]/100.0,
                    "yaw_rate": unpacked[12]/100.0,
                    "sway_speed": unpacked[13]/100.0,
                    "ekf_heading": ekf_heading
                },
                "gps": {
                    "cog": unpacked[14]/100.0,
                    "speed": unpacked[15]/100.0,
                    "lat": unpacked[16]/10000000.0,
                    "lon": unpacked[17]/10000000.0
                },
                "gps_B": {
                    "lat": unpacked[19]/10000000.0,
                    "lon": unpacked[20]/10000000.0
                },
                "timestamp": unpacked[22],
                "utc_time_A": unpacked[23],
                "utc_time_B": unpacked[24],
                "temperatures": {
                    "sensor_01": temperature_01,
                    "sensor_02": temperature_02,
                },
            }
        except (struct.error, IndexError, TypeError):
            # print(f"解包异常: {e}") # 调试用
            return None

    @staticmethod
    def get_boat_return_cmd() -> bytes:
        """子船专用返航特殊指令"""
        return bytes.fromhex("FA 56 00 00 E2".replace(' ', ''))

    @staticmethod
    def pack_gps_calib_cmd(target_id: int, lat_offset: float, lon_offset: float) -> bytes:
        """
        [下发] GPS 校准偏移指令 (13字节, 帧头 0xFD)
        将主天线A的校准偏差下发单片机，单片机对A/B两天线同时应用
        lat_offset, lon_offset: 单位 度 (如 0.0000001 = 1e-7 度 ≈ 1.1cm)
        """
        lat_i = int(round(lat_offset * 10000000.0))
        lon_i = int(round(lon_offset * 10000000.0))
        payload = struct.pack('>BBBii',
            0xFD,           # Byte 0: 帧头
            target_id,      # Byte 1: 目标 ID
            0x01,           # Byte 2: 命令码 GPS校准
            lat_i,          # Byte 3-6: 纬度偏移 (int32, 1e-7度)
            lon_i           # Byte 7-10: 经度偏移 (int32, 1e-7度)
        )
        checksum = USVProtocol._calc_checksum(payload)
        return payload + struct.pack('>BB', checksum, 0x55)

    @staticmethod
    def pack_ekf_cmd(target_id: int, enable: bool) -> bytes:
        """
        [下发] EKF 启停控制指令 (6字节, 帧头 0xFD)
        enable=True  → 开启 EKF 融合
        enable=False → 关闭 EKF，回退原始双GPS解算
        """
        payload = struct.pack('>BBBB',
            0xFD,           # Byte 0: 帧头
            target_id,      # Byte 1: 目标 ID
            0x02,           # Byte 2: 命令码 EKF控制
            0x01 if enable else 0x00  # Byte 3: 使能
        )
        checksum = USVProtocol._calc_checksum(payload)
        return payload + struct.pack('>BB', checksum, 0x55)

    @staticmethod
    def pack_imu_deadband_cmd(target_id: int, deadband_deg_s: float) -> bytes:
        """
        [下发] IMU 角速度积分死区配置指令 (9字节, 帧头 0xFD)
        deadband_deg_s: 死区阈值 (°/s)，范围 0.0~5.0
        """
        raw = struct.unpack('>I', struct.pack('>f', deadband_deg_s))[0]
        payload = struct.pack('>BBBI',
            0xFD,           # Byte 0: 帧头
            target_id,      # Byte 1: 目标 ID
            0x04,           # Byte 2: 命令码 IMU死区配置
            raw             # Byte 3-6: float32 死区值 (大端)
        )
        checksum = USVProtocol._calc_checksum(payload)
        return payload + struct.pack('>BB', checksum, 0x55)

    @staticmethod
    def pack_imu_calib_cmd(target_id: int) -> bytes:
        """
        [下发] IMU 静态零偏校准指令 (5字节, 帧头 0xFD)
        触发 IMU 传感器内部零偏校准，上电后保持静止 1s 以上后使用
        """
        payload = struct.pack('>BBB',
            0xFD,           # Byte 0: 帧头
            target_id,      # Byte 1: 目标 ID
            0x03            # Byte 2: 命令码 IMU校准
        )
        checksum = USVProtocol._calc_checksum(payload)
        return payload + struct.pack('>BB', checksum, 0x55)

    @staticmethod
    def bytes_to_hex_str(data: bytes) -> str:
        return ' '.join([f'{b:02X}' for b in data])






