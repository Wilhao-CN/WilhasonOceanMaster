"""Wire protocol and rolling statistics for Raspberry Pi link latency.

The latency packets are deliberately separate from the existing MCU frames so
old ground-station and Raspberry Pi deployments keep exchanging raw 33/65-byte
frames while the two sides are upgraded independently.
"""

from __future__ import annotations

from collections import deque
import statistics
import struct
from typing import Optional


MAGIC = b"LSLT"
VERSION = 1

TYPE_PING = 1
TYPE_PONG = 2
TYPE_TELEMETRY_STAMP = 3
TYPE_COMMAND = 4
TYPE_COMMAND_ACK = 5

_SIMPLE = struct.Struct("!4sBBBIQ")
_TIMED_REPLY = struct.Struct("!4sBBBIQQQ")
_WRAPPED = struct.Struct("!4sBBBIQH")


def is_latency_packet(data: bytes) -> bool:
    return len(data) >= 6 and data[:4] == MAGIC and data[4] == VERSION


def pack_ping(device_id: int, sequence: int, sent_ns: int) -> bytes:
    return _SIMPLE.pack(
        MAGIC, VERSION, TYPE_PING, device_id, sequence & 0xFFFFFFFF, sent_ns
    )


def pack_pong(
    device_id: int,
    sequence: int,
    origin_ns: int,
    received_ns: int,
    replied_ns: int,
) -> bytes:
    return _TIMED_REPLY.pack(
        MAGIC,
        VERSION,
        TYPE_PONG,
        device_id,
        sequence & 0xFFFFFFFF,
        origin_ns,
        received_ns,
        replied_ns,
    )


def pack_telemetry_stamp(device_id: int, sequence: int, sent_ns: int) -> bytes:
    return _SIMPLE.pack(
        MAGIC,
        VERSION,
        TYPE_TELEMETRY_STAMP,
        device_id,
        sequence & 0xFFFFFFFF,
        sent_ns,
    )


def pack_command(
    device_id: int, sequence: int, sent_ns: int, command: bytes
) -> bytes:
    if len(command) > 0xFFFF:
        raise ValueError("command is too large for latency wrapper")
    return _WRAPPED.pack(
        MAGIC,
        VERSION,
        TYPE_COMMAND,
        device_id,
        sequence & 0xFFFFFFFF,
        sent_ns,
        len(command),
    ) + command


def pack_command_ack(
    device_id: int,
    sequence: int,
    origin_ns: int,
    received_ns: int,
    replied_ns: int,
) -> bytes:
    return _TIMED_REPLY.pack(
        MAGIC,
        VERSION,
        TYPE_COMMAND_ACK,
        device_id,
        sequence & 0xFFFFFFFF,
        origin_ns,
        received_ns,
        replied_ns,
    )


def unpack_packet(data: bytes) -> Optional[dict]:
    """Return a validated packet dictionary, or ``None`` for invalid input."""
    if not is_latency_packet(data):
        return None

    packet_type = data[5]
    try:
        if packet_type in (TYPE_PING, TYPE_TELEMETRY_STAMP):
            if len(data) != _SIMPLE.size:
                return None
            _, _, _, device_id, sequence, sent_ns = _SIMPLE.unpack(data)
            return {
                "type": packet_type,
                "device_id": device_id,
                "sequence": sequence,
                "sent_ns": sent_ns,
            }

        if packet_type in (TYPE_PONG, TYPE_COMMAND_ACK):
            if len(data) != _TIMED_REPLY.size:
                return None
            (
                _,
                _,
                _,
                device_id,
                sequence,
                origin_ns,
                received_ns,
                replied_ns,
            ) = _TIMED_REPLY.unpack(data)
            return {
                "type": packet_type,
                "device_id": device_id,
                "sequence": sequence,
                "origin_ns": origin_ns,
                "received_ns": received_ns,
                "replied_ns": replied_ns,
            }

        if packet_type == TYPE_COMMAND:
            if len(data) < _WRAPPED.size:
                return None
            (
                _,
                _,
                _,
                device_id,
                sequence,
                sent_ns,
                payload_length,
            ) = _WRAPPED.unpack_from(data)
            if len(data) != _WRAPPED.size + payload_length:
                return None
            return {
                "type": packet_type,
                "device_id": device_id,
                "sequence": sequence,
                "sent_ns": sent_ns,
                "payload": data[_WRAPPED.size :],
            }
    except struct.error:
        return None
    return None


class LatencyTracker:
    """Maintain clock offset and recent up/down/RTT measurements."""

    def __init__(self, max_samples: int = 120):
        self.rtt_ms = deque(maxlen=max_samples)
        self.upload_ms = deque(maxlen=max_samples)
        self.download_ms = deque(maxlen=max_samples)
        self._offset_candidates = deque(maxlen=20)
        self.clock_offset_ns: Optional[float] = None  # Pi clock - PC clock
        self.probes_sent = 0
        self.probes_received = 0
        self.probes_lost = 0

    def reset(self) -> None:
        self.rtt_ms.clear()
        self.upload_ms.clear()
        self.download_ms.clear()
        self._offset_candidates.clear()
        self.clock_offset_ns = None
        self.probes_sent = 0
        self.probes_received = 0
        self.probes_lost = 0

    def record_probe_sent(self) -> None:
        self.probes_sent += 1

    def record_probe_lost(self) -> None:
        self.probes_lost += 1

    def record_pong(
        self, origin_ns: int, remote_received_ns: int, remote_replied_ns: int, now_ns: int
    ) -> float:
        processing_ns = max(0, remote_replied_ns - remote_received_ns)
        rtt_ns = max(0, (now_ns - origin_ns) - processing_ns)
        offset_ns = (
            (remote_received_ns - origin_ns) + (remote_replied_ns - now_ns)
        ) / 2.0
        self._offset_candidates.append((rtt_ns, offset_ns))
        # The least-delayed exchange is normally the least queue-biased offset.
        best = sorted(self._offset_candidates, key=lambda item: item[0])[:5]
        self.clock_offset_ns = statistics.median(item[1] for item in best)
        rtt_ms = rtt_ns / 1_000_000.0
        self.rtt_ms.append(rtt_ms)
        self.probes_received += 1
        return rtt_ms

    def record_upload(self, remote_sent_ns: int, local_received_ns: int) -> Optional[float]:
        if self.clock_offset_ns is None:
            return None
        delay_ms = (
            local_received_ns - (remote_sent_ns - self.clock_offset_ns)
        ) / 1_000_000.0
        if -5.0 <= delay_ms <= 60_000.0:
            self.upload_ms.append(max(0.0, delay_ms))
            return max(0.0, delay_ms)
        return None

    def record_download(self, local_sent_ns: int, remote_received_ns: int) -> Optional[float]:
        if self.clock_offset_ns is None:
            return None
        delay_ms = (
            (remote_received_ns - self.clock_offset_ns) - local_sent_ns
        ) / 1_000_000.0
        if -5.0 <= delay_ms <= 60_000.0:
            self.download_ms.append(max(0.0, delay_ms))
            return max(0.0, delay_ms)
        return None

    @staticmethod
    def _mean(values) -> Optional[float]:
        return statistics.fmean(values) if values else None

    def snapshot(self, peer_supported: bool) -> dict:
        rtt = self._mean(self.rtt_ms)
        upload = self._mean(self.upload_ms)
        download = self._mean(self.download_ms)
        upload_fallback = upload is None and rtt is not None
        download_fallback = download is None and rtt is not None
        if upload_fallback:
            upload = rtt / 2.0
        if download_fallback:
            download = rtt / 2.0
        jitter = statistics.pstdev(self.rtt_ms) if len(self.rtt_ms) >= 2 else 0.0
        decided = self.probes_received + self.probes_lost
        loss = (self.probes_lost / decided * 100.0) if decided else 0.0
        return {
            "available": peer_supported and rtt is not None,
            "peer_supported": peer_supported,
            "upload_ms": upload,
            "download_ms": download,
            "rtt_ms": rtt,
            "jitter_ms": jitter,
            "loss_percent": loss,
            # Directional values rely on the probe-derived clock offset. They
            # remain estimates unless the two hosts have independently verified
            # clock synchronisation.
            "upload_estimated": upload is not None,
            "download_estimated": download is not None,
            "upload_fallback": upload_fallback,
            "download_fallback": download_fallback,
        }
