"""上位机与树莓派共享的顶层故障位定义。"""

FAULT_MCU = 0x01
FAULT_RASPBERRY_PI = 0x02
FAULT_4G = 0x04

FAULT_LABELS = {
    FAULT_MCU: "MCU",
    FAULT_RASPBERRY_PI: "树莓派",
    FAULT_4G: "4G",
}

# MCU uplink Byte 4 sub-fault mask (shared with cmd_process.h).
MCU_FAULT_LABELS = {
    0x01: "控制指令超时",
    0x02: "IMU数据超时",
    0x04: "GPS天线A异常",
    0x08: "GPS天线B异常",
    0x10: "水温传感器01异常",
    0x20: "水温传感器02异常",
    0x40: "UART/DMA通信异常",
    0x80: "MCU内部预留故障",
}


def decode_fault_flags(value: int) -> list:
    """把组合故障位转换成中文名称列表。"""
    flags = int(value or 0) & 0xFF
    return [label for bit, label in FAULT_LABELS.items() if flags & bit]


def decode_mcu_faults(value: int) -> list:
    """Decode MCU telemetry Byte 4 into detailed Chinese fault names."""
    flags = int(value or 0) & 0xFF
    return [label for bit, label in MCU_FAULT_LABELS.items() if flags & bit]
