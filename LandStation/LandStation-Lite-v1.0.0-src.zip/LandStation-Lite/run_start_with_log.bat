@echo off
REM ===========================================================================
REM  Ground station launcher WITH DIAGNOSTIC LOGGING
REM ===========================================================================
REM  This is the same as start_groundstation.bat, but it also captures ALL
REM  console output to _baseline\startup_log.txt so it can be sent back
REM  without manual copy/paste.
REM
REM  Use this when the twin map is blank and you need to know why.
REM
REM  NOTE: keep this file pure ASCII. cmd.exe reads .bat as OEM 936 and
REM        non-ASCII comment text would be executed as a command.
REM ===========================================================================

cd /d "%~dp0"

set "VENV_PY=%~dp0venv_usv\Scripts\python.exe"
if not exist "%VENV_PY%" (
    echo [ERROR] venv_usv\Scripts\python.exe not found.
    pause
    exit /b 1
)

if not exist "_baseline" mkdir "_baseline"
set "LOG=%~dp0_baseline\startup_log.txt"

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "QTWEBENGINE_CHROMIUM_FLAGS=--disable-gpu-sandbox --disable-gpu --no-sandbox --disable-software-rasterizer"

echo.
echo ==========================================================================
echo  Starting ground station. Full output is being written to:
echo    _baseline\startup_log.txt
echo.
echo  Let it run ~15 seconds, then close the window normally.
echo  After it exits, send back _baseline\startup_log.txt
echo ==========================================================================
echo.

REM 2>&1 pipes stderr into stdout so the log has everything.
"%VENV_PY%" "%~dp0main.py" > "%LOG%" 2>&1

echo.
echo ==========================================================================
echo  Exited with code %ERRORLEVEL%
echo  Full log: _baseline\startup_log.txt
echo ==========================================================================
echo.
pause
