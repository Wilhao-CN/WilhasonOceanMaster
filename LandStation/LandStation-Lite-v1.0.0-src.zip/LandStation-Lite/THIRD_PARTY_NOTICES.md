# 第三方组件声明（THIRD_PARTY_NOTICES）

本工程使用了以下第三方组件。**发布前请确认每一节的许可义务都已满足。**

> ℹ️ 本文件中的版本号来自 `requirements.txt` 与实测环境。升级依赖后请回来同步。

---

## ⚠️ 需要你确认的两件事

### 1. PyQt5 / PyQtWebEngine —— GPL v3（传染性） ✅ **已决策：本项目采用 GPL v3**

| 组件 | 版本 | 许可 |
|---|---|---|
| PyQt5 | 5.15.11 | **GPL v3** 或 Riverbank 商业授权 |
| PyQtWebEngine | 5.15.7 | **GPL v3** 或 Riverbank 商业授权 |
| PyQt5-Qt5（Qt 运行库） | 5.15.2 | LGPL v3 / GPL v3 |
| PyQtWebEngine-Qt5 | 5.15.2 | LGPL v3 / GPL v3 |

**GPL v3 具有传染性**：若以 GPL 版 PyQt5 发布本工程，则**整个工程必须采用 GPL v3 兼容许可**。

- 学术 / 开源 / 内部使用 → 用 GPL v3 即可，零成本
- 闭源商用 → 需购买 Riverbank 商业授权，或迁移到 **PySide6**（LGPL，允许闭源）

**⇒ 本项目已选定 GPL v3**（方案 A），完整条款见根目录 `LICENSE`，说明见 `README.md` 的「许可」一节。

### 2. Ultralytics YOLOv8 —— AGPL-3.0（传染性，**可选依赖**）

| 组件 | 许可 | 是否随包 |
|---|---|---|
| `ultralytics` 框架 | **AGPL-3.0** | ❌ **不随包**（写在 `requirements-optional.txt`，用户自行安装） |
| `best.pt` / `boat_NOF.pt`（**自训权重**） | 项目方自有 | ✅ 随包发布 |

**AGPL-3.0 比 GPL 更强**：不仅分发触发义务，**通过网络提供服务也触发**。

- 只在本机/内部使用 → 无影响
- 对外发布或作为网络服务 → AGPL 可能要求你一并开源
- **`yolov8n.pt`（Ultralytics 官方预训练权重）已从本包移除**（AGPL，不随包发布）

⚠️ **请注明**：随包的 `best.pt` / `boat_NOF.pt` 虽然由项目方训练，
但**是使用 Ultralytics YOLOv8 框架训练的** —— 这一点建议在发布说明中讲清楚。

---

## 必需依赖（随 `requirements.txt`）

| 组件 | 版本 | 许可 | 说明 |
|---|---|---|---|
| PyQt5 | 5.15.11 | **GPL v3** / 商业 | 界面框架（见上） |
| PyQtWebEngine | 5.15.7 | **GPL v3** / 商业 | 内嵌浏览器（地图） |
| PyQt5-Qt5 | 5.15.2 | LGPL v3 / GPL v3 | Qt 运行库 |
| pyqtgraph | 0.13.7 | MIT | 实时遥测曲线 |
| NumPy | 2.2.6 | BSD-3-Clause | 数值计算 |
| opencv-python | 4.11.0.86 | Apache-2.0 | 图像处理、ArUco 检测 |
| pyserial | 3.5 | BSD-3-Clause | 串口通信 |
| pygame | 2.6.1 | LGPL-2.1 | USB 手柄读取 |

## 可选依赖（随 `requirements-optional.txt`）

| 组件 | 许可 | 说明 |
|---|---|---|
| ultralytics | **AGPL-3.0** | YOLOv8 目标检测（见上） |
| torch / torchvision | BSD-3-Clause | ultralytics 的后端（按需安装） |

## 前端 / 资源（随包发布）

| 组件 | 版本 | 许可 | 位置 |
|---|---|---|---|
| Leaflet | 1.9.4 | BSD-2-Clause | `ui/map/leaflet/`（**已本地化，离线可用**） |
| qwebchannel.js | 随 Qt | LGPL v3 / GPL v3 | `ui/map/qwebchannel.js` |
| Level1_Pool 正交底图 | — | 项目方自有 | `ui/map/twin_maps/` |

---

## 各许可要点速查

| 许可 | 传染性 | 闭源商用 | 网络服务触发 |
|---|---|---|---|
| MIT / BSD / Apache-2.0 | 无 | ✅ 可以 | 否 |
| LGPL | 弱（仅库本身） | ✅ 可以（动态链接） | 否 |
| **GPL v3** | **强** | ❌ 需商业授权 | 否 |
| **AGPL-3.0** | **最强** | ❌ 需商业授权 | ✅ **是** |

---

## 致谢

- **Qt / PyQt** —— 界面与内嵌浏览器
- **Leaflet** —— 轻量地图渲染
- **pyqtgraph** —— 高性能实时绘图
- **OpenCV** —— 计算机视觉
- **Ultralytics** —— YOLOv8 目标检测框架
- 以及所有参与本工程前期研究工作的同学与老师

---

## 维护提示

新增依赖时，请：

1. 在 `requirements.txt`（或 `-optional.txt`）中登记
2. **在本文档中补充该组件的许可**
3. 若许可具有传染性（GPL/AGPL），在 README 的「许可」一节中说明
