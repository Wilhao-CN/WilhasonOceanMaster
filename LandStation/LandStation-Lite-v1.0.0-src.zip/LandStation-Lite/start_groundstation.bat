@echo off
setlocal

rem ============================================================
rem  USV Ground Station launcher
rem
rem  NOTE: this file is intentionally pure ASCII.
rem  cmd.exe parses .bat files using the OEM code page (936 on a
rem  Chinese Windows), NOT UTF-8. Chinese comments here would be
rem  decoded as garbage and executed as commands, which breaks the
rem  script - even with "chcp 65001" (the file is read before the
rem  code page switch takes effect).
rem
rem  Chinese documentation lives in the project root: see the
rem  "environment setup" markdown file.
rem ============================================================

rem Always run from the project root. core/Managers/joystick_manager.py
rem uses the relative path "config/joystick_mapping.json".
cd /d "%~dp0"

set "VENV_PY=%~dp0venv_usv\Scripts\python.exe"

if not exist "%VENV_PY%" (
    echo.
    echo [ERROR] Virtual environment not found:
    echo         %VENV_PY%
    echo.
    echo Create it first ^(one time only^):
    echo     py -3.10 -m venv venv_usv
    echo     venv_usv\Scripts\python.exe -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host pypi.tuna.tsinghua.edu.cn
    echo.
    echo See the setup guide in the project root ^(SETUP note, Chinese^).
    echo.
    pause
    exit /b 1
)

rem The project logs a lot of emoji. On a Chinese Windows console the
rem default codec is GBK, which cannot encode them, and the resulting
rem UnicodeEncodeError aborts startup. Force UTF-8.
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

rem Let QtWebEngine's GPU process come up cleanly.
rem
rem HISTORY / WHY THESE FLAGS:
rem   The original value was just "--disable-gpu-sandbox". On this machine
rem   that was NOT enough: the map page rendered as a completely blank area
rem   with no error, and the renderer probe reported
rem       renderProcessTerminated status=-1 exitCode=18
rem   (exitCode 18 = Chromium RESULT_CODE_KILLED_BAD_MESSAGE), i.e. the
rem   GPU/renderer child process died during channel setup.
rem   The real fix is Qt.AA_ShareOpenGLContexts in main.py; these flags are
rem   belt-and-braces so a machine with an awkward GPU driver still works.
rem   If you have a working GPU and want hardware acceleration back, try
rem   removing --disable-gpu first.
set "QTWEBENGINE_CHROMIUM_FLAGS=--disable-gpu-sandbox --disable-gpu --no-sandbox --disable-software-rasterizer"

echo [START] Interpreter: %VENV_PY%
"%VENV_PY%" "%~dp0main.py" %*

set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
    echo.
    echo [EXIT] Ground station exited with code %EXITCODE%
    echo        See the output above, or logs under data_logs\.
    echo.
    pause
)
endlocal
