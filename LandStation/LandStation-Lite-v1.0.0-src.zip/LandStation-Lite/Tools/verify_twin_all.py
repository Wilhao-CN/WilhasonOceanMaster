#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""孪生底图改造 —— 一键回归自检（T1~T11）。

依次运行全部验证脚本并汇总结果。改动代码后跑这个即可。

用法：
    python Tools/verify_twin_all.py
退出码 0 = 全部通过。
"""
import io
import os
import subprocess
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable

SUITES = [
    ("静态校验 map.html（T1/T2/T3）", ["Tools/verify_map_static.py"]),
    ("孪生 JS 行为（node + Leaflet 桩）", ["Tools/verify_twin_js.py"]),
    ("孪生日志分离（T9）", ["Tools/verify_t9_logging.py"]),
    ("关卡配置读取（T4）", ["Tools/verify_twin_config.py"]),
    ("范围校验 + 守卫 + 互锁（T7/T8/T11）", ["Tools/verify_twin_logic.py"]),
    ("路径跟踪对齐工具数字（T12）", ["Tools/verify_trace_tool.py"]),
]


def main():
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"

    summary = []
    for label, argv in SUITES:
        script = os.path.join(ROOT, argv[0])
        print()
        print("#" * 74)
        print(f"# {label}")
        print("#" * 74)
        if not os.path.isfile(script):
            print(f"  [跳过] 未找到 {argv[0]}")
            summary.append((label, "SKIP", None))
            continue

        r = subprocess.run([PY, script], cwd=ROOT, capture_output=True,
                           text=True, encoding="utf-8", errors="replace",
                           env=env, timeout=300)
        out = (r.stdout or "")
        # 只显示断言行与结论，压掉噪声
        for line in out.splitlines():
            s = line.strip()
            if (s.startswith(("OK ", "FAIL", "通过", "T9", "===", "#"))
                    or "通过 " in s or s.startswith("[")):
                print(line)
        if r.returncode not in (0,) and not out.strip():
            print("  [无输出] rc=%s" % r.returncode)
            err = [l for l in (r.stderr or "").splitlines()
                   if "OpenGL" not in l and "QThread" not in l]
            for l in err[-6:]:
                print("   ! " + l)

        # 判定：优先看退出码；若退出码被 Qt 退出期崩溃污染，
        # 则退回看输出里是否有 FAIL 行 / 是否出现了通过标志。
        has_fail = any(l.strip().startswith("FAIL") for l in out.splitlines())
        has_pass = any(("通过" in l and "失败" not in l) or "通过" in l
                       for l in out.splitlines())
        if r.returncode == 0:
            status = "PASS"
        elif not has_fail and has_pass:
            status = "PASS"          # 断言全过，只是退出码被 Qt 崩溃污染
        else:
            status = "FAIL"
        summary.append((label, status, r.returncode))

    print()
    print("=" * 74)
    print("总览")
    print("=" * 74)
    bad = 0
    for label, status, rc in summary:
        mark = {"PASS": "  OK  ", "FAIL": " FAIL ", "SKIP": " SKIP "}[status]
        print(f"{mark} {label}")
        if status == "FAIL":
            bad += 1
    print("=" * 74)
    print("全部通过 ✅" if not bad else f"有 {bad} 组失败 ❌")

    # 清理各子脚本的落盘缓存（它们只为绕过 Qt 退出期崩溃而存在）
    for name in ("t9_verify_result.txt", "twin_logic_result.txt"):
        p = os.path.join(ROOT, "Tools", name)
        try:
            if os.path.isfile(p):
                os.remove(p)
        except OSError:
            pass

    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
