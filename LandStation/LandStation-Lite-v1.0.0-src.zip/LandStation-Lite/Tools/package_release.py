#!/usr/bin/env python3
"""LandStation-Lite 开源发布打包脚本。

用法：
    venv_usv\\Scripts\\python.exe Tools\\package_release.py

做什么（四道关卡，任何一道不过 → 退出码 1，不产出包）：
    1. 排除清单 —— 按 .gitignore 的权威口径 + 发布裁剪清单排除「不进包」的内容：
       · 四大目录 _pruned_trash / recover / venv_usv / _baseline
       · docs/ 按白名单：只随包 `联调_数字孪生V1_M5口径与验收.md`（与 Unity 端
         联调要用），其余 docs 文件（联调回执、会话总结、archive 历史存档）
         一律不进包（用户裁决 2026-10-08）
       · 根目录内部交接类 md：改造交接文档 / 公众号_素材交接清单
       · 与启动无关且依赖 _baseline 的 bat：run_twin_diag / run_ui_baseline
       · 运行产物 data_logs*、缓存 __pycache__、*.orig、*.pyc 等
       （包内只保留 start_groundstation.bat + run_start_with_log.bat 两个启动入口，
         后者是 README 故障排查章节指定的日志启动方式）
    2. 隐私门禁 —— 设备指纹 GUID、真实航点坐标、本机绝对路径，
       任何一个还在包里就拒绝打包
    3. 必备文件门禁 —— LICENSE(GPL v3) / README / THIRD_PARTY_NOTICES /
       requirements / 三个配置文件 …… 缺一个就拒绝打包
    4. 产出 dist/LandStation-Lite-v{版本}-src.zip（顶层目录 LandStation-Lite/）
       —— zip 内的 README / 环境配置说明 / 联调口径文档是**开源版措辞**：
         由 OPEN_SOURCE_EDITS 对仓库文档定点替换生成（删内部交接、docs/archive、
         回执等指向不进包文件的引用），每条断言恰好命中一次，文档改版打包即失败；
         另有门禁 2-3 全局扫描包内 md 的悬空引用（REF_FORBIDDEN），命中即拒绝出包

设计说明：
    · `.gitignore` 只管 git，zip 打包必须自己排除 —— 本脚本就是那个"自己排除"。
    · `missions.json` / `config/joystick_mapping.json` 当前已是**脱敏演示版**，
      故意**随包发布**（首次运行就有演示任务、手柄可重新配对），但隐私门禁
      会钉死"真实数据不许回来"。
    · 除标准库外零依赖，venv 缺什么都能跑。
"""
from __future__ import annotations

import argparse
import io
import json
import os
import re
import sys
import zipfile

# ---------------------------------------------------------------------------
# 0. 路径与版本
# ---------------------------------------------------------------------------
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_ROOT_NAME = "LandStation-Lite"          # zip 内顶层目录名

sys.path.insert(0, ROOT)
try:
    from _version import __version__         # noqa: E402
except Exception:                            # noqa: BLE001
    __version__ = "0.0.0"

# ---------------------------------------------------------------------------
# 1. 排除清单（口径与 .gitignore 对齐）
# ---------------------------------------------------------------------------
# 1a. 按「相对路径前缀」排除（顶层大目录 + 已删除功能的残留目录）
EXCLUDE_REL_PREFIXES = (
    # 四大目录（合计约 2.1 GB，不排掉包就废了）
    "_pruned_trash/",       # 1,141 MB 「只移走不删除」暂存区（含隐私原件备份）
    "recover/",             #  488 MB 改造前完整快照
    "venv_usv/",            #  477 MB 虚拟环境
    "_baseline/",           #  0.3 MB 基线与验收工具
    # 打包输出自身
    "dist/",
    # docs/ 内部：历史存档整目录不进包；其余 docs 文件按白名单（见 DOCS_INCLUDE）
    "docs/archive/",
    # 运行产物（含真实 GPS 轨迹 CSV）
    "data_logs/",
    "data_logs_sim/",
    "gps_paths/",
    "pinn_data/",
    "pinn_mpc/",
    # 大件 / 研究产物
    "datasets/",
    "records/",
    "outputs/",
    "USV_mcu/",
    "Dock_mcu/",
    "ascamera/",
    "camera_launch/",
    "_wasrt_backup/",
    "temperature_field/",
    ".git/",
    ".vscode/",
    ".idea/",
    # 已删除功能的残留目录（防止误建后混进包）
    "core/MPPI/",
    "core/PINN_MPC/",
    "core/GNPM/",
    "core/observers/",
    "core/experiment/",
    "vision/algorithms/wasrt_seg/",
    "vision/algorithms/water_seg/",
    "vision/algorithms/kcf_tracker/",
    "vision/algorithms/obstacle_distance/",
)

# 1b. 按「目录名」排除（任意深度）
EXCLUDE_DIR_NAMES = {
    "__pycache__",
    ".pytest_cache",
    ".git",
}

# 1c. 按「文件名 / 后缀」排除
EXCLUDE_FILE_NAMES = {"Thumbs.db", "desktop.ini"}
# 发布裁剪：根目录里不进包的文件（用户裁决 2026-10-08）
EXCLUDE_FILES = {
    "改造交接文档_LandStation-Lite.md",   # 内部交接文档
    "公众号_素材交接清单.md",             # 内部素材交接清单
    "run_twin_diag.bat",                  # 依赖不进包的 _baseline\，且与启动无关
    "run_ui_baseline.bat",                # 同上（UI 基线，依赖 _baseline\）
}
EXCLUDE_SUFFIXES = (".pyc", ".pyo", ".orig", ".swp")

# docs/ 白名单（用户裁决 2026-10-08）：只保留与 Unity 端联调要用的那一份，
# 其余 docs 文件（联调回执、会话总结等开发过程文档）一律不进包。
DOCS_INCLUDE = {
    "docs/联调_数字孪生V1_M5口径与验收.md",
}

# 1d. *.pt 权重规则：默认不进包，白名单例外
#     （ultralytics 官方权重 yolov8n.pt 是 AGPL，绝不随包；
#       best.pt / boat_NOF.pt 是自训权重，随包发布 —— 见 THIRD_PARTY_NOTICES）
ALLOWED_PT = {
    "vision/algorithms/yolo_v8/best.pt",
    "vision/algorithms/yolo_v8/boat_NOF.pt",
}

# ---------------------------------------------------------------------------
# 2. 隐私门禁
# ---------------------------------------------------------------------------
# 2a. 全包扫描（命中任意一个 → 硬失败）
#     ⚠️ 字面量刻意拆开写（`"前半" + "后半"`），否则扫描会命中本脚本自己。
HARD_FORBIDDEN = {
    "0300" + "e008": "手柄设备指纹 GUID（joystick_mapping 原件）",
    "BTP-" + "KP20": "手柄设备名（joystick_mapping 原件）",
}

# 2b. 真实航点特征（只允许出现在 docs 历史存档的叙述里，数据文件命中 → 硬失败）
REAL_COORD_MARKERS = ("22.367", "23.0141")

# 2c. 需要逐字段断言的文件
PRIVACY_FILES = ("missions.json", "config/joystick_mapping.json", "config/simulator.json")

# 2d. 告警级（不拦截，但要在报告里点名 —— 由项目方决定是否接受）
WARN_PATTERNS = {
    "D:\\Sunny": "本机开发路径（含 Windows 用户名）",
    "C:\\Users\\": "Windows 用户目录路径",
}

# 文本类文件才参与内容扫描（二进制跳过）
TEXT_SUFFIXES = {
    ".py", ".md", ".json", ".txt", ".bat", ".html", ".js", ".css", ".csv",
    ".cfg", ".ini", ".yml", ".yaml", ".sh", ".ps1", ".gitignore", "",
}

# ---------------------------------------------------------------------------
# 3. 必备文件门禁
# ---------------------------------------------------------------------------
REQUIRED_FILES = (
    "LICENSE",
    "README.md",
    "THIRD_PARTY_NOTICES.md",
    "requirements.txt",
    "requirements-optional.txt",
    "main.py",
    "_version.py",
    "start_groundstation.bat",
    "core/protocol.py",
    "ui/main_window.py",
    "missions.json",
    "config/simulator.json",
    "config/joystick_mapping.json",
    "docs/联调_数字孪生V1_M5口径与验收.md",   # Unity 联调必读（随包唯一 docs 文件）
)

# ---------------------------------------------------------------------------
# 3b. 开源版定点替换（仅在 zip 内生效；仓库版保持完整文档）
# ---------------------------------------------------------------------------
# {相对路径: ((原文, 开源版措辞), ...)}
# 每条替换断言「恰好命中一次」—— 仓库文档改版导致行文变化时打包直接失败，
# 强制回来同步，避免包里出现悄悄漂移的文档。
# 涉及三份文件：
#   · README.md            —— 删 docs/archive 结构行、内部交接文档/存档表行
#   · 环境配置说明.md        —— 删改造交接引用、两个不进包的 bat 行、回执引用
#   · docs/联调_…口径与验收.md —— 回执链接/引用、docs/archive 提法改为开源版措辞
OPEN_SOURCE_EDITS = {
    "README.md": (
        ("└── docs/archive/                与 Unity 的历史沟通记录（存档）",
         "└── docs/                      联调口径与验收（随包唯一文档：联调_数字孪生V1_M5口径与验收.md）"),
        ("| `改造交接文档_LandStation-Lite.md` | 完整的改造记录：做过什么、为什么、踩过什么坑 |\n",
         ""),
        ("| `docs/archive/` | 与 Unity 侧的历史沟通记录（存档，仅供参考） |",
         "| `docs/联调_数字孪生V1_M5口径与验收.md` | 与 Unity 数字孪生的联调口径与 12 项验收清单 |"),
    ),
    "环境配置说明.md": (
        ("> 📘 想了解改造历史（做过什么、踩过什么坑），请看 `改造交接文档_LandStation-Lite.md`。\n",
         ""),
        ("| `run_ui_baseline.bat` | 跑 UI 基线断言（不开主界面） |\n",
         ""),
        ("| `run_twin_diag.bat` | 孪生底图专项诊断 |\n",
         ""),
        ("（2026-10-08 已修复，详见 `docs/联调_数字孪生V1_M5回执.md` 附 C）。",
         "（2026-10-08 已修复）。"),
    ),
    "docs/联调_数字孪生V1_M5口径与验收.md": (
        ("> **回执**：✅ **已完成 —— 12/12 全部通过（2026-10-08）**，"
         "见 [`联调_数字孪生V1_M5回执.md`](联调_数字孪生V1_M5回执.md)",
         "> **验收结果**：✅ **已完成 —— 12/12 全部通过（2026-10-08）**（明细见 §7 清单）"),
        ("；`docs/archive/` 为历史存档**不改**，以本文为准",
         "；历史存档不随开源包，以本文为准"),
        ("（2026-10-08，与 V1 同步无关；详见回执附 C）",
         "（2026-10-08，与 V1 同步无关）"),
        ("## 7. 联调验收清单（12 项，回执填 [`联调_数字孪生V1_M5回执.md`](联调_数字孪生V1_M5回执.md)）",
         "## 7. 联调验收清单（12 项）"),
        ("明细与异常记录见回执。", "明细与异常记录见下表。"),
    ),
}

# 包内 .md 不得出现的「指向不进包文件」的引用（门禁 2-3 全局扫描）
REF_FORBIDDEN = (
    "改造交接文档",
    "公众号_素材交接清单",
    "联调_数字孪生V1_M5回执",
    "联调_数字孪生V1_M5_会话总结",
    "docs/archive",
    "run_ui_baseline",
    "run_twin_diag",
)


def apply_opensource_edits(rel: str, text: str) -> str:
    """按 OPEN_SOURCE_EDITS[rel] 做定点替换；每条必须恰好命中一次。"""
    for old, new in OPEN_SOURCE_EDITS.get(rel, ()):
        n = text.count(old)
        if n != 1:
            raise RuntimeError(
                "开源版定点替换同步失败 [%s]：命中 %d 次（期望 1 次）：%r"
                % (rel, n, old[:60]))
        text = text.replace(old, new)
    return text


def iter_package_files():
    """遍历工程根目录，产出 (relpath_posix, abspath)，跳过所有排除项。"""
    for dirpath, dirnames, filenames in os.walk(ROOT):
        rel_dir = os.path.relpath(dirpath, ROOT).replace("\\", "/")
        if rel_dir == ".":
            rel_dir = ""

        # 1a. 路径前缀排除
        dirnames[:] = [
            d for d in dirnames
            if not _excluded_dir(os.path.join(rel_dir, d).replace("\\", "/"))
        ]
        for name in sorted(filenames):
            rel = (rel_dir + "/" + name).lstrip("/") if rel_dir else name
            # docs/ 白名单：除 DOCS_INCLUDE 外一律不进包
            if rel.startswith("docs/") and rel not in DOCS_INCLUDE:
                continue

            if name in EXCLUDE_FILE_NAMES or name in EXCLUDE_FILES:
                continue
            if name.endswith(EXCLUDE_SUFFIXES):
                continue
            # *.pt 白名单
            if name.endswith(".pt") and rel not in ALLOWED_PT:
                continue
            yield rel, os.path.join(dirpath, name)


def _excluded_dir(rel):
    if rel in EXCLUDE_DIR_NAMES or os.path.basename(rel) in EXCLUDE_DIR_NAMES:
        return True
    return any(rel == p.rstrip("/") or rel.startswith(p) for p in EXCLUDE_REL_PREFIXES)


def _is_text(rel):
    return os.path.splitext(rel)[1].lower() in TEXT_SUFFIXES


def main() -> int:
    ap = argparse.ArgumentParser(description="LandStation-Lite 开源发布打包")
    ap.add_argument("--out", default=os.path.join(ROOT, "dist"),
                    help="输出目录（默认 <工程根>/dist）")
    args = ap.parse_args()

    fails = []
    warns = []
    scan_hits = {k: [] for k in HARD_FORBIDDEN}
    warn_hits = {k: [] for k in WARN_PATTERNS}
    coord_hits = []

    # ------------------------------------------------------------------
    # 收集文件
    # ------------------------------------------------------------------
    files = sorted(iter_package_files())
    rels = [r for r, _ in files]

    print("=" * 74)
    print("LandStation-Lite 打包 · v%s" % __version__)
    print("=" * 74)
    print("工程根目录: %s" % ROOT)
    print("候选文件数: %d" % len(files))

    # ------------------------------------------------------------------
    # 关卡 1 · 必备文件
    # ------------------------------------------------------------------
    print("\n[1/4] 必备文件门禁")
    for req in REQUIRED_FILES:
        ok = req in rels
        print("  %s %s" % ("OK  " if ok else "FAIL", req))
        if not ok:
            fails.append("缺少必备文件: %s" % req)

    # LICENSE 必须是 GPL v3 正文
    lic_path = os.path.join(ROOT, "LICENSE")
    if os.path.exists(lic_path):
        with io.open(lic_path, encoding="utf-8") as fh:
            head = fh.read(400)
        gpl_ok = ("GNU GENERAL PUBLIC LICENSE" in head and
                  "Version 3, 29 June 2007" in head)
        print("  %s LICENSE = GPL v3 官方全文" % ("OK  " if gpl_ok else "FAIL"))
        if not gpl_ok:
            fails.append("LICENSE 不是 GPL v3 官方全文")

    # 开源版定点替换：final_text = 包内实际写出的文本（后续门禁与写盘都以它为准）
    final_text = {}
    for rel, path in files:
        if not _is_text(rel):
            continue
        try:
            with io.open(path, encoding="utf-8", errors="ignore") as fh:
                final_text[rel] = apply_opensource_edits(rel, fh.read())
        except OSError as exc:
            fails.append("读取失败 %s: %s" % (rel, exc))
        except RuntimeError as exc:          # 定点替换没命中 = 文档改版了
            fails.append(str(exc))
    print("  --- 开源版定点替换（仓库版不变，仅 zip 内生效）---")
    for rel in sorted(OPEN_SOURCE_EDITS):
        ok = rel in final_text
        print("  %s %s（%d 条替换）"
              % ("OK  " if ok else "FAIL", rel, len(OPEN_SOURCE_EDITS[rel])))

    # ------------------------------------------------------------------
    # 关卡 2 · 隐私门禁
    # ------------------------------------------------------------------
    print("\n[2/4] 隐私门禁")

    # 2-1 三个配置/数据文件的逐字段断言
    for rel in PRIVACY_FILES:
        path = os.path.join(ROOT, rel)
        if not os.path.exists(path):
            fails.append("隐私文件缺失（应存在且已脱敏）: %s" % rel)
            print("  FAIL %s —— 文件不存在" % rel)
            continue
        with io.open(path, encoding="utf-8") as fh:
            raw = fh.read()

        # 数据文件里绝不许出现盘符绝对路径
        if re.search(r"[A-Za-z]:[\\/]", raw):
            fails.append("%s 含本机绝对路径" % rel)

        if rel == "missions.json":
            bad = [m for m in REAL_COORD_MARKERS if m in raw]
            data = json.loads(raw)
            n_pts = sum(len(t.get("coords") or [])
                        for t in (data.get("tasks") or {}).values())
            if bad:
                fails.append("missions.json 仍含真实航点特征: %s" % bad)
            if n_pts <= 0:
                fails.append("missions.json 无任何航点（不应为空）")
            print("  %s missions.json —— %d 任务 / %d 演示航点%s"
                  % ("OK  " if not bad and n_pts > 0 else "FAIL",
                     len(data.get("tasks") or {}), n_pts,
                     ("，真实坐标特征已清零" if not bad else "，残留 %s" % bad)))

        elif rel == "config/joystick_mapping.json":
            joy = json.loads(raw)
            guids = [v.get("guid") for v in joy.values() if isinstance(v, dict)]
            dirty = [g for g in guids if g]
            if dirty:
                fails.append("joystick_mapping.json 仍含 GUID: %s" % dirty)
            print("  %s joystick_mapping.json —— GUID %s"
                  % ("OK  " if not dirty else "FAIL",
                     "全部清空" if not dirty else dirty))

        elif rel == "config/simulator.json":
            sim = json.loads(raw)
            d = sim.get("simulator_dir", None)
            if d:
                fails.append("simulator.json 的 simulator_dir 非空: %r" % d)
            print("  %s simulator.json —— simulator_dir=%r" % ("OK  " if not d else "FAIL", d))

    # 2-2 全包扫描（仅文本文件；扫的是开源版替换后的最终内容）
    for rel, path in files:
        content = final_text.get(rel)
        if content is None:
            continue
        for pat in HARD_FORBIDDEN:
            if pat in content:
                scan_hits[pat].append(rel)
        for pat in WARN_PATTERNS:
            if pat in content:
                warn_hits[pat].append(rel)
        if os.path.basename(rel) == "missions.json" and any(
                m in content for m in REAL_COORD_MARKERS):
            coord_hits.append(rel)

    for pat, why in HARD_FORBIDDEN.items():
        hit = scan_hits[pat]
        print("  %s 全包扫描 %r（%s）—— %s"
              % ("OK  " if not hit else "FAIL", pat, why,
                 "0 处" if not hit else "命中: %s" % hit))
        if hit:
            fails.append("隐私特征 %r 仍在包里: %s" % (pat, hit))

    if coord_hits:
        fails.append("真实航点特征出现在: %s" % coord_hits)

    for pat, why in WARN_PATTERNS.items():
        hit = warn_hits[pat]
        if hit:
            warns.append("%r（%s）出现在 %d 个文件: %s"
                         % (pat, why, len(hit), hit))
            print("  WARN %r —— %d 个文件（告警，不拦截）: %s"
                  % (pat, len(hit), hit))
        else:
            print("  OK   %r —— 0 处" % pat)

    # 2-3 包内 md 不得引用「不进包」的文件（开源版措辞门禁）
    ref_hits = []
    for rel in sorted(final_text):
        if not rel.endswith(".md"):
            continue
        for pat in REF_FORBIDDEN:
            if pat in final_text[rel]:
                ref_hits.append("%s → %r" % (rel, pat))
    print("  %s 包内 md 悬空引用（指向不进包的文件）—— %s"
          % ("OK  " if not ref_hits else "FAIL",
             "0 处" if not ref_hits else "%d 处" % len(ref_hits)))
    for h in ref_hits:
        print("       · %s" % h)
    if ref_hits:
        fails.append("包内 md 仍引用不进包的文件: %s" % ref_hits)

    # ------------------------------------------------------------------
    # 关卡 3 · 汇总判定
    # ------------------------------------------------------------------
    print("\n[3/4] 判定")
    if fails:
        print("  ❌ 打包中止，共 %d 项不通过：" % len(fails))
        for f in fails:
            print("     · %s" % f)
        return 1
    print("  ✅ 必备文件与隐私门禁全部通过")
    for w in warns:
        print("     ⚠ %s" % w)

    # ------------------------------------------------------------------
    # 关卡 4 · 产出 zip
    # ------------------------------------------------------------------
    print("\n[4/4] 生成 zip")
    os.makedirs(args.out, exist_ok=True)
    zip_path = os.path.join(
        args.out, "LandStation-Lite-v%s-src.zip" % __version__)
    if os.path.exists(zip_path):
        os.remove(zip_path)

    total_bytes = 0
    per_top = {}
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED,
                         compresslevel=9) as zf:
        for rel, path in files:
            arc = "%s/%s" % (PKG_ROOT_NAME, rel)
            try:
                if rel in OPEN_SOURCE_EDITS:
                    # 开源版措辞（仅 zip 内生效；仓库版保持完整文档）
                    data = final_text[rel].encode("utf-8")
                    zf.writestr(arc, data)
                    size = len(data)
                else:
                    zf.write(path, arc)
                    size = os.path.getsize(path)
            except (OSError, KeyError, RuntimeError) as exc:
                fails.append("写入失败 %s: %s" % (rel, exc))
                break
            total_bytes += size
            top = rel.split("/")[0] if "/" in rel else "(根文件)"
            per_top[top] = per_top.get(top, 0) + size
    if fails:
        print("  ❌ %s" % fails[-1])
        return 1

    # 复查：zip 里不得出现任何被排除（或未白名单）的成员
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()

    def _leaked(rel):
        base = os.path.basename(rel)
        if _excluded_dir(rel) or base in EXCLUDE_FILE_NAMES or base in EXCLUDE_FILES:
            return True
        if rel.endswith(EXCLUDE_SUFFIXES) or "__pycache__" in rel:
            return True
        if rel.startswith("docs/") and rel not in DOCS_INCLUDE:
            return True
        if base.endswith(".pt") and rel not in ALLOWED_PT:
            return True
        return False

    leaked = [n for n in names if _leaked(n[len(PKG_ROOT_NAME) + 1:])]
    if leaked:
        print("  ❌ zip 内发现不该出现的成员: %s" % leaked[:10])
        return 1

    print("  %s" % zip_path)
    print("  文件数 %d ｜ 原始 %.1f MB ｜ 压缩后 %.1f MB"
          % (len(names), total_bytes / 1048576.0,
             os.path.getsize(zip_path) / 1048576.0))
    print("\n  按顶层目录（原始体积）：")
    for top, size in sorted(per_top.items(), key=lambda kv: -kv[1]):
        print("    %-28s %8.2f MB" % (top, size / 1048576.0))

    print("\n" + "=" * 74)
    print("✅ 打包完成：%s" % os.path.basename(zip_path))
    print("=" * 74)
    return 0


if __name__ == "__main__":
    sys.exit(main())
