#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1/T2/T3 的端到端验证：在无头 QtWebEngine 中真实加载 map.html。

验证点：
  1. Leaflet 从【本地】加载成功（不是 CDN）—— 通过检查 L 是否定义 +
     资源条目里 leaflet.js 的 URL 是否为本地 file:// 路径。
  2. googleTileLayer 是具名变量且可 remove()（T2）。
  3. showTwinMap / showRealMap / isTwinActive 存在且可调用（T3）。
  4. 切换后确实移除了 Google 图层并加上了 imageOverlay。
  5. 切回后 Google 图层恢复、视口还原。
  6. 孪生底图 PNG 能被真实加载（离线图片加载不被拦）。

用法： python Tools/verify_map_html.py
"""
import io
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

from PyQt5.QtCore import Qt, QCoreApplication, QUrl, QTimer  # noqa: E402

QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
import PyQt5.QtWebEngineWidgets  # noqa: E402,F401
from PyQt5.QtWebEngineCore import QWebEngineUrlRequestInterceptor  # noqa: E402
from PyQt5.QtWidgets import QApplication  # noqa: E402
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAP_HTML = os.path.join(ROOT, "ui", "map", "map.html")

results = []
requested = []


class Interceptor(QWebEngineUrlRequestInterceptor):
    """记录所有网络请求，用来证明 leaflet.js 走的是本地文件。"""

    def interceptRequest(self, info):
        requested.append(info.requestUrl().toString())


def finish(app, code=0):
    print()
    print("=" * 70)
    bad = [r for r in results if not r[0]]
    for ok, label, detail in results:
        print(("  OK   " if ok else "  FAIL ") + label + ("   " + detail if detail else ""))
    print("=" * 70)
    print(f"通过 {len(results) - len(bad)}/{len(results)}")
    app.exit(code if not bad else 1)


def main():
    app = QApplication(sys.argv)

    view = QWebEngineView()
    interceptor = Interceptor()
    view.page().profile().setRequestInterceptor(interceptor)

    def check(ok, label, detail=""):
        results.append((bool(ok), label, detail))

    def run_js(script, then):
        view.page().runJavaScript(script, then)

    def on_load(ok):
        if not ok:
            check(False, "map.html 加载", "loadFinished=False")
            return finish(app, 1)

        check(True, "map.html 加载成功")

        # ---- 1. 本地 Leaflet ----
        local_js = [u for u in requested if u.endswith("leaflet/leaflet.js")]
        cdn_js = [u for u in requested if "unpkg.com" in u and u.endswith("leaflet.js")]
        check(bool(local_js), "Leaflet 从本地加载", local_js[0] if local_js else "未发现本地请求")
        check(not cdn_js, "未回退到 CDN", ("CDN: " + cdn_js[0]) if cdn_js else "无 CDN 请求")

        # 2/3. JS 侧符号
        run_js(
            "JSON.stringify({"
            "  hasL: (typeof L !== 'undefined'),"
            "  ver: (typeof L !== 'undefined' && L.version) || null,"
            "  namedTile: (typeof googleTileLayer !== 'undefined'),"
            "  hasShowTwin: (typeof showTwinMap === 'function'),"
            "  hasShowReal: (typeof showRealMap === 'function'),"
            "  hasIsActive: (typeof isTwinActive === 'function'),"
            "  tileOnMap: (typeof googleTileLayer !== 'undefined' && map.hasLayer(googleTileLayer)),"
            "  twinActive: (typeof isTwinActive === 'function' && isTwinActive())"
            "})",
            lambda r: step2(r),
        )

    def step2(raw):
        import json as _json
        try:
            d = _json.loads(raw)
        except Exception as exc:  # noqa: BLE001
            check(False, "JS 自检返回", repr(raw)[:120] + f" ({exc})")
            return finish(app, 1)

        check(d["hasL"], "JS: Leaflet 已定义 (L)")
        check(d["ver"] == "1.9.4", f"JS: Leaflet 版本 = {d['ver']}", "期望 1.9.4")
        check(d["namedTile"], "T2: googleTileLayer 为具名变量")
        check(d["hasShowTwin"], "T3: showTwinMap 存在")
        check(d["hasShowReal"], "T3: showRealMap 存在")
        check(d["hasIsActive"], "T3: isTwinActive 存在")
        check(d["tileOnMap"], "初始状态: Google 图层在地图上")
        check(not d["twinActive"], "初始状态: 孪生未激活")

        # ---- 4. 切到孪生（用真实 L1 配置）----
        import json as _json2
        sys.path.insert(0, os.path.join(ROOT, "ui", "map"))
        from twin_scene_config import TwinSceneConfig
        cfg = TwinSceneConfig()
        scene = "Level1_Pool"
        bounds = cfg.bounds_for_js(scene)
        js = ("showTwinMap(%s, %s, %s, %d);" % (
            _json2.dumps(scene), _json2.dumps(cfg.image_for(scene)),
            _json2.dumps(bounds), cfg.image_px(scene)))

        run_js(js, lambda _r: step4())

    def step4(_r):
        run_js(
            "JSON.stringify({"
            "  twinActive: isTwinActive(),"
            "  tileOnMap: map.hasLayer(googleTileLayer),"
            "  hasOverlay: !!twinOverlay,"
            "  overlayInMap: (!!twinOverlay && map.hasLayer(twinOverlay)),"
            "  overlayUrl: (twinOverlay && twinOverlay._url) || null,"
            "  maxBounds: !!map.options.maxBounds,"
            "  zoom: map.getZoom()"
            "})",
            lambda r: step4b(r),
        )

    def step4b(raw):
        import json as _json
        d = _json.loads(raw)
        check(d["twinActive"], "切换后: isTwinActive() == True")
        check(not d["tileOnMap"], "切换后: Google 图层已移除 (T2 生效)")
        check(d["hasOverlay"] and d["overlayInMap"], "切换后: imageOverlay 已创建并加入地图")
        check(d["overlayUrl"] and "twin_maps/" in d["overlayUrl"],
              "切换后: overlay 指向 twin_maps/", str(d["overlayUrl"]))
        check(d["maxBounds"], "切换后: maxBounds 已设置（视觉约束）")
        check(13 <= d["zoom"] <= 21, f"切换后: 缩放级别已按分辨率自适应 = {d['zoom']}")

        # 图片是否真的被加载（离线可读）
        png = os.path.join(ROOT, "ui", "map", "twin_maps", "Level1_Pool.png")
        png_urls = [u for u in requested if "Level1_Pool.png" in u]
        check(os.path.isfile(png), "L1 底图文件存在")
        check(bool(png_urls), "切换后: 浏览器实际请求了 Level1_Pool.png",
              png_urls[0] if png_urls else "未观察到请求")

        # ---- 5. 切回真实地图 ----
        run_js("showRealMap();", lambda _x: step5())

    def step5(_x):
        run_js(
            "JSON.stringify({"
            "  twinActive: isTwinActive(),"
            "  tileOnMap: map.hasLayer(googleTileLayer),"
            "  overlayGone: !twinOverlay,"
            "  maxBoundsNull: (map.options.maxBounds === null || map.options.maxBounds === undefined)"
            "})",
            lambda r: step5b(r),
        )

    def step5b(raw):
        import json as _json
        d = _json.loads(raw)
        check(not d["twinActive"], "切回后: isTwinActive() == False")
        check(d["tileOnMap"], "切回后: Google 图层已恢复")
        check(d["overlayGone"], "切回后: 孪生叠加层已移除")
        check(d["maxBoundsNull"], "切回后: maxBounds 已清除")
        finish(app, 0)

    view.page().loadFinished.connect(on_load)
    view.load(QUrl.fromLocalFile(MAP_HTML))

    QTimer.singleShot(30000, lambda: (check(False, "超时", "30s 未完成"), finish(app, 1)))
    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())
