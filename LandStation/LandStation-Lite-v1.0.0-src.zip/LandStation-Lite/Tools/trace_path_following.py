#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
路径跟踪「逐帧参考轨迹」导出器
================================

Unity 侧在复刻我们的路径跟踪时撞到量纲/符号问题，需要一份**逐帧对照**
（他们的问题清单 v6 · E）。本工具用**本工程真实的算法代码**跑一遍，
导出每一帧的「输入 → 输出」，供孪生侧逐帧对齐。

**对齐价值在「输入 → 输出」这一段，不在轨迹本身。**
轨迹由本工具内置的**代用单轮模型**生成（不是你们的孪生物理）；
你们可以把导出的 `lat_mid/lon_mid/heading/v_now` 当作**输入**喂进你们的实现，
逐帧比对我方算出的 `target_heading/target_speed/r_main/r_steer/pwm1..4`。

用法
----
    # 默认：小船，L1，4 点含两个直角
    python Tools/trace_path_following.py

    # 换船坞（注意船坞没有 ×0.75 转向削弱、限幅也不同）
    python Tools/trace_path_following.py --ship dock --out trace_dock.csv

    # 打印 PID 量纲对照表（只回答 A1，不跑轨迹）
    python Tools/trace_path_following.py --pid-tables

    # 用你们自己的轨迹做输入（CSV 列：lat,lon,heading,v）
    python Tools/trace_path_following.py --replay their_track.csv --out trace_aligned.csv

真实调用的模块
--------------
* `core.Managers.navigator_manager.MissionNavigator` —— 真实领航器（P2P/LOS、到点即切、递归）
* `core.PID_controller.pid_controller.HeadingPIDController / StandardPIDController` —— 真实 PID
* `core.protocol.USVProtocol._apply_compensation` —— 真实「ratio→力→PWM→每通道窗」

**混控与限幅**因住在 `boat_brain.py`（依赖 Qt）里，本工具按其源码**逐行复刻**，
并在下方标注出处；`_get_thruster_ratio_limits` 是逐字符照搬。
"""

import argparse
import csv
import io
import math
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "ui", "map"))

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

from core.Managers.navigator_manager import MissionNavigator          # noqa: E402
from core.PID_controller.pid_controller import (                      # noqa: E402
    HeadingPIDController, StandardPIDController)
from core.protocol import USVProtocol                                 # noqa: E402
from twin_scene_config import TwinSceneConfig                         # noqa: E402

# ---------------------------------------------------------------------------
# 与 boat_brain.py / dock_brain.py 完全一致的常量（出处已标）
# ---------------------------------------------------------------------------
ARRIVAL_THRESHOLD = 2.0        # boat_brain.py:101 / dock_brain.py:106
DEFAULT_SPEED = 0.3            # 同上
MAX_PHYSICAL_SPEED = 2.0       # boat_brain.py:105 / dock_brain.py:110
SPEED_RATE_LIMIT = 0.5         # boat_brain.py:106 / dock_brain.py:111  (m/s²)
HEADING_KP, HEADING_KI, HEADING_KD, HEADING_DEADBAND = 3.0, 0.1, 1.5, 5.0   # :111 / :116
SPEED_KP, SPEED_KI, SPEED_KD = 150.0, 10.0, 0.0                             # :114 / :119
BOAT_STEER_ATTENUATION = 0.75  # boat_brain.py:351 —— ★ **仅小船**，船坞没有
DOCK_STEER_ATTENUATION = 1.0   # dock_brain.py:434-440 无削弱

SHIP_IDS = {"boat": 0x02, "dock": 0x01}

# solver 的积分步长 = 我们假设的控制周期（可改）
DT = 0.2


# ---------------------------------------------------------------------------
# 逐字符照搬 boat_brain.py:140-161 / dock_brain.py:190-211
# ---------------------------------------------------------------------------

def get_thruster_ratio_limits(ship_id, thruster_indices):
    """从 USV_CONFIGS 反算 ratio 有效限幅；返回 (min_ratio, max_ratio)。"""
    default_cfg = {"min": 1300, "max": 1800, "pos": 0, "neg": 0,
                   "slope_pos": 400, "slope_neg": 400}
    ship_configs = USVProtocol.USV_CONFIGS.get(ship_id, {})
    min_ratios, max_ratios = [], []
    for idx in thruster_indices:
        cfg = ship_configs.get(idx, default_cfg)
        max_r = ((cfg["max"] - 1500 - cfg["pos"]) / cfg["slope_pos"]
                 if cfg["slope_pos"] > 0 else 1.0)
        min_r = ((cfg["min"] - 1500 + cfg["neg"]) / cfg["slope_neg"]
                 if cfg["slope_neg"] > 0 else -1.0)
        min_ratios.append(min_r)
        max_ratios.append(max_r)
    return (max(min_ratios), min(max_ratios))


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# ---------------------------------------------------------------------------
# 经纬度 ↔ 以 origin 为基准的米（与 Unity 等距圆柱一致）
# ---------------------------------------------------------------------------

class Geo:
    def __init__(self, lat0, lon0):
        self.lat0, self.lon0 = lat0, lon0
        self.cos = math.cos(math.radians(lat0))

    def to_latlon(self, dx, dz):                 # 米 → 经纬度
        return (self.lat0 + dz / 111320.0,
                self.lon0 + dx / (111320.0 * self.cos))

    def to_meters(self, lat, lon):               # 经纬度 → 米
        return ((lon - self.lon0) * 111320.0 * self.cos,
                (lat - self.lat0) * 111320.0)


# ---------------------------------------------------------------------------
# 速度指令保护（照搬 boat_brain.py:207-228，用仿真时钟代替 wall clock）
# ---------------------------------------------------------------------------

class SpeedLimiter:
    def __init__(self):
        self.smooth = 0.0

    def apply(self, requested, dt):
        clamped = max(0.0, min(MAX_PHYSICAL_SPEED, requested))
        if 0 < dt < 1.0:
            max_delta = SPEED_RATE_LIMIT * dt
            delta = clamped - self.smooth
            delta = max(-max_delta, min(max_delta, delta))
            self.smooth += delta
        else:
            self.smooth = clamped
        return self.smooth


# ---------------------------------------------------------------------------
# A1：PID 量纲对照表（用真实 PID 类跑）
# ---------------------------------------------------------------------------

def print_pid_tables():
    print("=" * 78)
    print("A1 · PID 量纲对照表（**用工程真实 PID 类计算**）")
    print("=" * 78)
    print()
    print("【关键】两个 PID 的输出都做了 `raw / 100` 再 clamp(±1)：")
    print("        HeadingPIDController.compute   pid_controller.py:54")
    print("        StandardPIDController.compute  pid_controller.py:119")
    print()

    hp = HeadingPIDController(kp=HEADING_KP, ki=HEADING_KI, kd=HEADING_KD,
                              deadband=HEADING_DEADBAND)

    print("-" * 78)
    print(f"艏向 PID：kp={HEADING_KP} ki={HEADING_KI} kd={HEADING_KD} "
          f"deadband={HEADING_DEADBAND}°   （单位：度）")
    print("-" * 78)
    print(f"{'误差(°)':>9} {'P项=kp·e/100':>14} {'÷100后':>10} "
          f"{'PID输出':>10} {'小船 ×0.75':>11} {'小船clamp±0.25':>15}")
    for err in (1, 2, 5, 5.1, 8, 11.1, 15, 20, 30, 33.4, 45, 90, 180):
        raw = HEADING_KP * err                      # 只看 P 项（I/D 需历史）
        pid_out = clamp(raw / 100.0, -1.0, 1.0)
        boat = pid_out * BOAT_STEER_ATTENUATION
        lo, hi = get_thruster_ratio_limits(SHIP_IDS["boat"], [2, 3])
        print(f"{err:>9.1f} {raw:>14.2f} {raw/100.0:>10.3f} "
              f"{pid_out:>10.3f} {boat:>11.3f} {clamp(boat, lo, hi):>15.3f}")

    boat_slo, boat_shi = get_thruster_ratio_limits(SHIP_IDS["boat"], [2, 3])
    dock_slo, dock_shi = get_thruster_ratio_limits(SHIP_IDS["dock"], [2, 3])
    g_boat = HEADING_KP / 100.0 * BOAT_STEER_ATTENUATION      # ratio / 度
    g_dock = HEADING_KP / 100.0 * DOCK_STEER_ATTENUATION
    print()
    print(f"  增益（P 项）：小船 {g_boat:.4f} ratio/度、船坞 {g_dock:.4f} ratio/度")
    print(f"  ⇒ 小船转向：误差 **±{boat_shi/g_boat:.1f}°** 即饱和"
          f"（转向限幅 {boat_slo:+.2f}..{boat_shi:+.2f}）")
    print(f"  ⇒ 船坞转向：误差 **±{dock_shi/g_dock:.1f}°** 即饱和"
          f"（转向限幅 {dock_slo:+.2f}..{dock_shi:+.2f}，且**无 ×0.75**）")
    print("  ⚠️ 也就是说：**只要航向误差超过十几度，转向就是满舵（bang-bang）**，")
    print("     PID 的线性区只有 ±11°（小船）/ ±17°（船坞）。")

    sp = StandardPIDController(kp=SPEED_KP, ki=SPEED_KI, kd=SPEED_KD)
    print()
    print("-" * 78)
    print(f"速度 PID：kp={SPEED_KP} ki={SPEED_KI} kd={SPEED_KD}   （单位：m/s）")
    print("-" * 78)
    boat_mlo, boat_mhi = get_thruster_ratio_limits(SHIP_IDS["boat"], [1, 4])
    dock_mlo, dock_mhi = get_thruster_ratio_limits(SHIP_IDS["dock"], [1, 4])
    print(f"{'误差(m/s)':>11} {'P项':>12} {'÷100后':>10} {'PID输出':>10} "
          f"{'小船主推clamp':>14} {'船坞主推clamp':>14}")
    for err in (0.05, 0.1, 0.2, 0.3, 0.5, 0.667, 1.0, 2.0):
        raw = SPEED_KP * err
        pid_out = clamp(raw / 100.0, -1.0, 1.0)
        print(f"{err:>11.3f} {raw:>12.2f} {raw/100.0:>10.3f} {pid_out:>10.3f} "
              f"{clamp(pid_out, boat_mlo, boat_mhi):>14.3f} "
              f"{clamp(pid_out, dock_mlo, dock_mhi):>14.3f}")
    g_sp = SPEED_KP / 100.0                                   # ratio / (m/s)
    print()
    print(f"  增益（P 项）= {g_sp:.1f} ratio/(m/s)")
    print(f"  ⇒ 小船主推限幅 {boat_mlo:+.2f}..{boat_mhi:+.2f}"
          f" → 加速饱和于 **+{boat_mhi/g_sp:.3f} m/s**、"
          f"减速饱和于 **{boat_mlo/g_sp:.3f} m/s**（**不对称**！）")
    print(f"  ⇒ 船坞主推限幅 {dock_mlo:+.2f}..{dock_mhi:+.2f}"
          f" → 饱和于 **±{dock_mhi/g_sp:.3f} m/s**（对称）")
    print()

    # ---------------- 推力上限对照 ----------------
    # ratio → 单推进器力 是**线性映射**（protocol.py:171-174）：
    #     ratio > 0 → force = ratio × _MAX_FORCE_POS
    #     ratio < 0 → force = ratio × _MAX_FORCE_NEG
    # 主推挂在 ch1 + ch4 两路 ⇒ **纵向总推力 = 2 × 单器力**
    f_pos = USVProtocol._MAX_FORCE_POS
    f_neg = USVProtocol._MAX_FORCE_NEG
    print("-" * 78)
    print(f"推力上限：ratio→力为线性映射，主推挂 ch1+ch4 两路 ⇒ 总推力 = 2×单器力")
    print(f"  _MAX_FORCE_POS = {f_pos} N (ratio=+1.0)   "
          f"_MAX_FORCE_NEG = {f_neg} N (ratio=-1.0)")
    print("-" * 78)
    print(f"{'船型 / 路径':<24}{'主推ratio区间':<20}{'单器力(N)':<20}{'纵向总推力(N)':<18}")
    rows_f = [
        ("小船 boat（PID 巡线, ×0.75 只影响转向）", boat_mlo, boat_mhi),
        ("船坞 dock（PID 巡线）", dock_mlo, dock_mhi),
        ("船坞 dock（手动摇杆, PID 前钳 ±1.0）", -1.0, 1.0),
    ]
    for label, lo, hi in rows_f:
        tot_hi = 2.0 * hi * f_pos
        tot_lo = 2.0 * lo * f_neg
        print(f"{label:<24}{f'{lo:+.3f}..{hi:+.3f}':<20}"
              f"{f'{hi*f_pos:+.3f} / {lo*f_neg:+.3f}':<20}"
              f"{f'{tot_hi:+.2f} / {tot_lo:+.2f}':<18}")
    print()
    print("  ⚠ 对照 Unity 方给的「融合值 ±35 N（船坞）/ ±30 N（小船）」——")
    print("    本表说明这两个值在真实代码里**都达不到**，请按本表复核。")
    print("  ⚠ core/vision/docking/constants.py:161 的 THRUSTER_MAX_FORCE = 30.0")
    print("    是**死常量**（全工程从未引用），不要当权威值。")
    print()
    print("=" * 78)


# ---------------------------------------------------------------------------
# 轨迹跟踪
# ---------------------------------------------------------------------------

def default_mission(geo, shape="rightangle"):
    """在 ±extent 内造一条含直角的路径（单位：米，相对 origin）。

    lshape     —— 3 点 / **恰好一个** 90° 直角（Unity 在 E 题里点名要的形状）
    rightangle —— 4 点 / 两个 90° 直角
    straight   —— 2 点 / 无折角（基线对照）
    staircase  —— 5 点 / 多个折角
    """
    if shape == "lshape":
        pts_m = [(0, -18), (0, 10), (15, 10)]
    elif shape == "rightangle":
        pts_m = [(0, -18), (0, 10), (15, 10), (15, -10)]
    elif shape == "straight":
        pts_m = [(0, -18), (0, 18)]
    else:                                    # "staircase"：多个折角
        pts_m = [(0, -18), (0, 0), (10, 0), (10, 10), (20, 10)]
    return [geo.to_latlon(dx, dz) for dx, dz in pts_m]


def run_trace(ship, geo, coords, yaw_gain=60.0, v0=0.0, max_frames=4000):
    """用真实 navigator + PID + mixer 跑一遍，返回逐帧 dict 列表。

    船体模型：**代用单轮模型**（不是孪生物理），只为生成一条合理轨迹。
        yaw_rate(°/s) = yaw_gain × r_steer
        位置沿当前艏向以 v_now 积分
    """
    ship_id = SHIP_IDS[ship]
    atten = BOAT_STEER_ATTENUATION if ship == "boat" else DOCK_STEER_ATTENUATION

    nav = MissionNavigator(arrival_threshold=ARRIVAL_THRESHOLD,
                           default_speed=DEFAULT_SPEED)
    nav.set_path(list(coords))

    hp = HeadingPIDController(kp=HEADING_KP, ki=HEADING_KI, kd=HEADING_KD,
                              deadband=HEADING_DEADBAND)
    sp = StandardPIDController(kp=SPEED_KP, ki=SPEED_KI, kd=SPEED_KD)
    limiter = SpeedLimiter()

    main_lo, main_hi = get_thruster_ratio_limits(ship_id, [1, 4])
    steer_lo, steer_hi = get_thruster_ratio_limits(ship_id, [2, 3])

    # 状态（米 / 度）
    x, z = geo.to_meters(*coords[0])
    heading = 0.0
    v_now = v0
    t = 0.0
    rows = []
    hold_h, hold_s = 0.0, 0.0          # brain 保留的上一拍目标（到点时用）

    for frame in range(max_frames):
        lat, lon = geo.to_latlon(x, z)

        target_h, target_s, dist_wp, finished = nav.update(lat, lon, heading)
        wp_index = nav.current_wp_index

        if finished:
            # ⚠ 到点帧必须单独处理：**不能**把 nav 返回的 (0.0, 0.0) 当目标喂进 PID。
            #   nav 到点时先 stop() 再返回 (0.0, 0.0, dist, True)
            #   (navigator_manager.py:80-81)；但 boat_brain.py:287-299 在
            #   is_finished 时 **丢弃** 这两个返回值，转而调用 stop_mission()，
            #   后者 emit sig_control_ratios_ready(0,0,0,0,True)
            #   (boat_brain.py:739) → 四路 ratio 全 0 → PWM 全 1500（中位、舵回中）。
            #   若照抄 0.0 当目标航向，船头朝南时会算出 ±180° 误差 → 满舵，
            #   那是**本工具早期版本造出的假象**，真实代码不会这么发。
            rows.append(dict(
                # --- Unity 在 E 题点名的 12 列，**按同样顺序放最前** ---
                t=round(t, 3),
                lat_mid=lat, lon_mid=lon,
                heading=round(heading, 3),
                target_heading=round(hold_h, 3),     # brain 保留的上一拍目标
                target_speed=round(hold_s, 4),
                v_now=round(v_now, 4),
                r_main=0.0, r_steer=0.0,
                pwm1=1500, pwm2=1500, pwm3=1500, pwm4=1500,
                # --- 以下为我方附加诊断列 ---
                frame=frame,
                x_m=round(x, 4), z_m=round(z, 4),
                wp_index=wp_index,
                dist_to_wp=round(dist_wp, 3),
                h_ratio_pre_clamp=0.0, s_ratio_pre_clamp=0.0,
                steer_saturated=False, main_saturated=False,
                finished=True, note="stop_mission",
            ))
            break

        target_s_lim = limiter.apply(target_s, DT)

        # --- 速度环（boat_brain.py:333-338）---
        s_ratio = sp.compute(v_now, target_s_lim, DT)
        s_ratio = clamp(s_ratio, -1.0, 1.0)

        # --- 转向环（boat_brain.py:346-351）---
        h_ratio = hp.compute(heading, target_h, DT)
        h_ratio = h_ratio * atten                       # ★ 小船 0.75 / 船坞 1.0

        # --- 混控（boat_brain.py:175-179 / dock_brain.py:448）---
        r_main = clamp(s_ratio, main_lo, main_hi)
        r_steer = clamp(h_ratio, steer_lo, steer_hi)

        # --- ratio → PWM（protocol.py:_apply_compensation）---
        pwm = [USVProtocol._apply_compensation(ship_id, ch, v)
               for ch, v in ((1, r_main), (2, r_steer),
                             (3, -r_steer), (4, r_main))]

        rows.append(dict(
            # --- Unity 在 E 题点名的 12 列，**按同样顺序放最前** ---
            t=round(t, 3),
            lat_mid=lat, lon_mid=lon,
            heading=round(heading, 3),
            target_heading=round(target_h, 3),
            target_speed=round(target_s_lim, 4),
            v_now=round(v_now, 4),
            r_main=round(r_main, 5), r_steer=round(r_steer, 5),
            pwm1=pwm[0], pwm2=pwm[1], pwm3=pwm[2], pwm4=pwm[3],
            # --- 以下为我方附加诊断列 ---
            frame=frame,
            x_m=round(x, 4), z_m=round(z, 4),
            wp_index=wp_index,
            dist_to_wp=round(dist_wp, 3),
            h_ratio_pre_clamp=round(h_ratio, 5),
            s_ratio_pre_clamp=round(s_ratio, 5),
            steer_saturated=(abs(h_ratio) > abs(steer_hi) + 1e-9),
            main_saturated=(abs(s_ratio) > abs(main_hi) + 1e-9),
            finished=finished, note="run",
        ))

        hold_h, hold_s = target_h, target_s_lim

        # --- 代用单轮推进 ---
        yaw_rate = yaw_gain * r_steer                     # °/s
        heading = (heading + yaw_rate * DT + 180.0) % 360.0 - 180.0
        v_now = target_s_lim                              # 速度环当作瞬时跟随
        rad = math.radians(heading)
        x += math.sin(rad) * v_now * DT                   # 北=0 顺时针 → +X 东
        z += math.cos(rad) * v_now * DT
        t += DT

    return rows


def replay_trace(ship, geo, coords, replay_rows):
    """用**外部给定的轨迹**做输入，只算输出（供 Unity 逐帧对齐）。"""
    ship_id = SHIP_IDS[ship]
    atten = BOAT_STEER_ATTENUATION if ship == "boat" else DOCK_STEER_ATTENUATION
    nav = MissionNavigator(arrival_threshold=ARRIVAL_THRESHOLD,
                           default_speed=DEFAULT_SPEED)
    nav.set_path(list(coords))
    hp = HeadingPIDController(kp=HEADING_KP, ki=HEADING_KI, kd=HEADING_KD,
                              deadband=HEADING_DEADBAND)
    sp = StandardPIDController(kp=SPEED_KP, ki=SPEED_KI, kd=SPEED_KD)
    limiter = SpeedLimiter()
    main_lo, main_hi = get_thruster_ratio_limits(ship_id, [1, 4])
    steer_lo, steer_hi = get_thruster_ratio_limits(ship_id, [2, 3])

    rows = []
    hold_h, hold_s = 0.0, 0.0
    for i, r in enumerate(replay_rows):
        lat, lon = float(r["lat"]), float(r["lon"])
        heading = float(r["heading"])
        v_now = float(r.get("v", 0.0))
        th, ts, dist_wp, finished = nav.update(lat, lon, heading)
        x, z = geo.to_meters(lat, lon)
        if finished:
            # 同 run_trace：到点 → brain 走 stop_mission()，四路 ratio 归零
            rows.append(dict(
                t=round(i * DT, 3),
                lat_mid=lat, lon_mid=lon, heading=round(heading, 3),
                target_heading=round(hold_h, 3), target_speed=round(hold_s, 4),
                v_now=round(v_now, 4), r_main=0.0, r_steer=0.0,
                pwm1=1500, pwm2=1500, pwm3=1500, pwm4=1500,
                frame=i, x_m=round(x, 4), z_m=round(z, 4),
                wp_index=nav.current_wp_index, dist_to_wp=round(dist_wp, 3),
                h_ratio_pre_clamp=0.0, s_ratio_pre_clamp=0.0,
                steer_saturated=False, main_saturated=False,
                finished=True, note="stop_mission"))
            break
        ts_lim = limiter.apply(ts, DT)
        s_ratio = clamp(sp.compute(v_now, ts_lim, DT), -1.0, 1.0)
        h_ratio = hp.compute(heading, th, DT) * atten
        r_main = clamp(s_ratio, main_lo, main_hi)
        r_steer = clamp(h_ratio, steer_lo, steer_hi)
        pwm = [USVProtocol._apply_compensation(ship_id, ch, v)
               for ch, v in ((1, r_main), (2, r_steer),
                             (3, -r_steer), (4, r_main))]
        rows.append(dict(
            t=round(i * DT, 3),
            lat_mid=lat, lon_mid=lon, heading=round(heading, 3),
            target_heading=round(th, 3), target_speed=round(ts_lim, 4),
            v_now=round(v_now, 4), r_main=round(r_main, 5),
            r_steer=round(r_steer, 5),
            pwm1=pwm[0], pwm2=pwm[1], pwm3=pwm[2], pwm4=pwm[3],
            frame=i, x_m=round(x, 4), z_m=round(z, 4),
            wp_index=nav.current_wp_index, dist_to_wp=round(dist_wp, 3),
            h_ratio_pre_clamp=round(h_ratio, 5),
            s_ratio_pre_clamp=round(s_ratio, 5),
            steer_saturated=(abs(h_ratio) > abs(steer_hi) + 1e-9),
            main_saturated=(abs(s_ratio) > abs(main_hi) + 1e-9),
            finished=finished, note="run"))
        hold_h, hold_s = th, ts_lim
    return rows


def write_csv(path, rows):
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description="路径跟踪逐帧参考轨迹导出")
    ap.add_argument("--ship", choices=["boat", "dock"], default="boat")
    ap.add_argument("--scene", default="Level1_Pool")
    ap.add_argument("--shape",
                    choices=["lshape", "rightangle", "straight", "staircase"],
                    default="lshape",
                    help="lshape=3点1个直角(Unity E 题指定) / rightangle=4点2个直角 "
                         "/ straight=直线 / staircase=多折角")
    ap.add_argument("--out", default=None)
    ap.add_argument("--yaw-gain", type=float, default=60.0,
                    help="代用模型的偏航增益 (°/s @ r_steer=1)")
    ap.add_argument("--replay", default=None,
                    help="用外部轨迹做输入（CSV 列：lat,lon,heading[,v]）")
    ap.add_argument("--pid-tables", action="store_true",
                    help="只打印 PID 量纲对照表")
    args = ap.parse_args()

    if args.pid_tables:
        print_pid_tables()
        return 0

    cfg = TwinSceneConfig()
    lv = cfg.get(args.scene)
    if lv is None:
        raise SystemExit(f"[错误] 未知关卡 {args.scene}；可用: {cfg.names()}")
    geo = Geo(lv["originLat"], lv["originLon"])

    print("=" * 78)
    print(f"路径跟踪逐帧轨迹 ｜ 船={args.ship} 关卡={args.scene} 形状={args.shape}")
    print("=" * 78)
    print("真实调用: MissionNavigator / HeadingPID / StandardPID / _apply_compensation")
    print(f"混控与限幅: 逐行复刻自 boat_brain.py / dock_brain.py")
    print(f"控制周期 DT = {DT}s   转向削弱 = "
          f"{BOAT_STEER_ATTENUATION if args.ship=='boat' else DOCK_STEER_ATTENUATION}")
    ml, mh = get_thruster_ratio_limits(SHIP_IDS[args.ship], [1, 4])
    sl, sh = get_thruster_ratio_limits(SHIP_IDS[args.ship], [2, 3])
    print(f"主推 ratio 限幅 = {ml:+.3f}..{mh:+.3f}   "
          f"转向 ratio 限幅 = {sl:+.3f}..{sh:+.3f}")
    print()

    coords = default_mission(geo, args.shape)
    print(f"航线（{len(coords)} 点，相对 origin 的米）:")
    for i, (la, lo) in enumerate(coords):
        dx, dz = geo.to_meters(la, lo)
        print(f"   WP{i+1}: ({dx:+7.2f}, {dz:+7.2f}) m   {la:.8f}, {lo:.8f}")
    print()

    if args.replay:
        with open(args.replay, newline="", encoding="utf-8") as fh:
            rr = list(csv.DictReader(fh))
        rows = replay_trace(args.ship, geo, coords, rr)
        print(f"（回放模式：输入 {len(rr)} 帧，算法输出 {len(rows)} 帧）")
    else:
        rows = run_trace(args.ship, geo, coords, yaw_gain=args.yaw_gain)
        print(f"（仿真模式：代用单轮模型，{len(rows)} 帧）")

    out = args.out or f"trace_{args.ship}_{args.shape}.csv"
    write_csv(os.path.join(ROOT, out), rows)
    print()
    print(f"✅ 已写出 {out}  （{len(rows)} 帧 × {len(rows[0]) if rows else 0} 列）")
    print()
    print("列顺序（**前 13 列 = Unity 在 E 题点名的清单，顺序一致**）:")
    print("  1) t  2) lat_mid  3) lon_mid  4) heading        ← 【输入】")
    print("  5) target_heading  6) target_speed  7) v_now    ← v_now 是【输入】，"
          "其余为【输出】")
    print("  8) r_main  9) r_steer  10..13) pwm1 pwm2 pwm3 pwm4   ← 【输出】")
    print("  之后为附加诊断列: frame x_m z_m wp_index dist_to_wp")
    print("      h_ratio_pre_clamp s_ratio_pre_clamp steer_saturated main_saturated")
    print("      finished note")
    print()
    print("对齐方法：把 lat_mid/lon_mid/heading/v_now 逐帧喂进你们的实现，")
    print("          比对我方算出的 target_heading/r_main/r_steer/pwm1..4。")
    print("          note=stop_mission 的帧是到点停车帧（四路 ratio 归零、PWM 全 1500）。")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
