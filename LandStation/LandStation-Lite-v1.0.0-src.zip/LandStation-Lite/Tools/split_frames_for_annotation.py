# -*- coding: utf-8 -*-
"""把切好的训练图片平均分成 N 份，分给 N 个人并行标注。

配套 Tools/video_to_frames.py 使用：先用它把录像切成图片，再用本脚本分活。

特点：
  * 默认只挑船坞（dock_video_*）的图片，只分船坞的活；用 --match "" 可分全部；
  * 默认【复制】到目标目录，原始数据集保持完整，随时可以换个种子重新分；
  * 份数差最多 1 张（真正的"平均"），分完会校验不重不漏；
  * 每份都带一个 frames_manifest.csv，记录该份图片的来源视频/帧号/时间戳；
  * --by-video 可以按"整段视频"分，保证同一段录像不拆散（各人负责不同时间段）。

用法示例：
    python Tools/split_frames_for_annotation.py                     # dock 图片均分 3 份
    python Tools/split_frames_for_annotation.py --dry-run           # 只看怎么分，不复制
    python Tools/split_frames_for_annotation.py --parts 4           # 分 4 份
    python Tools/split_frames_for_annotation.py --by-video          # 按整段视频分
    python Tools/split_frames_for_annotation.py --move              # 移动而非复制（省空间）
    python Tools/split_frames_for_annotation.py --match ""          # boat + dock 一起分
    python Tools/split_frames_for_annotation.py --seed 7            # 换一种随机分法
"""

from __future__ import annotations

import argparse
import csv
import os
import random
import shutil
import sys
from typing import Dict, List

try:  # Windows 控制台/重定向到文件时避免 emoji 报编码错
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # pragma: no cover
    pass

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_INPUT = os.path.join(PROJECT_ROOT, "datasets", "nof_frames")
DEFAULT_OUTPUT = os.path.join(PROJECT_ROOT, "datasets", "nof_frames_split")
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".bmp")
MANIFEST_NAME = "frames_manifest.csv"


def find_images(src_dir: str, match: str) -> List[str]:
    """列出目录下的图片（按文件名排序）。match 为文件名关键字，空串表示全部。"""
    if not os.path.isdir(src_dir):
        return []
    names = []
    for name in os.listdir(src_dir):
        path = os.path.join(src_dir, name)
        if not os.path.isfile(path):
            continue
        if os.path.splitext(name)[1].lower() not in IMAGE_EXTS:
            continue
        if match and match not in name:
            continue
        names.append(name)
    return sorted(names)


def video_key(filename: str) -> str:
    """从 <视频名>_<帧号>.jpg 里还原视频名；认不出来就用文件名本身。"""
    stem = os.path.splitext(filename)[0]
    head, _sep, tail = stem.rpartition("_")
    return head if head and tail.isdigit() else stem


def split_random(names: List[str], parts: int, seed: int) -> List[List[str]]:
    """随机打乱后按块均分：各份数量相差最多 1 张。"""
    pool = list(names)
    random.Random(seed).shuffle(pool)
    base, extra = divmod(len(pool), parts)
    bins, cursor = [], 0
    for i in range(parts):
        size = base + (1 if i < extra else 0)
        bins.append(sorted(pool[cursor:cursor + size]))
        cursor += size
    return bins


def split_by_video(names: List[str], parts: int) -> List[List[str]]:
    """按整段视频分配：视频按张数从大到小，依次塞进当前最少的那一份（LPT 均衡）。"""
    groups: Dict[str, List[str]] = {}
    for name in names:
        groups.setdefault(video_key(name), []).append(name)
    bins: List[List[str]] = [[] for _ in range(parts)]
    for _key, items in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        target = min(range(parts), key=lambda i: len(bins[i]))
        bins[target].extend(items)
    return [sorted(b) for b in bins]


def load_manifest(path: str) -> Dict[str, dict]:
    """读原始清单，返回 {图片名: 行}（同一张图重复出现时保留第一条）。"""
    rows: Dict[str, dict] = {}
    if not os.path.isfile(path):
        return rows
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            image = os.path.basename(row.get("image", ""))
            if image and image not in rows:
                rows[image] = row
    return rows


def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        description="把训练图片平均分成 N 份，分给 N 个人标注",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--input", "-i", default=DEFAULT_INPUT, help=f"图片目录（默认 {DEFAULT_INPUT}）")
    p.add_argument("--output", "-o", default=DEFAULT_OUTPUT, help=f"输出目录（默认 {DEFAULT_OUTPUT}）")
    p.add_argument("--parts", "-n", type=int, default=3, help="分成几份（默认 3，即 3 个人）")
    p.add_argument("--match", "-m", default="dock_video", help="只挑文件名含该关键字的图片（默认 dock_video；空串=全部）")
    p.add_argument("--by-video", action="store_true", help="按整段视频分，不拆散同一段录像")
    p.add_argument("--seed", type=int, default=42, help="随机种子（默认 42，同种子分法可复现）")
    p.add_argument("--move", action="store_true", help="移动而非复制（默认复制，保留原始数据集）")
    p.add_argument("--prefix", default="part", help="每份的目录名前缀（默认 part → part1/part2/part3）")
    p.add_argument("--dry-run", action="store_true", help="只打印分法，不复制文件")
    args = p.parse_args(argv)

    if args.parts < 1:
        print("❌ --parts 至少为 1")
        return 2

    src_dir = os.path.abspath(args.input)
    names = find_images(src_dir, args.match)
    if not names:
        print(f"❌ 在 {src_dir} 里没找到匹配 \"{args.match}\" 的图片")
        return 1
    if len(names) < args.parts:
        print(f"❌ 只有 {len(names)} 张图，不够分 {args.parts} 份")
        return 2

    bins = split_by_video(names, args.parts) if args.by_video else split_random(names, args.parts, args.seed)

    # ---- 校验：不重、不漏 ----
    flat = [n for b in bins for n in b]
    assert len(flat) == len(names) and set(flat) == set(names), "分份结果不重不漏校验失败"

    manifest = load_manifest(os.path.join(src_dir, MANIFEST_NAME))
    out_dir = os.path.abspath(args.output)

    print("=" * 74)
    print(f"📤 把 {len(names)} 张图分成 {args.parts} 份"
          f"（{'按整段视频' if args.by_video else f'随机 seed={args.seed}'}，"
          f"{'移动' if args.move else '复制'}）")
    print(f"   来源: {src_dir}")
    print(f"   输出: {out_dir}")
    print("=" * 74)

    for i, items in enumerate(bins, 1):
        part_dir = os.path.join(out_dir, f"{args.prefix}{i}")
        videos = sorted({video_key(n) for n in items})
        print(f"  {args.prefix}{i}: {len(items):4d} 张 | 来自 {len(videos)} 段视频"
              f" | 示例 {items[0]} … {items[-1]}")

    counts = [len(b) for b in bins]
    print(f"\n  分量: {counts}   最大差 {max(counts) - min(counts)} 张")

    if args.dry_run:
        print("\n（dry-run：没有复制任何文件。去掉 --dry-run 即正式分份）")
        return 0

    for i, items in enumerate(bins, 1):
        part_dir = os.path.join(out_dir, f"{args.prefix}{i}")
        os.makedirs(part_dir, exist_ok=True)
        for name in items:
            src = os.path.join(src_dir, name)
            dst = os.path.join(part_dir, name)
            if os.path.exists(dst):
                continue
            shutil.move(src, dst) if args.move else shutil.copy2(src, dst)

        # 每份附带自己的清单，标注的人能查到每张图的来源视频/帧号/时间
        rows = [manifest[n] for n in items if n in manifest]
        if rows:
            with open(os.path.join(part_dir, MANIFEST_NAME), "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
                writer.writeheader()
                writer.writerows(rows)

    # ---- 落盘后复核 ----
    ok = True
    for i, items in enumerate(bins, 1):
        part_dir = os.path.join(out_dir, f"{args.prefix}{i}")
        got = len([n for n in os.listdir(part_dir) if os.path.splitext(n)[1].lower() in IMAGE_EXTS])
        if got != len(items):
            ok = False
            print(f"  ⚠️ {args.prefix}{i} 实际 {got} 张，预期 {len(items)} 张")

    print("\n" + "=" * 74)
    if ok:
        print(f"✅ 完成：{len(names)} 张图已分到 {args.parts} 个文件夹（复核通过，不重不漏）")
    else:
        print("⚠️ 完成，但上面有数量不符的目录，请检查磁盘空间")
    if args.move:
        print(f"ℹ️ 已用移动模式，原目录 {src_dir} 里对应的图片已不在（清单仍保留）")
    else:
        print(f"ℹ️ 原始数据集 {src_dir} 未改动，可随时换 --seed 重分")
    print("=" * 74)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
