#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
孪生底图占位图生成工具
======================

用途
----
在 Unity 侧产出【真实正交俯视截图】之前，生成**坐标正确**的网格占位底图，
以便地面站侧提前联调完整链路（打点 → GPS → P2P → 4 路 PWM → 孪生船/船坞）。

设计要点
--------
* 生成图与 `ui/map/twin_maps/scenes.json` 的**四角经纬度严格对应** ——
  图上的网格即"米"坐标系，因此点在哪、船去哪，位置可验证。
* **零第三方依赖**：只需 `numpy`（工程已有）。PNG 由内置的
  `zlib + struct` 写出，文字用自带点阵字体绘制。
  **刻意不用 PyQt5 画图** —— 无头环境下 Qt 字体子系统会原生崩溃
  （`QGuiApplication::font()` → `0xC0000005`），而占位图不值得引入该风险。
* 只写 `ui/map/twin_maps/` 下的 PNG 与 `scenes.json`，
  并**只针对孪生相关路径**，不触碰任何实船配置。

用法
----
    python Tools/make_twin_placeholder_map.py            # 生成全部关卡 + scenes.json
    python Tools/make_twin_placeholder_map.py --list     # 只打印将要生成的内容
    python Tools/make_twin_placeholder_map.py --only Level1_Pool

几何口径（2025-01 与 Unity 侧确认）
-----------------------------------
L1_Pool      : 水池 55×55 m → 底图四角 ±27.5；墙中心 ±26.5（池岸内侧 1 m，
               厚 2 m）→ 墙内表面 ±25.5 → navigableRadiusMeters = 25.5
L2_WindFarm  : 底图四角 ±200；墙中心 ±200，厚 2 m → 内表面 ±199
               → navigableRadiusMeters = 199

⚠️ `navigableRadiusMeters` 一律取【墙内表面】，即"船真正能到哪"。
   这正是 Unity 侧 Q1.2 要求的口径。
"""

import argparse
import json
import math
import os
import sys

# ---------------------------------------------------------------------------
# 场景定义（唯一数据源 —— 改尺寸只改这里）
# ---------------------------------------------------------------------------

# 占位原点（与 Unity 侧 isDemoOnly 原点一致）
ORIGIN_LAT = 23.1291
ORIGIN_LON = 113.2644

# 每度纬度约 111320 m（与 Unity GeoReference 的等距圆柱近似一致）
_M_PER_DEG_LAT = 111320.0

SCENES = [
    {
        "scene": "Level1_Pool",
        "image": "Level1_Pool.png",
        # 【v5 更正】底图范围 = Hierarchy 里 Terrain 的实际大小 → 100 m 见方 ⇒ 半边长 50
        #   （此前 v4 曾定 ±25「贴湖岸」，v5 改为覆盖整个 Terrain，含四周陆地）
        "halfExtentM": 50.0,
        # L1 不需要空气墙 —— 3 m 高天然湖岸即硬边界。wallHalfM = None 表示"不画墙"。
        "wallHalfM": None,
        "wallThicknessM": 0.0,
        # 可航水域：中间约半径 22 m 的圆（**仅作信息标注，不用于拒绝**）
        "navigableRadiusM": 22.0,
        # 【v5 更正】方形判据：只看是否落在底图范围内（|x|>50 或 |z|>50 才拒绝）
        #   ⚠️ 已删除"点在陆地上则拒绝"这条校验（用户决策）
        "boundsShape": "square",
        "note": "Terrain 100x100 m（±50）；中间半径约 22 m 圆形可航水域，其余为陆地。"
                "判据：仅【超出底图范围】才拒绝，陆地不拦。",
        "isDemoOnly": True,
        "kind": "lake",
    },
    {
        "scene": "Level2_WindFarm",
        "image": "Level2_WindFarm.png",
        "halfExtentM": 200.0,
        "wallHalfM": 200.0,
        "wallThicknessM": 2.0,
        "navigableRadiusM": 199.0,
        "boundsShape": "square",
        "note": "演示用 400x400 m 风场；墙中心 ±200，墙内表面 ±199",
        "isDemoOnly": True,
        "kind": "windfarm",
    },
]

# 图像边长（像素）。1024 对应 ±50 m → 约 10.2 px/m。
# ⚠️ Unity 侧实际交付为 2048 / 4096，届时改 scenes.json 的 width/height 即可。
IMAGE_PX = 1024


# ---------------------------------------------------------------------------
# 经纬度换算（等距圆柱 —— 与 Unity 侧 GeoReference 保持一致）
# ---------------------------------------------------------------------------

def geo_from_offset(dx_m: float, dz_m: float):
    """把以原点为基准的东向/北向偏移（米）换算为经纬度。"""
    lat = ORIGIN_LAT + dz_m / _M_PER_DEG_LAT
    lon = ORIGIN_LON + dx_m / (_M_PER_DEG_LAT * math.cos(math.radians(ORIGIN_LAT)))
    return lat, lon


def build_corners(half: float):
    """返回底图四角经纬度（half 为半边长，单位米）。"""
    top_lat, _ = geo_from_offset(0.0, +half)
    bottom_lat, _ = geo_from_offset(0.0, -half)
    _, left_lon = geo_from_offset(-half, 0.0)
    _, right_lon = geo_from_offset(+half, 0.0)
    return top_lat, bottom_lat, left_lon, right_lon


# ---------------------------------------------------------------------------
# 绘制（纯 numpy —— 不用 Qt，避免无头环境下 Qt 字体子系统原生崩溃）
# ---------------------------------------------------------------------------
#
# 说明：本工具**刻意不依赖 PyQt5**。
# 在无显示环境下 QPainter 绘制文字会触发 Qt 字体子系统的原生崩溃
# （QGuiApplication::font() → 0xC0000005），而占位图只是内部联调素材，
# 不值得为此引入环境依赖。故改用 numpy 直接生成 PNG，并自带一个 5x7 点阵字体。

# --- PNG 最小写出器（zlib + struct，无需 Pillow） ---

def _write_png(path: str, rgb) -> bool:
    """把 (H, W, 3) uint8 数组写成 PNG。"""
    import struct
    import zlib

    h, w, _ = rgb.shape
    raw = bytearray()
    for y in range(h):
        raw.append(0)                       # 每行的 filter type = 0 (None)
        raw.extend(rgb[y].tobytes())

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(bytes(raw), 6))
    png += chunk(b"IEND", b"")

    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path, "wb") as fh:
            fh.write(png)
    except OSError as exc:
        print(f"[错误] 保存失败 {path}: {exc}")
        return False
    return True


# --- 5x7 点阵字体（仅含本工具用到的字符） ---
# 每个字符 7 行、每行 5 位（高位在左）。用 '@' 与 '.' 书写便于校对。
_FONT_SRC = {
    "0": [".@@@.", "@...@", "@..@@", "@.@.@", "@@..@", "@...@", ".@@@."],
    "1": ["..@..", ".@@..", "..@..", "..@..", "..@..", "..@..", ".@@@."],
    "2": [".@@@.", "@...@", "....@", "...@.", "..@..", ".@...", "@@@@@"],
    "3": ["@@@@@", "...@.", "..@..", "...@.", "....@", "@...@", ".@@@."],
    "4": ["...@.", "..@@.", ".@.@.", "@..@.", "@@@@@", "...@.", "...@."],
    "5": ["@@@@@", "@....", "@@@@.", "....@", "....@", "@...@", ".@@@."],
    "6": ["..@@.", ".@...", "@....", "@@@@.", "@...@", "@...@", ".@@@."],
    "7": ["@@@@@", "....@", "...@.", "..@..", ".@...", ".@...", ".@..."],
    "8": [".@@@.", "@...@", "@...@", ".@@@.", "@...@", "@...@", ".@@@."],
    "9": [".@@@.", "@...@", "@...@", ".@@@@", "....@", "...@.", ".@@.."],
    "A": [".@@@.", "@...@", "@...@", "@@@@@", "@...@", "@...@", "@...@"],
    "B": ["@@@@.", "@...@", "@...@", "@@@@.", "@...@", "@...@", "@@@@."],
    "C": [".@@@.", "@...@", "@....", "@....", "@....", "@...@", ".@@@."],
    "D": ["@@@@.", "@...@", "@...@", "@...@", "@...@", "@...@", "@@@@."],
    "E": ["@@@@@", "@....", "@....", "@@@@.", "@....", "@....", "@@@@@"],
    "F": ["@@@@@", "@....", "@....", "@@@@.", "@....", "@....", "@...."],
    "G": [".@@@.", "@...@", "@....", "@.@@@", "@...@", "@...@", ".@@@@"],
    "H": ["@...@", "@...@", "@...@", "@@@@@", "@...@", "@...@", "@...@"],
    "I": [".@@@.", "..@..", "..@..", "..@..", "..@..", "..@..", ".@@@."],
    "L": ["@....", "@....", "@....", "@....", "@....", "@....", "@@@@@"],
    "M": ["@...@", "@@.@@", "@.@.@", "@...@", "@...@", "@...@", "@...@"],
    "N": ["@...@", "@@..@", "@.@.@", "@..@@", "@...@", "@...@", "@...@"],
    "O": [".@@@.", "@...@", "@...@", "@...@", "@...@", "@...@", ".@@@."],
    "P": ["@@@@.", "@...@", "@...@", "@@@@.", "@....", "@....", "@...."],
    "R": ["@@@@.", "@...@", "@...@", "@@@@.", "@.@..", "@..@.", "@...@"],
    "S": [".@@@@", "@....", "@....", ".@@@.", "....@", "....@", "@@@@."],
    "T": ["@@@@@", "..@..", "..@..", "..@..", "..@..", "..@..", "..@.."],
    "V": ["@...@", "@...@", "@...@", "@...@", "@...@", ".@.@.", "..@.."],
    "W": ["@...@", "@...@", "@...@", "@.@.@", "@.@.@", "@@.@@", "@...@"],
    "X": ["@...@", "@...@", ".@.@.", "..@..", ".@.@.", "@...@", "@...@"],
    "Y": ["@...@", "@...@", ".@.@.", "..@..", "..@..", "..@..", "..@.."],
    " ": [".....", ".....", ".....", ".....", ".....", ".....", "....."],
    ".": [".....", ".....", ".....", ".....", ".....", ".@@..", ".@@.."],
    ",": [".....", ".....", ".....", ".....", ".@@..", ".@@..", ".@..."],
    ":": [".....", ".@@..", ".@@..", ".....", ".@@..", ".@@..", "....."],
    "-": [".....", ".....", ".....", ".@@@.", ".....", ".....", "....."],
    "+": [".....", "..@..", "..@..", "@@@@@", "..@..", "..@..", "....."],
    "/": ["....@", "....@", "...@.", "..@..", ".@...", "@....", "@...."],
    "(": ["..@..", ".@...", "@....", "@....", "@....", ".@...", "..@.."],
    ")": ["..@..", "...@.", "....@", "....@", "....@", "...@.", "..@.."],
    "=": [".....", ".....", "@@@@@", ".....", "@@@@@", ".....", "....."],
    "?": [".@@@.", "@...@", "....@", "...@.", "..@..", ".....", "..@.."],
    "_": [".....", ".....", ".....", ".....", ".....", ".....", "@@@@@"],
}

_FONT = {}
for _ch, _rows in _FONT_SRC.items():
    _FONT[_ch] = [[1 if c == "@" else 0 for c in row] for row in _rows]


def _text_mask(text: str, scale: int = 2):
    """把字符串渲染成 (H, W) 的 0/1 掩码。不支持的字符按空格处理。"""
    import numpy as np

    glyphs = [_FONT.get(ch.upper(), _FONT[" "]) for ch in text]
    if not glyphs:
        return np.zeros((1, 1), dtype=bool)

    gw, gh, gap = 5, 7, 1
    width = len(glyphs) * (gw + gap) - gap
    m = np.zeros((gh, width), dtype=bool)
    for i, g in enumerate(glyphs):
        x0 = i * (gw + gap)
        m[:, x0:x0 + gw] = np.array(g, dtype=bool)

    # 最近邻放大
    m = np.repeat(np.repeat(m, scale, axis=0), scale, axis=1)
    return m


def _draw_text(rgb, text, x, y, scale=2, color=(255, 255, 255)):
    """在 rgb 数组上绘制点阵文字（x, y 为左上角）。"""
    import numpy as np

    m = _text_mask(text, scale)
    if m.size == 0:
        return
    h, w = m.shape
    H, W, _ = rgb.shape
    x0, y0 = max(0, x), max(0, y)
    x1, y1 = min(W, x + w), min(H, y + h)
    if x1 <= x0 or y1 <= y0:
        return
    sub = m[y0 - y:y1 - y, x0 - x:x1 - x]
    rgb[y0:y1, x0:x1][sub] = color


def draw_placeholder(scene: dict, out_path: str, px: int = IMAGE_PX):
    """绘制网格占位图：中心为原点，1 m 细网格 + 10 m 粗网格 + 墙示意。

    dz 向北为正；屏幕上 y 向下，故像素 y = cy - dz * ppm。
    """
    import numpy as np

    half = float(scene["halfExtentM"])
    wall_t = float(scene["wallThicknessM"])

    # 背景与水体（L2 全域为水；L1 稍后按圆形重绘）
    rgb = np.zeros((px, px, 3), dtype=np.uint8)
    rgb[:, :] = (26, 58, 92)

    ppm = px / (2.0 * half)
    cx = cy = px / 2.0

    def mx(dx_m):
        return int(round(cx + dx_m * ppm))

    def my(dz_m):
        return int(round(cy - dz_m * ppm))

    # --- 1 m 细网格（ppm 足够大时才画，避免糊成一片） ---
    if ppm >= 4.0:
        for i in range(-int(half), int(half) + 1):
            if i % 10 == 0:
                continue
            c = mx(i)
            if 0 <= c < px:
                rgb[:, c] = (44, 82, 120)
            r = my(i)
            if 0 <= r < px:
                rgb[r, :] = (44, 82, 120)

    # --- 10 m 粗网格 ---
    for i in range(-int(half // 10), int(half // 10) + 1):
        m = i * 10
        c = mx(m)
        if 0 <= c < px:
            rgb[:, c] = (78, 126, 170)
        r = my(m)
        if 0 <= r < px:
            rgb[r, :] = (78, 126, 170)

    # --- 边界示意 ---
    # L2：方形空气墙，以 wall_half 为中心、厚 wall_t。
    #      注意墙中心可能落在图像边界上（±200 = 四角），
    #      此时半条带在画面外，需把整条带向内收，保证厚度完整可见。
    # L1：圆形湖岸（无空气墙）—— 画圆环表示湖岸线 + 可航半径。
    if scene["kind"] == "lake":
        rgb[:, :] = (18, 26, 34)                 # 岸外背景（陆地色）
        yy, xx = np.mgrid[0:px, 0:px]
        rr = np.hypot(xx - cx, yy - cy) / ppm     # 半径（米）
        rgb[rr <= half] = (26, 58, 92)            # 湖面
        # 湖岸线（粗）
        ring = (rr >= half - max(0.6, 0.8 / ppm)) & (rr <= half + max(0.6, 0.8 / ppm))
        rgb[ring] = (205, 170, 110)
        # 可航半径（虚线感：细圆）
        navr = float(scene["navigableRadiusM"])
        navring = (rr >= navr - 0.35) & (rr <= navr + 0.35)
        rgb[navring] = (120, 200, 255)
        label = f"LAKE R={half:g}M  NAV R={navr:g}M (CIRCLE)"
    else:
        tp = max(2, int(round(wall_t * ppm / 2.0)))
        wall_half = float(scene["wallHalfM"])
        for sign in (+1, -1):
            o = mx(sign * wall_half)
            lo, hi = o - tp, o + tp
            if lo < 0:                       # 贴左边 → 整条带右移入画
                lo, hi = 0, 2 * tp
            if hi > px:                      # 贴右边 → 整条带左移入画
                lo, hi = px - 2 * tp, px
            for c in range(max(0, lo), min(px, hi)):
                rgb[:, c] = (255, 176, 64)
                rgb[c, :] = (255, 176, 64)
        label = f"WALL +-{wall_half:g}M"

    # --- 中心十字（原点） ---
    k = max(2, int(round(3 * ppm)))
    rgb[my(0), max(0, mx(0) - k):min(px, mx(0) + k)] = (120, 255, 170)
    rgb[max(0, my(0) - k):min(px, my(0) + k), mx(0)] = (120, 255, 170)

    # --- 比例尺（10 m） ---
    bar = max(6, int(round(10 * ppm)))
    bx1 = px - int(px * 0.05)
    bx0 = bx1 - bar
    by = px - int(px * 0.05)
    if 0 <= by < px:
        rgb[by, max(0, bx0):min(px, bx1)] = (255, 255, 255)
    _draw_text(rgb, "10M", max(0, bx0), by - 22, scale=2)

    # --- 文字标注 ---
    sc = max(2, px // 300)
    _draw_text(rgb, scene["scene"], int(px * 0.04), int(px * 0.04), scale=sc + 1)
    _draw_text(rgb, "PLACEHOLDER - NOT REAL CAPTURE",
               int(px * 0.04), int(px * 0.04) + 8 * (sc + 1) + 6, scale=sc)
    _draw_text(rgb, f"SIZE {half * 2:g}X{half * 2:g}M  CORNERS +-{half:g}M",
               int(px * 0.04), int(px * 0.04) + 8 * (sc + 1) + 6 + 8 * sc + 6, scale=sc)
    _draw_text(rgb, label,
               int(px * 0.04), int(px * 0.04) + 8 * (sc + 1) + 6 + 16 * sc + 12, scale=sc)
    _draw_text(rgb, "+X E", min(px - 40, mx(0) + 8), my(0) - 20, scale=sc)
    _draw_text(rgb, "+Z N", mx(0) + 8, int(px * 0.04), scale=sc)
    _draw_text(rgb, "(0,0)", min(px - 50, mx(0) + 8), my(0) + 6, scale=sc)

    return _write_png(out_path, rgb)


# ---------------------------------------------------------------------------
# scenes.json
# ---------------------------------------------------------------------------

def scene_to_json_entry(scene: dict):
    half = float(scene["halfExtentM"])
    top, bottom, left, right = build_corners(half)

    return {
        "scene": scene["scene"],
        "image": scene["image"],
        "width": IMAGE_PX,
        "height": IMAGE_PX,
        "topLat": top,
        "bottomLat": bottom,
        "leftLon": left,
        "rightLon": right,
        "sceneExtentMeters": half * 2.0,
        "navigableRadiusMeters": float(scene["navigableRadiusM"]),
        "boundsShape": scene["boundsShape"],
        "originLat": ORIGIN_LAT,
        "originLon": ORIGIN_LON,
        "isDemoOnly": True,
        "note": scene["note"],
    }


def main():
    ap = argparse.ArgumentParser(description="生成孪生底图占位图 + scenes.json")
    ap.add_argument("--list", action="store_true", help="只打印计划，不写文件")
    ap.add_argument("--only", metavar="SCENE", help="只生成指定关卡")
    ap.add_argument("--px", type=int, default=IMAGE_PX, help=f"图像边长（默认 {IMAGE_PX}）")
    args = ap.parse_args()

    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out_dir = os.path.join(base, "ui", "map", "twin_maps")

    scenes = SCENES
    if args.only:
        scenes = [s for s in SCENES if s["scene"] == args.only]
        if not scenes:
            print(f"[错误] 未知关卡: {args.only}")
            print("可用:", ", ".join(s["scene"] for s in SCENES))
            return 1

    print("=" * 68)
    print("孪生底图占位图生成")
    print("=" * 68)
    print(f"输出目录 : {out_dir}")
    print(f"占位原点 : {ORIGIN_LAT}, {ORIGIN_LON}  (isDemoOnly)")
    print(f"图像规格 : {args.px} x {args.px} PNG")
    print()

    entries = []
    for s in scenes:
        half = float(s["halfExtentM"])
        top, bottom, left, right = build_corners(half)
        e = scene_to_json_entry(s)
        entries.append(e)
        print(f"  {s['scene']}")
        print(f"    形状     : {s['boundsShape']}")
        print(f"    底图四角 : ±{half:g} m  ({half*2:g} x {half*2:g} m)")
        if s.get("wallHalfM") is not None:
            print(f"    墙中心   : ±{s['wallHalfM']:g} m   厚 {s['wallThicknessM']:g} m")
        else:
            print(f"    空气墙   : 无（天然地形即边界）")
        print(f"    可航半径 : {e['navigableRadiusMeters']} m")
        print(f"    topLat={top!r}")
        print(f"    bottomLat={bottom!r}")
        print(f"    leftLon={left!r}")
        print(f"    rightLon={right!r}")
        print()

    if args.list:
        print("(--list 模式，未写文件)")
        return 0

    ok = True
    for s in scenes:
        path = os.path.join(out_dir, s["image"])
        print(f"[生成] {path}")
        if not draw_placeholder(s, path, args.px):
            ok = False

    # scenes.json —— 保留未在本次生成范围内的已有条目（如 Unity 已提供的关卡）
    json_path = os.path.join(out_dir, "scenes.json")
    merged = {}
    if os.path.isfile(json_path):
        try:
            with open(json_path, "r", encoding="utf-8") as fh:
                for lv in json.load(fh).get("levels", []):
                    if lv.get("scene"):
                        merged[lv["scene"]] = lv
            print(f"[合并] 已读取现有 scenes.json（{len(merged)} 项）")
        except (OSError, ValueError) as exc:
            print(f"[警告] 现有 scenes.json 读取失败，将覆盖: {exc}")

    for e in entries:
        merged[e["scene"]] = e

    # 保持 SCENES 的顺序在前，其余保持原顺序
    order = [s["scene"] for s in SCENES]
    ordered = [merged[k] for k in order if k in merged]
    ordered += [v for k, v in merged.items() if k not in order]

    with open(json_path, "w", encoding="utf-8") as fh:
        json.dump({"levels": ordered}, fh, ensure_ascii=False, indent=2)
    print(f"[写入] {json_path}  ({len(ordered)} 个关卡)")

    print()
    print("=" * 68)
    print("完成。" if ok else "完成，但有错误。")
    print("下一步：启动地面站 → 工具栏「🌐 孪生底图」→ 选择关卡。")
    print("=" * 68)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
