#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T7 / T8 / T11 验证：范围校验、孪生视图守卫、互锁提示。

用 USVGroundStation.__new__() 绕过 __init__（避开沙箱禁止的 multiprocessing
命名管道），从而直接执行【真实方法体】，而不是复制一份逻辑来测。

关键回归保护：
  * 实船模式（twin_view_active=False）下，T7/T8/T11 全部【放行/静默】
用法： python Tools/verify_twin_logic.py
"""
import io
import math
import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

# Qt 退出时可能因未销毁的 QThread 崩溃，导致 stdout 丢失 → 结果同时落盘。
# 落盘位置放在 Tools/ 下，避免污染工程根。
_LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                    "twin_logic_result.txt")
_fh = open(_LOG, "w", encoding="utf-8")


def emit(line=""):
    print(line)
    _fh.write(line + "\n")
    _fh.flush()


from PyQt5.QtCore import Qt, QCoreApplication  # noqa: E402

QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
import PyQt5.QtWebEngineWidgets  # noqa: E402,F401
from PyQt5.QtWidgets import QApplication, QMessageBox  # noqa: E402

app = QApplication([])

from ui.main_window import USVGroundStation  # noqa: E402
from ui.map.twin_scene_config import TwinSceneConfig  # noqa: E402

fails = []


def check(ok, label, detail=""):
    emit(("  OK   " if ok else "  FAIL ") + label + (("   — " + detail) if detail else ""))
    if not ok:
        fails.append(label)


# 屏蔽模态弹窗（否则会阻塞）；记录弹窗内容
popups = []
QMessageBox.warning = staticmethod(lambda *a, **k: popups.append(a[1:3]))


def make_window():
    w = USVGroundStation.__new__(USVGroundStation)
    w.twin_scene_config = TwinSceneConfig()
    w.twin_view_active = False
    w._twin_bounds = None
    w._twin_current_scene = None
    w._twin_scene_actions = {}
    w._twin_tx_active = False
    w._twin_tx_timer = None
    w._twin_tx_ts = 0.0
    w.local_sim_process = None
    w.view_mode = "Auto"
    w._warned = []
    w._warn_twin_out_of_range = lambda t: w._warned.append(t)
    w.status_msgs = []

    class Bar:
        def showMessage(self, m, t=0):
            w.status_msgs.append(m)

    w.statusBar = Bar()
    return w


OX, OY = 23.1291, 113.2644

# 大场景方形边界（合成，四角 ±200 m）—— 精简版只随包 Level1_Pool，
# 但"大场景方形越界"的判据仍需覆盖，故用合成边界独立验证。
_LAT200 = 200.0 / 111320.0
_LON200 = 200.0 / (111320.0 * math.cos(math.radians(OX)))
LARGE_BOUNDS = {
    "bottomLat": OX - _LAT200,
    "topLat": OX + _LAT200,
    "leftLon": OY - _LON200,
    "rightLon": OY + _LON200,
    "boundsShape": "square",
}


def off(dn, de):
    """以 (北, 东) 米偏移生成经纬度。"""
    return (OX + dn / 111320.0,
            OY + de / (111320.0 * math.cos(math.radians(OX))))


def main():
    w = make_window()

    # ---------------------------------------------------------------- T7
    emit("=== T7-A 实船模式（twin_view_active=False）：必须全部放行 ===")
    def t7(label, lat, lon, expect):
        w._warned.clear()
        got = w._reject_if_outside_twin_bounds(lat, lon)
        check(got == expect, label, f"reject={got} 期望={expect}")

    t7("远在天边（10,100）", 10.0, 100.0, False)
    t7("赤道零点（0,0）", 0.0, 0.0, False)
    t7("None 坐标", None, None, False)

    emit()
    emit("=== T7-B L1 方形（±50 m，= Terrain 实际大小）——【v5 新口径】===")
    emit("    判据只有一条：超出底图范围才拒绝；**陆地不拦**")
    w.twin_view_active = True
    w._twin_current_scene = "Level1_Pool"
    w._twin_bounds = w.twin_scene_config.get("Level1_Pool")
    t7("圆心", *off(0, 0), expect=False)
    t7("正北 20 m（湖内）", *off(20, 0), expect=False)
    t7("正东 26 m（湖岸外→**现在允许**）", *off(0, 26), expect=False)
    t7("方图角点 (25,25)（陆地→**现在允许**）", *off(25, 25), expect=False)
    t7("正北 49 m（贴边内）", *off(49, 0), expect=False)
    t7("正东 49 m（贴边内）", *off(0, 49), expect=False)
    t7("东北 (49,49)（角内）", *off(49, 49), expect=False)
    t7("正北 50.1 m（越界→拒绝）", *off(50.1, 0), expect=True)
    t7("正东 51 m（越界→拒绝）", *off(0, 51), expect=True)
    t7("东北 (51,51)（越界→拒绝）", *off(51, 51), expect=True)
    t7("正北 80 m（远在界外→拒绝）", *off(80, 0), expect=True)

    emit()
    emit("=== T7-C 大场景方形（合成边界，四角 ±200 m）===")
    # 精简版只随包 Level1_Pool；"大场景方形越界"的判据用合成边界验证
    w._twin_current_scene = "TestArea_Large"
    w._twin_bounds = dict(LARGE_BOUNDS)
    t7("中心", *off(0, 0), expect=False)
    t7("北 199 m（内）", *off(199, 0), expect=False)
    t7("北 201 m（越界）", *off(201, 0), expect=True)
    t7("东 201 m（越界）", *off(0, 201), expect=True)
    t7("东北 (199,199) 仍在方内", *off(199, 199), expect=False)

    emit()
    emit("=== T7-D 航点列表逐点校验 ===")
    w._twin_current_scene = "Level1_Pool"
    w._twin_bounds = w.twin_scene_config.get("Level1_Pool")
    r = w._reject_twin_points([[OX, OY], [OX + 1e-4, OY + 1e-4]])
    check(r is False, "全部在内 → 放行", str(r))
    r = w._reject_twin_points([[OX, OY], [10.0, 100.0]])
    check(r is True, "任一点越界 → 整体拒绝", str(r))
    r = w._reject_twin_points([])
    check(r is False, "空列表 → 放行", str(r))
    r = w._reject_twin_points(None)
    check(r is False, "None → 放行", str(r))
    r = w._reject_twin_points([{"lat": 10.0, "lon": 100.0}])
    check(r is True, "支持 dict 形式航点且能拒绝", str(r))

    emit()
    emit("=== T7-E 越界提示文案（**应只讲范围，不讲陆地**）===")
    w._twin_current_scene = "Level1_Pool"
    w._twin_bounds = w.twin_scene_config.get("Level1_Pool")
    w._warned.clear()
    w._reject_if_outside_twin_bounds(*off(60, 0))          # 真的越界才提示
    txt = w._warned[0] if w._warned else ""
    check("底图" in txt or "范围" in txt, "L1 越界提示讲范围", txt[:70])
    check("陆地" not in txt and "湖岸" not in txt,
          "L1 提示【不再】提陆地/湖岸（已删除该判据）", txt[:70])
    # 关键：陆地不再触发任何提示
    w._warned.clear()
    r_land = w._reject_if_outside_twin_bounds(*off(25, 25))
    check(r_land is False and not w._warned,
          "陆地打点：放行且【不弹任何提示】", f"reject={r_land} 提示={len(w._warned)}")

    w._twin_current_scene = "TestArea_Large"
    w._twin_bounds = dict(LARGE_BOUNDS)
    w._warned.clear()
    w._reject_if_outside_twin_bounds(*off(201, 0))
    check("底图之外" in (w._warned[0] if w._warned else ""), "大场景提示为方形越界")

    # ---------------------------------------------------------------- T8
    emit()
    emit("=== T8 孪生视图守卫 ===")

    def t8(label, twin_view, sim_running, expect_block, expect_popup):
        popups.clear()
        w.twin_view_active = twin_view
        w._twin_is_running = lambda: sim_running
        got = w._guard_twin_control()
        check(got == expect_block, label,
              f"block={got} 期望={expect_block} 弹窗={bool(popups)}")
        if bool(popups) != expect_popup:
            check(False, label + " [弹窗不符]", str(bool(popups)))

    t8("孪生视图 + 孪生在跑 → 放行", True, True, False, False)
    t8("孪生视图 + 孪生未跑 → 放行", True, False, False, False)
    t8("真实地图 + 孪生在跑 → 拦截并弹窗", False, True, True, True)
    t8("真实地图 + 孪生未跑（实船）→ 放行", False, False, False, False)

    emit()
    emit("=== T8-b _twin_is_running 判定 ===")
    w._twin_is_running = USVGroundStation._twin_is_running.__get__(w, USVGroundStation)
    w.local_sim_process = None
    w.action_remote_sim = None
    check(w._twin_is_running() is False, "无进程且无 action → False")

    class FakeAct:
        def __init__(self, c):
            self._c = c

        def isChecked(self):
            return self._c

    w.action_remote_sim = FakeAct(True)
    check(w._twin_is_running() is True, "action_remote_sim 勾选 → True")
    w.action_remote_sim = FakeAct(False)
    check(w._twin_is_running() is False, "action_remote_sim 未勾选 → False")

    # --------------------------------------------------------------- T11
    emit()
    emit("=== T11 互锁提示 ===")
    import ui.main_window as mw

    created = []

    class _Sig:
        def connect(self, cb):
            self.cb = cb

    class FakeTimer:
        def __init__(self, parent):
            created.append(self)
            self.running = False
            self.timeout = _Sig()
            self._starts = 0
            self._cb = None

        def setSingleShot(self, b):
            pass

        def start(self, ms):
            self.running = True
            self.ms = ms
            self._starts += 1

        def stop(self):
            self.running = False

        def isActive(self):
            return self.running

    real_timer = mw.QTimer
    mw.QTimer = FakeTimer
    try:
        # --- 实船模式：必须完全静默 ---
        w2 = make_window()
        w2.twin_view_active = False
        w2.status_msgs.clear()
        w2._refresh_twin_status_hint()
        check(len(w2.status_msgs) == 0, "实船模式：状态栏不刷新（关键回归项）",
              f"刷新 {len(w2.status_msgs)} 次")
        w2._note_twin_tx()
        w2._on_twin_tx_idle()
        check(len(w2.status_msgs) == 0, "实船模式：下发也不刷新状态栏",
              f"刷新 {len(w2.status_msgs)} 次")

        # --- 孪生模式：用全新窗口，使 created 只含本段的定时器 ---
        created.clear()
        w2 = make_window()
        w2.twin_view_active = True
        w2._twin_current_scene = "Level1_Pool"
        w2.status_msgs.clear()
        w2._refresh_twin_status_hint()
        check("本机未下发" in w2.status_msgs[-1], "孪生·未下发 文案",
              w2.status_msgs[-1])
        check("Level1_Pool" in w2.status_msgs[-1], "文案含当前关卡", w2.status_msgs[-1])

        w2.status_msgs.clear()
        for _ in range(5):
            w2._note_twin_tx()
        check("本机正在下发中" in w2.status_msgs[-1], "下发中 文案",
              w2.status_msgs[-1])
        check(len(created) == 1, "定时器只创建一次（不每帧新建）",
              f"创建 {len(created)} 次")
        check(created[0]._starts == 5, "定时器被续期 5 次", f"start {created[0]._starts} 次")
        check(len(w2.status_msgs) == 1, "状态栏只在状态翻转时刷新",
              f"刷新 {len(w2.status_msgs)} 次")
        check(w2._twin_tx_timer is created[0], "定时器实例被复用（未重建）")

        w2.status_msgs.clear()
        w2._on_twin_tx_idle()
        check("本机未下发" in w2.status_msgs[-1], "静默后回落为 未下发",
              w2.status_msgs[-1])
        check(w2._twin_tx_active is False, "_twin_tx_active 已复位")

        # 再下发一轮：应复用同一实例
        n_before = len(created)
        w2._note_twin_tx()
        check(len(created) == n_before, "再次下发不重建定时器",
              f"创建 {len(created)} 次")

        # 文案纪律：不得出现我方无法确知的归因
        joined = "\n".join(w2.status_msgs)
        check("Unity" not in joined and "接管" not in joined,
              "文案不做归因（不写'Unity 内部链路正在跑'）", joined[:60])
    finally:
        mw.QTimer = real_timer

    emit()
    emit("=" * 64)
    emit("全部通过" if not fails else f"失败 {len(fails)} 项:")
    for f in fails:
        emit("   - " + f)
    return 0 if not fails else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    finally:
        _fh.close()
