#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T9 验证：孪生日志分离（data_logs_sim/ vs data_logs/）。

核心断言（回归保护）：
  * use_sim_dir 默认 False ⇒ 实船写 data_logs/，且【不会】创建 data_logs_sim/
  * use_sim_dir=True     ⇒ 孪生写 data_logs_sim/
用法： python Tools/verify_t9_logging.py
"""
import glob
import io
import os
import shutil
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

# 本脚本在 Tools/ 下，需把工程根加入 sys.path 才能 import core.*
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

# Qt 在解释器退出时可能因未销毁的 QThread 崩溃（"QThread: Destroyed while
# thread is still running"），导致 stdout 缓冲丢失。故把结果同时逐行落盘，
# 由外层读取文件而不是依赖 stdout。落盘位置放在 Tools/ 下，避免污染工程根。
_LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "t9_verify_result.txt")
_log_fh = open(_LOG_PATH, "w", encoding="utf-8")


def _emit(line=""):
    print(line)
    _log_fh.write(line + "\n")
    _log_fh.flush()
    try:
        sys.stdout.flush()
    except Exception:
        pass


from PyQt5.QtCore import Qt, QCoreApplication  # noqa: E402

QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
import PyQt5.QtWebEngineWidgets  # noqa: E402,F401
from PyQt5.QtWidgets import QApplication  # noqa: E402

app = QApplication([])

from core.data_logger import DataLogger  # noqa: E402

fails = []


def check(ok, label, detail=""):
    _emit(("  OK   " if ok else "  FAIL ") + label + (("   — " + detail) if detail else ""))
    if not ok:
        fails.append(label)


def main():
    lg = DataLogger(None)

    _emit("=== 默认值（必须保证实船不变）===")
    check(lg.log_dir == "data_logs", "log_dir 默认 data_logs", lg.log_dir)
    check(lg.log_dir_sim == "data_logs_sim", "log_dir_sim = data_logs_sim", lg.log_dir_sim)
    check(lg.use_sim_dir is False, "use_sim_dir 默认 False（关键回归项）", str(lg.use_sim_dir))

    for d in ("data_logs", "data_logs_sim"):
        shutil.rmtree(d, ignore_errors=True)

    _emit()
    _emit("=== 实船模式：use_sim_dir=False ===")
    lg.use_sim_dir = False
    lg.start_logging("verify_real")
    lg.stop_logging()
    real = sorted(os.listdir("data_logs")) if os.path.isdir("data_logs") else []
    check(set(real) == {"dock", "boat"}, "data_logs/ 下 dock|boat", str(real))
    check(not os.path.isdir("data_logs_sim"),
          "实船模式【未】创建 data_logs_sim/（关键回归项）",
          "存在" if os.path.isdir("data_logs_sim") else "未创建")

    _emit()
    _emit("=== 孪生模式：use_sim_dir=True ===")
    lg.use_sim_dir = True
    lg.start_logging("verify_sim")
    lg.stop_logging()
    sim = sorted(os.listdir("data_logs_sim")) if os.path.isdir("data_logs_sim") else []
    check(set(sim) == {"dock", "boat"}, "data_logs_sim/ 下 dock|boat", str(sim))

    rf = sorted(os.path.basename(p) for p in glob.glob("data_logs/*/*.csv"))
    sf = sorted(os.path.basename(p) for p in glob.glob("data_logs_sim/*/*.csv"))
    _emit("     实船文件: " + str(rf))
    _emit("     孪生文件: " + str(sf))
    check(len(rf) == 2, "实船产生 2 个 CSV", str(len(rf)))
    check(len(sf) == 2, "孪生产生 2 个 CSV", str(len(sf)))

    _emit()
    _emit("=== 切回实船（标志复位）===")
    lg.use_sim_dir = False
    check(lg.use_sim_dir is False, "use_sim_dir 可复位")

    # 清理
    for d in ("data_logs", "data_logs_sim"):
        shutil.rmtree(d, ignore_errors=True)
    _emit()
    _emit("（已清理测试产物）")
    _emit("=" * 60)
    _emit("T9 通过" if not fails else f"T9 失败 {len(fails)} 项: {fails}")
    return 0 if not fails else 1


if __name__ == "__main__":
    _code = main()
    try:
        _log_fh.flush()
        _log_fh.close()
        sys.stdout.flush()
    except Exception:  # noqa: BLE001
        pass
    # Qt 在解释器退出阶段可能因未销毁的 QThread 崩溃（0xC0000409），
    # 那会覆盖 sys.exit 的返回码、让"其实通过"的测试被误判为失败。
    # os._exit 直接结束进程，保留我们自己的返回码。
    os._exit(_code)
