#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""静态校验 ui/map/map.html（T1/T2/T3），无需 WebEngine。

本沙箱环境无法运行 QtWebEngine（离屏 OpenGL 上下文创建失败 → 原生崩溃），
因此改用静态手段验证：

  1. 抽出全部内联 <script>，逐个用 `node --check` 做**真实 JS 语法解析**。
  2. 确认 T2/T3 的具名变量与函数都已定义（且唯一，无重复声明冲突）。
  3. 确认所有**相对路径**资源真实存在（leaflet、images、twin_maps PNG）。
  4. 确认 Leaflet 版本字符串正确。
  5. 确认没有残留的 CDN 硬依赖（CDN 只应出现在回退分支里）。

用法： python Tools/verify_map_static.py
"""
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAP_DIR = os.path.join(ROOT, "ui", "map")
MAP_HTML = os.path.join(MAP_DIR, "map.html")

results = []


def check(ok, label, detail=""):
    results.append((bool(ok), label, detail))


def image_dimensions(path):
    """读取 PNG / JPEG 的真实像素尺寸（纯标准库，不依赖 Pillow）。

    返回 (w, h)；无法识别返回 None。
    """
    import struct

    try:
        with open(path, "rb") as fh:
            head = fh.read(32)
            if head[:8] == b"\x89PNG\r\n\x1a\n":
                w, h = struct.unpack(">II", head[16:24])
                return int(w), int(h)
            if head[:2] == b"\xff\xd8":                      # JPEG：扫 SOFn 段
                fh.seek(2)
                while True:
                    b = fh.read(1)
                    if not b:
                        return None
                    if b != b"\xff":
                        continue
                    while b == b"\xff":                       # 跳过填充
                        b = fh.read(1)
                        if not b:
                            return None
                    marker = b[0]
                    if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
                        continue
                    ln_b = fh.read(2)
                    if len(ln_b) < 2:
                        return None
                    seg_len = struct.unpack(">H", ln_b)[0]
                    if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6,
                                  0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                        body = fh.read(5)
                        if len(body) < 5:
                            return None
                        h, w = struct.unpack(">HH", body[1:5])
                        return int(w), int(h)
                    fh.seek(seg_len - 2, os.SEEK_CUR)
    except (OSError, struct.error, IndexError):
        return None


def main():
    if not os.path.isfile(MAP_HTML):
        check(False, "map.html 存在")
        return report(1)

    html = open(MAP_HTML, "r", encoding="utf-8").read()
    check(True, "map.html 可读", f"{len(html)} 字符")

    # ---------------------------------------------------------- 1. JS 语法
    scripts = re.findall(r"<script\b[^>]*>(.*?)</script>", html, re.S | re.I)
    # 排除外链 script（src=...）—— 它们在 findall 里内容为空
    scripts = [s for s in scripts if s.strip()]
    check(len(scripts) > 0, f"抽出内联 script 块 = {len(scripts)} 个")

    node = shutil.which("node")
    if node:
        tmpdir = tempfile.mkdtemp(prefix="mapjs_")
        all_ok = True
        for i, src in enumerate(scripts):
            p = os.path.join(tmpdir, f"inline_{i}.js")
            with open(p, "w", encoding="utf-8") as fh:
                fh.write(src)
            try:
                r = subprocess.run([node, "--check", p],
                                   capture_output=True, text=True, timeout=60,
                                   encoding="utf-8", errors="replace")
                if r.returncode != 0:
                    all_ok = False
                    first = (r.stderr or "").strip().splitlines()
                    check(False, f"node --check 内联块 #{i}", first[0] if first else "语法错误")
            except Exception as exc:  # noqa: BLE001
                all_ok = False
                check(False, f"node --check 内联块 #{i}", str(exc))
        if all_ok:
            check(True, "全部内联 JS 通过 node --check（真实语法解析）")
        # 顺带单独校验本地 leaflet.js 是否完好
        ljs = os.path.join(MAP_DIR, "leaflet", "leaflet.js")
        if os.path.isfile(ljs):
            r = subprocess.run([node, "--check", ljs], capture_output=True,
                               text=True, timeout=90, encoding="utf-8", errors="replace")
            check(r.returncode == 0, "本地 leaflet.js 语法完好",
                  "" if r.returncode == 0 else (r.stderr or "")[:120])
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception:  # noqa: BLE001
            pass
    else:
        check(False, "node 不可用，跳过 JS 语法检查")

    # ------------------------------------------------- 2. 符号定义（唯一性）
    for sym in ("googleTileLayer", "twinOverlay", "savedView", "twinActive"):
        n = len(re.findall(r"\bvar\s+" + sym + r"\b", html))
        check(n >= 1, f"T2/T3 变量 {sym} 已定义", f"var 声明 {n} 次")

    for fn in ("showTwinMap", "showRealMap", "isTwinActive", "_twinZoomFor"):
        n = len(re.findall(r"function\s+" + re.escape(fn) + r"\s*\(", html))
        check(n == 1, f"T3 函数 {fn}() 定义唯一", f"定义 {n} 次")

    # 不再有匿名 tileLayer 直接 addTo(map)（T2 的核心）
    anon = re.findall(r"L\.tileLayer\([^;]*?\)\.addTo\(map\)", html, re.S)
    check(not anon, "T2: 不存在匿名 tileLayer.addTo(map)", f"发现 {len(anon)} 处")

    # ------------------------------------------------------- 3. 相对路径存在
    # 从 html 里抓 href/src 相对路径
    rels = re.findall(r'(?:href|src)="([^"#:]+)"', html)
    rels = [r for r in rels if not r.startswith(("http", "//", "qrc"))]
    missing = []
    for r in sorted(set(rels)):
        if not os.path.isfile(os.path.join(MAP_DIR, r)):
            missing.append(r)
    check(not missing, "HTML 内相对资源均存在",
          ("缺失: " + ", ".join(missing)) if missing else f"{len(set(rels))} 个")

    # Leaflet 本地套件
    for f in ("leaflet/leaflet.js", "leaflet/leaflet.css",
              "leaflet/images/marker-icon.png", "leaflet/images/marker-shadow.png",
              "leaflet/images/layers.png"):
        check(os.path.isfile(os.path.join(MAP_DIR, f)), f"本地资源 {f}")

    # 版本字符串
    lcss = os.path.join(MAP_DIR, "leaflet", "leaflet.css")
    ljs = os.path.join(MAP_DIR, "leaflet", "leaflet.js")
    ver_ok = False
    if os.path.isfile(ljs):
        head = open(ljs, "r", encoding="utf-8", errors="replace").read(600)
        ver_ok = "Leaflet 1.9.4" in head
    check(ver_ok, "Leaflet 版本为 1.9.4")
    check(os.path.isfile(lcss), "leaflet.css 存在")

    # 孪生底图：存在 + **真实像素尺寸与 scenes.json 一致**
    # （导入 Unity 正交底图后最易出的错就是"图换了、JSON 里的 width/height 没更新"，
    #   那会让 JS 的自适应缩放算错，故此处做真解码校验。）
    sys.path.insert(0, MAP_DIR)
    try:
        from twin_scene_config import TwinSceneConfig
        cfg = TwinSceneConfig()
        for s in cfg.names():
            img = cfg.image_for(s)
            p = os.path.join(MAP_DIR, "twin_maps", img)
            check(os.path.isfile(p), f"孪生底图 {img} 存在")
            if not os.path.isfile(p):
                continue
            lv = cfg.get(s) or {}
            dims = image_dimensions(p)
            if dims is None:
                check(False, f"{img} 可解码为 PNG/JPEG", "无法识别格式")
                continue
            w, h = dims
            want_w, want_h = int(lv.get("width") or 0), int(lv.get("height") or 0)
            check((w, h) == (want_w, want_h),
                  f"{img} 实际尺寸 == JSON({want_w}×{want_h})",
                  f"实际 {w}×{h}")
    except Exception as exc:  # noqa: BLE001
        check(False, "读取 scenes.json", str(exc))

    # ------------------------------------------------- 4. CDN 只在回退分支
    #
    # 【改造说明】原实现用 `document.write(...)` 在解析期插 CDN 标签；
    # 现已改为更可靠的 DOM 方式（createElement + appendChild），因为
    # document.write 依赖解析时机，在 QtWebEngine 下不够稳。
    # 因此这里的"回退分支"判定要同时认识两种写法：
    #   · document.write('<script src=...>')      ← 旧写法
    #   · el.href = 'https://unpkg...'             ← 新写法（属性赋值）
    #   · 注释行 / 字符串字面量里的说明文字
    CDN_ASSIGN = re.compile(
        r"""(?:\.href|\.src|\.setAttribute\s*\(\s*['"]src['"])\s*=\s*['"]"""
        r"""https://unpkg\.com""")

    cdn_lines = [ln.strip() for ln in html.splitlines() if "unpkg.com" in ln]
    for ln in cdn_lines:
        is_fallback = ("document.write" in ln
                       or ln.strip().startswith("//")
                       or bool(CDN_ASSIGN.search(ln)))
        check(is_fallback, "unpkg 仅出现在回退分支", ln[:70])

    # 不再有直接的 <link href="https://unpkg..."> / <script src="https://unpkg...">（T1 的核心）
    # 注意：回退分支里的字符串/属性赋值内部也含这些片段，那属【预期】，
    # 必须排除，否则是本检查自身的假阳性。
    real_lines = [ln for ln in html.splitlines()
                  if "document.write" not in ln and not CDN_ASSIGN.search(ln)]
    real_html = "\n".join(real_lines)
    direct = re.findall(r'<link[^>]+href="https://unpkg\.com[^"]*"', real_html)
    check(not direct, "T1: 不存在直接 CDN <link>", f"发现 {len(direct)} 处")
    direct_js = re.findall(r'<script[^>]+src="https://unpkg\.com[^"]*"', real_html)
    check(not direct_js, "T1: 不存在直接 CDN <script src>", f"发现 {len(direct_js)} 处")

    # 反向确认：本地叶子确实是被引用的那两个标签（T1 改对了）
    has_local_css = bool(re.search(r'<link[^>]+href="leaflet/leaflet\.css"', real_html))
    has_local_js = bool(re.search(r'<script[^>]+src="leaflet/leaflet\.js"', real_html))
    check(has_local_css, "T1: 引用了本地 leaflet/leaflet.css")
    check(has_local_js, "T1: 引用了本地 leaflet/leaflet.js")

    return report(0)


def report(code):
    print()
    print("=" * 72)
    bad = [r for r in results if not r[0]]
    for ok, label, detail in results:
        print(("  OK   " if ok else "  FAIL ") + label + (("   — " + detail) if detail else ""))
    print("=" * 72)
    print(f"通过 {len(results) - len(bad)}/{len(results)}")
    return code if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
