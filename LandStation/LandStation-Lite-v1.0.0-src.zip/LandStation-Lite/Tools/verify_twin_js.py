#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T3 行为验证：用 node + 打桩的 Leaflet 真实执行 map.html 里的孪生底图函数。

为什么需要它：本沙箱无法运行 QtWebEngine（离屏 OpenGL 上下文创建失败），
所以无法在真浏览器里跑 map.html。改用 node 提供一个最小的 Leaflet/DOM 桩，
把 map.html 中【真实的函数源码】切出来执行，从而验证：

  * showTwinMap 会移除 Google 图层、创建 imageOverlay、设置视口与边界
  * **L1 → L2 切换时先清空旧 maxBounds**（否则会被上一个关卡的小边界钳住）
  * showRealMap 会恢复 Google 图层、移除叠加层、清空边界、还原视口
  * 缩放级别按"像素/米"自适应（L1≈21, L2≈18）
  * isTwinActive 状态正确
  * 图像 URL 指向 twin_maps/<file>

用法： python Tools/verify_twin_js.py
"""
import io
import json
import os
import re
import shutil
import subprocess
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAP_DIR = os.path.join(ROOT, "ui", "map")
MAP_HTML = os.path.join(MAP_DIR, "map.html")

sys.path.insert(0, MAP_DIR)

fails = []


def check(ok, label, detail=""):
    print(("  OK   " if ok else "  FAIL ") + label + (("   — " + detail) if detail else ""))
    if not ok:
        fails.append(label)


def extract_twin_block(html: str) -> str:
    """切出 map.html 中真实的孪生底图 JS 源码（含变量声明与三个函数）。"""
    start = html.find("var twinOverlay = null;")
    if start < 0:
        raise SystemExit("未找到 'var twinOverlay' —— map.html 结构变了？")
    end_marker = "function isTwinActive() { return twinActive; }"
    end = html.find(end_marker)
    if end < 0:
        raise SystemExit("未找到 isTwinActive 实现")
    return html[start:end + len(end_marker)]


STUB = r"""
// ---- 最小 Leaflet / map 桩：记录所有调用次序 ----
var calls = [];
var fakeMap = {
    _layers: {},
    getCenter: function () { return { lat: 23.014035, lng: 113.397917 }; },
    getZoom: function () { return 16; },
    hasLayer: function (l) { return !!this._layers[l && l._id]; },
    removeLayer: function (l) { calls.push('removeLayer:' + (l && l._id)); delete this._layers[l && l._id]; },
    addLayer: function (l) { calls.push('addLayer:' + (l && l._id)); if (l) this._layers[l._id] = l; return this; },
    setView: function (c, z) { calls.push('setView:' + z); this._z = z; return this; },
    setMaxBounds: function (b) { calls.push('setMaxBounds:' + (b ? 'BOUNDS' : 'null')); this._mb = b; return this; },
    getZoom2: function () { return this._z; }
};
var map = fakeMap;
var _idSeq = 0;
var L = {
    imageOverlay: function (url, bounds) {
        var o = { _id: 'overlay' + (++_idSeq), _url: url, _bounds: bounds, addTo: function (m) { m.addLayer(this); return this; } };
        calls.push('createOverlay:' + url);
        return o;
    },
    tileLayer: function (u, o) { return { _id: 'tile', _url: u, addTo: function (m) { m.addLayer(this); return this; } }; }
};
// 模拟已有的 Google 具名图层，且它此刻在地图上
var googleTileLayer = L.tileLayer('google');
map.addLayer(googleTileLayer);
"""

TESTS = r"""
// ---- 断言小工具 ----
var results = [];
function t(ok, label, detail) { results.push([!!ok, label, detail || '']); }
function idx(prefix) { for (var i = 0; i < calls.length; i++) { if (calls[i].indexOf(prefix) === 0) return i; } return -1; }
function reset() { calls.length = 0; }

// === 初始状态 ===
t(map.hasLayer(googleTileLayer), '初始: Google 图层在地图上');
t(isTwinActive() === false, '初始: isTwinActive()==false');

// === 切到 L1 ===
var B1 = __BOUNDS_L1__;
reset();
var r1 = showTwinMap('Level1_Pool', 'Level1_Pool.png', B1, 1024);
t(r1 === true, 'showTwinMap 返回 true');
t(isTwinActive() === true, 'L1: isTwinActive()==true');
t(!map.hasLayer(googleTileLayer), 'L1: Google 图层已移除');
t(!!twinOverlay, 'L1: twinOverlay 已创建');
t(twinOverlay._url === 'twin_maps/Level1_Pool.png', 'L1: overlay URL 正确', twinOverlay._url);
t(map.hasLayer(twinOverlay), 'L1: overlay 已加入地图');
t(JSON.stringify(twinOverlay._bounds) === JSON.stringify([[B1.bottomLat, B1.leftLon], [B1.topLat, B1.rightLon]]),
  'L1: overlay 四角顺序为 [[S,W],[N,E]]');
t(calls.indexOf('setMaxBounds:null') >= 0, 'L1: 先清空了 maxBounds');
t(calls.indexOf('setMaxBounds:BOUNDS') >= 0, 'L1: 设置了新 maxBounds');
var z1 = map._z;
t(z1 >= 20 && z1 <= 21, 'L1: 自适应缩放 ≈21', 'z=' + z1);

// === 切换到第二片（更大的）底图：必须先清 maxBounds ===
// ⚠ 精简版只随包 Level1_Pool，所以这里用**合成边界**验证"切换到大场景"的逻辑：
//   ① setMaxBounds(null) 必须发生在 setView 之前（否则被上一关的小边界钳住）
//   ② 缩放级别必须随场景变大而拉远
var B2 = __BOUNDS_TEST__;
reset();
showTwinMap('TestArea_Large', 'TestArea_Large.png', B2, 1024);
var iClear = idx('setMaxBounds:null');
var iView = idx('setView');
var iSet = idx('setMaxBounds:BOUNDS');
t(iClear >= 0, 'L1->大片: 调用过 setMaxBounds(null)');
t(iClear >= 0 && iView >= 0 && iClear < iView, 'L1->大片: 清空在 setView【之前】（关键修复）',
  'clear@' + iClear + ' view@' + iView);
t(iView >= 0 && iSet >= 0 && iView < iSet, 'L1->大片: 设置新边界在 setView【之后】');
t(twinOverlay._url === 'twin_maps/TestArea_Large.png', 'L1->大片: overlay 已换掉', twinOverlay._url);
var z2 = map._z;
t(z2 < z1, '大片 缩放级别小于 L1（场景更大 → 拉远）', z1 + ' -> ' + z2);

// === 切回真实地图 ===
reset();
var r2 = showRealMap();
t(r2 === true, 'showRealMap 返回 true');
t(isTwinActive() === false, '切回: isTwinActive()==false');
t(map.hasLayer(googleTileLayer), '切回: Google 图层已恢复');
t(!twinOverlay, '切回: twinOverlay 已清空');
t(calls.indexOf('setMaxBounds:null') >= 0, '切回: maxBounds 已清除');
t(calls.indexOf('setView:16') >= 0, '切回: 视口已还原到进入前的 z=16');

// === 防误用：参数缺失应安全返回 false ===
t(showTwinMap('X', null, B1, 1024) === false, 'showTwinMap 缺 imageFile → false');
t(showTwinMap('X', 'a.png', null, 1024) === false, 'showTwinMap 缺 bounds → false');

// === 缩放函数边界 ===
t(typeof _twinZoomFor(50, 23.1291, 1024) === 'number', '_twinZoomFor 返回数字');
t(_twinZoomFor(50, 23.1291, 1024) <= 21, '_twinZoomFor 上限 21', String(_twinZoomFor(50, 23.1291, 1024)));
t(_twinZoomFor(0.001, 23.1291, 1024) >= 13, '_twinZoomFor 下限 13', String(_twinZoomFor(0.001, 23.1291, 1024)));

// === 输出 ===
var out = results.map(function (r) {
    return (r[0] ? 'OK   ' : 'FAIL ') + r[1] + (r[2] ? '   — ' + r[2] : '');
});
console.log(out.join('\n'));
var bad = results.filter(function (r) { return !r[0]; }).length;
console.log('===');
console.log('通过 ' + (results.length - bad) + '/' + results.length);
process.exit(bad ? 1 : 0);
"""


def main():
    if not os.path.isfile(MAP_HTML):
        check(False, "map.html 存在")
        return report(1)

    node = shutil.which("node")
    if not node:
        check(False, "node 可用（必需）")
        return report(1)

    html = open(MAP_HTML, "r", encoding="utf-8").read()
    try:
        block = extract_twin_block(html)
    except SystemExit as exc:
        check(False, "切出孪生 JS 源码", str(exc))
        return report(1)
    check(True, "切出孪生 JS 源码", f"{len(block)} 字符")

    from twin_scene_config import TwinSceneConfig
    cfg = TwinSceneConfig()
    b1 = cfg.bounds_for_js("Level1_Pool")
    # 精简版只随包 Level1_Pool；"切换到大场景"的逻辑用合成边界验证
    b2 = {"bottomLat": 23.1250, "topLat": 23.1332,
          "leftLon": 113.2600, "rightLon": 113.2688}
    if not b1:
        check(False, "读取 Level1_Pool 四角")
        return report(1)
    check(True, "读取 Level1_Pool 四角（大场景用合成边界）")

    js = STUB + "\n" + block + "\n"
    js += TESTS.replace("__BOUNDS_L1__", json.dumps(b1)).replace("__BOUNDS_TEST__",
                                                                 json.dumps(b2))

    tmp = os.path.join(MAP_DIR, "_twin_js_test.js")
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(js)
    try:
        r = subprocess.run([node, tmp], capture_output=True, text=True,
                           timeout=90, encoding="utf-8", errors="replace")
        out = (r.stdout or "").strip()
        if out:
            for line in out.splitlines():
                if line.startswith("OK   "):
                    check(True, line[5:])
                elif line.startswith("FAIL "):
                    check(False, line[5:])
                else:
                    print("  " + line)
        if r.returncode != 0 and not out:
            check(False, "node 执行", (r.stderr or "")[:400])
        rc = r.returncode
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass

    return report(0 if not fails else 1)


def report(rc):
    print()
    print("=" * 72)
    print("通过" if not fails else f"失败 {len(fails)} 项: {fails}")
    return rc


if __name__ == "__main__":
    sys.exit(main())
