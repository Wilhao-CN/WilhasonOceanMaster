# joystick_tester.py — 增强版：诊断所有已连接手柄的详细信息
import pygame
import sys


def test_all_joysticks():
    """扫描并显示所有已连接手柄的详细身份信息"""
    pygame.init()
    pygame.joystick.init()

    joy_count = pygame.joystick.get_count()
    if joy_count == 0:
        print("❌ 未检测到手柄，请确认 USB 已插入！")
        print("   提示：插入后等待 2 秒再运行本工具。")
        return

    print(f"\n{'='*60}")
    print(f"   🎮 检测到 {joy_count} 个手柄")
    print(f"{'='*60}")

    joysticks = []
    for i in range(joy_count):
        joy = pygame.joystick.Joystick(i)
        joy.init()

        name = joy.get_name()
        try:
            guid = joy.get_guid()
        except Exception:
            guid = "N/A"
        try:
            instance_id = joy.get_instance_id()
        except Exception:
            instance_id = "N/A"

        num_axes = joy.get_numaxes()
        num_buttons = joy.get_numbuttons()
        num_hats = joy.get_numhats()
        num_balls = joy.get_numballs()

        joysticks.append(joy)

        print(f"\n  📌 硬件索引 [{i}]")
        print(f"     名称 (Name) : {name}")
        print(f"     GUID        : {guid}")
        print(f"     Instance ID : {instance_id}")
        print(f"     轴数量      : {num_axes}")
        print(f"     按键数量    : {num_buttons}")
        print(f"     十字键(Hat) : {num_hats}")
        print(f"     轨迹球      : {num_balls}")

    # --- 交互式实时监控 ---
    print(f"\n{'='*60}")
    print("   🕹️  实时监控模式 — 拨动摇杆/按键观察输出")
    print(f"{'='*60}")
    print("   提示：哪个手柄动了，下方就会打印对应索引。")
    print("   按 Ctrl+C 退出。")
    print(f"{'='*60}\n")

    try:
        while True:
            for event in pygame.event.get():
                if event.type == pygame.JOYAXISMOTION:
                    if abs(event.value) > 0.3:  # 过滤小抖动
                        joy_idx = _find_joy_index(event, joysticks)
                        name = joysticks[joy_idx].get_name() if joy_idx < len(joysticks) else "?"
                        print(f"🕹️  摇杆 | 索引[{joy_idx}] {name} | 轴{event.axis} | 值: {event.value:+.3f}")

                elif event.type == pygame.JOYBUTTONDOWN:
                    joy_idx = _find_joy_index(event, joysticks)
                    name = joysticks[joy_idx].get_name() if joy_idx < len(joysticks) else "?"
                    print(f"🔘 按下 | 索引[{joy_idx}] {name} | 按键{event.button}")

                elif event.type == pygame.JOYBUTTONUP:
                    joy_idx = _find_joy_index(event, joysticks)
                    name = joysticks[joy_idx].get_name() if joy_idx < len(joysticks) else "?"
                    print(f"🔘 松开 | 索引[{joy_idx}] {name} | 按键{event.button}")

                elif event.type == pygame.JOYHATMOTION:
                    joy_idx = _find_joy_index(event, joysticks)
                    name = joysticks[joy_idx].get_name() if joy_idx < len(joysticks) else "?"
                    print(f"➕ 十字 | 索引[{joy_idx}] {name} | 方向: {event.value}")

            pygame.time.wait(10)

    except KeyboardInterrupt:
        print("\n👋 退出。")
    finally:
        pygame.quit()


def _find_joy_index(event, joysticks):
    """
    通过 event.instance_id 匹配手柄索引。
    Pygame 事件的 instance_id 与 Joystick.get_instance_id() 对应。
    """
    if hasattr(event, 'instance_id'):
        for i, joy in enumerate(joysticks):
            try:
                if joy.get_instance_id() == event.instance_id:
                    return i
            except Exception:
                pass
    # 回退：通过 joy 属性（旧版 pygame）
    if hasattr(event, 'joy') and event.joy < len(joysticks):
        return event.joy
    return -1


if __name__ == "__main__":
    test_all_joysticks()
