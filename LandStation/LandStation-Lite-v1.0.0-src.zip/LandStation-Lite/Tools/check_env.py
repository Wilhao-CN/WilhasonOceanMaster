"""环境自检：不开窗，只做依赖 + Qt 平台/WebEngine 导入链检查。

用法（在工程根目录）：
    venv_usv\\Scripts\\python.exe Tools\\check_env.py

用来确认「环境是否配好」，比直接双击 main.py 更容易定位缺哪个包。
"""
from __future__ import annotations

import os
import sys
import traceback

# 本文件在 Tools/ 下，工程根目录是它的上一级
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, base_dir)
os.chdir(base_dir)

# 与 main.py 保持一致：中文 Windows 控制台默认 GBK，emoji 日志会炸
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
for _name in ("stdout", "stderr"):
    _s = getattr(sys, _name, None)
    if _s is not None and hasattr(_s, "reconfigure"):
        try:
            _s.reconfigure(encoding="utf-8", errors="replace")
        except (ValueError, OSError):
            pass

print(f"python   : {sys.version.split()[0]}")
print(f"exe      : {sys.executable}")
print(f"cwd      : {os.getcwd()}")
print("-" * 70)

# 第三方依赖逐个点名，方便一眼看出缺谁。
# ⚠ 必须与 requirements.txt 保持一致：精简版已删除 scipy / numba（实测全仓零引用），
#   如果把它们留在这里，干净环境安装后会误报"缺少必需依赖"。
THIRD_PARTY = [
    ("PyQt5.QtCore", "PyQt5"),
    ("PyQt5.QtWidgets", "PyQt5"),
    ("PyQt5.QtWebEngineWidgets", "PyQtWebEngine"),
    ("PyQt5.QtWebChannel", "PyQt5"),
    ("pyqtgraph", "pyqtgraph"),
    ("numpy", "numpy"),
    ("cv2", "opencv-python"),
    ("cv2.aruco", "opencv-python (aruco)"),
    ("serial", "pyserial"),
    ("pygame", "pygame"),
]

failed: list[str] = []
for mod, pip_name in THIRD_PARTY:
    try:
        m = __import__(mod, fromlist=["*"])
        ver = getattr(m, "__version__", "")
        print(f"  [ OK ] {mod:<28} {ver}")
    except Exception as exc:  # noqa: BLE001
        failed.append(f"{mod}  (pip install {pip_name})")
        print(f"  [FAIL] {mod:<28} {type(exc).__name__}: {exc}")

print("-" * 70)

# 延迟依赖：不装也能启动，只是对应视觉算法不可用
OPTIONAL = [
    ("ultralytics", "YOLOv8 目标检测"),
]
for mod, purpose in OPTIONAL:
    try:
        m = __import__(mod, fromlist=["*"])
        print(f"  [有] {mod:<14} {getattr(m, '__version__', '')}  -> {purpose}")
    except Exception:  # noqa: BLE001
        print(f"  [无] {mod:<14} 未安装 -> {purpose} 将不可用（不影响启动）")

print("-" * 70)

if failed:
    print("缺少必需依赖，请执行：")
    print("  venv_usv\\Scripts\\python.exe -m pip install -r requirements.txt")
    for item in failed:
        print(f"    - {item}")
    sys.exit(2)

# 用 offscreen 平台真正建一个 QApplication，验证 Qt 插件链是否完整
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
try:
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtCore import QT_VERSION_STR, PYQT_VERSION_STR

    app = QApplication([])
    print(f"Qt {QT_VERSION_STR} / PyQt {PYQT_VERSION_STR} 初始化成功 (offscreen)")
except Exception:  # noqa: BLE001
    print("QApplication 初始化失败：")
    traceback.print_exc()
    sys.exit(3)

# 走一遍真正的导入链，定位 __init__ 阶段的错误
print("-" * 70)
try:
    from ui.main_window import USVGroundStation

    print("ui.main_window          加载成功")
except Exception:  # noqa: BLE001
    detail = traceback.format_exc()
    with open(os.path.join(base_dir, "_smoke_failure.txt"), "w", encoding="utf-8") as fh:
        fh.write(detail)
    print("导入链失败：")
    print(detail)
    sys.exit(4)

print("-" * 70)
print("✅ 环境自检通过")
