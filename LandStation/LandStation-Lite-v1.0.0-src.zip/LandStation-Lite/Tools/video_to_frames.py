# -*- coding: utf-8 -*-
"""把录像视频按帧切分成图片，供 labelme 标注 → YOLO 训练（提高 NOF 识别成功率）。

设计目标（配合本项目的 NOF 检测链路）：
  * 默认扫 records/ 下的全部录像，每 N 帧取一张，输出到 datasets/nof_frames/；
  * 默认开“相似帧去重”，避免黄昏固定机位录像切出几百张几乎一样的图，浪费标注时间；
  * 可选清晰度门槛，先把糊掉的帧滤掉（糊帧对训练只有坏处）；
  * 输出文件名 = 视频名 + 帧号，并同时生成 frames_manifest.csv 记录
    图片 ↔ 视频 ↔ 帧号 ↔ 时间戳，方便回溯对齐 data_logs/ 里的遥测。

用法示例：
    python Tools/video_to_frames.py                      # 默认：records/ 每秒 10 张
    python Tools/video_to_frames.py --dry-run            # 只看会切出多少张，不写文件
    python Tools/video_to_frames.py --fps 2              # 采样变稀（每秒 2 张）
    python Tools/video_to_frames.py --every 10           # 按帧间隔采样（每 10 帧一张）
    python Tools/video_to_frames.py --start 00:10 --end 00:40   # 只切某一段时间
    python Tools/video_to_frames.py --per-video          # 每段视频一个子目录
    python Tools/video_to_frames.py --input records/dock_video_20260912_182804.mp4

下一步（标注 → 训练）：
    1) 用 labelme 打开输出目录逐张标框，类别统一填 NOF；
    2) 若用 Tools/labelme2yolo.py 转换，记得把里面的 LABEL_MAP 改成 {"NOF": 0}；
    3) 生成的 data.yaml 喂给 ultralytics 训练，训练完把 best.pt 放回
       vision/algorithms/yolo_v8/ 。
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
import time
from typing import List, Optional

import cv2
import numpy as np

try:  # Windows 控制台/重定向到文件时避免 emoji 报编码错
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # pragma: no cover - 老版本 Python 或特殊终端
    pass

# ===================== 默认路径 / 常量 =====================
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_INPUT = os.path.join(PROJECT_ROOT, "records")
DEFAULT_OUTPUT = os.path.join(PROJECT_ROOT, "datasets", "nof_frames")

VIDEO_EXTS = (".mp4", ".avi", ".mov", ".mkv", ".m4v", ".wmv", ".flv", ".ts", ".mpg", ".mpeg")
DEFAULT_FPS_FALLBACK = 20.0   # 与地面站录像 writer 的 fps 一致（video_thread.py 默认 20）
DEDUP_SIZE = (64, 48)         # 相似度比较用的缩略图尺寸 (w, h)
MANIFEST_NAME = "frames_manifest.csv"
MANIFEST_FIELDS = ["image", "video", "frame_index", "time_s", "width", "height"]


# ===================== 工具函数 =====================
def parse_time(text: str) -> float:
    """接受 12.5 / 00:12 / 00:00:12 三种写法，统一返回秒。"""
    text = str(text).strip()
    if not text:
        return 0.0
    parts = text.split(":")
    if len(parts) > 3:
        raise argparse.ArgumentTypeError(f"时间格式无法解析: {text}")
    try:
        values = [float(p) for p in parts]
    except ValueError:
        raise argparse.ArgumentTypeError(f"时间格式无法解析: {text}")
    if len(values) == 1:
        return values[0]
    if len(values) == 2:
        return values[0] * 60.0 + values[1]
    return values[0] * 3600.0 + values[1] * 60.0 + values[2]


def format_hms(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    m, s = divmod(seconds, 60.0)
    h, m = divmod(int(m), 60)
    return f"{h:d}:{m:02d}:{s:05.2f}" if h else f"{m:02d}:{s:05.2f}"


def is_video_file(path: str) -> bool:
    return os.path.isfile(path) and os.path.splitext(path)[1].lower() in VIDEO_EXTS


def collect_videos(inputs: List[str], recursive: bool) -> List[str]:
    """把命令行给的目录/文件展开成视频文件列表（去重、按名排序）。"""
    found: List[str] = []
    for item in inputs:
        item = os.path.abspath(item)
        if os.path.isfile(item):
            if is_video_file(item):
                found.append(item)
            else:
                print(f"⚠️  不是支持的视频文件，已忽略: {item}")
            continue
        if not os.path.isdir(item):
            print(f"⚠️  路径不存在，已忽略: {item}")
            continue
        if recursive:
            for root, _dirs, files in os.walk(item):
                found.extend(os.path.join(root, f) for f in files if is_video_file(os.path.join(root, f)))
        else:
            found.extend(
                os.path.join(item, f) for f in os.listdir(item) if is_video_file(os.path.join(item, f))
            )
    return sorted(set(found))


def save_jpeg(path: str, frame: np.ndarray, quality: int) -> bool:
    """写 JPEG。用 imencode + 二进制写盘，避免 cv2.imwrite 在中文路径下静默失败。"""
    ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)])
    if not ok:
        return False
    with open(path, "wb") as f:
        f.write(buf.tobytes())
    return True


def dedup_thumb(gray: np.ndarray) -> np.ndarray:
    return cv2.resize(gray, DEDUP_SIZE, interpolation=cv2.INTER_AREA).astype(np.int16)


def thumb_diff(a: Optional[np.ndarray], b: np.ndarray) -> float:
    """归一化平均绝对差 (0~1)。越大表示两张图差别越大。"""
    if a is None:
        return 1.0
    return float(np.mean(np.abs(a - b))) / 255.0


# ===================== 单段视频切分 =====================
def extract_video(
    video_path: str,
    out_dir: str,
    args: argparse.Namespace,
) -> dict:
    """切分一段视频，返回统计信息。"""
    stem = os.path.splitext(os.path.basename(video_path))[0]
    target_dir = os.path.join(out_dir, stem) if args.per_video else out_dir
    if not args.dry_run:
        os.makedirs(target_dir, exist_ok=True)

    stats = {
        "video": os.path.basename(video_path),
        "fps": 0.0,
        "total": 0,
        "size": "-",
        "kept": 0,
        "dup": 0,
        "blur": 0,
        "exists": 0,
        "error": "",
        "rows": [],
    }

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        stats["error"] = "无法打开（编码不支持或文件损坏）"
        return stats

    try:
        fps = cap.get(cv2.CAP_PROP_FPS)
        if not fps or not np.isfinite(fps) or fps <= 0.5:
            fps = DEFAULT_FPS_FALLBACK
        stats["fps"] = float(fps)

        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        stats["total"] = total

        # 采样步长：--every 优先；否则按 --fps 折算
        if args.every and args.every > 0:
            step = int(args.every)
        else:
            step = max(1, int(round(fps / max(args.fps, 0.01))))

        start_frame = int(round(args.start * fps)) if args.start else 0
        end_frame = int(round(args.end * fps)) if args.end else None

        index = 0
        last_thumb: Optional[np.ndarray] = None
        next_report = time.time() + 2.0

        while True:
            if not cap.grab():           # grab 只解封装，不做色彩转换，抽样时快很多
                break
            if end_frame is not None and index >= end_frame:
                break
            if index < start_frame:
                index += 1
                continue
            if (index - start_frame) % step != 0:
                index += 1
                continue

            ok, frame = cap.retrieve()
            if not ok or frame is None:
                index += 1
                continue

            if stats["size"] == "-":
                h, w = frame.shape[:2]
                stats["size"] = f"{w}x{h}"

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # 1) 清晰度门槛（可选）：Laplacian 方差越小越糊
            if args.min_sharpness > 0:
                sharpness = float(cv2.Laplacian(gray, cv2.CV_64F).var())
                if sharpness < args.min_sharpness:
                    stats["blur"] += 1
                    index += 1
                    continue

            # 2) 相似帧去重（默认开）：与上一张“已保留”的帧比较
            thumb = dedup_thumb(gray)
            if args.dedup > 0 and thumb_diff(last_thumb, thumb) < args.dedup:
                stats["dup"] += 1
                index += 1
                continue

            last_thumb = thumb
            filename = f"{stem}_{index:06d}.jpg"
            filepath = os.path.join(target_dir, filename)

            if os.path.exists(filepath) and not args.force:
                stats["exists"] += 1
            else:
                if not args.dry_run and not save_jpeg(filepath, frame, args.quality):
                    stats["error"] = "写图失败"
                    break
                stats["kept"] += 1
                stats["rows"].append(
                    {
                        "image": os.path.relpath(filepath, out_dir).replace(os.sep, "/"),
                        "video": os.path.basename(video_path),
                        "frame_index": index,
                        "time_s": f"{index / fps:.3f}",
                        "width": frame.shape[1],
                        "height": frame.shape[0],
                    }
                )

            if args.max_frames and (stats["kept"] + stats["exists"]) >= args.max_frames:
                break

            if not args.quiet and time.time() >= next_report:
                next_report = time.time() + 2.0
                print(
                    f"\r    … {stats['video']} 帧 {index}"
                    f"{'/' + str(total) if total else ''} 已取 {stats['kept']}",
                    end="",
                    flush=True,
                )

            index += 1
    finally:
        cap.release()

    if not args.quiet:
        print("\r" + " " * 60 + "\r", end="")
    return stats


# ===================== 主流程 =====================
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="把录像视频按帧切分成图片（用于 labelme 标注 → YOLO 训练）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--input", "-i", nargs="+", default=[DEFAULT_INPUT],
                   help=f"视频目录或文件，可给多个（默认: {DEFAULT_INPUT}）")
    p.add_argument("--output", "-o", default=DEFAULT_OUTPUT,
                   help=f"图片输出目录（默认: {DEFAULT_OUTPUT}）")
    p.add_argument("--every", "-e", type=int, default=0,
                   help="每 N 帧取一张（默认 0=不按帧间隔；此时用 --fps 控制每秒张数）")
    p.add_argument("--fps", type=float, default=10.0,
                   help="按每秒 N 张采样（默认 10；仅当 --every 为 0 时生效）")
    p.add_argument("--start", type=parse_time, default=0.0, help="起始时间，如 12.5 / 00:12")
    p.add_argument("--end", type=parse_time, default=0.0, help="结束时间（不含），如 00:40")
    p.add_argument("--max-frames", type=int, default=0, help="每段视频最多导出多少张（0=不限）")
    p.add_argument("--dedup", type=float, default=0.012,
                   help="相似帧去重阈值 0~1，越大丢得越多（默认 0.012；设 0 关闭）")
    p.add_argument("--min-sharpness", type=float, default=0.0,
                   help="清晰度门槛（Laplacian 方差），低于它的糊帧丢弃（默认 0=不过滤）")
    p.add_argument("--quality", "-q", type=int, default=95, help="JPEG 质量 1~100（默认 95）")
    p.add_argument("--per-video", action="store_true", help="每段视频单独一个子目录")
    p.add_argument("--recursive", action="store_true", help="递归扫描输入目录")
    p.add_argument("--force", action="store_true", help="覆盖已存在的图片（默认跳过，可断点续切）")
    p.add_argument("--dry-run", action="store_true", help="只统计不写图")
    p.add_argument("--quiet", "-Q", action="store_true", help="不打印进度")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    if args.every and args.every < 0:
        print("❌ --every 不能为负")
        return 2
    if not args.every and args.fps <= 0:
        print("❌ --every 为 0 时必须用 --fps 指定每秒采样数")
        return 2
    if args.end and args.end <= args.start:
        print("❌ --end 必须大于 --start")
        return 2

    videos = collect_videos(args.input, args.recursive)
    if not videos:
        print(f"❌ 没找到视频文件。输入: {', '.join(os.path.abspath(i) for i in args.input)}")
        print(f"   支持的扩展名: {', '.join(VIDEO_EXTS)}")
        return 1

    out_dir = os.path.abspath(args.output)
    if not args.dry_run:
        os.makedirs(out_dir, exist_ok=True)

    print("=" * 78)
    print(f"🎬 视频切帧{'（dry-run，只统计不写图）' if args.dry_run else ''}")
    print(f"   输入: {len(videos)} 段视频")
    print(f"   输出: {out_dir}")
    print(f"   采样: " + (f"每 {args.every} 帧一张" if args.every else f"每秒 {args.fps:g} 张"))
    if args.start or args.end:
        print(f"   区间: {format_hms(args.start)} ~ {format_hms(args.end) if args.end else '结尾'}")
    if args.dedup > 0:
        print(f"   去重: 阈值 {args.dedup:g}（与上一张保留帧比较）")
    if args.min_sharpness > 0:
        print(f"   清晰度: Laplacian 方差 ≥ {args.min_sharpness:g}")
    print("=" * 78)

    all_rows: List[dict] = []
    totals = {"kept": 0, "dup": 0, "blur": 0, "exists": 0, "frames": 0}
    t0 = time.time()

    for i, video in enumerate(videos, 1):
        print(f"[{i}/{len(videos)}] {os.path.basename(video)}")
        stats = extract_video(video, out_dir, args)
        totals["kept"] += stats["kept"]
        totals["dup"] += stats["dup"]
        totals["blur"] += stats["blur"]
        totals["exists"] += stats["exists"]
        totals["frames"] += stats["total"]
        all_rows.extend(stats["rows"])

        if stats["error"]:
            print(f"    ❌ {stats['error']}")
        else:
            extra = []
            if stats["exists"]:
                extra.append(f"已存在跳过 {stats['exists']}")
            if stats["dup"]:
                extra.append(f"相似丢弃 {stats['dup']}")
            if stats["blur"]:
                extra.append(f"糊帧丢弃 {stats['blur']}")
            print(
                f"    ✅ 输出 {stats['kept']} 张 | 源 {stats['size']} {stats['fps']:.2f}fps "
                f"{stats['total'] or '?'} 帧"
                + (" | " + " | ".join(extra) if extra else "")
            )

    # 清单：记录 图片 ↔ 视频 ↔ 帧号 ↔ 时间戳，便于和 data_logs 对齐
    if not args.dry_run and all_rows:
        manifest = os.path.join(out_dir, MANIFEST_NAME)
        write_header = not os.path.exists(manifest)
        with open(manifest, "a", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=MANIFEST_FIELDS)
            if write_header:
                writer.writeheader()
            writer.writerows(all_rows)
        print(f"\n📄 清单已追加: {manifest}")

    print("\n" + "=" * 78)
    print(f"📦 合计: 导出 {totals['kept']} 张"
          f"（跳过已存在 {totals['exists']}，相似丢弃 {totals['dup']}，糊帧丢弃 {totals['blur']}）"
          f" | 源视频共 {totals['frames']} 帧 | 耗时 {time.time() - t0:.1f}s")

    if args.dry_run:
        print("（dry-run：没有写任何图片。去掉 --dry-run 即正式导出）")
    elif totals["kept"]:
        print("\n下一步:")
        print(f"  1) labelme 打开 {out_dir} 逐张标框，类别填 NOF")
        print("  2) 转换时把 Tools/labelme2yolo.py 的 LABEL_MAP 改成 {\"NOF\": 0}，"
              "并改对 JSON_DIR / OUT_DIR")
        print("  3) ultralytics 训练完把 best.pt 放回 vision/algorithms/yolo_v8/")
        print("  ℹ️ 没有 NOF 的背景帧也有用（负样本），别全删。")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
