#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""回归自检：`Tools/trace_path_following.py` 对外公布的数字是否漂移。

这些数字已经**写进给 Unity 的 v12 答复文档**，一旦控制链路被改动，
它们就会变。此脚本把文档里的每个关键数字钉成断言，防止"文档说的"
和"代码实际算的"悄悄分家。

用法：
    python Tools/verify_trace_tool.py
退出码 0 = 全部通过。
"""
import importlib.util
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

PASS = 0
FAIL = 0


def check(label, got, want, tol=0.0):
    global PASS, FAIL
    if tol:
        ok = abs(float(got) - float(want)) <= tol
    else:
        ok = got == want
    if ok:
        PASS += 1
        print(f"  OK   {label}   — {got}")
    else:
        FAIL += 1
        print(f"  FAIL {label}   — 实际 {got} / 期望 {want}")


def load_tool():
    path = os.path.join(ROOT, "Tools", "trace_path_following.py")
    spec = importlib.util.spec_from_file_location("trace_tool", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    # ⚠ 顺序要紧：先导入工具（它会把 sys.stdout 换成 UTF-8 wrapper），
    #   再用 reconfigure 就地调整，**不要**自己造第二个 TextIOWrapper ——
    #   那样旧 wrapper 被 GC 时会连带关掉底层 buffer（ValueError: closed file）。
    tt = load_tool()
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

    # ---------------- 1. ratio 限幅（文档 §A1 附注） ----------------
    print("=== 1. ratio 限幅 ===")
    check("小船 主推 [ch1,4]", tt.get_thruster_ratio_limits(0x02, [1, 4]),
          (-0.5, 0.75))
    check("小船 转向 [ch2,3]", tt.get_thruster_ratio_limits(0x02, [2, 3]),
          (-0.25, 0.25))
    check("船坞 主推 [ch1,4]", tt.get_thruster_ratio_limits(0x01, [1, 4]),
          (-1.25, 1.25))
    check("船坞 转向 [ch2,3]", tt.get_thruster_ratio_limits(0x01, [2, 3]),
          (-0.5, 0.5))

    # ---------------- 2. 推力上限（文档 §C3） ----------------
    print("=== 2. 推力上限（纵向总推力 = 2 × ratio × MAX_FORCE）===")
    f_pos = tt.USVProtocol._MAX_FORCE_POS
    f_neg = tt.USVProtocol._MAX_FORCE_NEG
    check("_MAX_FORCE_POS", f_pos, 9.5974, tol=1e-6)
    check("_MAX_FORCE_NEG", f_neg, 9.2045, tol=1e-6)
    check("小船 PID 推力上限", f"{2*0.75*f_pos:+.2f}/{2*-0.5*f_neg:+.2f}",
          "+14.40/-9.20")
    check("船坞 PID 推力上限", f"{2*1.25*f_pos:+.2f}/{2*-1.25*f_neg:+.2f}",
          "+23.99/-23.01")
    check("船坞手动推力上限", f"{2*1.0*f_pos:+.2f}/{2*-1.0*f_neg:+.2f}",
          "+19.19/-18.41")

    # ---------------- 3. PID 饱和临界角（文档 §E.6） ----------------
    print("=== 3. 转向饱和临界误差角 ===")
    g_boat = tt.HEADING_KP / 100.0 * tt.BOAT_STEER_ATTENUATION   # ratio/度
    g_dock = tt.HEADING_KP / 100.0 * tt.DOCK_STEER_ATTENUATION
    check("小船 临界角(°)", 0.25 / g_boat, 11.1, tol=0.05)
    check("船坞 临界角(°)", 0.50 / g_dock, 16.7, tol=0.05)

    # ---------------- 4. CSV 列顺序 = Unity E 题清单 ----------------
    print("=== 4. CSV 前 13 列顺序 ===")
    cfg = tt.TwinSceneConfig()
    lv = cfg.get("Level1_Pool")
    geo = tt.Geo(lv["originLat"], lv["originLon"])
    want_cols = ["t", "lat_mid", "lon_mid", "heading", "target_heading",
                 "target_speed", "v_now", "r_main", "r_steer",
                 "pwm1", "pwm2", "pwm3", "pwm4"]

    boat_rows = None
    for ship, expect_steer in (("boat", 0.25), ("dock", 0.50)):
        coords = tt.default_mission(geo, "lshape")
        rows = tt.run_trace(ship, geo, coords)
        if ship == "boat":
            boat_rows = rows
        check(f"{ship} lshape 前13列",
              list(rows[0].keys())[:13], want_cols)

        # ---------------- 5. 直角切换帧（文档 §E.5 锚点） ----------------
        # 找到 wp_index 由 1 变 2 的那一帧
        idx = None
        for i in range(1, len(rows)):
            if (int(rows[i]["wp_index"]) == 2
                    and int(rows[i - 1]["wp_index"]) == 1):
                idx = i
                break
        if idx is None:
            check(f"{ship} 找到直角切换帧", None, "存在")
            continue
        prev, cur = rows[idx - 1], rows[idx]
        check(f"{ship} 切换帧 frame 号", cur["frame"], 435)
        check(f"{ship} 切换前 target_heading", prev["target_heading"], 0.0)
        check(f"{ship} 切换帧 target_heading", cur["target_heading"],
              82.555, tol=0.01)
        check(f"{ship} 切换帧 r_steer(满舵)", cur["r_steer"], expect_steer)

        # ---------------- 6. 到点帧必须中性（文档 §D3 附注） ----------------
        last = rows[-1]
        check(f"{ship} 末帧 note", last["note"], "stop_mission")
        check(f"{ship} 末帧 r_main/r_steer 归零",
              (last["r_main"], last["r_steer"]), (0.0, 0.0))
        check(f"{ship} 末帧 PWM 全 1500",
              (last["pwm1"], last["pwm2"], last["pwm3"], last["pwm4"]),
              (1500, 1500, 1500, 1500))
        check(f"{ship} 末帧 finished", last["finished"], True)

    # ---------------- 7. 折角处不减速（文档 §D2） ----------------
    print("=== 7. 折角处不减速（窗口内 target_speed 恒定 0.3）===")
    if boat_rows:
        win = [r["target_speed"] for r in boat_rows[425:495]]
        check("窗口内 target_speed 唯一值", set(win), {0.3})

    print()
    print(f"通过 {PASS} 项，失败 {FAIL} 项")
    print("全部通过" if FAIL == 0 else "有失败项")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
