#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
导入 Unity 的正交俯视底图（schema: digitaltwin/ortho-map/v1）
==============================================================

Unity 的 `Tools/DigitalTwin/9.` 工具一次输出 **PNG + JSON**；
本脚本把该 JSON 转成地面站使用的 `ui/map/twin_maps/scenes.json` 条目，
并把图片拷入 `ui/map/twin_maps/`。

用法
----
    # 只导入 JSON（图片保持不动）
    python Tools/import_unity_ortho.py <路径>/Level1_Pool_ortho_2048x2048.json

    # 同时导入图片（PNG 或 JPG 均可）
    python Tools/import_unity_ortho.py <路径>/xxx.json --image <路径>/xxx.png

    # 只看会写什么，不落盘
    python Tools/import_unity_ortho.py <json> --dry-run

设计要点
--------
* **四角以 Unity 的 JSON 为权威**（它是相机实测值），但脚本会**用我方自己的
  等距圆柱实现独立复算一遍**并报告偏差 —— 两边不一致时立刻能看出来。
* 合并写入 `scenes.json`，**不影响其它关卡**。
* 幂等：同一关卡重复导入会覆盖该条目，不产生重复。
* 不改任何 Python 业务代码 —— 地面站读取的是同一个 `scenes.json`。
"""

import argparse
import json
import math
import os
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_OUT_DIR = os.path.join(ROOT, "ui", "map", "twin_maps")

SUPPORTED_SCHEMA = "digitaltwin/ortho-map/v1"
_M_PER_DEG_LAT = 111320.0

# 我方内部字段的顺序（用于输出美观，非必需）
_FIELD_ORDER = ["scene", "image", "width", "height",
                "topLat", "bottomLat", "leftLon", "rightLon",
                "sceneExtentMeters", "navigableRadiusMeters", "boundsShape",
                "originLat", "originLon", "isDemoOnly", "note"]


# --------------------------------------------------------------------------
# 读取
# --------------------------------------------------------------------------

def load_unity_json(path):
    if not os.path.isfile(path):
        raise SystemExit(f"[错误] 找不到 JSON: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    schema = data.get("schema")
    if schema != SUPPORTED_SCHEMA:
        print(f"[警告] schema = {schema!r}，期望 {SUPPORTED_SCHEMA!r} —— 仍尝试解析")

    for key in ("scene", "png", "geoReference", "corners", "extent"):
        if key not in data:
            raise SystemExit(f"[错误] JSON 缺少必需字段: {key}")
    return data


def to_internal(uj, image_name=None):
    """Unity JSON → 我方 scenes.json 条目。"""
    c = uj["corners"]
    tl, tr, br, bl = c["topLeft"], c["topRight"], c["bottomRight"], c["bottomLeft"]
    gr = uj["geoReference"]
    png = uj["png"]
    ext = uj["extent"]

    # 一致性自检（同一行/列的四角坐标应当相等）
    problems = []
    if tl["lat"] != tr["lat"]:
        problems.append(f"topLeft.lat({tl['lat']}) != topRight.lat({tr['lat']})")
    if bl["lat"] != br["lat"]:
        problems.append(f"bottomLeft.lat({bl['lat']}) != bottomRight.lat({br['lat']})")
    if tl["lon"] != bl["lon"]:
        problems.append(f"topLeft.lon({tl['lon']}) != bottomLeft.lon({bl['lon']})")
    if tr["lon"] != br["lon"]:
        problems.append(f"topRight.lon({tr['lon']}) != bottomRight.lon({br['lon']})")

    # 米/像素 与 extent 是否自洽
    mppx = uj.get("projection", {}).get("metersPerPixelX")
    mppy = uj.get("projection", {}).get("metersPerPixelY")
    if mppx and png.get("width"):
        calc = mppx * png["width"]
        if abs(calc - ext["eastWestMeters"]) > 0.05:
            problems.append(f"metersPerPixelX×W = {calc:g} != extent {ext['eastWestMeters']:g}")
    if mppy and png.get("height"):
        calc = mppy * png["height"]
        if abs(calc - ext["northSouthMeters"]) > 0.05:
            problems.append(f"metersPerPixelY×H = {calc:g} != extent {ext['northSouthMeters']:g}")

    if image_name is None:
        image_name = os.path.basename(png.get("file") or f"{uj['scene']}.png")

    # navigableRadiusMeters：Unity 的 ortho schema 里没有；
    # 我方保留为"信息标注"（当前不参与拒绝，见 scenes.json 的 boundsShape=square）
    nav = uj.get("navigableRadiusMeters")
    if nav is None:
        nav = uj.get("_groundstationNavigableRadiusMeters")

    entry = {
        "scene": uj["scene"],
        "image": image_name,
        "width": int(png.get("width") or 0),
        "height": int(png.get("height") or 0),
        "topLat": float(tl["lat"]),
        "bottomLat": float(bl["lat"]),
        "leftLon": float(tl["lon"]),
        "rightLon": float(tr["lon"]),
        "sceneExtentMeters": float(ext["eastWestMeters"]),
        "boundsShape": "square",
        "originLat": float(gr["lat0"]),
        "originLon": float(gr["lon0"]),
        "isDemoOnly": bool(gr.get("isDemoOnly", True)),
    }
    if nav is not None:
        entry["navigableRadiusMeters"] = float(nav)

    note = (f"Unity 正交俯视底图（{uj.get('schema')}，{png.get('width')}×{png.get('height')}）"
            f"；底图 {ext['eastWestMeters']:g}×{ext['northSouthMeters']:g} m"
            f"；origin=({gr['lat0']}, {gr['lon0']}) isDemoOnly={gr.get('isDemoOnly')}")
    if uj.get("note"):
        note += "；" + str(uj["note"])
    entry["note"] = note

    return entry, problems


# --------------------------------------------------------------------------
# 独立复算（用我方自己的等距圆柱，交叉验证 Unity 的四角）
# --------------------------------------------------------------------------

def recompute_corners(origin_lat, origin_lon, half_w, half_h):
    """由 origin + 半宽/半高（米）算出四角经纬度（我方实现）。"""
    def lat_of(dz):
        return origin_lat + dz / _M_PER_DEG_LAT

    def lon_of(dx):
        return origin_lon + dx / (_M_PER_DEG_LAT * math.cos(math.radians(origin_lat)))

    return {
        "topLat": lat_of(+half_h), "bottomLat": lat_of(-half_h),
        "leftLon": lon_of(-half_w), "rightLon": lon_of(+half_w),
    }


def verify_corners(entry):
    """返回 [(字段, 我方值, Unity值, 偏差米)]。"""
    half_w = entry["sceneExtentMeters"] / 2.0
    # 南北跨度由纬度差反推，避免依赖额外字段
    half_h = (entry["topLat"] - entry["bottomLat"]) * _M_PER_DEG_LAT / 2.0
    mine = recompute_corners(entry["originLat"], entry["originLon"], half_w, half_h)

    cos_lat = math.cos(math.radians(entry["originLat"]))
    rows = []
    for k in ("topLat", "bottomLat"):
        d_deg = abs(mine[k] - entry[k])
        rows.append((k, mine[k], entry[k], d_deg * _M_PER_DEG_LAT))
    for k in ("leftLon", "rightLon"):
        d_deg = abs(mine[k] - entry[k])
        rows.append((k, mine[k], entry[k], d_deg * _M_PER_DEG_LAT * cos_lat))
    return rows


# --------------------------------------------------------------------------
# 合并写入
# --------------------------------------------------------------------------

def load_scenes(path):
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return list(json.load(fh).get("levels", []) or [])
    except (OSError, ValueError) as exc:
        print(f"[警告] 现有 scenes.json 读取失败，将重建: {exc}")
        return []


def order_entry(entry):
    out = {}
    for k in _FIELD_ORDER:
        if k in entry:
            out[k] = entry[k]
    for k, v in entry.items():
        if k not in out:
            out[k] = v
    return out


def merge(levels, entry):
    """按 scene 覆盖或追加，保持原有顺序。"""
    out, replaced = [], False
    for lv in levels:
        if lv.get("scene") == entry["scene"]:
            out.append(entry)
            replaced = True
        else:
            out.append(lv)
    if not replaced:
        out.append(entry)
    return out


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="导入 Unity 正交俯视底图 JSON（digitaltwin/ortho-map/v1）")
    ap.add_argument("json_path", help="Unity 导出的 *_ortho_*.json")
    ap.add_argument("--image", help="配套的 PNG/JPG 路径（可选；给了就拷贝）")
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR,
                    help=f"底图目录（默认 {os.path.relpath(DEFAULT_OUT_DIR, ROOT)}）")
    ap.add_argument("--keep-nav-radius", type=float,
                    help="保留/写入 navigableRadiusMeters（信息标注用，不参与拒绝）")
    ap.add_argument("--dry-run", action="store_true", help="只打印，不写文件")
    args = ap.parse_args()

    print("=" * 72)
    print("导入 Unity 正交俯视底图")
    print("=" * 72)

    uj = load_unity_json(args.json_path)
    print(f"  schema      : {uj.get('schema')}")
    print(f"  scene       : {uj['scene']}")
    print(f"  generatedAt : {uj.get('generatedAtUtc')}")
    print(f"  playMode    : {uj.get('playMode')}")
    print(f"  UI 可见     : {uj.get('uiVisible')} | 船可见: {uj.get('vesselsVisible')}")
    print()

    # 图片名：以 JSON 的 file 为准；若本地给了 image 就用它的扩展名
    image_name = os.path.basename(uj["png"].get("file") or f"{uj['scene']}.png")
    if args.image:
        image_name = os.path.basename(args.image)

    entry, problems = to_internal(uj, image_name)
    if args.keep_nav_radius is not None:
        entry["navigableRadiusMeters"] = args.keep_nav_radius
    elif "navigableRadiusMeters" not in entry:
        # 兜底：从现有 scenes.json 继承（保持信息标注不丢）
        scenes_path0 = os.path.join(args.out_dir, "scenes.json")
        for lv in load_scenes(scenes_path0):
            if lv.get("scene") == entry["scene"] and "navigableRadiusMeters" in lv:
                entry["navigableRadiusMeters"] = lv["navigableRadiusMeters"]
                break

    print("--- 解析出的内部条目 ---")
    for k in _FIELD_ORDER:
        if k in entry:
            print(f"  {k:24} = {entry[k]}")
    print()

    print("--- 一致性自检 ---")
    if problems:
        for p in problems:
            print(f"  ⚠️  {p}")
    else:
        print("  ✅ 四角同行/同列一致；metersPerPixel×边长 = extent")
    print()

    print("--- 四角独立复算（我方等距圆柱 vs Unity 相机实测）---")
    worst = 0.0
    for name, mine, theirs, d_m in verify_corners(entry):
        worst = max(worst, d_m)
        flag = "✅" if d_m < 0.01 else ("⚠️" if d_m < 1.0 else "❌")
        print(f"  {flag} {name:10} 我方={mine:.12f}  Unity={theirs:.12f}  Δ={d_m*1000:.3f} mm")
    print(f"  → 最大偏差 {worst*1000:.3f} mm  "
          f"({'两边投影实现一致 ✔' if worst < 0.01 else '存在偏差，请核对 origin/范围'})")
    print()

    scenes_path = os.path.join(args.out_dir, "scenes.json")

    # 拷图片
    if args.image:
        src = os.path.abspath(args.image)
        if not os.path.isfile(src):
            raise SystemExit(f"[错误] 找不到图片: {src}")
        dst = os.path.abspath(os.path.join(args.out_dir, image_name))
        print(f"--- 拷贝图片 ---\n  {src}\n    → {dst}")
        if src == dst:
            print("  （源与目标相同，跳过拷贝 —— 文件已在位）")
        elif args.dry_run:
            pass
        else:
            os.makedirs(args.out_dir, exist_ok=True)
            try:
                shutil.copy2(src, dst)
            except shutil.SameFileError:
                print("  （同一文件，跳过）")
        print()

    # 写 scenes.json
    levels = load_scenes(scenes_path)
    before = len(levels)
    levels = merge(levels, order_entry(entry))
    print(f"--- 写入 scenes.json ---")
    print(f"  路径   : {scenes_path}")
    print(f"  关卡数 : {before} → {len(levels)}   （覆盖/新增: {entry['scene']}）")
    if args.dry_run:
        print("\n(--dry-run：未写盘)")
    else:
        os.makedirs(args.out_dir, exist_ok=True)
        with open(scenes_path, "w", encoding="utf-8") as fh:
            json.dump({"levels": levels}, fh, ensure_ascii=False, indent=2)
        print("\n✅ 完成。地面站无需改代码 —— 重启或重选关卡即生效。")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    sys.exit(main())
