#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T4 验证：TwinSceneConfig 关卡配置读取（纯 Python，无需 Qt）。

覆盖：
  * 正常读取随包关卡（精简版只有 Level1_Pool）、四角/形状/半径/原点
  * navigableRadiusMeters 缺失时的三级回退
  * 多关卡场景用**测试夹具**验证（保证"菜单按 JSON 动态生成"这条规格仍有覆盖）
  * 字段不完整的条目被跳过（避免位置算错）
  * 配置文件缺失/损坏时安全降级（levels 为空，不抛异常）
用法： python Tools/verify_twin_config.py
"""
import io
import json
import os
import sys
import tempfile

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "ui", "map"))

from twin_scene_config import TwinSceneConfig  # noqa: E402

fails = []


def check(ok, label, detail=""):
    print(("  OK   " if ok else "  FAIL ") + label + (("   — " + detail) if detail else ""))
    if not ok:
        fails.append(label)


def tmp_cfg(payload, name, is_path=False):
    """写一份临时关卡配置；is_path=True 时直接把 payload 当路径返回。"""
    if is_path:
        return payload
    p = os.path.join(tempfile.gettempdir(), name)
    with open(p, "w", encoding="utf-8") as fh:
        if isinstance(payload, str):
            fh.write(payload)
        else:
            json.dump(payload, fh, ensure_ascii=False)
    return p


def main():
    print("=== 随包配置（精简版：1 个关卡）===")
    cfg = TwinSceneConfig()
    check(cfg.available(), "配置可用")
    check(cfg.names() == ["Level1_Pool"],
          "关卡拉表 = JSON 顺序（精简版只保留 Level1_Pool）", str(cfg.names()))
    check("Level2_WindFarm" not in cfg.names(),
          "第 2 关已按裁决移除", str(cfg.names()))

    b = cfg.bounds_for_js("Level1_Pool")
    check(b is not None and set(b) == {"topLat", "bottomLat", "leftLon", "rightLon"},
          "bounds_for_js 返回四角", str(sorted(b or {})))
    check(all(isinstance(v, float) for v in (b or {}).values()), "四角均为 float")
    check((b or {}).get("topLat", 0) > (b or {}).get("bottomLat", 0), "topLat > bottomLat")

    # 图片名/分辨率是**数据驱动**的：L1 现在是 Unity 的 2048² 正交底图，
    # 将来换成 4096² 也只改 scenes.json，故此断言只校验"与 JSON 一致"，
    # 不硬编码具体像素数（避免每次重导出都要改测试）。
    l1 = cfg.get("Level1_Pool") or {}
    img = cfg.image_for("Level1_Pool")
    check(isinstance(img, str) and img.lower().endswith((".png", ".jpg", ".jpeg")),
          "image_for 返回图片名", str(img))
    check(cfg.image_px("Level1_Pool") == max(int(l1.get("width", 0)),
                                             int(l1.get("height", 0))),
          "image_px = JSON 里的 max(width,height)",
          f"{cfg.image_px('Level1_Pool')} (width={l1.get('width')}, height={l1.get('height')})")
    check(cfg.image_px("Level1_Pool") >= 1024, "image_px ≥ 1024（底图分辨率够用）",
          str(cfg.image_px("Level1_Pool")))

    check(cfg.bounds_shape("Level1_Pool") == "square",
          "L1 形状 = square（v5：只看是否超出底图范围）")
    check(cfg.navigable_radius("Level1_Pool") == 22.0,
          "L1 可航半径 = 22（**仅信息标注，不用于拒绝**）",
          str(cfg.navigable_radius("Level1_Pool")))
    check(l1.get("sceneExtentMeters") == 100.0,
          "L1 sceneExtentMeters = 100（±50，= Terrain 实际大小）",
          str(l1.get("sceneExtentMeters")))
    check(cfg.origin("Level1_Pool") == (23.1291, 113.2644), "origin 正确",
          str(cfg.origin("Level1_Pool")))
    check(cfg.describe("Level1_Pool") != "", "describe 非空", cfg.describe("Level1_Pool"))
    check(cfg.get("不存在") is None, "未知关卡返回 None")

    print()
    print("=== 多关卡能力（用夹具验证：菜单仍按 JSON 动态生成）===")
    p = tmp_cfg({"levels": [
        {"scene": "A", "image": "a.png", "topLat": 1.0, "bottomLat": 0.0,
         "leftLon": 0.0, "rightLon": 1.0, "sceneExtentMeters": 100.0,
         "navigableRadiusMeters": 22.0, "boundsShape": "square"},
        {"scene": "B", "image": "b.png", "topLat": 2.0, "bottomLat": 0.0,
         "leftLon": 0.0, "rightLon": 2.0, "sceneExtentMeters": 400.0,
         "navigableRadiusMeters": 199.0, "boundsShape": "square"},
    ]}, "_tw_multi.json")
    try:
        cm = TwinSceneConfig(p)
        check(cm.names() == ["A", "B"], "多关卡顺序 = JSON 顺序", str(cm.names()))
        check(cm.navigable_radius("B") == 199.0, "大场景半径 = 199", str(cm.navigable_radius("B")))
        check(cm.get("B").get("sceneExtentMeters") == 400.0, "大场景 400 m",
              str(cm.get("B").get("sceneExtentMeters")))
        check(cm.bounds_shape("B") == "square", "大场景形状 = square")
        check(cm.image_for("B") == "b.png", "image_for 按关卡取值", str(cm.image_for("B")))
    finally:
        os.remove(p)

    print()
    print("=== 回退：无 navigableRadiusMeters ===")
    p = tmp_cfg({"levels": [{
        "scene": "T", "image": "t.png", "topLat": 1.0, "bottomLat": 0.0,
        "leftLon": 0.0, "rightLon": 1.0, "sceneExtentMeters": 400}]}, "_tw_a.json")
    try:
        c2 = TwinSceneConfig(p)
        check(c2.navigable_radius("T") == 199.0,
              "由 sceneExtentMeters/2−1 回退 = 199", str(c2.navigable_radius("T")))
        check(c2.bounds_shape("T") == "square", "缺 boundsShape → 默认 square（向后兼容）")
    finally:
        os.remove(p)

    print()
    print("=== 回退：连 sceneExtentMeters 也没有 ===")
    p = tmp_cfg({"levels": [{
        "scene": "T2", "image": "t.png", "topLat": 0.01, "bottomLat": 0.0,
        "leftLon": 0.0, "rightLon": 0.01}]}, "_tw_b.json")
    try:
        c3 = TwinSceneConfig(p)
        r = c3.navigable_radius("T2")
        expect = 0.01 * 111320.0 / 2.0 - 1.0
        check(r is not None and abs(r - expect) < 0.01,
              "由纬度跨度回退", f"{r} ≈ {expect:.1f}")
        check(c3.origin("T2") is not None, "origin 缺失时用四角中心兜底",
              str(c3.origin("T2")))
    finally:
        os.remove(p)

    print()
    print("=== 健壮性：坏数据不应崩 ===")
    p = tmp_cfg({"levels": [
        {"scene": "坏1"},                                            # 缺四角
        {"scene": "坏2", "topLat": "x", "bottomLat": 0,
         "leftLon": 0, "rightLon": 1},                               # 非数值
        {"scene": "退化", "topLat": 0.0, "bottomLat": 0.0,
         "leftLon": 0, "rightLon": 0},                               # 退化（零面积）
        {"scene": "好", "topLat": 1.0, "bottomLat": 0.0,
         "leftLon": 0.0, "rightLon": 1.0},
    ]}, "_tw_c.json")
    try:
        c4 = TwinSceneConfig(p)
        check(c4.names() == ["好"], "只保留四角有效的条目", str(c4.names()))
    finally:
        os.remove(p)

    p = tmp_cfg("{ this is not json", "_tw_d.json")
    try:
        c5 = TwinSceneConfig(p)
        check(not c5.available() and c5.error is not None,
              "JSON 损坏 → 安全降级（不抛异常）", str(c5.error)[:50])
        check(c5.names() == [], "损坏时 names() 为空")
        check(c5.bounds_for_js("任意") is None, "损坏时 bounds 为 None")
        check(c5.navigable_radius("任意") is None, "损坏时半径 None")
    finally:
        os.remove(p)

    c6 = TwinSceneConfig(os.path.join(tempfile.gettempdir(), "绝对不存在的文件.json"))
    check(not c6.available(), "文件不存在 → 安全降级", str(c6.error)[:50])

    print()
    print("=" * 64)
    print("T4 通过" if not fails else f"T4 失败 {len(fails)} 项: {fails}")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
