# 文件路径: vision/gui/vision_window.py
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                             QGroupBox, QCheckBox, QScrollArea, QFrame, QSplitter,
                             QSizePolicy)
from PyQt5.QtCore import QObject, Qt, pyqtSignal, pyqtSlot, QRectF, QTimer, QSize, QThread
from PyQt5.QtGui import QPainter, QColor, QPen, QFont, QPixmap, QImage
from core.vision.control_source import describe_boat_control, describe_dock_control


class HUDVideoLabel(QLabel):
    """
    HUD 视频图层：负责渲染视频，并在其上绘制 AI 识别结果
    优化：仅负责显示与 HUD 绘制，不负责任何图像缩放计算。
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("background-color: black;")
        self.results = []
        self.current_fps = 0.0            # 📊 实时帧率

    def update_vision_data(self, results):
        """接收归一化坐标并刷新图层"""
        self.results = results
        self.update()

    def paintEvent(self, event):
        super().paintEvent(event)
        pix = self.pixmap()
        if not pix: return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        pix_w, pix_h = pix.width(), pix.height()
        offset_x = (self.width() - pix_w) // 2
        offset_y = (self.height() - pix_h) // 2

        # 📊 实时帧率显示 (画面右上角)
        if self.current_fps > 0:
            fps_text = f"FPS: {self.current_fps:.1f}"
            fps_font = QFont("Consolas", 11, QFont.Bold)
            painter.setFont(fps_font)
            fps_fm = painter.fontMetrics()
            fps_text_width = fps_fm.boundingRect(fps_text).width() + 12
            fps_x = offset_x + pix_w - fps_text_width - 4
            fps_y = offset_y + 4
            painter.setBrush(QColor(0, 0, 0, 140))
            painter.setPen(Qt.NoPen)
            painter.drawRect(fps_x, fps_y, fps_text_width, 22)
            if self.current_fps >= 25:
                fps_color = QColor(0, 255, 0)
            elif self.current_fps >= 15:
                fps_color = QColor(255, 255, 0)
            else:
                fps_color = QColor(255, 80, 80)
            painter.setPen(fps_color)
            painter.drawText(fps_x + 6, fps_y + 16, fps_text)

        if not self.results:
            painter.end()
            return

        # ── 第一步：先画所有检测框，同时收集文字信息 ──
        draw_items = []
        for res in self.results:
            x1, y1, x2, y2 = res.bbox
            rx1 = offset_x + (x1 * pix_w)
            ry1 = offset_y + (y1 * pix_h)
            rx2 = offset_x + (x2 * pix_w)
            ry2 = offset_y + (y2 * pix_h)

            # 为不同算法分配专属颜色
            if res.algo_id == "yolo_v8":
                color = QColor(0, 255, 0)      # 绿色
                display_text = f"{res.label} {res.confidence:.2f}"
            else:
                color = QColor(255, 255, 0)    # 黄色 (默认兜底)
                display_text = f"{res.label} {res.confidence:.2f}"

            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(color, 2))
            painter.drawRect(QRectF(rx1, ry1, rx2 - rx1, ry2 - ry1))

            draw_items.append({
                "rx1": rx1, "ry1": ry1, "ry2": ry2,
                "text": display_text, "color": color,
            })

        # ── 第二步：统一绘制文字标签，带防重叠布局 ──
        font = QFont("Consolas", 10, QFont.Bold)
        painter.setFont(font)
        fm = painter.fontMetrics()
        label_h = 20
        gap = 2
        right_edge = offset_x + pix_w
        left_edge = int(offset_x)

        def _base_y(item):
            # 纵向自适应：上方空间不够时，标签移到框下方
            y = int(item["ry1"] - label_h)
            if y < offset_y:
                y = int(item["ry2"] + 2)
            return y

        # 按基准 y 排序，重叠时自上而下顺序展开，避免四码距离文字叠成一团
        draw_items.sort(key=_base_y)

        placed = []
        for item in draw_items:
            text_width = fm.boundingRect(item["text"]).width() + 10

            # 横向防溢出：标签超出右侧时自动左移
            x = int(item["rx1"])
            if x + text_width > right_edge:
                x = int(right_edge - text_width - 2)
            if x < left_edge:
                x = left_edge

            y = _base_y(item)

            # 防重叠：与已放置标签逐一比对，相交则向下推
            while True:
                hit = False
                for (px, py, pw, ph) in placed:
                    if (x < px + pw and px < x + text_width
                            and y < py + ph and py < y + label_h):
                        y = py + ph + gap
                        hit = True
                        break
                if not hit:
                    break

            placed.append((x, y, text_width, label_h))

            painter.setBrush(item["color"])
            painter.setPen(Qt.NoPen)
            painter.drawRect(x, y, text_width, label_h)
            painter.setPen(item.get("text_color", QColor(0, 0, 0)))
            painter.drawText(x + 5, y + 15, item["text"])

        painter.end()


class VideoSurface(QWidget):
    """左侧视频画布：把 HUD 视频标签锁死在“源画面的原生宽高比”上。

    地面站两条链路都是按“控件尺寸”出图的：
      * 实机 UDP 链路在 core/Thread/video_thread.py 里按 target_size 做 cv2.resize；
      * 孪生 ZMQ 链路保留原帧，由 VisionWindow.update_frame 等比缩放进控件。
    所以只要视频标签自身的比例 = 源画面比例，窗口怎么拉、右侧分割条怎么拖，画面都不会变形：
      * 实机 640×480 (4:3) → 视频区 4:3，等比放大后正好铺满；
      * 数字孪生 Unity (16:9) → 视频区 16:9，保持原生比例，不压扁也不留黑边。
    初始比例由链路决定（VisionWindow 构造参数），之后由 follow_source() 按真实帧自动校正。
    """

    # 视频标签的实际尺寸变化（恒为当前源比例），转发给 VisionWindow.sig_resized
    sig_video_size_changed = pyqtSignal(QSize)

    # 允许的比例范围，防止异常帧把视频区拉成细条
    MIN_ASPECT = 0.5
    MAX_ASPECT = 2.6

    def __init__(self, aspect_w: int = 4, aspect_h: int = 3, parent=None):
        super().__init__(parent)
        self._aspect = float(aspect_w) / float(aspect_h)
        self.setStyleSheet("background-color: black;")  # 画面外的留边
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(160, 120)
        self.video_label = HUDVideoLabel(self)
        # 窗口还没走过 resizeEvent 之前（start_video_display 就在这个阶段取尺寸），
        # 也要保证标签已是目标比例，否则会把 QLabel 默认的 100×30 当成目标尺寸发给后台。
        hint = self.sizeHint()
        self.video_label.setGeometry(0, 0, hint.width(), hint.height())

    def sizeHint(self):
        """给分割条一个建议尺寸（按当前比例），保证首次显示时左区不会被压成畸形。"""
        height = 660
        width = int(round(height * self._aspect))
        return QSize(width, height)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.apply_aspect_ratio()
        self._emit_video_size()

    def apply_aspect_ratio(self):
        """在画布内居中放置一个当前比例的视频标签，多余空间留黑边。"""
        w, h = self.width(), self.height()
        if w <= 0 or h <= 0:
            return
        label_w = min(w, int(round(h * self._aspect)))
        label_h = int(round(label_w / self._aspect))
        if label_h > h:  # 极端窄高时的兜底
            label_h = h
            label_w = int(round(label_h * self._aspect))
        self.video_label.setGeometry(
            (w - label_w) // 2, (h - label_h) // 2, label_w, label_h
        )

    def set_aspect_ratio(self, aspect_w, aspect_h=None):
        """切换视频区比例（可传 (16, 9) 或直接传 16/9 的比值）。返回是否发生变化。"""
        if aspect_h is None:
            aspect = float(aspect_w)
        else:
            aspect = float(aspect_w) / float(aspect_h)
        aspect = min(max(aspect, self.MIN_ASPECT), self.MAX_ASPECT)
        if abs(aspect - self._aspect) < 1e-4:
            return False
        self._aspect = aspect
        self.apply_aspect_ratio()
        self._emit_video_size()
        return True

    def follow_source(self, frame_width: int, frame_height: int):
        """按真实收到的帧把视频区调成源比例（实机 4:3 / 孪生 16:9 都是原生显示）。"""
        if frame_width < 32 or frame_height < 32:
            return False
        ratio = float(frame_width) / float(frame_height)
        if abs(ratio - self._aspect) <= self._aspect * 0.01:  # 1% 容差，避免抖动
            return False
        return self.set_aspect_ratio(ratio)

    def _emit_video_size(self):
        size = self.video_label.size()
        if size.width() > 0 and size.height() > 0:
            self.sig_video_size_changed.emit(size)


class VisionWindow(QWidget):
    """
    视觉任务中心窗口：具备视频 HUD 与算法插件面板
    """
    sig_closed = pyqtSignal()
    sig_toggle_algo = pyqtSignal(str, str, bool)
    # 🚀 [新增] 尺寸变更信号：用于实时通知后台线程调整缩放比例
    sig_resized = pyqtSignal(QSize)

    def __init__(self, target_id: str, title: str, parent=None, video_aspect=(4, 3)):
        """video_aspect: 视频区初始比例。实机 UDP 链路 (640×480) 传 (4, 3)；
        数字孪生 Unity 链路传 (16, 9)，保持孪生画面原生比例不变。"""
        super().__init__(parent)
        self.target_id = target_id
        self.setWindowTitle(title)
        self.resize(1280, 780)
        self.setMinimumSize(960, 620)

        self.display_timer = QTimer(self)
        self.display_timer.timeout.connect(self._pull_latest_frame)
        self.video_thread_ref = None

        self.main_layout = QHBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        # 🔧 [QSplitter] 拖拽分割条即可自由缩放视频 / 面板比例
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setHandleWidth(4)
        self.splitter.setStyleSheet("QSplitter::handle { background-color: #ccc; }")

        # --- 1. 左侧：HUD 视频区 (按链路保持原生比例：实机 4:3 / 孪生 16:9) ---
        self.video_surface = VideoSurface(*video_aspect)
        self.hud_label = self.video_surface.video_label
        # 画布尺寸一变就把“视频标签尺寸”回传给后台线程；实机链路按此尺寸等比
        # 缩放 640×480 原始帧，于是画面不再随窗口被拉扁/拉长。
        self.video_surface.sig_video_size_changed.connect(self.sig_resized)
        self.splitter.addWidget(self.video_surface)

        # --- 2. 右侧：算法控制面板 ---
        self.side_panel = QFrame()
        self.side_panel.setMinimumWidth(300)
        self.side_panel.setMaximumWidth(400)
        self.side_panel.setStyleSheet("background-color: #f0f0f0; border-left: 1px solid #ccc;")
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.addWidget(QLabel("🧠 视觉算法插件"))

        # =============== 🎮 控制源指示器（实时显示谁在控制船坞/小船） ===============
        self.group_control_source = QGroupBox("🎮 控制源")
        control_layout = QVBoxLayout(self.group_control_source)
        self.lbl_control_source = QLabel(
            "<span style='color:#888'>控制源未连接</span>"
        )
        self.lbl_control_source.setWordWrap(True)
        self.lbl_control_source.setTextFormat(Qt.RichText)
        self.lbl_control_source.setStyleSheet(
            "font-family: Consolas; background-color: white; "
            "border: 1px solid #ccc; padding: 6px;"
        )
        control_layout.addWidget(self.lbl_control_source)
        self.side_layout.addWidget(self.group_control_source)

        self._dock_brain = None
        self._boat_brain = None
        self.control_source_timer = QTimer(self)
        self.control_source_timer.setInterval(300)
        self.control_source_timer.timeout.connect(self._refresh_control_source)
        self.control_source_timer.start()

        self._algo_checkboxes = {}  # algo_id -> QCheckBox，供程序化启停算法
        
        # [控制对接开关] 外壳按钮保留外形，无实际功能
        from PyQt5.QtWidgets import QPushButton
        self.btn_dock_action = QPushButton("🚢 开始闭环对接")
        self.btn_dock_action.setStyleSheet("background-color: #d1e7dd; font-size: 14px; font-weight: bold; padding: 8px;")
        self.btn_dock_action.setCheckable(True)
        self.btn_dock_action.setEnabled(False)
        self.btn_dock_action.setText("🔒 闭环已锁定（勾选 ArUco 后解锁）")
        self.side_layout.addWidget(self.btn_dock_action)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll.setWidget(self.scroll_content)
        self.side_layout.addWidget(self.scroll)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setCollapsible(0, False)
        self.splitter.setCollapsible(1, False)
        self.splitter.setStretchFactor(0, 3)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([900, 360])
        self.main_layout.addWidget(self.splitter)

        # [控制对接开关] 保留外形与锁定文案；实际功能已移除。
        self.btn_dock_action.toggled.connect(
            lambda checked: QTimer.singleShot(0, lambda: self.btn_dock_action.setChecked(False))
        )

        self.scroll = QScrollArea()

    def set_control_source_providers(self, dock_brain, boat_brain):
        """绑定船坞/子船控制大脑，供控制源指示器定时刷新。"""
        self._dock_brain = dock_brain
        self._boat_brain = boat_brain
        self._refresh_control_source()

    def _refresh_control_source(self):
        """轮询两个大脑的控制标志，刷新控制源指示器文案。"""
        dock_mode, dock_detail = describe_dock_control(self._dock_brain)
        boat_mode, boat_detail = describe_boat_control(self._boat_brain)

        def color(mode: str) -> str:
            if mode in ("--", "手动"):
                return "#6c757d"  # 灰
            if "视觉" in mode or "NOF" in mode or "ArUco" in mode:
                return "#0d6efd"  # 蓝
            if "任务" in mode or "返航" in mode or "稳停" in mode:
                return "#198754"  # 绿
            if "协同" in mode:
                return "#0dcaf0"  # 青
            return "#0d6efd"      # 自动 PID → 蓝

        text = (
            f"<b>🚢 船坞</b>&nbsp;&nbsp;"
            f"<span style='color:{color(dock_mode)}'><b>{dock_mode}</b></span><br>"
            f"<span style='font-size:11px;color:#777'>&nbsp;&nbsp;&nbsp;&nbsp;{dock_detail}</span><br><br>"
            f"<b>🚤 小船</b>&nbsp;&nbsp;"
            f"<span style='color:{color(boat_mode)}'><b>{boat_mode}</b></span><br>"
            f"<span style='font-size:11px;color:#777'>&nbsp;&nbsp;&nbsp;&nbsp;{boat_detail}</span>"
        )
        self.lbl_control_source.setText(text)

    # ========================================================
    def resizeEvent(self, event):
        """
        🚀 [核心接口] 窗口尺寸变化时，发射信号告知 Controller
        """
        super().resizeEvent(event)
        # 发射当前视频标签的实际尺寸
        self.sig_resized.emit(self.hud_label.size())

    def start_video_display(self, video_thread):
        self.video_thread_ref = video_thread
        # 🔒 先把视频区几何按当前链路比例落位，再把尺寸同步给后台
        # （首次显示前也能拿到正确尺寸：实机 4:3 / 孪生 16:9）
        self.video_surface.apply_aspect_ratio()
        self.video_thread_ref.set_target_size(self.hud_label.size())
        self.display_timer.start(33)

    def stop_video_display(self):
        self.display_timer.stop()
        self.video_thread_ref = None

    def _pull_latest_frame(self):
        if self.video_thread_ref:
            latest_image = self.video_thread_ref.get_latest_frame()
            if latest_image:
                self.update_frame(latest_image)
            # 📊 同步实时帧率到 HUD 显示
            self.hud_label.current_fps = getattr(self.video_thread_ref, 'current_fps', 0.0)

    def update_frame(self, qimg):
        """
        接收 VideoThread 保留的完整分辨率 QImage，并仅按本窗口尺寸显示。
        主界面小预览不会再改变这里拿到的原始画面尺寸。
        """
        # 🖼 画面比例跟随真实帧：实机 640×480 → 4:3，数字孪生 Unity → 16:9。
        # 两条链路各按原生比例铺满显示区，既不变形也不浪费黑边。
        self.video_surface.follow_source(qimg.width(), qimg.height())

        pixmap = QPixmap.fromImage(qimg)
        target_size = self.hud_label.size()
        if target_size.width() > 0 and target_size.height() > 0:
            pixmap = pixmap.scaled(
                target_size,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation,
            )
        self.hud_label.setPixmap(pixmap)

    def add_algo_toggle(self, algo_id: str, name: str):
        cb = QCheckBox(name)
        cb.setStyleSheet("font-size: 14px; padding: 5px;")

        def on_algo_toggled(state):
            is_checked = (state == Qt.Checked)
            self.sig_toggle_algo.emit(self.target_id, algo_id, is_checked)

        cb.stateChanged.connect(on_algo_toggled)
        self.scroll_layout.addWidget(cb)
        self._algo_checkboxes[algo_id] = cb

    def set_algo_enabled(self, algo_id: str, enabled: bool):
        """程序化启停算法勾选框（自动联动 sig_toggle_algo）。"""
        cb = self._algo_checkboxes.get(algo_id)
        if cb is not None and cb.isChecked() != bool(enabled):
            cb.setChecked(bool(enabled))

    def set_control_source_providers(self, dock_brain, boat_brain):
        """绑定船坞/子船控制大脑，供控制源指示器定时刷新。"""
        self._dock_brain = dock_brain
        self._boat_brain = boat_brain
        self._refresh_control_source()

    def on_vision_data_arrived(self, results, imu=None):
        """将 AI 生成的数据送入 HUD 涂层进行标注"""
        self.hud_label.update_vision_data(results)

    def closeEvent(self, event):
        if self.btn_dock_action.isChecked():
            self.btn_dock_action.setChecked(False)
        self.stop_video_display()
        self.sig_closed.emit()
        event.accept()
