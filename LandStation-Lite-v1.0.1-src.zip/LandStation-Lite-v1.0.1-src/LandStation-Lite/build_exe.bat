@echo off
setlocal enabledelayedexpansion

rem ============================================================
rem  LandStation-Lite v1.0.1 - build the Windows exe (onedir)
rem
rem  NOTE: this file is intentionally pure ASCII. cmd.exe parses
rem  .bat files using the OEM code page (936 on a Chinese
rem  Windows), NOT UTF-8 - Chinese comments here would be decoded
rem  as garbage and executed as commands. See start_groundstation.bat.
rem
rem  What it does:
rem    1. sanity checks (venv, PyInstaller, pure-ASCII project path)
rem    2. PyInstaller build with LandStation-Lite.spec (onedir, no console)
rem    3. stage sidecar files next to the exe (config\, missions.json,
rem       LICENSE, docs whitelist via Tools\build_selfcheck.py)
rem    4. PRODUCT SELF-CHECK (4 required artifacts):
rem         QtWebEngineProcess.exe
rem         Qt5WebEngineCore.dll
rem         qtwebengine_locales\
rem         ui\map\map.html
rem    Non-zero exit code on any failure.
rem
rem  Usage:  build_exe.bat        (from the project root)
rem ============================================================

cd /d "%~dp0"

set "VENV_PY=%~dp0venv_usv\Scripts\python.exe"
set "OUTDIR=%~dp0dist\LandStation-Lite"
set "INTERNAL=%OUTDIR%\_internal"
set "QTDIR=%INTERNAL%\PyQt5\Qt5"
set "FAILED=0"

echo [1/4] Environment checks...

if not exist "%VENV_PY%" (
    echo [ERROR] venv not found: %VENV_PY%
    echo         Create it first:
    echo             py -3.10 -m venv venv_usv
    echo             venv_usv\Scripts\python.exe -m pip install -r requirements.txt
    echo             venv_usv\Scripts\python.exe -m pip install pyinstaller
    exit /b 1
)

rem PyInstaller must be installed in the venv (see BUILD.md).
"%VENV_PY%" -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] PyInstaller is missing from the venv.
    echo         "%VENV_PY%" -m pip install pyinstaller
    exit /b 1
)

rem QtWebEngine resources must be present in the venv, otherwise the
rem collected locales/resources will silently be missing from the build.
if not exist "%~dp0venv_usv\Lib\site-packages\PyQt5\Qt5\bin\QtWebEngineProcess.exe" (
    echo [ERROR] PyQt5 QtWebEngine runtime not found in the venv.
    echo         Check that requirements.txt versions are installed:
    echo         PyQt5==5.15.11 + PyQtWebEngine==5.15.7
    exit /b 1
)

rem The build path must be pure ASCII: non-ASCII project paths make
rem QtWebEngine resource loading fail silently at runtime.
"%VENV_PY%" -c "import os,sys; p=os.path.abspath('.'); bad=[c for c in p if ord(c)>127]; sys.exit(1 if bad else 0)"
if errorlevel 1 (
    echo [ERROR] Project path contains non-ASCII characters.
    echo         Move the project to a pure ASCII path, e.g. D:\LandStation-Lite
    exit /b 1
)

echo [2/4] PyInstaller build (spec: LandStation-Lite.spec)...
"%VENV_PY%" -m PyInstaller --noconfirm --clean LandStation-Lite.spec
if errorlevel 1 (
    echo [ERROR] PyInstaller build failed - see output above.
    exit /b 1
)

if not exist "%OUTDIR%\LandStation-Lite.exe" (
    echo [ERROR] Expected exe not produced: %OUTDIR%\LandStation-Lite.exe
    exit /b 1
)

echo [3/4] Staging sidecar files (config, missions, license, docs)...
rem Runtime reads these relative to the exe's working directory.
if not exist "%OUTDIR%\config" mkdir "%OUTDIR%\config"
copy /y "%~dp0config\*.json" "%OUTDIR%\config\" >nul
if errorlevel 1 (
    echo [ERROR] Failed to copy config\*.json
    exit /b 1
)
copy /y "%~dp0missions.json" "%OUTDIR%\" >nul
if errorlevel 1 (
    echo [ERROR] Failed to copy missions.json
    exit /b 1
)
copy /y "%~dp0LICENSE" "%OUTDIR%\" >nul
if errorlevel 1 (
    echo [ERROR] Failed to copy LICENSE
    exit /b 1
)
rem docs whitelist (single file, non-ASCII name) - handled in Python.
"%VENV_PY%" "%~dp0Tools\build_selfcheck.py" --stage-docs "%OUTDIR%"
if errorlevel 1 (
    echo [ERROR] Failed to stage docs whitelist.
    exit /b 1
)

echo [4/4] Product self-check...
set "FAILED=0"

call :need_file "%OUTDIR%\LandStation-Lite.exe"
call :need_file "%QTDIR%\bin\QtWebEngineProcess.exe"
call :need_file "%QTDIR%\bin\Qt5WebEngineCore.dll"
call :need_dir  "%QTDIR%\translations\qtwebengine_locales"
call :need_file "%INTERNAL%\ui\map\map.html"
call :need_file "%INTERNAL%\ui\map\leaflet\leaflet.js"
call :need_file "%INTERNAL%\ui\map\twin_maps\scenes.json"
call :need_file "%OUTDIR%\config\joystick_mapping.json"
call :need_file "%OUTDIR%\missions.json"
call :need_file "%OUTDIR%\LICENSE"

if "%FAILED%"=="1" (
    echo.
    echo [FAIL] Self-check failed - see the missing items above.
    exit /b 1
)

echo.
echo [OK] Build + self-check passed.
echo      Output: %OUTDIR%
echo      Start it from that folder: LandStation-Lite.exe
echo      (First-run environment check: venv_usv\Scripts\python.exe Tools\check_env.py)
exit /b 0

rem ------------------------------------------------------------
rem helpers
rem ------------------------------------------------------------
:need_file
if exist "%~1" (
    echo   [OK] %~1
) else (
    echo   [MISSING] %~1
    set "FAILED=1"
)
goto :eof

:need_dir
if exist "%~1\" (
    echo   [OK] %~1\
) else (
    echo   [MISSING] %~1\
    set "FAILED=1"
)
goto :eof
