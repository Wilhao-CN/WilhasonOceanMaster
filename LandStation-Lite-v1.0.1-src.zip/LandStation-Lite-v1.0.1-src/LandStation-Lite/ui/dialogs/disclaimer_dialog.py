"""启动许可 / 免责声明弹窗（强制门禁）。

行为（用户需求）
----------------
双击 EXE 后**先**弹出本窗口，只有两个出口：

* 点「我已阅读并同意」→ 继续启动主界面；
* 点「不同意并退出」（含右上角 ✕ / Esc）→ **直接退出，不进入主界面**。

设计要点
--------
* 纯 PyQt5，不引入任何第三方依赖，避免给打包增加负担；
* 正文**写死在程序里**（:data:`DEFAULT_DISCLAIMER_TEXT`），随 exe 一起编译，
  运行时**不读取任何外部文件**。
  为什么不做成可编辑的 txt：免责声明是要用户「确认接受」的许可条款，
  如果能被随手替换成别的内容（甚至替换成一句「我同意」），
  这个确认就失去意义了。要改措辞只能改本文件并**重新打包**；
* 同意记录追加写入 `data_logs/免责声明接受记录.log`，留痕可查；
* 自动化冒烟测试可用环境变量 ``USV_SKIP_DISCLAIMER=1`` 跳过本弹窗。

用法（main.py 中）::

    from ui.dialogs.disclaimer_dialog import run_disclaimer_gate
    if not run_disclaimer_gate():
        sys.exit(0)
"""

from __future__ import annotations

import datetime
import os
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QCheckBox, QDialog, QHBoxLayout, QLabel,
                             QPushButton, QTextBrowser, QVBoxLayout)

import app_paths

try:
    from _version import APP_TITLE, __version__
except Exception:  # noqa: BLE001 - 兜底：缺 _version 也要能弹窗
    APP_TITLE, __version__ = 'LandStation-Lite', '0.0.0'

__all__ = ['DisclaimerDialog', 'run_disclaimer_gate', 'load_disclaimer_text',
           'SKIP_ENV_VAR']

#: 自动化测试跳过开关（仅测试用，不影响正常用户的门禁语义）
SKIP_ENV_VAR = 'USV_SKIP_DISCLAIMER'

#: 同意记录的相对路径（锚定到 :func:`app_paths.app_dir`）
ACCEPT_LOG_RELPATH = os.path.join('data_logs', '免责声明接受记录.log')

DEFAULT_DISCLAIMER_TEXT = """【重要提示】请在使用本软件前完整阅读本免责声明。

本软件（LandStation-Lite，下称「本软件」）是一套用于双无人船（USV）与浮船坞
协同控制的**地面站上位机**，面向科研、教学与实验场景。通过本软件可以下发控制
指令、驱动真实推进器与舵机、并接收视频与遥测数据，**操作失误可能造成设备损坏、
人员受伤、财产损失或水域安全事故**。

一经点击「我已阅读并同意」，即表示你已阅读、理解并自愿接受下列全部条款：

一、按「现状」提供
    本软件按「现状」（AS IS）提供，不附带任何明示或默示的担保，包括但不限于
    适销性、特定用途适用性与不侵权担保。作者与提供方不承诺本软件无缺陷、
    不中断或完全符合你的预期。

二、使用风险自负
    你须自行评估使用场景的安全性，并对使用本软件产生的一切后果负责。
    在任何情况下，作者与提供方均不对因使用或无法使用本软件而导致的任何直接、
    间接、偶然、特殊或后果性损害（含设备损毁、数据丢失、人身伤害、停航损失、
    第三方索赔等）承担赔偿责任，即使已被告知该等损害的可能性。

三、必须遵守法律法规
    你须自行确保使用行为符合当地及所在国关于**水域航行、无线电频谱、
    无人机/无人船作业、数据安全与个人隐私**等方面的全部法律法规与主管
    单位的许可要求。因违规使用产生的一切责任由你自行承担。

四、真实设备操作要求
    驱动真实推进器与舵机前，请务必：
    1. 完成通讯链路、应急停船（E-Stop）与失效保护的地面验证；
    2. 在有人看管、可人工干预的条件下作业，并设置安全半径与防护措施；
    3. 先空载/台架测试，再下水实船测试。
    严禁在无监护、无应急手段的状态下对真实设备下发控制指令。

五、数据与隐私
    本软件会在本地记录日志、遥测数据与（可能包含真实坐标的）任务文件。
    这些数据的收集、存储、传输与保密由你自行负责，作者与提供方不接触、
    不收集、也不承担相关责任。对外分享前请自行脱敏。

六、许可与第三方组件
    本软件以 GPL v3 发布，完整条款见随包 LICENSE；所依赖的第三方组件
    （PyQt5 / PyQtWebEngine / OpenCV / NumPy / pygame / pySerial / pyqtgraph 等）
    的许可与归属见随包 THIRD_PARTY_NOTICES.md。若你选择安装可选的
    Ultralytics YOLOv8（AGPL-3.0）用于目标检测，请自行确认其许可对你的
    发布方式的影响。

七、条款接受
    若你不同意上述任何一条，请点击「不同意并退出」。此时程序将立即关闭，
    不会进入主界面，也不会向任何设备下发指令。
"""


def load_disclaimer_text() -> str:
    """返回免责声明正文。

    ⚠️ **只返回编译进程序里的内置正文，不读任何外部文件。**

    这样做的原因：免责声明是用户必须「确认接受」的许可条款。如果正文来自
    exe 旁边的可编辑文件，任何人都能把 `免责声明.txt` 换成别的内容（甚至
    换成一句「我同意」）再分发，用户的「确认」就变成了一句空话。
    写死在 exe 内部后，要改措辞只能改源码并重新打包。

    保留成函数（而不是直接引用常量）是为了留一个改动的入口：
    将来若确实需要「正式版 / 定制版」不同文案，可以在这里按版本分发。
    """
    return DEFAULT_DISCLAIMER_TEXT


def _should_skip() -> bool:
    """测试模式判断：`USV_SKIP_DISCLAIMER=1` 时跳过门禁。"""
    return (os.environ.get(SKIP_ENV_VAR) or '').strip().lower() in (
        '1', 'true', 'yes', 'on')


class DisclaimerDialog(QDialog):
    """模态免责声明窗。``exec_()`` 返回 ``QDialog.Accepted`` 才算同意。"""

    def __init__(self, parent=None, text: str = None):
        super().__init__(parent)
        self._text = text if text is not None else load_disclaimer_text()

        self.setWindowTitle('免责声明与使用许可 —— %s' % APP_TITLE)

        # 去掉右上角的「?」帮助按钮（Windows 打包版会显示）
        self.setWindowFlags(self.windowFlags()
                            & ~Qt.WindowContextHelpButtonHint)

        self.setMinimumSize(820, 620)
        self.resize(880, 660)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)

        title = QLabel('⚠️  免责声明与使用许可')
        title.setStyleSheet('font-size: 18px; font-weight: bold; color: #b00020;')
        layout.addWidget(title)

        subtitle = QLabel(
            '使用本软件前，请完整阅读下列条款。'
            '点击「我已阅读并同意」即表示你接受全部条款；\n'
            '点击「不同意并退出」将立即关闭程序，不会进入主界面。')
        subtitle.setStyleSheet('color: #444;')
        layout.addWidget(subtitle)

        self.browser = QTextBrowser()
        self.browser.setPlainText(self._text)
        self.browser.setOpenExternalLinks(False)
        self.browser.setStyleSheet(
            'QTextBrowser { background: #fffdf5; border: 1px solid #d8cfae;'
            ' border-radius: 4px; padding: 8px; font-size: 13px; }')

        # 打开时定位到正文开头（而不是上次滚动位置）
        self.browser.verticalScrollBar().setValue(0)
        layout.addWidget(self.browser, 1)

        # 复选框：不勾选不允许点同意
        self.ack_box = QCheckBox('我已逐条阅读并理解上述免责声明')
        layout.addWidget(self.ack_box)

        buttons = QHBoxLayout()
        buttons.addStretch(1)

        self.btn_reject = QPushButton('不同意并退出')
        self.btn_reject.setMinimumHeight(36)
        self.btn_reject.setMinimumWidth(150)
        self.btn_reject.setStyleSheet(
            'QPushButton { padding: 6px 18px; border: 1px solid #b00020;'
            ' color: #b00020; border-radius: 4px; }'
            'QPushButton:hover { background: #fdecef; }')

        # Esc / 右上角 ✕ 都走 reject()（QDialog 默认行为）→ 视为不同意
        self.btn_reject.clicked.connect(self.reject)

        self.btn_accept = QPushButton('我已阅读并同意')
        self.btn_accept.setMinimumHeight(36)
        self.btn_accept.setMinimumWidth(170)
        self.btn_accept.setDefault(True)
        self.btn_accept.setStyleSheet(
            'QPushButton { padding: 6px 18px; background: #1b7f3b;'
            ' color: white; border: 1px solid #14622d; border-radius: 4px;'
            ' font-weight: bold; }'
            'QPushButton:hover { background: #219247; }'
            'QPushButton:disabled { background: #9bbfa8; border-color: #8aa895; }')

        self.btn_accept.clicked.connect(self.accept)

        self.btn_accept.setEnabled(False)
        self.ack_box.toggled.connect(self.btn_accept.setEnabled)

        buttons.addWidget(self.btn_reject)
        buttons.addWidget(self.btn_accept)
        layout.addLayout(buttons)

    def log_acceptance(self) -> None:
        """把「本次同意」追加写入日志，便于事后追溯。"""
        try:
            log_path = os.path.join(app_paths.app_dir(), ACCEPT_LOG_RELPATH)
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            with open(log_path, 'a', encoding='utf-8') as fh:
                fh.write(f'[{stamp}] 已同意免责声明（版本 {__version__}）'
                         f' exe={sys.executable}\n')
        except OSError as exc:
            print(f'[许可] 写入同意记录失败（不影响运行）: {exc}')


def run_disclaimer_gate(parent=None) -> bool:
    """弹出免责声明门禁。

    :return: ``True`` = 用户同意，可以继续启动；``False`` = 不同意，调用方应退出。
    """
    if _should_skip():
        print(f'[许可] 检测到 {SKIP_ENV_VAR}=1，跳过免责声明弹窗（测试模式）')
        return True

    dialog = DisclaimerDialog(parent)
    if dialog.exec_() != QDialog.Accepted:
        return False

    dialog.log_acceptance()
    print('[许可] 用户已同意免责声明')
    return True
