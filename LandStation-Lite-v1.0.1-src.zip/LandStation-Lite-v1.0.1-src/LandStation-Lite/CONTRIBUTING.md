# CONTRIBUTING.md —— 贡献指南

> 欢迎参与 LandStation-Lite 的改进！本文说明如何提交代码、参与讨论，以及贡献的授权方式。

---

## 1. 源码与交流

- **源码获取**：本仓库内的所有源码均公开可见、可直接克隆或下载，无需任何注册或申请。
- **问题反馈**：请在 GitHub 提交 Issue，并附上复现步骤、`data_logs\` 日志片段、操作系统与 Python 版本。
- **安全漏洞**：如发现涉及控制指令安全等敏感漏洞，请**勿公开提 Issue**，直接发送邮件至 **2571217194@qq.com**。
- **协作交流**：欢迎希望参与二次开发或加入兴趣小组的开发者发送邮件至上述邮箱进行交流。

---

## 2. 贡献者授权声明

**提交贡献（包括 Pull Request 或补丁）即表示你同意以 GPL v3（`SPDX-License-Identifier: GPL-3.0-only`）授权该贡献。**

本项目不设 CLA（Contributor License Agreement），通过提交代码参与开发，默认采用与本项目一致的 GPL v3 许可。

---

## 3. 提交代码流程

1. Fork 仓库并创建特性分支（建议命名：`feat/<简述>` / `fix/<简述>`）。
2. **保持小步提交**，每次 commit 说明「做了什么、为什么」。
3. **运行回归自检**（详见 `README.md`），确保修改没有破坏既有功能：

   ```bat
   venv_usv\Scripts\python.exe Tools\check_env.py