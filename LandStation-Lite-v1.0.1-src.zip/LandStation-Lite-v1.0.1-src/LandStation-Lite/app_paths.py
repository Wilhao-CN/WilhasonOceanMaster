"""冻结（frozen）运行时路径适配层。

为什么需要这个文件
------------------
开发态和 PyInstaller 打包后的「根目录」不是同一个地方：

===============  ==========================  ==============================
                可写根 (app_dir)             只读资源根 (resource_dir)
===============  ==========================  ==============================
开发态           工程根目录                   工程根目录
                 (python main.py)            （同一个目录）
PyInstaller      **exe 所在目录**             ``sys._MEIPASS``
打包后           用户看得见、可备份、可编辑    （onedir 模式即 exe 同级的
                                             ``_internal/``，会被重建覆盖）
===============  ==========================  ==============================

所以在本文件里把两类路径分开：

* 会**被程序写**的东西（``missions.json``、``data_logs/``、``config/``、
  ``gcs_target_ip.txt``）一律锚定到 :func:`app_dir`；
* 只**随包分发**的只读资源（``ui/map/map.html``、``twin_maps/scenes.json``、
  ``*.pt`` 权重）走 :func:`resolve`，优先找 exe 旁边同名文件，
  找不到再回退到内置资源 —— 这样用户想换底图/改网页时，
  在 exe 旁边放一份同名文件即可，**不必重新打包**。

只依赖标准库，开发态与打包态行为都不变（开发态两个根目录相同）。
"""

from __future__ import annotations

import os
import sys

__all__ = ['is_frozen', 'app_dir', 'resource_dir', 'resolve']


def is_frozen() -> bool:
    """是否运行在 PyInstaller 打包产物里。"""
    return bool(getattr(sys, 'frozen', False))


def app_dir() -> str:
    """可写根目录：exe 所在目录（开发态为工程根目录）。

    所有运行时生成/修改的文件都放这里，保证用户在资源管理器里
    看得见、可备份，也保证从任意工作目录启动都不会写到别处。
    """
    if is_frozen():
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def resource_dir() -> str:
    """只读资源根目录：``sys._MEIPASS``（开发态为工程根目录）。

    onedir 模式下 ``sys._MEIPASS`` 即 exe 同级的 ``_internal/`` 目录。
    """
    meipass = getattr(sys, '_MEIPASS', None)
    if meipass:
        return meipass
    if is_frozen():
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def resolve(*rel_parts: str) -> str:
    """解析随包资源路径：优先 exe 旁边（用户可覆盖），回退内置资源。

    :param rel_parts: 相对路径片段，例如 ``('ui', 'map', 'map.html')``
    :return: 存在的绝对路径（两个位置都没有时返回「外部」位置，交给调用方报错）
    """
    rel = os.path.join(*rel_parts)
    outside = os.path.join(app_dir(), rel)
    if os.path.exists(outside):
        return outside
    inside = os.path.join(resource_dir(), rel)
    if os.path.exists(inside):
        return inside
    return outside
