# BUILD.md —— 构建与运行环境说明（LandStation-Lite v1.0.1）

> 本文面向希望从源码构建 Windows 可执行版（exe）的开发者，说明构建步骤与运行环境约束。
> 普通使用者直接运行现成 exe 即可，无需阅读本文。
> 源码直接运行方式见 `README.md` 与 `环境配置说明.md`。

---

## 1. 构建环境准备

### 1.1 解释器与虚拟环境

- 目标解释器：**Python 3.10**。本项目基于此版本开发和测试，请勿使用 3.11 及以上版本进行打包，以免出现底层依赖不兼容的问题。
- 虚拟环境名称约定为 `venv_usv`（`build_exe.bat` 会按此路径查找解释器）：

```bat
py -3.10 -m venv venv_usv
venv_usv\Scripts\python.exe -m pip install -r requirements.txt
```

### 1.2 安装打包工具

```bat
venv_usv\Scripts\python.exe -m pip install pyinstaller
```

- 打包依赖 `pyinstaller-hooks-contrib`，它会被自动安装，**请勿卸载**。
- `PyQt5` 和 `PyQtWebEngine` 的收集完全依赖该 hook 库。构建前请确保 `venv_usv` 中已正确安装所有 `requirements.txt` 中的依赖。

---

## 2. 构建前置检查（🔴 必须遵守）

### 2.1 工程路径必须纯 ASCII
请将工程放置在类似 `D:\LandStation-Lite` 的**纯英文（ASCII）路径**下。
若路径包含中文或非 ASCII 字符，QtWebEngine 的资源加载会**静默失败**（表现为双击 exe「没反应」，退出码 `0x80000003`）。`build_exe.bat` 脚本会先做此检查，不通过将直接退出。

### 2.2 必须在工程根目录执行
无论是构建还是运行，都必须确保当前工作目录是**工程根目录**。
代码内部使用了相对路径（如 `config/joystick_mapping.json`），在其它目录启动会导致配置文件丢失或读取失败。

### 2.3 环境自检
在尝试构建前，建议先跑一遍环境自检，确保 Python 环境、Qt 插件链和主窗口代码均无异常：

```bat
venv_usv\Scripts\python.exe Tools\check_env.py
```

---

## 3. 构建步骤与产物

### 3.1 一键构建

在工程根目录执行：

```bat
build_exe.bat
```

`build_exe.bat` 会依次执行以下动作：
1. **环境检查**：验证 venv、PyInstaller、QtWebEngine 运行时以及路径合规性。
2. **执行打包**：调用 `python -m PyInstaller --noconfirm --clean LandStation-Lite.spec`。
3. **随包文件入位**：将 `config\*.json`、`missions.json`、`LICENSE`、`README.md` 等必要文件复制到 exe 同级目录。（其他文本文件如：将 `使用说明.txt`、`THIRD_PARTY_NOTICES.md` 等必要文件，可以手动复制到 exe 同级目录。）
4. **产物自检**（任一缺失即非零退出）：
   - `LandStation-Lite.exe`
   - `_internal\PyQt5\Qt5\bin\QtWebEngineProcess.exe`
   - `_internal\PyQt5\Qt5\bin\Qt5WebEngineCore.dll`
   - `_internal\PyQt5\Qt5\translations\qtwebengine_locales\`
   - `_internal\ui\map\map.html`（及 `leaflet\leaflet.js`、`twin_maps\scenes.json`）
   - exe 同级 `config\joystick_mapping.json`、`missions.json`、`LICENSE`

### 3.2 构建产物结构

最终生成的便携版目录如下：

```text
dist\LandStation-Lite\
├── LandStation-Lite.exe        ← 主程序（无控制台窗口）
├── _internal\                  ← Python 运行时 + Qt + ui/map 等核心资源
├── config\                     ← 预置配置（运行期按 cwd 相对路径读取）
├── missions.json               ← 预置任务
├── README.md                   ← 使用说明
└── LICENSE                     ← GPL-3.0 许可文件
```

如果只想对已经构建好的产物进行完整性检查（不重新构建），可以执行：

```bat
venv_usv\Scripts\python.exe Tools\build_selfcheck.py dist\LandStation-Lite
```

---

## 4. PyInstaller 配置说明（Spec 要点）

`LandStation-Lite.spec` 是打包的核心配置文件，其中与 Qt 相关的关键处理如下：

1. **打包模式**：`onedir` 模式，`console=False`（运行时不显示黑色控制台）。
2. **QtWebEngine 资源收集**：由 `pyinstaller-hooks-contrib` 的 Hook 自动收集，Spec 中额外兜底追加了三类数据，以确保运行时资源完整：
   - `PyQt5/Qt5/translations/qtwebengine_locales/`
   - `PyQt5/Qt5/resources/`（含 `icudtl.dat`、`qtwebengine_resources*.pak`）
   - `PyQt5/Qt5/bin/`（含 `QtWebEngineProcess.exe` 等）
3. **冻结态路径解析**：`main.py::_configure_qt_webengine()` 使用 `importlib.util.find_spec("PyQt5")` 定位 Qt5 目录。在冻结态下，`PyQt5` 会解析到 `_internal\PyQt5\`，因此所有目标路径必须匹配 `PyQt5/Qt5/...`，否则 `QTWEBENGINE_LOCALES_PATH` 等环境变量会指向空路径。
4. **地图数据**：`ui/map/**` 整树打包至 `_internal\ui\map\`。代码通过 `dirname(dirname(__file__))` + `ui/map/map.html` 进行定位。
5. **无视觉权重**：本项目不内置视觉算法，`ALLOWED_PT` 为空集，不打包任何 `.pt` 权重文件。

---

## 5. 运行说明与排查（exe 版）

- **启动方式**：双击 `LandStation-Lite.exe`，或在 exe 所在目录下打开命令行运行。**必须在 exe 所在目录启动**（`config\`、`missions.json` 是相对路径依赖）。
- **免责声明**：首次启动会弹出「免责声明与使用许可」窗口。勾选「我已逐条阅读并理解上述免责声明」后点「我已阅读并同意」进入主界面；点「不同意并退出」、按 Esc 或关窗均会退出程序。
- **日志位置**：程序无控制台窗口，运行日志写入 `data_logs\`。
- **地图白屏排查**：
  1. 确认 `_internal\PyQt5\Qt5\bin\QtWebEngineProcess.exe` 存在。
  2. 确认安装路径为纯 ASCII。
  3. 关闭杀毒软件拦截。
  4. 查看 `data_logs\` 下的日志文件。
- **外部视觉插件**：本项目不内置视觉算法；若需目标检测，请参考 `requirements-optional.txt` 的说明进行外部接入。