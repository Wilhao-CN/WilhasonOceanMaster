# -*- mode: python ; coding: utf-8 -*-
"""LandStation-Lite v1.0.1 —— PyInstaller 打包配置（onedir 模式）

本文件定义了将 LandStation-Lite 打包为免安装 Windows 可执行程序（exe）的规则。
打包模式为 onedir（一个 exe 主程序 + _internal/ 资源目录），运行时不显示控制台窗口。

用法：venv_usv\\Scripts\\python.exe -m PyInstaller --noconfirm LandStation-Lite.spec
（或直接运行 build_exe.bat）
"""
import os

# SPECPATH = 本 spec 所在目录（工程根）
ROOT = os.path.abspath(SPECPATH)

APP_NAME = "LandStation-Lite"

# ---------------------------------------------------------------------------
# 数据文件收集
# ---------------------------------------------------------------------------
def _tree(src_rel, dest_rel):
    """把 src_rel 目录整棵树打成 datas 条目（排除 __pycache__ / .pyc）。"""
    out = []
    src_abs = os.path.join(ROOT, src_rel)
    for dirpath, dirnames, filenames in os.walk(src_abs):
        dirnames[:] = [d for d in dirnames if d != "__pycache__"]
        for name in sorted(filenames):
            if name.endswith((".pyc", ".pyo")):
                continue
            abs_path = os.path.join(dirpath, name)
            rel_dir = os.path.relpath(dirpath, src_abs).replace("\\", "/")
            dest = dest_rel if rel_dir == "." else "%s/%s" % (dest_rel, rel_dir)
            out.append((abs_path, dest))
    return out


datas = []
# 1) 地图资源（map.html 用相对路径拉 leaflet/ 与 twin_maps/）
datas += _tree("ui/map", "ui/map")

# 2) QtWebEngine 运行时资源兜底（locales 目录是自检硬项）
#    main.py 的 _configure_qt_webengine() 按 find_spec("PyQt5") 定位 Qt5 目录，
#    冻结态解析到 _internal/PyQt5/Qt5，因此这里的目标路径必须是 PyQt5/Qt5/...
_QT5 = os.path.join(ROOT, "venv_usv", "Lib", "site-packages", "PyQt5", "Qt5")
if os.path.isdir(_QT5):
    for _sub in (
        "translations/qtwebengine_locales",   # 自检项：qtwebengine_locales/
        "resources",                          # icudtl.dat / qtwebengine_resources*.pak
        "bin",                                # QtWebEngineProcess.exe 等
    ):
        _abs = os.path.join(_QT5, *_sub.split("/"))
        if os.path.isdir(_abs):
            datas.append((_abs, "PyQt5/Qt5/" + _sub))

binaries = []

# ---------------------------------------------------------------------------
# 分析与依赖配置
# ---------------------------------------------------------------------------
hiddenimports = [
    "PyQt5.QtWebEngineWidgets",
    "PyQt5.QtWebChannel",
    "PyQt5.sip",
]

excludes = [
    # 本项目不内置视觉算法，排除相关深度学习框架（避免触发 AGPL）
    "ultralytics", "torch", "torchvision", "tensorflow",
    # 未使用的冗余依赖
    "scipy", "numba",
    # 开发期工具，运行期不需要
    "IPython", "matplotlib.tests",
]

a = Analysis(
    [os.path.join(ROOT, "main.py")],
    pathex=[ROOT],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name=APP_NAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,          # 无控制台黑窗口
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name=APP_NAME,          # → dist\LandStation-Lite\
)