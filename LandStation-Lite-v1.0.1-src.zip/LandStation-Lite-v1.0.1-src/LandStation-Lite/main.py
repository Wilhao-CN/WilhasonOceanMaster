"""USV 双船协同控制地面站 —— 启动入口。

Qt 环境变量这里全部都是「自动定位」：
只要 PyQt5 / PyQtWebEngine 装在当前解释器里，就能自己找到 QtWebEngineProcess、
resources、translations 和 plugins。
"""

import datetime
import multiprocessing
import os
import sys

import app_paths

os.environ.setdefault('KMP_DUPLICATE_LIB_OK', 'True')

def _adapt_to_frozen_runtime() -> None:
    """冻结环境（PyInstaller onedir）启动自适应。

    - 工作目录切到 exe 所在目录：子模块用相对路径读写 config/、data_logs/
      等目录（如 joystick_mapping.json），不切换会落错位置。
    - 双击启动（无控制台）时把 stdout/stderr 重定向到
      data_logs/startup_log.txt，排查启动问题不用再猜黑窗口去哪了。
    """
    if not app_paths.is_frozen():
        return

    try:
        os.chdir(app_paths.app_dir())
        print(f"[启动] 已切换到 exe 所在目录: {app_paths.app_dir()}")
    except OSError as exc:
        print(f"[启动] ⚠ 切换工作目录失败: {exc}")
        return

    # pythonw/双击没有控制台时 sys.stdout/stderr 为 None，所有 print 都被丢弃。
    # 重定向到启动日志，保住启动阶段的排障线索（渲染进程终止、路径告警等）。
    if sys.stdout is not None and sys.stderr is not None:
        return
    try:
        log_path = os.path.join(app_paths.app_dir(), "data_logs", "startup_log.txt")
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        log_stream = open(log_path, "a", encoding="utf-8", errors="replace", buffering=1)
        log_stream.write("\n" + "=" * 60 + "\n")
        log_stream.write(f"[启动] {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        sys.stdout = log_stream
        sys.stderr = log_stream
    except OSError:
        # 日志写不出来也不能拦启动流程
        pass


_adapt_to_frozen_runtime()

# 💡 中文 Windows 控制台默认是 GBK(cp936)，而全项目有大量 emoji 日志
# （⚠️/✅/❌/🚀 ...）。这些字符在 GBK 下编码失败，会直接抛 UnicodeEncodeError
# 这里同时做两件事：
#   1) PYTHONIOENCODING 让本进程 + multiprocessing 子进程都用 UTF-8；
#   2) 直接把当前 stdout/stderr 重定向成 UTF-8，兼容被 IDE/终端重定向的情况。
os.environ.setdefault('PYTHONIOENCODING', 'utf-8')
for _stream_name in ('stdout', 'stderr'):
    _stream = getattr(sys, _stream_name, None)
    if _stream is not None and hasattr(_stream, 'reconfigure'):
        try:
            _stream.reconfigure(encoding='utf-8', errors='replace')
        except (ValueError, OSError):
            pass

# 解决中文路径识别与资源丢失问题
base_dir = os.path.dirname(os.path.abspath(__file__))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)


def _configure_qt_webengine() -> None:
    """
    自动定位 PyQt5 自带的 Qt5 目录并注入 QtWebEngine 需要的环境变量。
    """
    try:
        import importlib.util

        spec = importlib.util.find_spec("PyQt5")
    except Exception as exc:  # pragma: no cover - 只在 PyQt5 缺失时触发
        print(f"[启动] 无法定位 PyQt5：{exc}")
        return

    if spec is None or not spec.origin:
        print("[启动] 未找到 PyQt5，请先执行：pip install -r requirements.txt")
        return

    # PyQt5/__init__.py -> PyQt5/Qt5（多候选择优，兼容冻结态与各类 pip 布局）
    _candidates = [
        os.path.join(os.path.dirname(spec.origin), "Qt5"),
        os.path.join(os.path.dirname(os.path.dirname(spec.origin)), "Qt5"),
        os.path.join(app_paths.resource_dir(), "Qt5"),
        os.path.join(app_paths.resource_dir(), "PyQt5", "Qt5"),
    ]
    qt5_dir = next((d for d in _candidates if os.path.isdir(d)), None)
    if qt5_dir is None:
        print(f"[启动] 未找到 Qt5 资源目录（已尝试：{'；'.join(_candidates)}），地图控件可能不可用")
        return

    bin_dir = os.path.join(qt5_dir, "bin")
    resources_dir = os.path.join(qt5_dir, "resources")
    locales_dir = os.path.join(qt5_dir, "translations", "qtwebengine_locales")
    plugins_dir = os.path.join(qt5_dir, "plugins")

    # 1. 执行进程路径（解决 QtWebEngineProcess 启动失败）
    webengine_path = os.path.join(bin_dir, "QtWebEngineProcess.exe")
    os.environ["QTWEBENGINEPROCESS_PATH"] = webengine_path
    os.putenv("QTWEBENGINEPROCESS_PATH", webengine_path)  # 强制写入底层

    # 2. 窗口插件路径（解决 windows 平台插件报错）
    os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = plugins_dir

    # 3. 资源包路径（解决 "resources not found"）
    os.environ["QTWEBENGINE_RESOURCES_PATH"] = resources_dir

    # 4. 语言包路径（解决 "locales directory not found"）
    os.environ["QTWEBENGINE_LOCALES_PATH"] = locales_dir

    # 5. QtWebEngine 会把缓存写到 %LOCALAPPDATA%；路径含中文/无权限时改用工程内目录
    cache_dir = os.path.join(app_paths.app_dir(), "data_logs", ".qtwebengine_cache")
    if "QTWEBENGINE_DISK_CACHE_DIR" not in os.environ:
        try:
            os.makedirs(cache_dir, exist_ok=True)
            os.environ["QTWEBENGINE_DISK_CACHE_DIR"] = cache_dir
        except OSError:
            pass

    # 6. dll 搜索路径（解决 ICU data / ffmpeg 找不到）
    os.environ["PATH"] = bin_dir + os.pathsep + os.environ.get("PATH", "")

    # 7. 本机 GPU/沙箱组合下 QtWebEngine 渲染进程初始化失败
    #    （RESULT_CODE_KILLED_BAD_MESSAGE，页面零加载一片空白），地图+底图全空。
    #    禁用 GPU 渲染与沙箱后恢复正常。
    os.environ.setdefault(
        "QTWEBENGINE_CHROMIUM_FLAGS",
        "--disable-gpu-sandbox --disable-gpu --no-sandbox",
    )


# 必须在设置完所有环境变量后，再导入 PyQt5 相关模块
_configure_qt_webengine()

# ⚠️ 请始终在工程根目录下启动（start_groundstation.bat 已 `cd /d %~dp0`）：
# core/Managers/joystick_manager.py 用的是相对路径 "config/joystick_mapping.json"，
# 在别处启动会新建一个空的 config 目录，手柄映射就丢了。

from PyQt5.QtCore import Qt, QCoreApplication  # noqa: E402
from PyQt5.QtWidgets import QApplication  # noqa: E402
from ui.main_window import USVGroundStation  # noqa: E402

# ============================================================================
# 注意：QtWebEngine 必须在 QApplication 创建【之前】声明共享 OpenGL 上下文
# ============================================================================
# 症状：
#     地图区域完全空白，且**没有任何报错**。渲染进程探针给出
#         ❌❌ 渲染进程终止! status=-1 exitCode=18
#     `exitCode=18` 就是 Chromium 的 RESULT_CODE_KILLED_BAD_MESSAGE
#     （渲染进程收到非法 IPC 消息被杀）—— QtWebEngine 典型的初始化失败。
#
# 原因：
#     使用 QWebEngineView 时，Qt 要求进程级设置 AA_ShareOpenGLContexts，
#     否则 QtWebEngine 的 GPU/渲染子进程 channel 建立失败并崩溃。
#     忘记设置该属性时，症状即为地图区域空白且无任何报错。
#
# 注意：必须在 QApplication 实例化之前调用，之后再设无效。
# ============================================================================
try:
    QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
    print("[启动] 已设置 Qt.AA_ShareOpenGLContexts（QtWebEngine 必需）")
except Exception as _exc:  # noqa: BLE001 - 属性设置失败不应阻断启动
    print(f"[启动] ⚠ 设置 AA_ShareOpenGLContexts 失败: {_exc}")


def _warn_if_non_ascii_path() -> None:
    """路径含中文等非 ASCII 字符时告警。

    Qt 5.15 在 Windows 上无法处理含非 ASCII 字符的程序路径，
    会导致 QtWebEngine 加载失败（"Couldn't mmap icu data file"）或闪退。
    """
    app_dir = app_paths.app_dir()
    try:
        app_dir.encode("ascii")
        return
    except UnicodeEncodeError:
        pass

    msg = (
        f"程序所在路径含有非 ASCII 字符（例如中文）：\n\n{app_dir}\n\n"
        "Qt 5.15 在 Windows 上无法处理这种路径，会导致：\n"
        "  · 地图（QtWebEngine）加载失败或整个程序闪退\n"
        '  · 报错形如 "Couldn\'t mmap icu data file"\n\n'
        "解决办法：把程序放到**纯英文/数字**的路径下再运行，\n"
        "例如  D:\\LandStation-Lite\\\n"
    )
    print("[启动] ⚠⚠ 路径含非 ASCII 字符，Qt/QtWebEngine 很可能工作不正常：")
    print(f"[启动]     {app_dir}")

    if os.environ.get("QT_QPA_PLATFORM", "").lower() == "offscreen":
        # 无界面环境（如 verify_xxx 脚本）不弹窗
        print("[启动]     （offscreen 模式：只打印，不弹窗）")
        return

    try:
        from PyQt5.QtWidgets import QMessageBox

        QMessageBox.warning(None, "路径含非 ASCII 字符 —— 可能无法正常运行", msg)
    except Exception as _exc:  # noqa: BLE001 - 弹窗失败不应阻断启动
        print(f"[启动] ⚠ 显示路径警告弹窗失败: {_exc}")


def main():
    # 实例化 QApplication
    app = QApplication(sys.argv)

    # 设置全局样式表
    app.setStyleSheet("""
        QGroupBox { font-weight: bold; border: 1px solid #ccc; border-radius: 5px; margin-top: 1ex; }
        QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 3px; }
        QPushButton { padding: 5px; }
    """)

    # 路径含非 ASCII 字符 → 提前告警（地图空白/闪退的高危因素）
    _warn_if_non_ascii_path()

    # 🔴 强制门禁：用户必须在免责声明弹窗点「我已阅读并同意」才能进主界面。
    # 「不同意并退出」（含 ✕ / Esc）直接退出，不创建主窗口、不下发任何指令。
    from ui.dialogs.disclaimer_dialog import run_disclaimer_gate
    if not run_disclaimer_gate():
        print('[启动] 用户不同意免责声明，程序已退出')
        sys.exit(0)

    # 实例化并显示主窗口
    window = USVGroundStation()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    # 注意：PyInstaller 冻结程序在 Windows 上用 multiprocessing spawn
    # 子进程 = 用 exe 自身加 --multiprocessing-fork 参数重启自己。PyInstaller
    # 的运行时钩子 pyi_rth_multiprocessing 替换了 freeze_support 的实现（检测
    # 到 fork 参数就转 spawn_main 并退出），但**必须在 main() 之前有人调用它**；
    # 漏调则每个 VisionProcess 子进程都从头执行整个程序（又建 QApplication +
    # 又起 VisionProcess），表现为窗口级联无限叠加。
    multiprocessing.freeze_support()
    main()
