# TRADEMARK.md —— 品牌与商标声明

> 本文件说明 **WilhasonOceanMaster / LandStation-Lite** 的品牌标识与使用边界。
> 代码许可条款见 [`LICENSE`](LICENSE)（GPL v3）；品牌标识不在 GPL v3 授权范围内。

---

## 1. 品牌标识

| 项 | 内容 |
|---|---|
| 平台名称 | **WilhasonOceanMaster** |
| 子产品名称 | **LandStation-Lite**（USV 双船协同控制地面站） |
| 平台标语 | 海洋水面系统数字孪生平台 · A Physics-Based Digital Twin for Marine Surface Systems |
| 出品与维护 | 华南理工大学 NOF 创新创业团队、海洋科学与工程学院<br>NOF Innovation & Entrepreneurship Team, School of Marine Science and Engineering, South China University of Technology |
| Logo / 视觉识别 | 以团队官方发布的视觉识别系统为准（本声明同样适用于其后续版本） |

---

## 2. 商标与许可边界

本项目以 **GPL v3** 发布。GPL v3 授予您对**代码**的自由使用、修改与再分发权利，但**不包含任何商标许可**。

「WilhasonOceanMaster」「LandStation-Lite」名称、团队名称、标语及相关 Logo 均属于华南理工大学 NOF 创新创业团队的品牌资产，受商标法保护。GPL v3 不授权将上述标识用于任何形式的商业背书或品牌混淆。

---

## 3. 修改版的再分发要求

依据 GPL v3 关于附加条款的规定，如果您基于本工程创建并对外分发**修改版**，必须遵守以下要求：

1. **重命名**：必须使用与官方不同的产品名称；或者
2. **明确标注**：在文档和程序「关于」界面的显著位置，明确标注「**非官方修改版 / Unofficial Modified Version**」，并注明与官方版本无任何关联。

同时，您**不得以任何方式暗示**修改版本获得了华南理工大学 NOF 创新创业团队或海洋科学与工程学院的官方背书。满足上述要求后，您依然可以按 GPL v3 自由分发您的修改版。

---

## 4. 联系与授权咨询

如需在非开源场景下使用本团队品牌标识，或进行商业合作与深度交流，请发送邮件至：**2571217194@qq.com**。